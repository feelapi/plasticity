import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import { SweepParams } from './SweepFactory';
import * as c3d from '../../kernel/kernel';

export class SweepDialog extends AbstractDialog<SweepParams> {
    readonly name = "Sweep";

    constructor(protected readonly params: SweepParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { thickness, alignment, twist } = this.params;

        render(
            <>
                <ol>
                    <plasticity-prompt name="Select region, face, or curve" description="to sweep"></plasticity-prompt>
                    <plasticity-prompt name="Select spine" description="to sweep along"></plasticity-prompt>
                </ol>

                <ul>
                    <li>
                        <label for="thickness">Thickness</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="thickness" value={thickness} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="twist">Twist</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="twist" value={twist} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="alignment">Alignment</label>
                        <div class="fields">
                            <input type="radio" hidden name="alignment" id="parallel" value={c3d.SweepAlignmentType.Parallel} checked={alignment === c3d.SweepAlignmentType.Parallel} onClick={this.onChange}></input>
                            <label for="parallel">Parallel</label>

                            <input type="radio" hidden name="alignment" id="normal" value={c3d.SweepAlignmentType.Normal} checked={alignment === c3d.SweepAlignmentType.Normal} onClick={this.onChange}></input>
                            <label for="normal">Normal</label>
                        </div>
                    </li>
                </ul></>, this);
    }
}
customElements.define('plasticity-evolution-dialog', SweepDialog);
