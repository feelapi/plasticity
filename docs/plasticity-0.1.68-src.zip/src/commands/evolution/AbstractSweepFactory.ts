import * as THREE from "three";
import { GeometryFactory, ValidationError } from '../../command/GeometryFactory';
import { PlaneSnap } from "../../editor/snaps/PlaneSnap";
import * as c3d from '../../kernel/kernel';
import { vec2vec } from "../../util/Conversion";
import { assertUnreachable, computeBoxCentroid, computeCentroid } from "../../util/Util";
import * as visual from '../../visual_model/VisualModel';

type Profile =
    { tag: 'regions', regions: c3d.Region[], profile?: c3d.Body }
    | { tag: 'curves', curves: c3d.Wire[] }
    | { tag: 'faces', faces: c3d.Face[] }
    | { tag: 'edges', edges: c3d.Edge[] };

export abstract class AbstractSweepFactory extends GeometryFactory<c3d.Shell, visual.Shell, []> {
    constructionPlane?: PlaneSnap;
    readonly direction = new THREE.Vector3();

    protected profile!: Profile;
    protected _center!: THREE.Vector3;

    set region(region: visual.Region) {
        this.regions = [region];
    }

    private _regions!: { views: visual.Region[]; models: c3d.Region[]; };
    get regions() { return this._regions.views; }
    set regions(regions: visual.Region[]) {
        if (regions.length === 0) return;

        const sketchView = regions[0].parentItem;
        const sketchModel = this.db.lookup(sketchView);
        const basis = sketchModel.GetBasis();
        const z = basis.Axis;
        this.direction.copy(vec2vec(z, 1));

        const models = regions.map(r => this.db.lookupTopologyItem(r));
        this._regions = { views: regions, models };
        this.profile = { tag: 'regions', regions: models };

        const box = new THREE.Box3();
        const centroid = computeBoxCentroid(regions.map(r => r.getBoundingBox(box)));
        this._center = centroid;
    }

    protected _curves!: { views: visual.SpaceInstance[]; models: c3d.Wire[]; };
    get curves() { return this._curves.views }
    set curves(curves: visual.SpaceInstance[]) {
        if (curves.length === 0) return;

        const models = curves.map(c => this.db.lookup(c));
        this._curves = { views: curves, models };
        this.profile = { tag: 'curves', curves: models };

        this._center = computeCentroid(curves);

        const first = this._curves.models[0];
        const basis = first.FindPlanarBasis();
        const axis = first.FindLinearAxis();
        if (basis !== undefined) {
            const z = basis.Axis;
            this.direction.copy(vec2vec(z, 1));
        } else {
            const geos = first.GetConstructionGeometry();
            const geo = geos[0] as c3d.Geometry | undefined;
            if (geo instanceof c3d.Plane) {
                const info = geo.GetInfo();
                this.direction.copy(vec2vec(info.Axis, 1));
            } else if (this.constructionPlane !== undefined) {
                if (axis === undefined) {
                    this.direction.copy(this.constructionPlane.n);
                } else {
                    const z = vec2vec(axis.Direction, 1);
                    if (Math.abs(1-Math.abs(z.dot(this.constructionPlane.n))) < 1e-6) {
                        this.direction.copy(this.constructionPlane.x);
                    } else {
                        this.direction.copy(this.constructionPlane.n);
                    }
                }
            }
        }
    }

    protected _edges!: { views: visual.CurveEdge[]; models: c3d.Edge[]; };
    get edges() { return this._edges.views }
    set edges(edges: visual.CurveEdge[]) {
        if (edges.length === 0) return;

        const models = edges.map(c => this.db.lookupTopologyItem(c));
        this._edges = { views: edges, models };
        this.profile = { tag: 'edges', edges: models };

        const box = new THREE.Box3();
        const centroid = computeBoxCentroid(edges.map(e => e.getBoundingBox(box)));
        this._center = centroid;

        const first = this._edges.models[0];
        const { normal: normal_ } = first.EvalBasis(0.5);
        const normal = vec2vec(normal_, 1);
        if (normal.manhattanLength() > 0) {
            this.direction.copy(normal);
        } else {
            if (this.constructionPlane !== undefined) {
                this.direction.copy(this.constructionPlane.n);
            }
        }
    }

    protected _faces!: { views: visual.Face[], models: c3d.Face[] };
    get faces() { return this._faces.views }
    set faces(faces: visual.Face[]) {
        if (faces.length === 0)
            return;

        const models = faces.map(f => this.db.lookupTopologyItem(f));
        this._faces = { views: faces, models: models };
        this.profile = { tag: 'faces', faces: models };

        const box = new THREE.Box3();
        const centroid = computeBoxCentroid(faces.map(f => f.getBoundingBox(box)));
        this._center = centroid;

        const model = this._faces.models[0];
        const { normal } = model.EvalBasis(0.5, 0.5);
        this.direction.copy(vec2vec(normal, 1));
    }

    get center(): THREE.Vector3 { return this._center; }

    private readonly profilePartition = new c3d.Partition();
    protected profiles: c3d.Wire[] | c3d.Sheet[] = [];
    async prepare() { this.profiles = await this.makeProfile(this.profilePartition); }

    async makeProfile(partition: c3d.Partition): Promise<c3d.Wire[] | c3d.Sheet[]> {
        const tag = this.profile.tag;
        switch (tag) {
            case 'regions':
                return faces2boundaryProfiles(partition, this.profile.regions);
            case 'curves':
                return this.profile.curves.map(c => c.CopyTo(partition));
            case 'faces':
                return faces2boundaryProfiles(partition, this.profile.faces);
            case 'edges':
                return edges2profiles(partition, this.profile.edges);
            default: assertUnreachable(tag);
        }
    }
}

export async function faces2boundaryProfiles(partition: c3d.Partition, regions: c3d.Face[]): Promise<c3d.Sheet[]> {
    if (regions.length === 0) throw new ValidationError();
    const options = new c3d.SheetBodyMakeFromFacesOptions();
    options.DeleteRedundant = true;
    const { sheets } = await partition.SheetBody.MakeFromFaces_async(regions, options);
    if (sheets.length === 0) throw new ValidationError();
    return sheets;
}

export async function faces2individualProfiles(partition: c3d.Partition, regions: c3d.Face[]): Promise<c3d.Sheet[]> {
    if (regions.length === 0) throw new ValidationError();
    const options = new c3d.SheetBodyMakeFromFacesOptions();
    const results = [];
    for (const region of regions) {
        const { sheets } = await partition.SheetBody.MakeFromFaces_async([region], options);
        if (sheets.length !== 1) throw new ValidationError();
        results.push(sheets[0]);
    }
    return results;
}

export async function edges2profiles(partition: c3d.Partition, edges: c3d.Edge[]): Promise<c3d.Wire[]> {
    if (edges.length === 0) throw new ValidationError();
    const options = new c3d.WireBodyCreateFromEdgesOptions();
    const { wires } = await partition.WireBody.CreateFromEdges_async(edges, options);
    if (wires.length === 0) throw new ValidationError();
    return wires;
}

