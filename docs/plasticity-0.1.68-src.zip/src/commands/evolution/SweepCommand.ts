import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { SelectionMode } from "../../selection/SelectionModeSet";
import { Y } from "../../util/Constants";
import { SweepDialog } from "./SweepDialog";
import { SweepFactory } from "./SweepFactory";
import { SweepGizmo } from "./SweepGizmo";

export class SweepCommand extends Command {
    async execute(): Promise<void> {
        const { editor, editor: { selection: { selected } } } = this;

        const sweep = new SweepFactory(editor.db, editor.materials, editor.signals).resource(this);

        const gizmo = new SweepGizmo(sweep, this.editor);
        const dialog = new SweepDialog(sweep, editor.signals);
        const objectPicker = new ObjectPicker(this.editor);
        objectPicker.copy(this.editor.selection);

        dialog.execute(async (params) => {
            await sweep.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const getRegionOrFace = dialog.prompt("Select region, face, or curve", () => {
            const objectPicker = new ObjectPicker(this.editor);
            objectPicker.mode.set(SelectionMode.Face, SelectionMode.Region, SelectionMode.Curve);
            objectPicker.copy(this.editor.selection, SelectionMode.Face, SelectionMode.Region, SelectionMode.Curve);
            const min = 1 - objectPicker.selection.selected.regions.size - objectPicker.selection.selected.faces.size - objectPicker.selection.selected.curves.size;
            return objectPicker.execute(() => { }, min, 1).resource(this)
        });
        const selection = await getRegionOrFace();
        if (selection.faces.size > 0) sweep.faces = [...selection.faces];
        if (selection.regions.size > 0) sweep.regions = [...selection.regions];
        if (selection.curves.size > 0) sweep.curves = [...selection.curves];
        await sweep.prepare();

        const getSpine = dialog.prompt("Select spine", () => {
            const objectPicker = new ObjectPicker(this.editor);
            objectPicker.mode.set(SelectionMode.Curve);
            return objectPicker.execute(() => { }, 1, 1).resource(this);
        });
        const spine = await getSpine();
        sweep.spine = spine.curves.first;

        gizmo.position.copy(sweep.center);
        gizmo.quaternion.setFromUnitVectors(Y, sweep.tangent);

        gizmo.execute(async params => {
            await sweep.update();
            dialog.render();
        }).resource(this);

        sweep.update();

        await this.finished;

        const evolved = await sweep.commit();

        selected.removeAll();
        editor.selection.selected.add(evolved);
    }
}