import * as THREE from "three";
import * as c3d from '../../kernel/kernel';
import { point2point, vec2vec } from '../../util/Conversion';
import * as visual from '../../visual_model/VisualModel';
import { AbstractSweepFactory } from "./AbstractSweepFactory";

export interface SweepParams {
    alignment: c3d.SweepAlignmentType;
    thickness: number;
    twist: number;
}

export class SweepFactory extends AbstractSweepFactory implements SweepParams {
    alignment = c3d.SweepAlignmentType.Normal;
    tangent = new THREE.Vector3();

    private _thickness = 0;
    get thickness() { return this._thickness }
    set thickness(thickness: number) {
        this._thickness = Math.max(0, thickness);
    }

    twist = 0;

    protected _spine!: { view: visual.SpaceInstance; model: c3d.Wire; };
    get spine(): visual.SpaceInstance { return this._spine.view; }
    set spine(spine: visual.SpaceInstance) {
        const model = this.db.lookup(spine)!;
        this._spine = { view: spine, model };

        const first = model.FindFirstEdge();
        const { position, tangent } = first.GetPointAndTangent(0);
        this._center = point2point(position);
        this.tangent = vec2vec(tangent, 1);
    }

    async calculate() {
        const { _spine: { model: spine }, thickness, alignment, twist, profiles } = this;

        const options = new c3d.SweepOptions();
        options.Twist = twist;
        options.Alignment = alignment;
        options.Thickness = thickness;
        const copied = profiles.map(p => p.CopyTo(this.partition));
        const result = [];
        for (const profile of copied) {
            const swept = await profile.Sweep_async(spine, options);
            result.push(swept);
        }
        return result;
    }
}
