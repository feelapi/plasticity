import * as THREE from "three";
import { Line2 } from "three/examples/jsm/lines/Line2";
import { EditorLike, Mode } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { AbstractAxialScaleGizmo, boxGeometry, lineGeometry, MagnitudeStateMachine } from "../../command/MiniGizmos";
import { CancellablePromise } from "../../util/CancellablePromise";
import { Y, Z } from "../../util/Constants";
import { SweepParams } from "./SweepFactory";

export class SweepGizmo extends CompositeGizmo<SweepParams> {
    private readonly thicknessGizmo = new MagnitudeGizmo("sweep:thickness", this.editor);
    private readonly twistGizmo = new MagnitudeGizmo("sweep:twist", this.editor);

    protected prepare(mode: Mode) {
        const { twistGizmo, thicknessGizmo } = this;
        twistGizmo.relativeScale.setScalar(0.8);
        thicknessGizmo.relativeScale.setScalar(0.8);

        thicknessGizmo.quaternion.setFromUnitVectors(Z, Y);

        this.add(twistGizmo, thicknessGizmo);
    }

    execute(cb: (params: SweepParams) => void, finishFast: Mode = Mode.Persistent): CancellablePromise<void> {
        const { twistGizmo, thicknessGizmo, params } = this;

        this.addGizmo(twistGizmo, twist => {
            params.twist = twist;
        });

        this.addGizmo(thicknessGizmo, thickness => {
            params.thickness = thickness;
        });

        return super.execute(cb, finishFast);
    }

    render(params: SweepParams) {
        this.twistGizmo.value = params.twist;
        this.thicknessGizmo.value = params.thickness;
    }

    get shouldRescaleOnZoom() { return false }
}

class MagnitudeGizmo extends AbstractAxialScaleGizmo {
    readonly state = new MagnitudeStateMachine(0);
    readonly tip: THREE.Mesh<any, any> = new THREE.Mesh(boxGeometry, this.material.mesh);
    protected readonly shaft = new Line2(lineGeometry, this.material.line2);
    protected readonly knob = new THREE.Mesh(new THREE.SphereGeometry(0.2), this.editor.gizmos.invisible);
    override handleLength = 0.3;

    constructor(name: string, editor: EditorLike) {
        super(name, editor, editor.gizmos.default);
        this.setup();
    }

    onInterrupt(cb: (radius: number) => void) {
        this.state.push();
    }

    get shouldRescaleOnZoom() { return true }
}
