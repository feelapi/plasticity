import * as THREE from "three";
import * as c3d from '../../kernel/kernel';
import { point2point, unit, vec2vec } from '../../util/Conversion';
import { SweepFactory, SweepParams } from "./SweepFactory";

export interface RevolutionParams extends SweepParams {
    origin: THREE.Vector3;
    axis: THREE.Vector3;

    side1: number;
    side2: number;
    degrees1: number;
    degrees2: number;
}

export class RevolutionFactory extends SweepFactory implements RevolutionParams {
    readonly origin = new THREE.Vector3();
    readonly axis = new THREE.Vector3();

    side1 = 2 * Math.PI;
    side2 = 0;

    get degrees1() { return THREE.MathUtils.radToDeg(this.side1) }
    set degrees1(degrees1: number) {
        this.side1 = THREE.MathUtils.degToRad(degrees1);
    }

    get degrees2() { return THREE.MathUtils.radToDeg(this.side2) }
    set degrees2(degrees2: number) {
        this.side1 = THREE.MathUtils.degToRad(degrees2);
    }

    async calculate(partition = this.partition) {
        const { origin, axis, side1, side2, profiles } = this;

        const copied = profiles.map(p => p.CopyTo(this.partition));
        const options = new c3d.SpinOptions()
        const results = [];
        for (const profile of copied) {
            const spun = await profile.Spin_async(point2point(origin), vec2vec(axis, 1), side1, options);
            results.push(spun);
        }
        return results;
    }
}