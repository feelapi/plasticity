import * as THREE from "three";
import { derive } from "../../command/FactoryBuilder";
import { NoOpError, ValidationError } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { mat2mat, point2point, unit, vec2vec } from '../../util/Conversion';
import { findOrthogonal } from "../../util/Util";
import * as visual from '../../visual_model/VisualModel';
import { PossiblyBoolean } from "../boolean/PossiblyBooleanFactory";
import { AbstractSweepFactory } from "./AbstractSweepFactory";

export interface PipeParams {
    sectionSize: number;
    vertexCount: number;
    angle: number;
    degrees: number;
    thickness: number;
}

export class PipeFactory extends AbstractSweepFactory implements PipeParams {
    sectionSize = 0.05;
    private _thickness = 0;
    get thickness() { return this._thickness }
    set thickness(thickness: number) {
        this._thickness = Math.max(0, thickness);
    }

    angle = 0;
    get degrees() { return THREE.MathUtils.radToDeg(this.angle) }
    set degrees(degrees: number) {
        this.angle = THREE.MathUtils.degToRad(degrees);
    }

    private _vertexCount = 0;
    get vertexCount() { return this._vertexCount }
    set vertexCount(count: number) {
        count = Math.floor(Math.max(0, count));
        switch (count) {
            case 2: count = 3; break;
        }
        this._vertexCount = count;
    }

    protected _spine!: { view?: visual.SpaceInstance, model?: c3d.Wire };
    @derive(visual.SpaceInstance) get spine(): visual.SpaceInstance { throw '' }
    set spine(curve: visual.SpaceInstance | c3d.Wire) { }

    protected _edges!: { views: visual.CurveEdge[]; models: c3d.Edge[]; };
    @derive([visual.CurveEdge]) get edges(): visual.CurveEdge[] { throw ''; }
    set edges(edges: visual.CurveEdge[] | c3d.Edge[]) { }

    get placement() { return getPlacement(this._edges.models[0] ?? this._spine.model?.FindFirstEdge()); }

    get origin() { return point2point(this.placement.Location) }
    get axis() { return vec2vec(this.placement.Axis) }

    protected spines!: c3d.Wire[];
    // private lockFaces!: c3d.Face[];
    async prepare() {
        const { _spine: { model: curve }, _edges: { models: edges } } = this;
        let spines;
        if (curve !== undefined) {
            spines = [curve];
        } else {
            if (edges.length === 0) throw new NoOpError();
            const options = new c3d.WireBodyCreateFromEdgesOptions();
            // options.Track = true;
            const { wires } = await c3d.Wire.CreateFromEdges_async(edges, options);
            if (wires.length === 0) throw new ValidationError("Invalid edge selection");
            spines = wires;
            // const { faces } = record.GetOriginalBoundary(wires[0]);
            // this.lockFaces = faces.GetFaces();
        }
        this.spines = spines;
    }

    private readonly quat = new THREE.Quaternion();
    private readonly move = new THREE.Matrix4();
    private readonly rotate = new THREE.Matrix4();
    private readonly toOrigin = new THREE.Matrix4();

    async calculate(partition: c3d.Partition) {
        const { profile, spines, sectionSize, thickness, vertexCount, angle, direction, center } = this;
        const { quat, move, rotate, toOrigin } = this;

        const result = [];
        for (const spine of spines) {
            // NOTE: for some reason, it's important to  recompute the placement after building the spine // TODO: investigate
            const spinePlacement = getPlacement(spine.FindFirstEdge());

            quat.setFromAxisAngle(vec2vec(spinePlacement.Axis, 1), angle);
            const ref = vec2vec(spinePlacement.Ref, 1);
            ref.applyQuaternion(quat).normalize();
            const rotated = new c3d.Basis(spinePlacement.Location, spinePlacement.Axis, vec2vec(ref, 1));

            let polygons;
            if (profile === undefined) {
                polygons = [
                    (vertexCount < 3)
                        ? partition.SheetBody.CreateCircle(unit(sectionSize), rotated)
                        : partition.SheetBody.CreatePolygon(unit(sectionSize), vertexCount, rotated)];
            } else {
                const profiles = await this.makeProfile(partition);
                const profileCenter = center;
                toOrigin.makeTranslation(-profileCenter.x, -profileCenter.y, -profileCenter.z);
                quat.setFromUnitVectors(direction, vec2vec(spinePlacement.Axis, 1));
                rotate.makeRotationFromQuaternion(quat);
                const spineLocation = point2point(spinePlacement.Location, 1);
                move.makeTranslation(spineLocation.x, spineLocation.y, spineLocation.z);
                move.multiply(rotate);
                move.multiply(toOrigin);
                const transform = c3d.Transform.CreateFromMatrix(mat2mat(move));
                for (const profile of profiles) {
                    await profile.Transform_async(transform, new c3d.TransformOptions());
                }

                polygons = profiles;
            }

            const sweptData = new c3d.SweepOptions();
            sweptData.Thickness = thickness;
            // TODO: LockFaces seems to be even more strict and fails too often :(
            // sweptData.LockFaces = this.lockFaces;
            for (const polygon of polygons) {
                result.push(await polygon.Sweep_async(spine, sweptData));
            }
        }
        return result;
    }
}

export class PossiblyBooleanPipeFactory extends PossiblyBoolean(PipeFactory) implements PipeParams {
}

function getPlacement(first: c3d.Edge) {
    const position = first.GetPoint(0);
    let { tangent, normal } = first.EvalBasis(0);
    const n = vec2vec(normal, 1);
    if (n.manhattanLength() === 0) {
        const t = vec2vec(tangent, 1)
        findOrthogonal(t, n);
        normal = vec2vec(n, 1);
    }
    return new c3d.Basis(position, tangent, normal);
}