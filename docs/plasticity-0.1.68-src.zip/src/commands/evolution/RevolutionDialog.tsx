import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import { RevolutionParams } from "./RevolutionFactory";

export class RevolutionDialog extends AbstractDialog<RevolutionParams> {
    name = "Revolve";

    constructor(protected readonly params: RevolutionParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { thickness, degrees1, degrees2 } = this.params;

        render(
            <>
                <ul>
                    <li>
                        <label for="thickness">Thickness </label>
                        <div class="fields">
                            <plasticity-number-scrubber name="thickness" value={thickness} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="degrees">Degrees side 1</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="degrees1" value={degrees1} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="degrees2">Degrees side 2</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="degrees2" value={degrees2} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                </ul></>, this);
    }
}
customElements.define('plasticity-revolution-dialog', RevolutionDialog);
