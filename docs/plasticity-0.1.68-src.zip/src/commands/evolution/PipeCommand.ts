import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import * as c3d from '../../kernel/kernel';
import { SelectionMode } from '../../selection/SelectionModeSet';
import { Y } from '../../util/Constants';
import { PossiblyBooleanKeyboardGizmo } from "../boolean/BooleanKeyboardGizmo";
import { PipeDialog } from "./PipeDialog";
import { PossiblyBooleanPipeFactory } from "./PipeFactory";
import { PipeGizmo } from "./PipeGizmo";
import { PipeKeyboardGizmo } from "./PipeKeyboardGizmo";

export class PipeCommand extends Command {
    async execute(): Promise<void> {
        const { editor, editor: { selection: { selected } } } = this;
        const pipe = new PossiblyBooleanPipeFactory(editor.db, editor.materials, editor.signals).resource(this);
        if (selected.curves.size > 0) {
            pipe.spine = selected.curves.first;
            pipe.targets = [...selected.solids];
        } else if (selected.edges.size > 0) {
            pipe.edges = [...selected.edges];
            pipe.targets = [selected.edges.first.parentItem];
        }
        await pipe.prepare();

        const dialog = new PipeDialog(pipe, editor.signals);
        const boolean = new PossiblyBooleanKeyboardGizmo("pipe", this.editor);
        const keyboard = new PipeKeyboardGizmo(this.editor);
        const gizmo = new PipeGizmo(pipe, this.editor);

        boolean.prepare(pipe).resource(this);

        dialog.execute(async (params) => {
            await pipe.update();
            gizmo.render(params);
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const startSelect = dialog.prompt("Select target bodies", () => {
            const objectPicker = new ObjectPicker(this.editor);
            objectPicker.selection.selected.add(pipe.targets);
            if (pipe.operationType === undefined) pipe.operationType = c3d.OperationType.Difference;
            return objectPicker.execute(async delta => {
                const targets = [...objectPicker.selection.selected.solids];
                pipe.targets = targets;
                await pipe.update();
            }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Solid).resource(this)
        }, async () => {
            pipe.targets = [];
            await pipe.update();
        });
        boolean.startSelect = startSelect;

        GetCustomProfile: {
            const selectProfiles = dialog.prompt("Select custom profile", () => {
                const objectPicker = new ObjectPicker(this.editor);
                objectPicker.mode.set(SelectionMode.Face, SelectionMode.Region, SelectionMode.Curve);
                objectPicker.copy(this.editor.selection, SelectionMode.Face, SelectionMode.Region, SelectionMode.Curve);
                return objectPicker.execute(async _ => {
                    const selected = objectPicker.selection.selected;
                    if (selected.faces.size > 0) pipe.faces = [...selected.faces];
                    if (selected.regions.size > 0) pipe.regions = [...selected.regions];
                    if (selected.curves.size > 0) pipe.curves = [...selected.curves];
                    await pipe.update();
                }, 1, 1).resource(this)
            });

            keyboard.execute(s => {
                switch (s) {
                    case 'custom-profile':
                        selectProfiles();
                }
            }).resource(this);
        }

        gizmo.position.copy(pipe.origin);
        gizmo.quaternion.setFromUnitVectors(Y, pipe.axis);
        gizmo.execute(params => {
            pipe.update();
            dialog.render();
        }).resource(this);

        await pipe.update();

        await this.finished;

        const evolved = await pipe.commit();
        selected.remove(pipe.spine ?? pipe.edges ?? []);
        selected.add(evolved);
    }
}
