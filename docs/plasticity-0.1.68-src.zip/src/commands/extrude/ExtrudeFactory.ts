import * as THREE from "three";
import { delegate } from "../../command/FactoryBuilder";
import { NoOpError } from '../../command/GeometryFactory';
import { MultiGeometryFactory } from "../../command/MultiFactory";
import * as c3d from '../../kernel/kernel';
import { unit, vec2vec } from "../../util/Conversion";
import { VectorProxy } from "../../util/VectorProxy";
import * as visual from '../../visual_model/VisualModel';
import { PossiblyBoolean } from "../boolean/PossiblyBooleanFactory";
import { AbstractSweepFactory } from "../evolution/AbstractSweepFactory";

export interface ExtrudeParams {
    get gizmoDirection(): THREE.Vector3;
    get direction(): THREE.Vector3;
    distance1: number;
    distance2: number;
    angle1: number;
    angle2: number;
    thickness1: number;
    thickness2: number;
    thickness: number;
    lockDistances: boolean;
}

abstract class AbstractExtrudeFactory extends AbstractSweepFactory implements ExtrudeParams {
    get gizmoDirection() { return this.direction }

    lockDistances = false;
    distance1 = 0;
    distance2 = 0;
    angle1 = 0;
    angle2 = 0;

    thickness1 = 0;
    thickness2 = 0;
    set thickness(thickness: number) {
        this.thickness1 = this.thickness2 = Math.max(0, thickness);
    }

    async calculate(partition: c3d.Partition = this.partition) {
        const { direction, distance1, thickness1, thickness2, distance2, lockDistances, profiles } = this;
        let { angle1, angle2, } = this;

        if (distance1 === 0 && distance2 === 0) throw new NoOpError();

        const copied = profiles.map(p => p.CopyTo(partition));
        const params = new c3d.ExtrudeOptions(unit(distance1), unit(lockDistances ? -distance1 : distance2));

        params.Angle1 = angle1;
        params.Angle2 = angle2;
        params.Thickness1 = unit(thickness1);
        params.Thickness2 = unit(thickness2);
        const result = [];
        for (const profile of copied) {
            result.push(await profile.Extrude_async(vec2vec(direction, 1), params));
        }
        return result;
    }

    override calculatePhantoms(partition: c3d.Partition) {
        return super.calculatePhantoms(partition);
    }

    get originalItems() { return [] }
}

export class RegionExtrudeFactory extends AbstractExtrudeFactory {
}

export class CurveExtrudeFactory extends AbstractExtrudeFactory {
}

export class EdgeExtrudeFactory extends AbstractExtrudeFactory {
}

export class FaceExtrudeFactory extends AbstractExtrudeFactory {
}

export class MultiExtrudeFactory extends MultiGeometryFactory<AbstractExtrudeFactory, c3d.Shell, visual.Shell, []> implements ExtrudeParams {
    private _lockDistances = false;
    get lockDistances() { return this._lockDistances }
    set lockDistances(lock: boolean) { this._lockDistances = lock; this.updateFactories() }

    private _distance1 = 0;
    get distance1() { return this._distance1 }
    set distance1(d: number) { this._distance1 = d; this.updateFactories() }

    private _distance2 = 0;
    get distance2() { return this._distance2 }
    set distance2(d: number) { this._distance2 = d; this.updateFactories() }

    private _angle1 = 0;
    get angle1() { return this._angle1 }
    set angle1(a: number) { this._angle1 = a; this.updateFactories() }

    private _angle2 = 0;
    get angle2() { return this._angle2 }
    set angle2(a: number) { this._angle2 = a; this.updateFactories() }

    private _thickness1 = 0;
    get thickness1() { return this._thickness1 }
    set thickness1(t: number) { this._thickness1 = t; this.updateFactories() }

    private _thickness2 = 0;
    get thickness2() { return this._thickness2 }
    set thickness2(t: number) { this._thickness2 = t; this.updateFactories() }

    set thickness(thickness: number) {
        this.thickness1 = this.thickness2 = Math.max(0, thickness);
    }

    @delegate.get center!: THREE.Vector3;

    get gizmoDirection() { return this.factories[0].direction }
    readonly direction = new VectorProxy(direction => {
        this.factories.forEach(f => f.direction.copy(direction));
    });

    protected override updateFactories() {
        for (const f of this.factories) {
            f.lockDistances = this.lockDistances;
            f.distance1 = this.distance1;
            f.distance2 = this.distance2;
            f.angle1 = this.angle1;
            f.angle2 = this.angle2;
            f.thickness1 = this.thickness1;
            f.thickness2 = this.thickness2;
            if (this.direction.manhattanLength() > 0) f.direction.copy(this.direction);
        };
    }
}

export interface PossiblyBooleanExtrudeParams extends ExtrudeParams {
    keepTools: boolean;
}

export class PossiblyBooleanMultiExtrudeFactory extends PossiblyBoolean(MultiExtrudeFactory) implements ExtrudeParams { }