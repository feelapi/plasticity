import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import { PossiblyBooleanParams } from '../boolean/PossiblyBooleanFactory';
import { ExtrudeParams } from './ExtrudeFactory';

export class ExtrudeDialog extends AbstractDialog<ExtrudeParams & PossiblyBooleanParams> {
    name = "Extrude";

    constructor(protected readonly params: ExtrudeParams & PossiblyBooleanParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { distance1, distance2, angle1, angle2, thickness1, thickness2, keepTools } = this.params;

        render(
            <>
                <ol>
                    <plasticity-prompt name="Select region, face, or curve" description="to extrude"></plasticity-prompt>
                    <plasticity-prompt name="Select target bodies" description="to cut or join into"></plasticity-prompt>
                </ol>

                <ul>
                    <li>
                        <label for="distance">Distance</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="distance1" value={distance1} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber name="distance2" value={distance2} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label>Angle</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="angle1" value={angle1} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber name="angle2" value={angle2} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label>Thickness</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="thickness1" value={thickness1} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber name="thickness2" value={thickness2} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="keepTools">Keep tools</label>
                        <div class="fields">
                            <input type="checkbox" hidden id="keepTools" name="keepTools" checked={keepTools} onClick={this.onChange}></input>
                            <label for="keepTools">Keep Tools</label>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('extrude-dialog', ExtrudeDialog);
