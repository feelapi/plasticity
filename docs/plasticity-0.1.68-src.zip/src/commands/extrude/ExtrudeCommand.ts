// TODO:
// - Multiboolean not fully working; if faces belong to multiple bodies, it will error
import * as THREE from "three";
import Command, { EditorLike } from "../../command/Command";
import { groupBy } from "../../command/MultiFactory";
import { ObjectPicker } from "../../command/ObjectPicker";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { Quasimode } from "../../command/Quasimode";
import * as c3d from "../../kernel/kernel";
import { HasSelection } from "../../selection/SelectionDatabase";
import { SelectionMode } from "../../selection/SelectionModeSet";
import { CancellablePromise } from "../../util/CancellablePromise";
import { freeze, Y, Z } from "../../util/Constants";
import * as visual from "../../visual_model/VisualModel";
import { PossiblyBooleanKeyboardGizmo } from "../boolean/BooleanKeyboardGizmo";
import { PhantomLineFactory } from "../line/LineFactory";
import { ExtrudeDialog } from "./ExtrudeDialog";
import { CurveExtrudeFactory, EdgeExtrudeFactory, FaceExtrudeFactory, PossiblyBooleanMultiExtrudeFactory, RegionExtrudeFactory } from "./ExtrudeFactory";
import { ExtrudeGizmo } from "./ExtrudeGizmo";
import { ExtrudeDirectionKeyboardGizmo, ExtrudeToggleKeyboardGizmo } from "./ExtrudeKeyboardGizmo";


export class ExtrudeCommand extends Command {
    point?: THREE.Vector3;

    async execute(): Promise<void> {
        const { editor, editor: { db, materials, signals, selection: { selected } }, point } = this;

        const extrude = new PossiblyBooleanMultiExtrudeFactory(db, materials, signals).resource(this);
        const dialog = new ExtrudeDialog(extrude, signals);
        const gizmo = new ExtrudeGizmo(extrude, editor);
        const booleanKeyboard = new PossiblyBooleanKeyboardGizmo("extrude", editor);
        const directionKeyboard = new ExtrudeDirectionKeyboardGizmo(editor);
        const toggleKeyboard = new ExtrudeToggleKeyboardGizmo(editor);
        const quasimode = new Quasimode("modify-selection", editor, extrude);
        const objectPicker = new ObjectPicker(editor);
        objectPicker.mode.set(SelectionMode.Face, SelectionMode.Region, SelectionMode.Curve);
        objectPicker.copy(this.editor.selection, SelectionMode.Face, SelectionMode.Region, SelectionMode.Curve);

        let q: CancellablePromise<void> | undefined;
        let g: CancellablePromise<void> | undefined;
        let b: CancellablePromise<void> | undefined;
        let d: CancellablePromise<void> | undefined;
        let t: CancellablePromise<void> | undefined;

        const stopQuasimode = () => { q?.finish(); q = undefined; }
        const stopGizmo = () => { gizmo.disable() }
        const stopBooleanKeyboard = () => { b?.finish(); b = undefined; }
        const stopDirectionKeyboard = () => { d?.finish(); d = undefined; }
        const stopToggleKeyboard = () => { t?.finish(); t = undefined; }

        const startDialog = () => {
            dialog.execute(params => {
                gizmo.render(params);
                startToggleKeyboard();
                startQuasimode();
                extrude.update();
            }).resource(this).then(() => this.finish(), () => this.cancel());
        }

        const startGizmo = () => {
            if (g !== undefined) { gizmo.enable(); return; }
            gizmo.position.copy(point ?? extrude.center);
            gizmo.pivot.copy(gizmo.position);
            gizmo.quaternion.setFromUnitVectors(Y, extrude.gizmoDirection);
            g = gizmo.execute(async params => {
                dialog.render();
                startToggleKeyboard();
                startQuasimode();
                await extrude.update();
            }).resource(this);
        }

        const startBooleanKeyboard = () => {
            if (b !== undefined) return;
            b = booleanKeyboard.prepare(extrude).resource(this);
        }

        const startDirectionKeyboard = () => {
            if (d !== undefined) return;
            d = directionKeyboard.execute(onKeyPress).resource(this);
        }

        const startToggleKeyboard = () => {
            if (t !== undefined) return;
            t = toggleKeyboard.execute(s => {
                switch (s) {
                    case 'lock-distances':
                        extrude.lockDistances = !extrude.lockDistances;
                        extrude.update();
                        break;
                }
            }).resource(this);
        }

        const onKeyPress = async (s: string) => {
            switch (s) {
                case 'pivot': {
                    gizmo.disable();
                    const pointPicker = new PointPicker(this.editor);
                    await pointPicker.execute(({ point: pivot, info: { snap } }) => {
                        const { orientation } = snap.project(pivot);
                        extrude.direction.copy(Z.clone().applyQuaternion(orientation));
                        gizmo.position.copy(pivot);
                        gizmo.quaternion.copy(orientation).multiply(Y2Z);
                    }).resource(this);
                    gizmo.enable();
                    break;
                }
                case 'free':
                    const line = new PhantomLineFactory(editor.db, editor.materials, editor.signals).resource(this);
                    const pointPicker = new PointPicker(editor);
                    gizmo.disable();
                    const { point: p1 } = await pointPicker.execute().resource(this);
                    line.p1 = p1;
                    await pointPicker.execute(async ({ point: p2 }) => {
                        line.p2 = p2;
                        const delta = p2.clone().sub(p1);
                        extrude.distance1 = delta.length();
                        extrude.direction.copy(delta.normalize());
                        await line.update();
                        await extrude.update();
                        dialog.render();
                        gizmo.quaternion.setFromUnitVectors(Y, extrude.direction);
                        gizmo.render(extrude);
                    }).resource(this);
                    line.cancel();
                    gizmo.enable();
                    break;
            }
        }

        const getProfiles = async () => {
            const getRegionFaceOrCurve = dialog.prompt("Select region, face, or curve", () => {
                const min = 1 - objectPicker.selection.selected.regions.size - objectPicker.selection.selected.faces.size - objectPicker.selection.selected.curves.size;
                return objectPicker.execute(() => { }, min, 1).resource(this)
            });
            const selection = await getRegionFaceOrCurve();
            await ExtrudeFactory(this.editor, extrude, selection);
        }

        const startQuasimode = () => {
            if (q !== undefined) return;
            if (Math.abs(extrude.distance1) === 0 && Math.abs(extrude.distance2) === 0) return;

            const quasiPicker = new ObjectPicker(editor, objectPicker.selection, 'viewport-selector[quasimode]');
            objectPicker.mode.set(SelectionMode.Face, SelectionMode.Region, SelectionMode.Curve);
            q = quasimode.execute(() => {
                stopGizmo();
                stopBooleanKeyboard();
                stopDirectionKeyboard();
                stopToggleKeyboard();

                return quasiPicker.execute(async delta => {
                    await ExtrudeFactory(editor, extrude, objectPicker.selection.selected);
                }, 1, Number.MAX_SAFE_INTEGER).after(async () => {
                    if (!this.isAwaiting) return;
                    startGizmo();
                    startBooleanKeyboard();
                    startDirectionKeyboard();
                    startToggleKeyboard();
                }).resource(this);
            }).resource(this);
        }

        const startSelect = () => {
            const startSelect = dialog.prompt("Select target bodies", () => {
                stopQuasimode();

                const objectPicker = new ObjectPicker(this.editor);
                objectPicker.selection.selected.add(extrude.targets);
                return objectPicker.execute(async delta => {
                    const targets = [...objectPicker.selection.selected.solids];
                    extrude.targets = targets;
                    if (extrude.operationType === undefined) extrude.operationType = c3d.OperationType.Difference;
                    await extrude.update();
                }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Solid).after(() => {
                    if (!this.isAwaiting) return;
                    startQuasimode();
                }).resource(this);
            }, async () => {
                extrude.targets = [];
                await extrude.update();
            });
            booleanKeyboard.startSelect = startSelect;
        }

        startDialog();
        await getProfiles();
        startBooleanKeyboard();
        startDirectionKeyboard();
        startGizmo();
        startSelect();

        await this.finished;

        selected.removeAll();
        const results = await extrude.commit();
        selected.add(results);
    }
}

async function ExtrudeFactory(editor: EditorLike, into: PossiblyBooleanMultiExtrudeFactory, selected: HasSelection) {
    const { db, materials, signals } = editor;

    const factories = [];
    if (selected.regions.size > 0) {
        const sketches = groupBy('parentItem', [...selected.regions]);
        for (const [_, regions] of sketches) {
            const phantom = new RegionExtrudeFactory(db, materials, signals);
            phantom.constructionPlane = editor.activeViewport?.constructionPlane;
            phantom.regions = regions;
            factories.push(phantom);
        }
    }
    const faceParents = new Set<visual.Shell>();
    if (selected.faces.size > 0) {
        const phantom = new FaceExtrudeFactory(db, materials, signals);
        phantom.constructionPlane = editor.activeViewport?.constructionPlane;
        const faces = [...selected.faces];
        phantom.faces = faces;
        faceParents.add(faces[0].parentItem);
        factories.push(phantom);
    }
    for (const curve of selected.curves) {
        const phantom = new CurveExtrudeFactory(db, materials, signals);
        phantom.constructionPlane = editor.activeViewport?.constructionPlane;
        phantom.curves = [curve];
        factories.push(phantom);
    }
    for (const edge of selected.edges) {
        const phantom = new EdgeExtrudeFactory(db, materials, signals);
        phantom.constructionPlane = editor.activeViewport?.constructionPlane;
        phantom.edges = [edge];
        factories.push(phantom);
    }
    for (const factory of factories) await factory.prepare();
    into.factories = factories;
    into.targets = [...faceParents];
    return into;
}

const Y2Z = freeze(new THREE.Quaternion().setFromUnitVectors(Y, Z));
