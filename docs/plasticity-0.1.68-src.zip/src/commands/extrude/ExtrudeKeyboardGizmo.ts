import { CommandKeyboardInput, EditorLike } from "../../command/CommandKeyboardInput";

export class ExtrudeDirectionKeyboardGizmo extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('extrude', editor, [
            'direction:extrude:free',
            'direction:extrude:pivot',
        ]);
    }
}

export class ExtrudeToggleKeyboardGizmo extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('extrude', editor, [
            'gizmo:extrude:lock-distances',
        ]);
    }
}