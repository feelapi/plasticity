import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';
import { vec2vec } from '../../util/Conversion';
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import { derive } from '../../command/FactoryBuilder';

export class ExtrudeSurfaceFactory extends GeometryFactory {
    direction!: THREE.Vector3;
    distance1 = 0;
    distance2 = 0;

    protected _curve!: { view: visual.SpaceInstance, model: c3d.Wire };
    @derive(visual.SpaceInstance) get curve(): visual.SpaceInstance { throw '' }
    set curve(curve: visual.SpaceInstance | c3d.Wire) { }

    async calculate(partition: c3d.Partition) {
        const { _curve: { model: curve }, direction, } = this;
        let { distance1, distance2 } = this;
        if (distance1 === 0 && distance2 === 0) throw new NoOpError();

        const sign1 = Math.sign(distance1), sign2 = Math.sign(distance2);
        if (sign1 === sign2) {
            distance2 = sign2 * Math.max(Math.abs(distance1), Math.abs(distance2));
            distance1 = 0;
        }
        return curve.Extrude_async(vec2vec(direction, 1), new c3d.ExtrudeOptions(distance1, distance2));
    }
}