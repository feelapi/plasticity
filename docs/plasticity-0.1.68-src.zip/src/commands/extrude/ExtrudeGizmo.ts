import * as THREE from "three";
import { Line2 } from "three/examples/jsm/lines/Line2";
import { EditorLike, Mode } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { AbstractAxialScaleGizmo, AngleGizmo, boxGeometry, DistanceGizmo, lineGeometry, MagnitudeStateMachine } from "../../command/MiniGizmos";
import { CancellablePromise } from "../../util/CancellablePromise";
import { Y, Z, _Y } from "../../util/Constants";
import { PlanarMoveGizmo } from "../translate/MoveGizmo";
import { ExtrudeParams } from "./ExtrudeFactory";

export class ExtrudeGizmo extends CompositeGizmo<ExtrudeParams> {
    private readonly distance1Gizmo = new ExtrudeDistanceGizmo("extrude:distance1", this.editor);
    private readonly angleGizmo = new ExtrudeAngleGizmo("extrude:angle1", this.editor, this.editor.gizmos.white);
    private readonly thicknessGizmo = new MagnitudeGizmo("extrude:thickness", this.editor);
    private readonly xy = new ShearGizmo("extrude:xy", this.editor, this.editor.gizmos.cyan);

    protected prepare(mode: Mode) {
        const { angleGizmo: angle1Gizmo, distance1Gizmo, thicknessGizmo, xy } = this;
        angle1Gizmo.relativeScale.setScalar(0.3);
        distance1Gizmo.relativeScale.setScalar(0.8);
        thicknessGizmo.relativeScale.setScalar(0.8);

        thicknessGizmo.quaternion.setFromUnitVectors(Z, Y);

        xy.quaternion.setFromUnitVectors(Z, _Y);

        this.add(distance1Gizmo, thicknessGizmo, xy);

        distance1Gizmo.tip.add(angle1Gizmo);
    }

    readonly pivot = new THREE.Vector3();
    execute(cb: (params: ExtrudeParams) => void, finishFast: Mode = Mode.Persistent): CancellablePromise<void> {
        const { angleGizmo, distance1Gizmo, thicknessGizmo, xy, params } = this;

        this.addGizmo(distance1Gizmo, length => {
            params.distance1 = length;
            this.setXYValue(length);
            this.setXYPosition(length);
            this.updateState();
        });

        this.addGizmo(angleGizmo, angle => {
            params.angle1 = angle;
        }, false);

        this.addGizmo(thicknessGizmo, thickness => {
            params.thickness1 = params.thickness2 = thickness;
        }, false);

        this.addGizmo(xy, () => {
            this.setXYPosition(params.distance1);

            extrudeDirection.copy(xy.position).applyQuaternion(xy.quaternion);
            extrudeDirection.normalize();
            if (params.distance1 < 0) extrudeDirection.negate();
            params.direction.copy(extrudeDirection);
        }, false);

        return super.execute(cb, finishFast);
    }

    render(params: ExtrudeParams) {
        this.distance1Gizmo.value = params.distance1;
        this.angleGizmo.value = params.angle1;
        this.thicknessGizmo.value = params.thickness;
    }

    get shouldRescaleOnZoom() { return false }

    private setXYPosition(distance: number) {
        const { xy } = this;
        inv.copy(xy.quaternion).invert();
        xy.position.copy(xy.value).applyQuaternion(inv);
        xy.position.y = distance;
    }

    private setXYValue(distance: number) {
        const { xy, params } = this;
        if (params.direction.manhattanLength() === 0) {
            xy.position.y = distance;
            return;
        }
        extrudeDirection.copy(xy.position).applyQuaternion(xy.quaternion);
        extrudeDirection.normalize();
        gizmoDirection.copy(Y).applyQuaternion(this.quaternion);
        const dot = extrudeDirection.dot(gizmoDirection);
        extrudeDirection.multiplyScalar(distance / dot);
        xy.value = new THREE.Vector3(extrudeDirection.x, extrudeDirection.y, 0);
    }

    get hasDistance(): boolean {
        return Math.abs(this.params.distance1) + Math.abs(this.params.distance2) > 0
    }

    enable() {
        super.enable();
        this.updateState();
    }

    private updateState() {
        this.thicknessGizmo.stateMachine!.isEnabled = this.hasDistance;
        this.angleGizmo.stateMachine!.isEnabled = this.hasDistance;
        this.xy.stateMachine!.isEnabled = this.hasDistance;
    }
}

export class ExtrudeDistanceGizmo extends DistanceGizmo {
    protected minShaft = 1;

    onInterrupt(cb: (radius: number) => void) {
        this.state.push();
    }
}

class ExtrudeAngleGizmo extends AngleGizmo {
    onInterrupt(cb: (radius: number) => void) {
        this.state.push();
    }

    get shouldRescaleOnZoom() { return false }
}

export class MagnitudeGizmo extends AbstractAxialScaleGizmo {
    readonly state = new MagnitudeStateMachine(0);
    readonly tip: THREE.Mesh<any, any> = new THREE.Mesh(boxGeometry, this.material.mesh);
    protected readonly shaft = new Line2(lineGeometry, this.material.line2);
    protected readonly knob = new THREE.Mesh(new THREE.SphereGeometry(0.2), this.editor.gizmos.invisible);
    override handleLength = 0.3;

    constructor(name: string, editor: EditorLike) {
        super(name, editor, editor.gizmos.default);
        this.setup();
    }

    onInterrupt(cb: (radius: number) => void) {
        this.state.push();
    }

    get shouldRescaleOnZoom() { return true }
    onEnabled() { this.visible = true }
    onDisabled() { this.visible = false }
}

class ShearGizmo extends PlanarMoveGizmo {
    get value() { return this.state.current }
    set value(value: THREE.Vector3) { this.state.current.copy(value) }

    protected get offset() { return new THREE.Vector3(0, 0, 0) }
    get shouldRescaleOnZoom() { return true }

    onEnabled() { this.visible = true }
    onDisabled() { this.visible = false }
}

const extrudeDirection = new THREE.Vector3();
const gizmoDirection = new THREE.Vector3();
const inv = new THREE.Quaternion();
