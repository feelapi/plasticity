import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';

export class SubdivideCurveFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance, []> {
    protected _curves!: { views: visual.SpaceInstance[]; models: c3d.Wire[]; };
    @derive([visual.SpaceInstance]) get curves(): visual.SpaceInstance[] { throw ''; }
    set curves(curves: visual.SpaceInstance[] | c3d.Wire[]) { }

    async calculate() {
        const { _curves: { models: curves } } = this;

        for (const curve of curves) curve.Subdivide();
        return curves;
    }

    get originalItems() { return this.curves }
}