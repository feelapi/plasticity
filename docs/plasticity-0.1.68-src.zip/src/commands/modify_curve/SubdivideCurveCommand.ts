import Command from "../../command/Command";
import { SubdivideCurveFactory } from "./SubdivideCurveFactory";

export class SubdivideCurveCommand extends Command {
    async execute(): Promise<void> {
        const { editor: { selection: { selected }, db, materials, signals } } = this;
        const subdivide = new SubdivideCurveFactory(db, materials, signals);
        subdivide.curves = [...selected.curves];

        const results = await subdivide.commit();
        selected.removeAll();
        selected.add(results);
    }
}

