import * as THREE from "three";
import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import { groupBy } from "../../command/MultiFactory";
import * as c3d from '../../kernel/kernel';
import { identityMatrix, origin } from "../../util/Constants";
import { mat2mat, point2point } from "../../util/Conversion";
import { GConstructor } from "../../util/Util";
import * as visual from '../../visual_model/VisualModel';
import { TransformFactory } from "../translate/TransformFactory";
import { BasicScale, FreestyleScale, FreestyleScaleFactoryLike, MoveFactory, MoveFactoryLike, RotateFactory, RotateFactoryLike, ScaleParams } from "../translate/TransformMixins";

class WireFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> { }

abstract class TransformVertexFactory extends TransformFactory(WireFactory) {
    protected _curve!: { view: visual.SpaceInstance, model: c3d.Wire };
    @derive(visual.SpaceInstance) get curve(): visual.SpaceInstance { throw '' }
    set curve(curve: visual.SpaceInstance | c3d.Wire) { }

    protected _vertices!: { views: visual.Vertex[]; models: c3d.Vertex[]; };
    @derive([visual.Vertex]) get vertices(): visual.Vertex[] { throw ''; }
    set vertices(vertices: visual.Vertex[] | c3d.Vertex[]) { }

    // NOTE: the centroid is often used as a pivot for a transformation, so it is important
    // to use the highest precision available -- i.e., do not compute the centroid in viewspace.
    get centroid() {
        const { _vertices: { models: vertices } } = this;
        const ids = vertices.map(v => v.Id());
        return point2point(new c3d.VertexCollection(ids).GetCentroid());
    }

    async calculate() {
        const { _curve: { model: curve }, _vertices: { models: vertices }, matrix } = this;

        if (vertices.length === 0) throw new NoOpError();
        if (matrix.equals(identityMatrix)) throw new NoOpError();

        const mat = mat2mat(this.matrix);
        const transform = c3d.Transform.CreateFromMatrix(mat);

        const cvs = new c3d.CVCollection();
        const vertexCollection = new c3d.VertexCollection(vertices.map(v => v.Id()));
        const tracking = await curve.TransformControlPoints_async(vertexCollection, cvs, transform);
        this._tracking = tracking;
        return curve;
    }

    protected _tracking!: c3d.TransformControlPointsTrackRecord;
    get selection() {
        const { state } = this.state;
        if (state.tag !== 'committed') throw new Error("invalid state");
        const wire = state.result;
        const ids = this._tracking.GetChangedVertices().GetIds();
        const names = [...ids].map(id => visual.Vertex.simpleName(wire.simpleName, id));
        return names.map(name => this.db.lookupTopologyItemById(name).view);
    }

    get originalItem() { return this.curve }
    async showPhantoms(): Promise<void> { }
    get items(): visual.Item[] { return [] }
}

export class MoveVertexFactory extends MoveFactory(TransformVertexFactory) implements MoveFactoryLike {
}

export class ScaleVertexFactory extends BasicScale(TransformVertexFactory) implements ScaleParams {
}

export class FreestyleScaleVertexFactory extends FreestyleScale(TransformVertexFactory) implements FreestyleScaleFactoryLike {
}

export class RotateVertexFactory extends RotateFactory(TransformVertexFactory) implements RotateFactoryLike {

}

abstract class TransformCVFactory extends TransformFactory(WireFactory) {
    protected _curve!: { view: visual.SpaceInstance, model: c3d.Wire, cvs: c3d.CVCollection };
    get curve(): visual.SpaceInstance { return this._curve.view }
    set curve(curve: visual.SpaceInstance) {
        const model = this.db.lookup(curve)!;
        const view = curve;
        const cvs = model.FindOrderedEdges().GetCVs();
        this._curve = { view, model, cvs };
    }

    protected _cvs!: { views: visual.CV[]; models: c3d.CV[]; };
    @derive([visual.CV]) get cvs(): visual.CV[] { throw ''; }
    set cvs(cvs: visual.CV[] | c3d.CV[]) { }

    get centroid() {
        const { _curve: { cvs: collection }, _cvs: { models: cvs } } = this;
        return point2point(collection.GetCentroid(cvs));
    }

    async calculate() {
        const { _curve: { model: curve, cvs: collection }, _cvs: { models: cvs }, matrix } = this;

        if (cvs.length === 0) throw new NoOpError();
        if (matrix.equals(identityMatrix)) throw new NoOpError();

        const mat = mat2mat(this.matrix);
        const transform = c3d.Transform.CreateFromMatrix(mat);

        this._tracking = await curve.TransformControlPoints_async(new c3d.VertexCollection(), collection.Slice(cvs), transform);
        return curve;
    }

    protected _tracking!: c3d.TransformControlPointsTrackRecord;
    get selection() {
        const { state } = this.state;
        if (state.tag !== 'committed') throw new Error("invalid state");
        const wire = state.result;
        const ids = this._tracking.GetChangedVertices().GetIds();
        const names = [...ids].map(id => visual.Vertex.simpleName(wire.simpleName, id));
        return names.map(name => this.db.lookupTopologyItemById(name).view);
    }

    get originalItem() { return this.curve }
    async showPhantoms(): Promise<void> { }
    get items(): visual.Item[] { return [] }
}

export class MoveCVFactory extends MoveFactory(TransformCVFactory) implements MoveFactoryLike {
}

export class ScaleCVFactory extends BasicScale(TransformCVFactory) implements ScaleParams {
}

export class FreestyleScaleCVFactory extends FreestyleScale(TransformCVFactory) implements FreestyleScaleFactoryLike {
}

export class RotateCVFactory extends RotateFactory(TransformCVFactory) implements RotateFactoryLike {
}

class TransformControlPointFactory extends TransformFactory(WireFactory) {
    protected _curve!: { view: visual.SpaceInstance, model: c3d.Wire, cvs: c3d.CVCollection };
    get curve(): visual.SpaceInstance { return this._curve.view }
    set curve(curve: visual.SpaceInstance) {
        const model = this.db.lookup(curve)!;
        const view = curve;
        const cvs = model.FindOrderedEdges().GetCVs();
        this._curve = { view, model, cvs };
    }

    protected _cvs!: { views: visual.CV[]; models: c3d.CV[]; };
    @derive([visual.CV]) get cvs(): visual.CV[] { throw ''; }
    set cvs(cvs: visual.CV[] | c3d.CV[]) { }

    protected _vertices!: { views: visual.Vertex[]; models: c3d.Vertex[]; };
    @derive([visual.Vertex]) get vertices(): visual.Vertex[] { throw ''; }
    set vertices(vertices: visual.Vertex[] | c3d.Vertex[]) { }

    private readonly _centroid = new THREE.Vector3();
    get centroid() {
        const { _curve: { cvs: collection }, _cvs: { models: cvs }, _vertices: { models: vertices } } = this;
        let vertexCentroid = origin;
        if (vertices.length > 0) {
            const ids = vertices.map(v => v.Id());
            vertexCentroid = point2point(new c3d.VertexCollection(ids).GetCentroid());
            vertexCentroid.multiplyScalar(vertices.length);
        }
        let cvCentroid = origin;
        if (cvs.length > 0) {
            cvCentroid = point2point(collection.GetCentroid(cvs));
            cvCentroid.multiplyScalar(cvs.length);
        }
        this._centroid
            .addVectors(cvCentroid, vertexCentroid)
            .multiplyScalar(1 / (cvs.length + vertices.length));
        return this._centroid;
    }

    async calculate() {
        const { _curve: { model: curve, cvs: collection }, _cvs: { models: cvs }, _vertices: { models: vertices }, matrix } = this;

        if (cvs.length === 0 && vertices.length === 0) throw new NoOpError();
        if (matrix.equals(identityMatrix)) throw new NoOpError();

        const mat = mat2mat(this.matrix);
        const transform = c3d.Transform.CreateFromMatrix(mat);

        const vertexCollection = new c3d.VertexCollection(vertices.map(v => v.Id()));
        const tracking = await curve.TransformControlPoints_async(vertexCollection, collection.Slice(cvs), transform);
        this.tracking = tracking;

        return curve;
    }

    tracking!: c3d.TransformControlPointsTrackRecord;
    get selection() {
        const { state } = this.state;
        if (state.tag !== 'committed') throw new Error("invalid state");
        const wire = state.result;
        const ids = this.tracking.GetChangedVertices().GetIds();
        const names = [...ids].map(id => visual.Vertex.simpleName(wire.simpleName, id));
        return names.map(name => this.db.lookupTopologyItemById(name).view);
    }

    get hulls(): { before: THREE.Vector3 | undefined, after: THREE.Vector3 | undefined }[] {
        const { _curve: { cvs: collection }, _cvs: { models: cvs } } = this;
        const hulls = cvs.map(cv => collection.EvalBasis(cv));
        return hulls.map(hull => {
            const { before, after } = hull;
            return {
                before: before !== undefined ? point2point(before) : undefined,
                after: after !== undefined ? point2point(after) : undefined
            };
        });
    }

    get originalItem() { return this.curve }
    async showPhantoms(): Promise<void> { }
    get items(): visual.Item[] { return [] }
}

function MultiControlPoint<T extends GConstructor<TransformControlPointFactory>>(klass: T) {
    class Anon extends TransformFactory(GeometryFactory<c3d.Wire, visual.SpaceInstance, []>) {
        private factories: TransformControlPointFactory[] = [];

        protected _cvs: { views: visual.CV[] } = { views: [] };
        get cvs(): visual.CV[] { return this._cvs.views }
        set cvs(cvs: visual.CV[]) {
            this._cvs = { views: cvs };
            this.dirty();
        }

        protected _vertices: { views: visual.Vertex[] } = { views: [] };
        get vertices(): visual.Vertex[] { return this._vertices.views }
        set vertices(vertices: visual.Vertex[]) {
            this._vertices = { views: vertices };
            this.dirty();
        }

        private dirty() {
            const { _cvs: { views: cvs }, _vertices: { views: vertices } } = this;
            const cvmap = groupBy('parentItem', cvs);
            const vertexmap = groupBy('parentItem', vertices);
            const curves = new Set([...cvmap.keys(), ...vertexmap.keys()]);
            const factories = [...curves].map(item => {
                const factory = new klass(this.db, this.materials, this.signals);
                factory.curve = item;
                factory.cvs = cvmap.get(item) ?? [];
                factory.vertices = vertexmap.get(item) ?? [];
                return factory;
            });
            this.factories = factories;
        }

        get centroid() {
            const { factories } = this;
            const centroid = new THREE.Vector3();
            factories.forEach(factory => centroid.add(factory.centroid));
            centroid.multiplyScalar(1 / factories.length);
            return centroid;
        }

        get selection() {
            const { factories } = this;
            const { state } = this.state;
            if (state.tag !== 'committed') throw new Error("invalid state");
            const wires = state.result;
            if (wires.length !== factories.length) throw new Error("invalid state");
            const result = [];
            for (let i = 0; i < factories.length; i++) {
                const wire = wires[i];
                const factory = factories[i];
                const ids = factory.tracking.GetChangedVertices().GetIds();
                const names = [...ids].map(id => visual.Vertex.simpleName(wire.simpleName, id));
                result.push(names.map(name => this.db.lookupTopologyItemById(name).view));
            }
            return result.flat();
        }

        async calculate() {
            const { factories, matrix } = this;
            const results = [];
            for (const factory of factories) {
                factory.last.copy(matrix);
                results.push(await factory.calculate());
            }
            return results;
        }

        async showPhantoms() { }

        get originalItems() {
            const { _cvs: { views: cvs }, _vertices: { views: vertices } } = this;
            return Array.from(new Set([...cvs.map(cv => cv.parentItem), ...vertices.map(v => v.parentItem)]));
        }
    }
    return Anon;
}

export class MoveControlPointFactory extends MoveFactory(TransformControlPointFactory) implements MoveFactoryLike { }
export class ScaleControlPointFactory extends BasicScale(TransformControlPointFactory) implements ScaleParams { }
export class FreestyleScaleControlPointFactory extends FreestyleScale(TransformControlPointFactory) implements FreestyleScaleFactoryLike { }
export class RotateControlPointFactory extends RotateFactory(TransformControlPointFactory) implements RotateFactoryLike { }

export class MultiMoveControlPointFactory extends MoveFactory(MultiControlPoint(TransformControlPointFactory)) implements MoveFactoryLike { }
export class MultiScaleControlPointFactory extends BasicScale(MultiControlPoint(TransformControlPointFactory)) implements ScaleParams { }
export class MultiFreestyleScaleControlPointFactory extends FreestyleScale(MultiControlPoint(TransformControlPointFactory)) implements FreestyleScaleFactoryLike { }
export class MultiRotateControlPointFactory extends RotateFactory(MultiControlPoint(TransformControlPointFactory)) implements RotateFactoryLike { }
