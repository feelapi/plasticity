import { DisableOptions } from "../../editor/db/Database";
import { GConstructor } from "../../util/Util";
import { AbstractFreestyleMoveCommand, AbstractFreestyleRotateCommand, AbstractFreestyleScaleCommand } from "../translate/AbstractFreestyleTranformCommand";
import { AbstractMoveCommand, AbstractRotateCommand, AbstractScaleCommand } from "../translate/AbstractTransformCommand";
import { MoveFactoryLike, RotateFactoryLike } from "../translate/TransformMixins";
import { MoveControlPointCommand, RotateControlPointCommand, ScaleControlPointCommand } from "./TransformControlPointCommand";
import { MultiFreestyleScaleControlPointFactory, MultiMoveControlPointFactory, MultiRotateControlPointFactory } from "./TransformControlPointFactory";

export class FreestyleMoveControlPointCommand extends AbstractFreestyleMoveCommand {
    protected async makeFactory(): Promise<MoveFactoryLike> {
        const { editor, editor: { selection: { selected }, db } } = this;
        const vertices = [...selected.vertices];
        const cvs = [...selected.cvs];
        const curve = (vertices[0] || cvs[0]).parentItem;
        const move = new MultiMoveControlPointFactory(editor.db, editor.materials, editor.signals).resource(this);
        move.vertices = vertices;
        move.cvs = cvs;
        const centroid = move.centroid;
        move.pivot.copy(centroid);
        db.disable([curve], DisableOptions.KeepPointSnaps);

        return move;
    }

    protected getNextCommand(): GConstructor<AbstractMoveCommand> {
        return MoveControlPointCommand;
    }
}

export class FreestyleRotateControlPointCommand extends AbstractFreestyleRotateCommand {
    protected async makeFactory(): Promise<RotateFactoryLike> {
        const { editor, editor: { selection: { selected }, db } } = this;
        const vertices = [...selected.vertices];
        const cvs = [...selected.cvs];
        const curve = (vertices[0] || cvs[0]).parentItem;
        const rotate = new MultiRotateControlPointFactory(editor.db, editor.materials, editor.signals).resource(this);
        rotate.vertices = vertices;
        rotate.cvs = cvs;
        rotate.curve = curve;
        db.disable([curve], DisableOptions.KeepPointSnaps);
        return rotate;
    }

    protected getNextCommand(): GConstructor<AbstractRotateCommand> {
        return RotateControlPointCommand;
    }
}

export class FreestyleScaleControlPointCommand extends AbstractFreestyleScaleCommand {
    protected async makeFactory() {
        const { editor, editor: { selection: { selected }, db } } = this;
        const vertices = [...selected.vertices];
        const cvs = [...selected.cvs];
        const curve = (vertices[0] || cvs[0]).parentItem;
        const scale = new MultiFreestyleScaleControlPointFactory(editor.db, editor.materials, editor.signals).resource(this);
        scale.vertices = vertices;
        scale.cvs = cvs;
        db.disable([curve], DisableOptions.KeepPointSnaps);
        return scale;
    }

    protected getNextCommand(): GConstructor<AbstractScaleCommand> {
        return ScaleControlPointCommand;
    }
}
