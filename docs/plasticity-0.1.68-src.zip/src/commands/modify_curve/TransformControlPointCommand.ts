import { AbstractMoveCommand, AbstractRotateCommand, AbstractScaleCommand } from "../translate/AbstractTransformCommand";
import { FreestyleMoveControlPointCommand, FreestyleRotateControlPointCommand, FreestyleScaleControlPointCommand } from "./FreestyleTransformControlPointCommand";
import { MultiMoveControlPointFactory, MultiRotateControlPointFactory, MultiScaleControlPointFactory } from "./TransformControlPointFactory";

export class MoveControlPointCommand extends AbstractMoveCommand {
    protected makeFactory() {
        const { editor: { db, materials, signals, selection: { selected } } } = this;
        const vertices = [...selected.vertices];
        const cvs = [...selected.cvs];
        const move = new MultiMoveControlPointFactory(db, materials, signals).resource(this);
        move.vertices = vertices;
        move.cvs = cvs;
        return move;
    }

    protected getFreestyleCommand() {
        return FreestyleMoveControlPointCommand;
    }
}


export class RotateControlPointCommand extends AbstractRotateCommand {
    protected makeFactory() {
        const { editor: { db, materials, signals, selection: { selected } } } = this;
        const vertices = [...selected.vertices];
        const cvs = [...selected.cvs];
        const rotate = new MultiRotateControlPointFactory(db, materials, signals).resource(this);
        rotate.vertices = vertices;
        rotate.cvs = cvs;
        const centroid = rotate.centroid;
        rotate.pivot.copy(centroid);
        return rotate;
    }

    protected getFreestyleCommand() {
        return FreestyleRotateControlPointCommand;
    }
}

export class ScaleControlPointCommand extends AbstractScaleCommand {
    protected makeFactory() {
        const { editor: { db, materials, signals, selection: { selected } } } = this;
        const vertices = [...selected.vertices];
        const cvs = [...selected.cvs];
        const scale = new MultiScaleControlPointFactory(db, materials, signals).resource(this);
        scale.vertices = vertices;
        scale.cvs = cvs;
        const centroid = scale.centroid;
        scale.pivot.copy(centroid);
        return scale;
    }

    protected getFreestyleCommand() {
        return FreestyleScaleControlPointCommand;
    }
}
