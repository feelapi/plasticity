import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';

export class ConvertVertexFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> {
    protected _curve!: { view: visual.SpaceInstance, model: c3d.Wire };
    @derive(visual.SpaceInstance) get curve(): visual.SpaceInstance { throw '' }
    set curve(curve: visual.SpaceInstance | c3d.Wire) { }

    protected _vertices!: { views: visual.Vertex[]; models: c3d.Vertex[]; };
    @derive([visual.Vertex]) get vertices(): visual.Vertex[] { throw ''; }
    set vertices(vertices: visual.Vertex[] | c3d.Vertex[]) { }

    async calculate() {
        const { _curve: { model: curve }, _vertices: { models: vertices } } = this;

        if (vertices.length === 0) throw new NoOpError();

        curve.ConvertVertices(vertices);
        return curve;
    }

    get originalItem() { return this.curve }
}