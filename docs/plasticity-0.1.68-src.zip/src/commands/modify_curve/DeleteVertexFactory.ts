import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';

export class DeleteControlPointFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> {
    protected _curve!: { view: visual.SpaceInstance, model: c3d.Wire, cvs: c3d.CVCollection };
    get curve(): visual.SpaceInstance { return this._curve.view }
    set curve(curve: visual.SpaceInstance) {
        const model = this.db.lookup(curve)!;
        const view = curve;
        const cvs = model.FindOrderedEdges().GetCVs();
        this._curve = { view, model, cvs };
    }

    protected _vertices!: { views: visual.Vertex[]; models: c3d.Vertex[]; };
    @derive([visual.Vertex]) get vertices(): visual.Vertex[] { throw ''; }
    set vertices(vertices: visual.Vertex[] | c3d.Vertex[]) { }

    protected _cvs!: { views: visual.CV[]; models: c3d.CV[]; };
    @derive([visual.CV]) get cvs(): visual.CV[] { throw ''; }
    set cvs(cvs: visual.CV[] | c3d.CV[]) { }

    async calculate() {
        const { _curve: { model: curve, cvs: collection }, _cvs: { models: cvs }, _vertices: { models: vertices } } = this;

        if (cvs.length === 0 && vertices.length === 0) throw new NoOpError();

        const vertexCollection = new c3d.VertexCollection(vertices.map(v => v.Id()));
        await curve.DeleteControlPoints_async(vertexCollection, collection.Slice(cvs));
        return curve;
    }

    get originalItem() { return this.curve }
}