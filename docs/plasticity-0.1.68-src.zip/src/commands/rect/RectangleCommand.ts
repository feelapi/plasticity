import * as THREE from "three";
import Command from "../../command/Command";
import { PointPicker, PointResult } from "../../command/point-picker/PointPicker";
import { AxisSnap } from "../../editor/snaps/AxisSnap";
import { Snap } from "../../editor/snaps/Snap";
import { FaceCenterPointSnap, FaceSnap } from "../../editor/snaps/Snaps";
import * as visual from "../../visual_model/VisualModel";
import { addSquareSnaps, booleanTargets } from "../box/BoxCommand";
import { KnifeKeyboardGizmo } from "../circle/KnifeKeyboardGizmo";
import LineFactory from '../line/LineFactory';
import { RectangleDialog } from "./RectangleDialog";
import { EditCenterRectangleFactory, EditCornerRectangleFactory, EditThreePointRectangleFactory, KnifeCenterRectangleFactory, KnifeCornerRectangleFactory, KnifeThreePointRectangleFactory } from './RectangleFactory';
import { EditRectangleGizmo } from "./RectangleGizmo";
import { RectangleModeKeyboardGizmo } from "./RectangleModeKeyboardGizmo";

export class ThreePointRectangleCommand extends Command {
    async execute(): Promise<void> {
        const rect = new KnifeThreePointRectangleFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        rect.constructionPlane = this.editor.activeViewport?.constructionPlane;

        const knife = new KnifeKeyboardGizmo('rectangle', this.editor);
        const pointPicker = new PointPicker(this.editor);

        knife.execute(e => {
            switch (e) {
                case 'knife':
                    rect.isKnife = !rect.isKnife;
                    rect.update();
            }
        }).resource(this);

        let pr1, pr2, pr3;
        const line = new LineFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        const { point: p1, info: { snap: snap1 } } = pr1 = await pointPicker.execute().resource(this);
        line.p1 = p1;

        const targets1 = booleanTargets(snap1)
        if (targets1.length > 0) rect.target = targets1[0];

        const { point: p2, info: { snap: snap2 } } = pr2 = await pointPicker.execute(({ point: p2 }) => {
            line.p2 = p2;
            line.update();
        }).resource(this);
        line.cancel();
        rect.p1 = p1;
        rect.p2 = p2;

        const targets2 = booleanTargets(snap1, snap2)
        if (targets2.length > 0) rect.target = targets2[0];

        pr3 = await pointPicker.execute(({ point: p3 }) => {
            rect.p3 = p3;
            rect.update();
        }).resource(this);
        const { info: { snap: snap3 } } = pr3;

        const targets3 = booleanTargets(snap1, snap2, snap3)
        if (targets3.length > 0) rect.target = targets3[0];

        const result = await rect.commit();

        this.editor.selection.selected.removeAll();
        const newSelection = rect.selection;
        this.editor.selection.selected.add(newSelection);

        if (rect.isKnife) return;

        const next = new EditThreePointRectangleCommand(this.editor);
        next.pr1 = pr1;
        next.pr2 = pr2;
        next.pr3 = pr3;
        next.rectangle = result as visual.SpaceInstance;
        next.agent = 'automatic';
        this.editor.enqueue(next);
    }
}

export class CornerRectangleCommand extends Command {
    pr1?: PointResult;
    pr2?: PointResult;
    isKnife = false;

    async execute(): Promise<void> {
        const rect = new KnifeCornerRectangleFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        rect.constructionPlane = this.editor.activeViewport?.constructionPlane;
        let { pr1, pr2, isKnife } = this;
        rect.isKnife = isKnife;

        const keyboard = new RectangleModeKeyboardGizmo(this.editor);
        const knife = new KnifeKeyboardGizmo('rectangle', this.editor);

        knife.execute(e => {
            switch (e) {
                case 'knife':
                    rect.isKnife = isKnife = !rect.isKnife;
                    rect.update();
            }
        }).resource(this);

        let pointPicker = new PointPicker(this.editor);
        const { point: p1, info: { snap: snap1, orientation: o1 } } = pr1 = await pointPicker.execute({ result: pr1 }).resource(this);
        rect.p1 = p1;

        const targets1 = booleanTargets(snap1)
        if (targets1.length > 0) rect.target = targets1[0];

        keyboard.execute(e => {
            switch (e) {
                case 'mode':
                    const command = new CenterRectangleCommand(this.editor);
                    command.pr1 = pr1;
                    command.pr2 = pr2;
                    command.isKnife = isKnife;
                    this.editor.exec(command);
            }
        }).resource(this);

        pointPicker = new PointPicker(this.editor);
        const planar = pointPicker.restrictToPlaneThroughPoint(p1, snap1);
        addSquareSnaps(planar, p1, o1, pointPicker);

        const { point: p2, info: { snap: snap2, orientation: orientation2 } } = pr2 = await pointPicker.execute(result => {
            const { point: p2, info: { orientation } } = pr2 = result;
            rect.p2 = p2;
            rect.orientation = orientation;
            rect.update();
        }, { result: pr2 }).resource(this);
        rect.p2 = p2;
        rect.orientation = orientation2;

        const targets2 = booleanTargets(snap1, snap2)
        if (targets2.length > 0) rect.target = targets2[0];

        const result = await rect.commit();

        this.editor.selection.selected.removeAll();
        const newSelection = rect.selection;
        this.editor.selection.selected.add(newSelection);

        if (rect.isKnife) return;

        const next = new EditCornerRectangleCommand(this.editor);
        next.pr1 = pr1;
        next.pr2 = pr2;
        next.rectangle = result as visual.SpaceInstance;
        next.agent = 'automatic';
        this.editor.enqueue(next);
    }
}

export class CenterRectangleCommand extends Command {
    pr1?: PointResult;
    pr2?: PointResult;
    isKnife = false;

    async execute(): Promise<void> {
        const rect = new KnifeCenterRectangleFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        rect.constructionPlane = this.editor.activeViewport?.constructionPlane;
        let { pr1, pr2, isKnife } = this;
        rect.isKnife = isKnife;

        const keyboard = new RectangleModeKeyboardGizmo(this.editor);
        const knife = new KnifeKeyboardGizmo('rectangle', this.editor);

        knife.execute(e => {
            switch (e) {
                case 'knife':
                    rect.isKnife = isKnife = !rect.isKnife;
                    rect.update();
            }
        }).resource(this);

        let pointPicker = new PointPicker(this.editor);
        const { point: p1, info: { snap: snap1, orientation: o1 } } = pr1 = await pointPicker.execute({ result: pr1 }).resource(this);
        rect.p1 = p1;

        const targets1 = booleanTargets(snap1)
        if (targets1.length > 0) rect.target = targets1[0];

        keyboard.execute(e => {
            switch (e) {
                case 'mode':
                    const command = new CornerRectangleCommand(this.editor);
                    command.pr1 = pr1;
                    command.pr2 = pr2;
                    command.isKnife = isKnife;
                    this.editor.exec(command);
            }
        }).resource(this);

        pointPicker = new PointPicker(this.editor);
        const planar = pointPicker.restrictToPlaneThroughPoint(p1, snap1);
        addSquareSnaps(planar, p1, o1, pointPicker);

        const { point: p2, info: { snap: snap2, orientation: orientation2 } } = pr2 = await pointPicker.execute(result => {
            const { point: p2, info: { orientation } } = pr2 = result;
            rect.p2 = p2;
            rect.orientation = orientation;
            rect.update();
        }, { result: pr2 }).resource(this);
        rect.p2 = p2;
        rect.orientation = orientation2;

        const targets2 = booleanTargets(snap1, snap2)
        if (targets2.length > 0) rect.target = targets2[0];

        const result = await rect.commit();

        this.editor.selection.selected.removeAll();
        const newSelection = rect.selection;
        this.editor.selection.selected.add(newSelection);

        if (rect.isKnife) return;

        const next = new EditCenterRectangleCommand(this.editor);
        next.pr1 = pr1;
        next.pr2 = pr2;
        next.rectangle = result as visual.SpaceInstance;
        next.agent = 'automatic';
        this.editor.enqueue(next);
    }
}

export class EditCenterRectangleCommand extends Command {
    readonly remember = false;
    pr1!: PointResult;
    pr2!: PointResult;
    rectangle!: visual.SpaceInstance;

    async execute(): Promise<void> {
        const { pr1, pr2, rectangle } = this;
        const edit = new EditCenterRectangleFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        edit.p1 = pr1.point;
        edit.p2 = pr2.point;
        edit.orientation = pr2.info.orientation;
        edit.rectangle = rectangle;
        edit.constructionPlane = pr2.info.constructionPlane;

        const dialog = new RectangleDialog(edit, this.editor.signals);
        const gizmo = new EditRectangleGizmo(edit, this.editor);

        dialog.execute(params => {
            edit.update();
            dialog.render();
            gizmo.render(edit);
        }).rejectOnInterrupt().resource(this);

        gizmo.position.copy(pr1.point);
        gizmo.basis = edit.basis;
        gizmo.execute(async params => {
            dialog.render();
            await edit.update();
        }).resource(this);

        await this.finished;

        const result = await edit.commit();
        this.editor.selection.selected.addCurve(result);
    }
}

export class EditCornerRectangleCommand extends Command {
    readonly remember = false;
    pr1!: PointResult;
    pr2!: PointResult;
    rectangle!: visual.SpaceInstance;

    async execute(): Promise<void> {
        const { pr1, pr2, rectangle } = this;
        const edit = new EditCornerRectangleFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        edit.p1 = pr1.point;
        edit.p2 = pr2.point;
        edit.orientation = pr2.info.orientation;
        edit.constructionPlane = pr2.info.constructionPlane;
        edit.rectangle = rectangle;

        const dialog = new RectangleDialog(edit, this.editor.signals);
        const gizmo = new EditRectangleGizmo(edit, this.editor);

        dialog.execute(params => {
            edit.update();
            dialog.render();
            gizmo.render(edit);
        }).rejectOnInterrupt().resource(this);

        gizmo.position.copy(pr1.point);
        gizmo.basis = edit.basis;
        gizmo.execute(async params => {
            dialog.render();
            await edit.update();
        }).resource(this);

        await this.finished;

        const result = await edit.commit();
        this.editor.selection.selected.addCurve(result);
    }
}

export class EditThreePointRectangleCommand extends Command {
    readonly remember = false;
    pr1!: PointResult;
    pr2!: PointResult;
    pr3!: PointResult;
    rectangle!: visual.SpaceInstance;

    async execute(): Promise<void> {
        const { pr1, pr2, pr3, rectangle } = this;
        const edit = new EditThreePointRectangleFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        edit.p1 = pr1.point;
        edit.p2 = pr2.point;
        edit.p3 = pr3.point;
        edit.rectangle = rectangle;

        const dialog = new RectangleDialog(edit, this.editor.signals);
        const gizmo = new EditRectangleGizmo(edit, this.editor);

        dialog.execute(params => {
            edit.update();
            dialog.render();
            gizmo.render(edit);
        }).rejectOnInterrupt().resource(this);

        gizmo.position.copy(pr1.point);
        gizmo.basis = edit.basis;
        gizmo.execute(async params => {
            dialog.render();
            await edit.update();
        }).resource(this);

        await this.finished;

        const result = await edit.commit();
        this.editor.selection.selected.addCurve(result);
    }
}

export function addFacePreference(snap: Snap) {
    if (snap instanceof FaceSnap) return snap;
    else if (snap instanceof FaceCenterPointSnap) return snap.faceSnap;
    else return undefined;
}
