import { CommandKeyboardInput, EditorLike } from "../../command/CommandKeyboardInput";

export class PlaceKeyboardGizmo extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('place', editor, [
            'gizmo:place:flip',
            'gizmo:place:x',
            'gizmo:place:y',
            'gizmo:place:z',
        ]);
    }
}