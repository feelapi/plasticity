import * as THREE from "three";
import Command from "../../command/Command";
import { PointPicker, PointResult } from "../../command/point-picker/PointPicker";
import { PickedPointSnap } from "../../editor/snaps/PointSnap";
import { CancellablePromise } from "../../util/CancellablePromise";
import { freeze, X, Y, Z } from "../../util/Constants";
import { PossiblyBooleanKeyboardGizmo } from "../boolean/BooleanKeyboardGizmo";
import { booleanTargets } from "../box/BoxCommand";
import { PossiblyBooleanPlaceFactory } from "./PlaceFactory";
import { PlaceGizmo } from "./PlaceGizmo";
import { PlaceKeyboardGizmo } from "./PlaceKeyboardGizmo";
import * as c3d from '../../kernel/kernel';
import { assertUnreachable } from "../../util/Util";

export class PlaceCommand extends Command {
    origin?: PointResult;
    destination?: PointResult;
    flip?: boolean;
    operationType?: c3d.OperationType | 'new-body';
    angle?: number;
    offset?: number;
    scale?: number;
    up?: THREE.Vector3;

    async execute(): Promise<void> {
        const { editor, editor: { db, materials, signals, selection: { selected: { solids }, selected } } } = this;
        const place = new PossiblyBooleanPlaceFactory(db, materials, signals).resource(this);
        let { origin, destination, flip, operationType, angle, offset, scale, up } = this;

        place.items = [...solids];
        place.operationType = operationType ?? place.operationType;
        place.flip = flip ?? place.flip;
        place.angle = angle ?? place.angle;
        place.offset = offset ?? place.offset;
        place.scale = scale ?? place.scale;
        place.up.copy(up ?? place.up);

        const keyboard = new PlaceKeyboardGizmo(editor);
        const gizmo = new PlaceGizmo(place, editor);
        let g: CancellablePromise<void> | undefined = undefined;
        const startGizmo = () => {
            if (g !== undefined) return;
            g = gizmo.execute(s => {
                place.update();
            }).resource(this);
            gizmo.disable();
        }

        const defaultPosition = place.centroid;

        let pointPicker = new PointPicker(this.editor);
        pointPicker.addSnap(new PickedPointSnap(defaultPosition));
        const { point: p1, info: { orientation: originOrientation } } = origin = await pointPicker.execute(({ point, info: { orientation } }) => {
            startGizmo();
            gizmo.position.copy(point);
            gizmo.quaternion.copy(orientation);
        }, { default: { position: defaultPosition, orientation: defaultOrientation }, result: origin, returnIfResult: true }).resource(this);
        place.origin = p1;
        place.originOrientation = originOrientation;
        gizmo.disable();

        keyboard.execute(s => {
            switch (s) {
                case 'flip':
                    place.flip = !place.flip;
                    break;
                case 'x':
                    place.up.copy(X);
                    break;
                case 'y':
                    place.up.copy(Y);
                    break;
                case 'z':
                    place.up.copy(Z);
                    break;
                default: throw new Error(`Unknown keyboard state: ${s}`);
            }
            gizmo.quaternion.copy(place.destinationUp);
            place.update();
        }).resource(this);

        const boolean = new PossiblyBooleanKeyboardGizmo("place", this.editor);
        boolean.prepare(place).resource(this);

        pointPicker = new PointPicker(this.editor);
        destination = await pointPicker.execute(({ point, info: { snap } }) => {
            startGizmo();
            const { orientation } = snap.project(point);
            place.destination = point;
            place.destinationOrientation = orientation;
            place.targets = booleanTargets(snap);
            gizmo.position.copy(point);
            gizmo.quaternion.copy(place.destinationUp);
            place.update();
        }).resource(this);
        gizmo.enable();

        await this.finished;

        const result = await place.commit();
        // TODO: if you modify yourself, you need to do something a bit more sophisticated

        const command = new PlaceCommand(this.editor);
        command.agent = 'automatic';
        command.origin = origin;
        command.destination = destination;
        command.flip = place.flip;
        command.operationType = place.operationType;
        command.angle = place.angle;
        command.offset = place.offset;
        command.scale = place.scale;
        command.up = place.up;
        this.editor.enqueue(command);
    }
}

const defaultOrientation = new THREE.Quaternion();
freeze(defaultOrientation);