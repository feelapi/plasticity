import * as fs from 'fs';
import * as THREE from 'three';
import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import { TemporaryObject } from '../../editor/DatabaseLike';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';
import { OBJExporter } from './Exporter';

export interface ExportParams {
    curveChordTolerance: number;
    curveChordAngle: number;
    surfacePlaneTolerance: number;
    surfacePlaneAngle: number;
    maxSides: number;
    planeTolerance: number;
    planeAngle: number;
    minWidth: number;
    maxWidth: number;
    matchTopology: boolean;
}

export class ExportFactory extends GeometryFactory<c3d.Body, visual.Item, []> {
    filePath!: string;

    protected _shells!: { views: visual.Shell[]; models: c3d.Shell[]; };
    @derive([visual.Shell]) get shells(): visual.Shell[] { throw ''; }
    set shells(shells: visual.Shell[] | c3d.Shell[]) { }

    curveChordTolerance = 0.01;
    curveChordAngle = Math.PI / 9;
    surfacePlaneTolerance = 0.01;
    surfacePlaneAngle = Math.PI / 9;
    maxSides = 3;
    planeTolerance = 0;
    planeAngle = 0;
    minWidth = 0;
    maxWidth = 0;
    matchTopology = true;

    async doUpdate(): Promise<TemporaryObject[]> {
        const { db, shells } = this;

        const faceted = await this.calc();

        const temps: TemporaryObject[] = faceted.map(([preview, wireframe], i) => {
            db.temporaryObjects.add(wireframe, preview);
            wireframe.visible = preview.visible = false;
            return {
                underlying: wireframe,
                show() {
                    wireframe.visible = preview.visible = true;
                    shells[i].visible = false;
                },
                hide() {
                    wireframe.visible = preview.visible = false;
                    shells[i].visible = true;
                },
                cancel() {
                    wireframe.geometry.dispose();
                    preview.geometry.dispose();
                    db.temporaryObjects.remove(wireframe, preview);
                    shells[i].visible = true;
                }
            }
        });

        this.cleanupTemps();
        db.temporaryObjects.add(...temps.map(t => t.underlying));
        return this.temps = this.showTemps(temps);
    }

    private async calc(): Promise<[THREE.Mesh, THREE.LineSegments][]> {
        const { _shells: { models, views }, curveChordTolerance, curveChordAngle, surfacePlaneTolerance, surfacePlaneAngle, maxSides } = this;

        const options = new c3d.FacetOptions(curveChordTolerance, curveChordAngle, surfacePlaneTolerance, surfacePlaneAngle);
        options.MatchTopology = this.matchTopology;
        options.Incremental = c3d.FacetIncrementalType.None;
        options.MaxSides = maxSides;
        options.PlaneTolerance = this.planeTolerance;
        options.PlaneAngle = this.planeAngle;
        options.MinWidth = this.minWidth;
        options.MaxWidth = this.maxWidth;

        const objects: [THREE.Mesh, THREE.LineSegments][] = [];
        for (let i = 0; i < models.length; i++) {
            const model = models[i], view = views[i];
            const results = await c3d.DisplayHelper.FacetFacesAndEdges_async([model], options);
            if (results.length !== 1) throw new Error('Unexpected result length');
            const keepAlive = results[0];
            const { faceFacet, facePosition, faceIndex }  = keepAlive;

            let shell;
            let faceFacetInfo = faceFacet;
            if (maxSides === 3) {
                const triangles = faceIndex.length;
                faceFacetInfo = new Uint32Array(triangles);
                for (let i = 0; i < triangles; i++) {
                    faceFacetInfo[i] = Math.trunc(i / 3);
                }

                const geometry = new THREE.BufferGeometry();
                geometry.setAttribute('position', new THREE.BufferAttribute(facePosition, 3));
                geometry.setIndex(new THREE.BufferAttribute(faceIndex, 1));
                geometry.userData.keepAlive = keepAlive;

                // @ts-expect-error
                shell = new THREE.Mesh(geometry, view.faces.mesh.material[2]);
            } else {
                let prev = -1, firstIndexOfFace = 0;
                const faceTriangles = [];
                const faceIndices = [];
                for (let i = 0; i < faceFacetInfo.length; i++) {
                    const current = faceFacetInfo[i];
                    if (current !== prev) {
                        for (let j = 1; j < faceIndices.length - 1; j++) {
                            faceTriangles.push(faceIndex[firstIndexOfFace], faceIndex[firstIndexOfFace + j], faceIndex[firstIndexOfFace + j + 1]);
                        }
                        faceIndices.length = 0;
                        firstIndexOfFace = i;
                    }
                    faceIndices.push(faceIndex[i]);
                    prev = current;
                }
                for (let j = 1; j < faceIndices.length - 1; j++) {
                    faceTriangles.push(faceIndex[firstIndexOfFace], faceIndex[firstIndexOfFace + j], faceIndex[firstIndexOfFace + j + 1]);
                }
                
                const geometry = new THREE.BufferGeometry();
                geometry.setAttribute('position', new THREE.BufferAttribute(facePosition, 3));
                geometry.setIndex(new THREE.BufferAttribute(new Uint32Array(faceTriangles), 1));
                geometry.userData.keepAlive = keepAlive;

                // @ts-expect-error
                shell = new THREE.Mesh(geometry, view.faces.mesh.material[2]);
            }

            let prev = -1, firstIndexOfFace = 0;
            const result = [];
            for (let i = 0; i < faceFacetInfo.length - 1; i++) {
                const current = faceFacetInfo[i];
                const next = faceFacetInfo[i + 1];
                if (current !== prev) {
                    firstIndexOfFace = i;
                }

                result.push(facePosition[faceIndex[i] * 3 + 0]);
                result.push(facePosition[faceIndex[i] * 3 + 1]);
                result.push(facePosition[faceIndex[i] * 3 + 2]);

                if (current === next) {
                    result.push(facePosition[faceIndex[i + 1] * 3 + 0]);
                    result.push(facePosition[faceIndex[i + 1] * 3 + 1]);
                    result.push(facePosition[faceIndex[i + 1] * 3 + 2]);
                } else {
                    result.push(facePosition[faceIndex[firstIndexOfFace] * 3 + 0]);
                    result.push(facePosition[faceIndex[firstIndexOfFace] * 3 + 1]);
                    result.push(facePosition[faceIndex[firstIndexOfFace] * 3 + 2]);
                }

                prev = current;
            }

            const geometry = new THREE.BufferGeometry();
            geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(result), 3));
            const line = new THREE.LineSegments(geometry, lineMaterial);
            objects.push([shell, line]);
        }

        return objects;
    }

    async doCommit() {
        const { filePath, db, _shells: { models, views }, curveChordTolerance, curveChordAngle, surfacePlaneTolerance, surfacePlaneAngle, maxSides } = this;

        const options = new c3d.FacetOptions(curveChordTolerance, curveChordAngle, surfacePlaneTolerance, surfacePlaneAngle);
        options.MatchTopology = this.matchTopology;
        options.Incremental = c3d.FacetIncrementalType.None;
        options.MaxSides = maxSides;
        options.PlaneTolerance = this.planeTolerance;
        options.PlaneAngle = this.planeAngle;
        options.MinWidth = this.minWidth;
        options.MaxWidth = this.maxWidth;

        const exporter = new OBJExporter();
        for (let i = 0; i < models.length; i++) {
            const model = models[i], view = views[i];
            const results = await c3d.DisplayHelper.FacetFacesAndEdges_async([model], options);
            if (results.length !== 1) throw new Error('Unexpected result length');
            const keepAlive = results[0];
            const { faceFacet, facePosition, faceIndex, faceNormal } = keepAlive;
            let faceFacetInfo = faceFacet;
            if (maxSides === 3) {
                const triangles = faceIndex.length;
                faceFacetInfo = new Uint32Array(triangles);
                for (let i = 0; i < triangles; i++) {
                    faceFacetInfo[i] = Math.trunc(i / 3);
                }
            }

            const name = db.getName(view) ?? String(this.db.lookupStableId(view.simpleName));
            exporter.add(name, undefined, facePosition, faceNormal, faceFacetInfo, faceIndex);
        }
        await fs.promises.writeFile(filePath, exporter.output);

        for (const temp of this.temps) temp.cancel();

        return [];
    }

    toJSON(): ExportParams {
        const { curveChordTolerance, curveChordAngle, surfacePlaneTolerance, surfacePlaneAngle, maxSides, planeTolerance, planeAngle, minWidth, maxWidth, matchTopology } = this;
        return {
            curveChordTolerance, curveChordAngle, surfacePlaneTolerance, surfacePlaneAngle, maxSides, planeTolerance, planeAngle, minWidth, maxWidth, matchTopology
        }
    }

    fromJSON(params?: ExportParams) {
        if (params === undefined) return;
        const { curveChordTolerance, curveChordAngle, surfacePlaneTolerance, surfacePlaneAngle, maxSides, planeTolerance, planeAngle, minWidth, maxWidth, matchTopology } = params;
        this.curveChordTolerance = curveChordTolerance;
        this.curveChordAngle = curveChordAngle;
        this.surfacePlaneTolerance = surfacePlaneTolerance;
        this.surfacePlaneAngle = surfacePlaneAngle;
        this.maxSides = maxSides;
        this.planeTolerance = planeTolerance;
        this.planeAngle = planeAngle;
        this.minWidth = minWidth;
        this.maxWidth = maxWidth;
        this.matchTopology = matchTopology;
    }
}

const lineMaterial = new THREE.LineBasicMaterial({ color: 0x00ffff, polygonOffset: true, polygonOffsetFactor: -100, polygonOffsetUnits: -100 });
