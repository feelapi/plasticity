import { render } from 'preact';
import { EditorSignals } from "../../editor/EditorSignals";
import { AbstractDialog } from "../../command/AbstractDialog";
import { ExportParams } from "./ExportFactory";

export class ExportDialog extends AbstractDialog<ExportParams> {
    name = "Export";

    constructor(protected readonly params: ExportParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { curveChordTolerance, curveChordAngle, surfacePlaneTolerance, surfacePlaneAngle, maxSides, planeTolerance, planeAngle, minWidth, maxWidth, matchTopology } = this.params;

        render(
            <>
                <ul>
                    <li>
                        <label for="matchTopology">Match topology
                        </label>
                        <div class="fields">
                            <input type="checkbox" hidden id="matchTopology" name="matchTopology" checked={matchTopology} onClick={this.onChange}></input>
                            <label for="matchTopology">Match</label>
                        </div>
                    </li>
                    <li>
                        <label for="surfacePlaneTolerance">
                            Surface plane tolerance
                            <plasticity-tooltip>Maximum allowable deviation (in centimeters). Usually this is the only thing you need to change.</plasticity-tooltip>
                        </label>
                        <div class="fields">
                            <plasticity-number-scrubber disabled={0} precision={4} name="surfacePlaneTolerance" value={surfacePlaneTolerance} min={0.001} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="surfacePlaneAngle">
                            Surface angle tolerance
                            <plasticity-tooltip>Maximum allowable angular deviation (in radians). With this you can add more detail to tight turns over small areas.</plasticity-tooltip>
                        </label>
                        <div class="fields">
                            <plasticity-number-scrubber disabled={0} name="surfacePlaneAngle" value={surfacePlaneAngle} min={0} max={Math.PI / 2} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="curveChordTolerance">
                            Curve plane tolerance
                            <plasticity-tooltip>Maximum allowable deviation (in centimeters). Usually this is the only thing you need to change.</plasticity-tooltip>
                        </label>
                        <div class="fields">
                            <plasticity-number-scrubber disabled={0} precision={4} name="curveChordTolerance" value={curveChordTolerance} min={0.001} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="curveChordAngle">
                            Curve angle tolerance
                            <plasticity-tooltip>Maximum allowable angular deviation (in radians).</plasticity-tooltip>
                        </label>
                        <div class="fields">
                            <plasticity-number-scrubber disabled={0} name="curveChordAngle" value={curveChordAngle} min={0} max={Math.PI / 2} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="maxSides">
                            Max sides
                            <plasticity-tooltip>Maximum number of sides per facet. Typical values are 3, 4, 12.</plasticity-tooltip>
                        </label>
                        <div class="fields">
                            <plasticity-number-scrubber name="maxSides" value={maxSides} min={3} precision={1} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="planeTolerance">
                            Plane tolerance
                            <plasticity-tooltip>the maximum distance between the mid-plane of a facet and its facet vertices</plasticity-tooltip>
                        </label>
                        <div class="fields">
                            <plasticity-number-scrubber disabled={0} name="planeTolerance" value={planeTolerance} min={0.001} default={0.01} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="planeAngle">
                            Plane angle
                            <plasticity-tooltip>The maximum ratio permitted between the plane tolerance and the maximum width of a facet</plasticity-tooltip>
                        </label>
                        <div class="fields">
                            <plasticity-number-scrubber disabled={0} name="planeAngle" value={planeAngle} min={0.1} max={Math.PI / 2} default={Math.PI / 4} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="minWidth">
                            Min width
                        </label>
                        <div class="fields">
                            <plasticity-number-scrubber disabled={0} name="minWidth" value={minWidth} min={0.01} default={Math.PI / 4} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="maxWidth">
                            Max width
                        </label>
                        <div class="fields">
                            <plasticity-number-scrubber disabled={0} name="maxWidth" value={maxWidth} min={0.01} default={Math.PI / 4} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('export-dialog', ExportDialog);