import * as THREE from 'three';

export class OBJExporter {
    private indexVertex = 0;
    private indexVertexUvs = 0;
    private indexNormals = 0;

    private _output: string = "";
    get output() { return this._output; }

    add(name: string, material: string | undefined, positions: Float32Array, normals: Float32Array, faces: Uint32Array, indices: Uint32Array): void {
        const vertex = new THREE.Vector3();
        const color = new THREE.Color();
        const normal = new THREE.Vector3();

        let nbVertex = 0;
        let nbNormals = 0;

        this._output += 'o ' + name + '\n';
        if (material !== undefined) {
            this._output += 'usemtl ' + material + '\n';
        }
        const mergeVertices = new Map<string, number>();
        let j = 0;
        for (let i = 0; i < positions.length; i += 3) {
            vertex.fromArray(positions, i);
            const s = vertex2key(vertex);
            if (mergeVertices.has(s)) continue;
            mergeVertices.set(s, j++);
            this._output += 'v ' + s + '\n';
            nbVertex++;
        }
        for (let i = 0; i < normals.length; i += 3, nbNormals++) {
            normal.fromArray(normals, i);
            this._output += 'vn ' + normal.x + ' ' + normal.y + ' ' + normal.z + '\n';
        }
        let prev = -1, firstIndexOfFace = 0;
        const face: string[] = [];
        for (let i = 0; i < faces.length; i++) {
            const current = faces[i];
            if (current !== prev) {
                firstIndexOfFace = i;
            }
            vertex.fromArray(positions, indices[i] * 3);
            const vindex = vertex2index(vertex, mergeVertices);
            if (current !== prev && prev !== -1) {
                this._output += 'f ' + face.join(' ') + '\n';
                face.length = 0;
                const v = this.indexVertex + Number(vindex) + 1;
                const n = this.indexNormals + Number(indices[i]) + 1;
                face.push(`${v}//${n}`);
            } else {
                const v = this.indexVertex + Number(vindex) + 1;
                const n = this.indexNormals + Number(indices[i]) + 1;
                face.push(`${v}//${n}`);
            }
            prev = current;
        }
        this._output += 'f ' + face.join(' ') + '\n';
        this.indexVertex += nbVertex;
        this.indexNormals += nbNormals;
    }
}

function vertex2key(vertex: THREE.Vector3): string {
    return vertex.x + ' ' + vertex.y + ' ' + vertex.z;
}

function vertex2index(vertex: THREE.Vector3, mergeVertices: ReadonlyMap<string, number>): number {
    const s = vertex2key(vertex);
    const result = mergeVertices.get(s);
    if (result === undefined) throw new Error('vertex not found: ' + s);
    return result;
}