import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from "../../command/GeometryFactory";
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';

export interface PatchHoleParams {
    fillPreference: c3d.FillHolePreferenceType;
    internalSmoothness: c3d.FillHoleInternalSmoothnessType;
    continuity: c3d.ContinuityType;
}

export class PatchHoleInSheetFactory extends GeometryFactory<c3d.Shell, visual.Shell> implements PatchHoleParams {
    fillPreference = c3d.FillHolePreferenceType.NonSmooth;
    internalSmoothness = c3d.FillHoleInternalSmoothnessType.Sharp;
    continuity = c3d.ContinuityType.G1;

    private _sheet!: { view: visual.Sheet; model: c3d.Sheet; };
    @derive(visual.Sheet) get sheet(): visual.Sheet { throw ''; }
    set sheet(sheet: visual.Sheet | c3d.Sheet) { }

    private _edges!: { views: visual.CurveEdge[]; models: c3d.Edge[]; };
    @derive([visual.CurveEdge]) get edges(): visual.CurveEdge[] { throw ''; }
    set edges(edges: visual.CurveEdge[] | c3d.Edge[]) { }

    private _guides: { views: visual.SpaceInstance[]; models: c3d.Wire[]; } = { views: [], models: [] };
    @derive([visual.SpaceInstance]) get guides(): visual.SpaceInstance[] { throw ''; }
    set guides(guides: visual.SpaceInstance[] | c3d.Wire[]) { }

    async calculate() {
        const { _edges: { models: edges }, _sheet: { model: sheet }, _guides: { models: guides }, fillPreference, internalSmoothness, continuity: smoothness } = this;

        const options = new c3d.FillHoleOptions();
        options.FillPreference = fillPreference;
        options.InternalSmoothness = internalSmoothness;
        options.Smoothness = smoothness;
        options.SupportBodies = guides;

        const result = sheet.FillHole_async(edges, options);
        return result;
    }

    get originalItem() { return this.sheet }
}

export class PatchHoleInWireFactory extends GeometryFactory<c3d.Sheet, visual.SpaceInstance | visual.Sheet> implements PatchHoleParams {
    fillPreference = c3d.FillHolePreferenceType.Smooth;
    internalSmoothness = c3d.FillHoleInternalSmoothnessType.Sharp;
    continuity = c3d.ContinuityType.G1;

    private _curve!: { view: visual.SpaceInstance, model: c3d.Wire };
    @derive(visual.SpaceInstance) get curve(): visual.SpaceInstance { throw '' }
    set curve(curve: visual.SpaceInstance | c3d.Wire) { }

    async calculate() {
        const { _curve: { model: curve }, fillPreference, internalSmoothness, continuity: smoothness } = this;

        const options = new c3d.FillHoleOptions();
        options.FillPreference = fillPreference;
        options.InternalSmoothness = internalSmoothness;
        options.Smoothness = smoothness;

        const result = curve.FillHole_async(options);
        return result;
    }

    get originalItem() { return this.curve }
}