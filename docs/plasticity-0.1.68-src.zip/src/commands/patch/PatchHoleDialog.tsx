import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import { PatchHoleParams } from "./PatchHoleFactory";
import * as c3d from '../../kernel/kernel';


export class PatchHoleInSheetDialog extends AbstractDialog<PatchHoleParams> {
    name = "Patch hole";

    constructor(protected readonly params: PatchHoleParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { fillPreference, internalSmoothness, continuity } = this.params;

        render(
            <>
                <ol>
                    <plasticity-prompt name="Select guides" description="to loft along"></plasticity-prompt>
                </ol>

                <ul>
                    <li>
                        <label for="fillPreference">Fill Preference</label>
                        <div class="fields">
                            <input type="radio" hidden name="fillPreference" id="smooth" value={c3d.FillHolePreferenceType.Smooth} checked={fillPreference === c3d.FillHolePreferenceType.Smooth} onClick={this.onChange}></input>
                            <label for="smooth">Smooth</label>

                            <input type="radio" hidden name="fillPreference" id="non-smooth" value={c3d.FillHolePreferenceType.NonSmooth} checked={fillPreference === c3d.FillHolePreferenceType.NonSmooth} onClick={this.onChange}></input>
                            <label for="non-smooth">Nonsmooth</label>

                            <input type="radio" hidden name="fillPreference" id="planar" value={c3d.FillHolePreferenceType.PlaneOnly} checked={fillPreference === c3d.FillHolePreferenceType.PlaneOnly} onClick={this.onChange}></input>
                            <label for="planar">Planar</label>
                        </div>
                    </li>

                    <li class={fillPreference !== c3d.FillHolePreferenceType.Smooth ? 'disabled' : ''}>
                        <label for="closed">Continuity</label>
                        <div class="fields">
                            <input type="radio" hidden name="continuity" id="g1" value={c3d.ContinuityType.G1} checked={continuity === c3d.ContinuityType.G1} onClick={this.onChange}></input>
                            <label for="g1">G1</label>

                            <input type="radio" hidden name="continuity" id="g2" value={c3d.ContinuityType.G2} checked={continuity === c3d.ContinuityType.G2} onClick={this.onChange}></input>
                            <label for="g2">G2</label>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('patch-hole-in-sheet-dialog', PatchHoleInSheetDialog);

export class PatchHoleInCurveDialog extends AbstractDialog<PatchHoleParams> {
    name = "Patch hole";

    constructor(protected readonly params: PatchHoleParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { fillPreference, internalSmoothness, continuity } = this.params;

        render(
            <>
                <ul>
                    <li>
                        <label for="fillPreference">Fill Preference</label>
                        <div class="fields">
                            <input type="radio" hidden name="fillPreference" id="smooth" value={c3d.FillHolePreferenceType.Smooth} checked={fillPreference === c3d.FillHolePreferenceType.Smooth} onClick={this.onChange}></input>
                            <label for="smooth">Smooth</label>

                            <input type="radio" hidden name="fillPreference" id="non-smooth" value={c3d.FillHolePreferenceType.NonSmooth} checked={fillPreference === c3d.FillHolePreferenceType.NonSmooth} onClick={this.onChange}></input>
                            <label for="non-smooth">Nonsmooth</label>

                            <input type="radio" hidden name="fillPreference" id="planar" value={c3d.FillHolePreferenceType.PlaneOnly} checked={fillPreference === c3d.FillHolePreferenceType.PlaneOnly} onClick={this.onChange}></input>
                            <label for="planar">Planar</label>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('patch-hole-in-curve-dialog', PatchHoleInCurveDialog);
