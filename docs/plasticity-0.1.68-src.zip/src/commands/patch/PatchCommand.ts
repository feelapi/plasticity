
import Command from "../../command/Command";
import { ValidationError } from "../../command/GeometryFactory";
import { ObjectPicker } from "../../command/ObjectPicker";
import { SelectionMode } from "../../selection/SelectionModeSet";
import * as visual from '../../visual_model/VisualModel';
import { PatchHoleInCurveDialog, PatchHoleInSheetDialog } from "./PatchHoleDialog";
import { PatchHoleInSheetFactory, PatchHoleInWireFactory as PatchHoleInCurveFactory } from "./PatchHoleFactory";

export class PatchCommand extends Command {
    async execute(): Promise<void> {
        const selected = this.editor.selection.selected;
        if (selected.edges.size > 0) {
            const command = new PatchHoleInSheetCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.curves.size > 0) {
            const command = new PatchHoleInCurveCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        }
    }
}

export class PatchHoleInSheetCommand extends Command {
    async execute(): Promise<void> {
        const patch = new PatchHoleInSheetFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);

        const selected = this.editor.selection.selected;
        patch.edges = [...selected.edges];
        const sheet = selected.edges.first.parentItem;
        if (!(sheet instanceof visual.Sheet)) throw new ValidationError();
        patch.sheet = sheet;

        const dialog = new PatchHoleInSheetDialog(patch, this.editor.signals);
        dialog.execute(async (params) => {
            await patch.update();
            dialog.render();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        GetGuides: {
            dialog.prompt("Select guides", () => {
                const objectPicker = new ObjectPicker(this.editor);
                return objectPicker.execute(delta => {
                    patch.guides = [...objectPicker.selection.selected.curves];
                    patch.update();
                }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Curve).resource(this);
            })();
        }

        await patch.update();

        await this.finished;

        const results = await patch.commit();
        this.editor.selection.selected.add(results);
        this.editor.selection.selected.remove(patch.edges);
    }
}

export class PatchHoleInCurveCommand extends Command {
    async execute(): Promise<void> {
        const patch = new PatchHoleInCurveFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);

        const selected = this.editor.selection.selected;
        const curve = selected.curves.first;
        patch.curve = curve;

        const dialog = new PatchHoleInCurveDialog(patch, this.editor.signals);
        dialog.execute(async (params) => {
            await patch.update();
            dialog.render();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        await patch.update();

        await this.finished;

        const results = await patch.commit();
        this.editor.selection.selected.add(results);
    }
}
