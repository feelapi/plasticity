import * as THREE from "three";
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { Z } from "../../util/Constants";
import { point2point, vec2vec } from "../../util/Conversion";
import * as visual from '../../visual_model/VisualModel';

export class CenterPointArcFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> {
    center!: THREE.Vector3;
    p2!: THREE.Vector3;
    p3!: THREE.Vector3;
    orientation = new THREE.Quaternion();


    private lastQuadrant = 0;
    private sense = false;

    async calculate(partition: c3d.Partition = this.partition) {
        const { center, p2, p3, orientation } = this;

        normal.copy(Z).applyQuaternion(orientation).normalize();

        Cp2.copy(p2).sub(center);
        Cp3.copy(p3).sub(center);

        const dot = Cp2.dot(Cp3);
        cross.crossVectors(Cp2, Cp3);

        let quadrant;
        const crossDotN = cross.dot(normal);
        if (dot > 0) {
            if (crossDotN > 0) quadrant = 3;
            else quadrant = 0;
        } else {
            if (crossDotN > 0) quadrant = 2;
            else quadrant = 1;
        }

        const diff = quadrant - this.lastQuadrant;
        if (diff == -3 || diff == 3) {
            this.sense = crossDotN > 0;
        }
        this.lastQuadrant = quadrant;

        // if (cross.manhattanLength() < 10e-6) throw new ValidationError();

        const angle = Math.atan2(crossDotN, Cp2.dot(Cp3));

        const z = vec2vec(normal, 1);
        const basis = new c3d.Basis(point2point(center), z, vec2vec(Cp2.normalize(), 1));

        const circle = partition.WireBody.CreateCircle(p2.distanceTo(center), basis);
        const edge = circle.GetEdges().Get(0);
        const interval = this.sense ? [0, angle] : [angle, 2 * Math.PI];
        const trimmed = await circle.Trim_async([edge], interval);
        return trimmed[0];
    }
}

export class ThreePointArcFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> {
    p1!: THREE.Vector3;
    p2!: THREE.Vector3;
    p3!: THREE.Vector3;

    async calculate(partition: c3d.Partition = this.partition) {
        const { p1, p2, p3 } = this;

        const circle = partition.Circle.CreateFromThreePoints(point2point(p1), point2point(p2), point2point(p3));
        const basis = circle.GetInfo().basis;
        const center = point2point(basis.Location);

        const normal = vec2vec(basis.Axis, 1);

        Cp2.copy(p1).sub(center);
        Cp3.copy(p2).sub(center);

        cross.crossVectors(Cp2, Cp3);

        const angle = Math.atan2(cross.dot(normal), Cp2.dot(Cp3));

        const wire = partition.WireBody.CreateFromCurves([circle]);
        const interval = [angle, 2 * Math.PI];
        const trimmed = await wire.Trim_async([wire.GetEdges().Get(0)], interval);
        return trimmed[0];
    }
}

const Cp2 = new THREE.Vector3();
const Cp3 = new THREE.Vector3();
const cross = new THREE.Vector3();
const normal = new THREE.Vector3();
