import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';

// NOTE: This factory is trickier than most. It is typically used in an
// event loop where the user mouses over a face, raycasting. Since this factory modifies the face, it
// is unsafe to raycast over the face as it is being modified. To avoid this, the factory makes
// the isoparam as a phantom during interactive view, returning nothing during calculateForUpdate

export interface IsoparamParams {
    param: number;
    uOrV: boolean;
}

export class IsoparamFactory extends GeometryFactory implements IsoparamParams {
    count = 1;
    param = 0.5;
    uOrV = true;
    toggle() { this.uOrV = !this.uOrV }

    private _face!: { view: visual.Face, model: c3d.Face };
    @derive(visual.Face) get face(): visual.Face { throw '' }
    set face(face: visual.Face | c3d.Face) { }

    protected _shell!: { view: visual.Shell; model: c3d.Shell; };
    @derive(visual.Shell) get shell(): visual.Shell { throw ''; }
    set shell(shell: visual.Shell | c3d.Shell) { }

    async calculatePhantoms() {
        const { _face: { model: face }, _shell: { model: shell }, param, uOrV, count } = this;
        const wires = face.MakeIsoparams(param, uOrV, Math.max(1, count));
        return wires.map(phantom => ({ material: {}, phantom }));
    }

    async calculateForUpdate(): Promise<c3d.Shell> {
        return this._shell.model;
    }

    async calculateForCommit() {
        const { _face: { model: face }, _shell: { model: shell }, param, uOrV, count } = this;
        face.ImprintIsoparams(param, uOrV, Math.max(1, count));
        return shell;
    }

    get originalItem() { return this.shell }
}