import Command from "../../command/Command";
import { PointPicker } from '../../command/point-picker/PointPicker';
import { CurveEdgeSnap, EdgePointSnap, FaceCenterPointSnap, FaceSnap } from "../../editor/snaps/Snaps";
import { edge2faces } from "../../selection/SelectionConversionStrategy";
import { point2point } from "../../util/Conversion";
import { IsoparamFactory } from './IsoparamFactory';
import { IsoparamKeyboardGizmo } from "./IsoparamKeyboardGizmo";

export class IsoparamCommand extends Command {
    async execute(): Promise<void> {
        const { editor } = this;
        const iso = new IsoparamFactory(editor.db, editor.materials, editor.signals).resource(this);

        const keyboard = new IsoparamKeyboardGizmo(this.editor);
        keyboard.execute(s => {
            switch (s) {
                case 'add-cut':
                    iso.count++;
                    break;
                case 'subtract-cut':
                    iso.count--;
                    break;
                case 'toggle':
                    iso.toggle();
                    break;
            }
            iso.update();
        }).resource(this);

        const pointPicker = new PointPicker(this.editor);
        await pointPicker.execute(async ({ point, info: { snap } }) => {
            if (snap instanceof FaceSnap) {
                iso.face = snap.view;
                iso.shell = snap.view.parentItem;
                const { u, v } = snap.uv(point);
                iso.param = iso.uOrV ? u : v;
            } else if (snap instanceof FaceCenterPointSnap) {
                iso.face = snap.faceSnap.view;
                iso.shell = snap.faceSnap.view.parentItem;
                const { u, v } = snap.faceSnap.uv(point);
                iso.param = iso.uOrV ? u : v;
            } else if (snap instanceof CurveEdgeSnap || snap instanceof EdgePointSnap) {
                const edge = snap instanceof CurveEdgeSnap ? snap.view : snap.edgeSnap.view;
                const faces = edge2faces(edge, this.editor.db);
                const { position: exact } = snap.project(point);
                let set = false;
                for (const face of faces) {
                    if (iso.face === undefined) continue;
                    if (iso.face.simpleName !== face.simpleName) continue;
                    const model = this.editor.db.lookupTopologyItem(face);
                    const { u, v } = model.FindPointNear(point2point(exact));
                    iso.param = iso.uOrV ? u : v;
                    set = true;
                    break;
                }
                if (!set) {
                    const face = faces[0];
                    const model = this.editor.db.lookupTopologyItem(face);
                    const { u, v } = model.FindPointNear(point2point(exact));
                    iso.param = iso.uOrV ? u : v;
                    iso.face = face;
                }
            } else return;
            await iso.update();
        }).resource(this);

        const cut = await iso.commit();
        editor.selection.selected.add(cut);
    }
}
