import { CommandKeyboardInput, EditorLike } from "../../command/CommandKeyboardInput";

export class IsoparamKeyboardGizmo  extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('move', editor, [
            'gizmo:isoparam:toggle',
            'gizmo:isoparam:add-cut',
            'gizmo:isoparam:subtract-cut',
        ]);
    }
}
