import * as THREE from "three";
import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory, NoOpError, ValidationError } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { mat2mat, point2point, vec2vec } from "../../util/Conversion";
import * as visual from "../../visual_model/VisualModel";

const maxItems = 1_000;

export interface ArrayParams {
    dir1: THREE.Vector3;
    step1: number;
    num1: number;

    dir2: THREE.Vector3;
    step2: number;
    num2: number;
}

export interface RadialArrayParams extends ArrayParams {
    degrees: number;
}

type RectangularArrayMode = 'extent' | 'spacing';

export interface RectangularArrayParams extends ArrayParams {
    mode: RectangularArrayMode;
    distance1: number;
    distance2: number;
}

abstract class AbstractArrayFactory extends GeometryFactory<c3d.Body, visual.Item, []> implements ArrayParams {
    protected _items!: { views: visual.Item[]; models: c3d.Body[]; };
    @derive([visual.Item]) get items(): visual.Item[] { throw ''; }
    set items(items: visual.Item[] | c3d.Body[]) { }

    dir1!: THREE.Vector3;
    step1 = 0;
    private _num1 = 2;
    get num1() { return this._num1 }
    set num1(num1: number) {
        if (num1 < 1) throw new Error("invalid argument");
        this._num1 = Math.trunc(num1);
    }

    dir2!: THREE.Vector3;

    abstract num2: number;
    abstract step2: number;

    protected abstract get params(): c3d.BodyArrayOptions;
    async calculate() {
        const { params, _items: { models: items }, num1, num2 } = this;
        if (items.length === 0) throw new NoOpError();
        if (num1 * num2 > maxItems) throw new ValidationError("Too many items");

        const result = [];
        for (const item of items) {
            result.push(await item.ArrayDuplicate_async(params));
        }
        return result.flat();
    }

    protected override async calculateTemps(abortEarly: () => boolean, options?: any) {
        const fasts = this.fastUpdate();
        const temps = [];
        for (const fast of fasts) {
            temps.push(this.db.addTemporaryItem(fast));
        }
        return { temps, toHide: [] };
    }

    private readonly ti = new THREE.Matrix4();
    private readonly tj = new THREE.Matrix4();
    private fastUpdate() {
        const { params, _items: { views: items }, num1, num2 } = this;
        if (items.length === 0) throw new NoOpError();
        if (num1 * num2 > maxItems) throw new ValidationError("Too many items");

        const results: visual.Item[] = [];

        const t1 = mat2mat(params.Transform1.GetMatrix());
        const t2 = mat2mat(params.Transform2.GetMatrix());

        const { ti, tj } = this;
        ti.identity();
        tj.identity();
        for (let i = 0; i < params.Count1; i++) {
            tj.copy(ti);
            for (let j = 0; j < params.Count2; j++) {
                if (i > 0 || j > 0) {
                    for (const item of items) {
                        const clone = item.clone();
                        const temp = transformTemporary(clone, tj);
                        results.push(temp);
                    }
                }

                tj.premultiply(t2);
            }
            ti.premultiply(t1);
        }
        return results;
    }
}

export class RadialArrayFactory extends AbstractArrayFactory {
    center = new THREE.Vector3();
    isAlongAxis = false;

    private _num2 = 8;
    get num2() { return this._num2 }
    set num2(num2: number) {
        num2 = Math.max(1, num2);
        this._num2 = Math.floor(num2);
        this.updateStep2();
    }

    angle = 2 * Math.PI;
    get degrees() { return THREE.MathUtils.radToDeg(this.angle) }
    set degrees(degrees: number) {
        this.angle = THREE.MathUtils.degToRad(degrees);
        this.updateStep2();
    }

    step2 = this.angle / this.num2;
    private updateStep2() {
        const isWholeCircle = Math.abs(this.angle - 2 * Math.PI) < 1e-6;
        this.step2 = isWholeCircle ? 2 * Math.PI / this.num2 : this.angle / (this.num2 - 1);
    }

    get params() {
        const { dir1, step1, center, step2, dir2, num1, num2 } = this;

        const radial = vec2vec(dir1.clone().multiplyScalar(step1), 1);
        const transform1 = c3d.Transform.CreateTranslation(radial);

        const position = point2point(center);
        const axis = vec2vec(dir2, 1);
        const transform2 = c3d.Transform.CreateRotation(position, axis, step2);

        return new c3d.BodyArrayOptions(transform1, transform2, num1, num2);
    }
}

export class RectangularArrayFactory extends AbstractArrayFactory {
    mode: RectangularArrayMode = 'extent';

    private _num2 = 1;
    get num2() { return this._num2 }
    set num2(num2: number) {
        const distance2 = this.distance2;
        this._num2 = Math.max(1, Math.trunc(num2))
        if (this.mode === 'extent') this.distance2 = distance2;
    }

    get num1() { return super.num1 }
    set num1(num1: number) {
        const distance1 = this.distance1;
        super.num1 = num1;
        if (this.mode === 'extent') this.distance1 = distance1;
    }

    step2 = 1;

    get distance2() { return this.num2 === 1 ? this.step2 : this.step2 * (this.num2 - 1) }
    set distance2(distance2: number) {
        this.step2 = this.num2 === 1 ? distance2 : distance2 / (this.num2 - 1);
    }

    get distance1() { return this.num1 === 1 ? this.step1 : this.step1 * (this.num1 - 1) }
    set distance1(distance1: number) {
        this.step1 = this.num1 === 1 ? distance1 : distance1 / (this.num1 - 1);
    }

    protected get params() {
        const { step1, step2, dir1, dir2, num1, num2 } = this;

        const y = vec2vec(dir1.clone().multiplyScalar(step1));
        const transform1 = c3d.Transform.CreateTranslation(y);

        const x = vec2vec(dir2.clone().multiplyScalar(step2));
        const transform2 = c3d.Transform.CreateTranslation(x);

        return new c3d.BodyArrayOptions(transform2, transform1, num2, num1);
    }
}

function transformTemporary(item: visual.Item, mat: THREE.Matrix4) {
    item.matrixAutoUpdate = false;
    item.matrix.copy(mat);
    item.matrix.decompose(item.position, item.quaternion, item.scale);
    item.updateMatrixWorld(true);
    return item;
}