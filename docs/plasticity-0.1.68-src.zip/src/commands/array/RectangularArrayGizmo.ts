import { Mode } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { DistanceGizmo } from "../../command/MiniGizmos";
import { CancellablePromise } from "../../util/CancellablePromise";
import { Y } from "../../util/Constants";
import { RectangularArrayParams } from "./ArrayFactory";

export class RectangularArrayGizmo extends CompositeGizmo<RectangularArrayParams> {
    private readonly distance1Gizmo = new ExtrudeDistanceGizmo("array:distance1", this.editor);
    private readonly distance2Gizmo = new ExtrudeDistanceGizmo("array:distance1", this.editor);

    protected prepare(mode: Mode) {
        const { distance1Gizmo, distance2Gizmo, params } = this;

        distance1Gizmo.relativeScale.setScalar(0.8);
        distance1Gizmo.value = params.distance1;
        distance1Gizmo.quaternion.setFromUnitVectors(Y, params.dir1);

        distance2Gizmo.relativeScale.setScalar(0.8);

        this.add(distance1Gizmo, distance2Gizmo);
    }

    execute(cb: (params: RectangularArrayParams) => void, finishFast: Mode = Mode.Persistent): CancellablePromise<void> {
        const { distance1Gizmo, distance2Gizmo, params } = this;

        this.addGizmo(distance1Gizmo, length => {
            params.distance1 = length;
        });

        this.addGizmo(distance2Gizmo, length => {
            params.distance2 = length;
        }, false);

        return super.execute(cb, finishFast);
    }

    addDistance2() {
        const { distance2Gizmo, params } = this;

        distance2Gizmo.quaternion.setFromUnitVectors(Y, params.dir2);
        if (distance2Gizmo.stateMachine !== undefined)
            distance2Gizmo.stateMachine.isEnabled = true;
    }

    render(params: RectangularArrayParams) {
        const { distance1Gizmo, distance2Gizmo } = this;

        distance1Gizmo.value = params.distance1;
        distance2Gizmo.value = params.distance2;

        distance1Gizmo.quaternion.setFromUnitVectors(Y, params.dir1);
        distance2Gizmo.quaternion.setFromUnitVectors(Y, params.dir2);

        if (distance2Gizmo.stateMachine !== undefined) {
            distance2Gizmo.stateMachine.isEnabled = params.num2 > 1;
        }
    }

    get shouldRescaleOnZoom() { return false }
}

class ExtrudeDistanceGizmo extends DistanceGizmo {
    protected minShaft = 0;

    onInterrupt(cb: (radius: number) => void) {
        this.state.push();
    }

    onEnabled() { this.visible = true }
    onDisabled() { this.visible = false }
}
