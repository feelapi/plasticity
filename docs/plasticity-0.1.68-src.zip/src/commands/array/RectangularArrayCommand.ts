import * as THREE from "three";
import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { computeCentroid } from "../../util/Util";
import { RectangularArrayFactory } from "./ArrayFactory";
import { ArrayKeyboardGizmo } from "./ArrayKeyboardGizmo";
import { RectangularArrayDialog } from "./RectangularArrayDialog";
import { RectangularArrayGizmo } from "./RectangularArrayGizmo";

export class RectangularArrayCommand extends Command {
    async execute(): Promise<void> {
        const array = new RectangularArrayFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        array.num1 = 8;
        array.num2 = 1;

        const dialog = new RectangularArrayDialog(array, this.editor.signals);
        const gizmo = new RectangularArrayGizmo(array, this.editor);

        dialog.execute(async params => {
            array.update();
            gizmo.render(array);
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const selected = await dialog.prompt("Select solids or curves", () => {
            const objectPicker = new ObjectPicker(this.editor);
            objectPicker.copy(this.editor.selection);
            const min = 1 - objectPicker.selection.selected.curves.size - objectPicker.selection.selected.shells.size;
            return objectPicker.execute(() => { }, min, Number.MAX_SAFE_INTEGER).resource(this)
        })();
        array.items = [...selected.shells, ...selected.curves];

        const centroid = computeCentroid(array.items);

        const step1 = new THREE.Vector3();
        const pointPicker1 = new PointPicker(this.editor);
        await pointPicker1.addAxesAt(centroid, this.editor.activeViewport!.constructionPlane.orientation);
        await dialog.prompt("Select endpoint 1", () => {
            return pointPicker1.execute(async ({ point, info: { constructionPlane } }) => {
                step1.copy(point).sub(centroid);
                array.distance1 = step1.length();
                array.distance2 = step1.length();
                array.dir1 = step1.normalize();
                array.dir2 = constructionPlane.n.clone().cross(step1).normalize();
                await array.update();
                dialog.render();
                gizmo.render(array);
            }).resource(this);
        })();

        gizmo.position.copy(centroid);
        gizmo.execute(async params => {
            array.update();
            dialog.render();
        }).resource(this);

        const step2 = new THREE.Vector3();
        const pointPicker2 = new PointPicker(this.editor);
        await pointPicker2.addAxesAt(centroid, this.editor.activeViewport!.constructionPlane.orientation);
        dialog.prompt("Select endpoint 2", () => {
            return pointPicker2.execute(async ({ point, info: { constructionPlane } }) => {
                step2.copy(point).sub(centroid);
                array.distance2 = step2.length();
                array.dir2 = step2.normalize();
                if (array.num2 === 1) array.num2 = Math.max(2, array.num1);
                await array.update();
                dialog.render();
                gizmo.render(array);
            }).resource(this);
        });

        const keyboard = new ArrayKeyboardGizmo(this.editor);
        keyboard.execute(e => {
            switch (e) {
                case 'add':
                    array.num1++;
                    break;
                case 'subtract':
                    array.num1--;
                    break;
            }
            dialog.render();
            array.update();
        }).resource(this);

        await this.finished;

        const items = await array.commit();
        this.editor.selection.selected.add(items);
    }
}
