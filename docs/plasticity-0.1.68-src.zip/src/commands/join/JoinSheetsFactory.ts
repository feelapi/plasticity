import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import { derive } from '../../command/FactoryBuilder';

export class JoinSheetsFactory extends GeometryFactory<c3d.Sheet | c3d.Solid, visual.Sheet | visual.Solid, []> {
    protected _sheets!: { views: visual.Sheet[]; models: c3d.Sheet[]; };
    @derive([visual.Sheet]) get sheets(): visual.Sheet[] { throw ''; }
    set sheets(sheets: visual.Sheet[] | c3d.Sheet[]) { }

    async calculate() {
        const { _sheets: { models: sheets } } = this;
        if (sheets.length < 2) throw new NoOpError();
        const options = new c3d.SewBodiesOptions();
        const { sewn, unsewn } = await c3d.RegionBody.Sew_async(sheets, options);
        return [...sewn, ...unsewn];
    }

    get originalItems() { return this.sheets }
}

export class ExplodeShellsFactory extends GeometryFactory<c3d.Shell, visual.Shell, []> {
    protected _shells!: { views: visual.Shell[]; models: c3d.Shell[]; };
    @derive([visual.Shell]) get shells(): visual.Shell[] { throw ''; }
    set shells(shells: visual.Shell[] | c3d.Shell[]) { }

    async calculate() {
        const { _shells: { models: shells } } = this;
        const results: c3d.Sheet[][] = [];
        for (const shell of shells) {
            results.push(shell.Explode());
        }
        return results.flat();
    }

    get originalItems() { return this.shells }
}