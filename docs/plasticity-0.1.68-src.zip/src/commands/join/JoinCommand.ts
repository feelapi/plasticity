import Command from "../../command/Command";
import { ExplodeCurvesFactory, JoinCurvesFactory } from './JoinCurvesFactory';
import { ExplodeShellsFactory, JoinSheetsFactory } from "./JoinSheetsFactory";

export class JoinCommand extends Command {
    async execute(): Promise<void> {
        const selected = this.editor.selection.selected;
        if (selected.curves.size > 0) {
            const command = new JoinCurvesCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.sheets.size > 0) {
            const command = new JoinSheetsCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        }
    }
}

export class JoinCurvesCommand extends Command {
    async execute(): Promise<void> {
        const join = new JoinCurvesFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        join.curves = [...this.editor.selection.selected.curves];
        const results = await join.commit();
        this.editor.selection.selected.add(results);
    }
}

export class JoinSheetsCommand extends Command {
    async execute(): Promise<void> {
        const join = new JoinSheetsFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        join.sheets = [...this.editor.selection.selected.sheets];
        const results = await join.commit();
        this.editor.selection.selected.add(results);
    }
}

export class ExplodeCommand extends Command {
    async execute(): Promise<void> {
        const selected = this.editor.selection.selected;
        if (selected.curves.size > 0) {
            const command = new ExplodeCurvesCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.shells.size > 0) {
            const command = new ExplodeShellsCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        }
    }
}

export class ExplodeCurvesCommand extends Command {
    async execute(): Promise<void> {
        const explode = new ExplodeCurvesFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        explode.curves = [...this.editor.selection.selected.curves];
        const results = await explode.commit();
        this.editor.selection.selected.add(results);
    }
}

export class ExplodeShellsCommand extends Command {
    async execute(): Promise<void> {
        const explode = new ExplodeShellsFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        explode.shells = [...this.editor.selection.selected.shells];
        const results = await explode.commit();
        this.editor.selection.selected.add(results);
    }
}