import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import { derive } from '../../command/FactoryBuilder';

export class JoinCurvesFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance, []> {
    protected _curves!: { views: visual.SpaceInstance[]; models: c3d.Wire[]; };
    @derive([visual.SpaceInstance]) get curves(): visual.SpaceInstance[] { throw ''; }
    set curves(curves: visual.SpaceInstance[] | c3d.Wire[]) { }

    async calculate(): Promise<c3d.Wire[]> {
        const { _curves: { models: curves } } = this;
        if (curves.length < 2) throw new NoOpError();
        const allEdges = curves.map(m => m.GetEdges().GetEdges()).flat();
        const options = new c3d.WireBodyCreateFromEdgesOptions();
        const { wires } = await c3d.Wire.CreateFromEdges_async(allEdges, options);
        return wires;
    }

    get originalItems() { return this.curves }
}

export class ExplodeCurvesFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance, []> {
    protected _curves!: { views: visual.SpaceInstance[]; models: c3d.Wire[]; };
    @derive([visual.SpaceInstance]) get curves(): visual.SpaceInstance[] { throw ''; }
    set curves(curves: visual.SpaceInstance[] | c3d.Wire[]) { }

    async calculate(): Promise<c3d.Wire[]> {
        const { _curves: { models: curves } } = this;
        const results = [];
        for (const curve of curves){
            results.push(curve.Explode());
        }
        return results.flat();
    }

    get originalItems() { return this.curves }
}
