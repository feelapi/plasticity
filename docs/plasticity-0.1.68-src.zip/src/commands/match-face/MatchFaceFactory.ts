import { delegate, derive } from '../../command/FactoryBuilder';
import { MultiplyableFactory } from '../../command/MultiFactory';
import { Database } from '../../editor/db/Database';
import { EditorSignals } from '../../editor/EditorSignals';
import MaterialDatabase from '../../editor/MaterialDatabase';
import * as c3d from '../../kernel/kernel';
import * as visual from "../../visual_model/VisualModel";
import { ModifyFaceFactory } from '../offset-face/ModifyFaceFactory';
import { MultiModifyFaceFactory } from '../offset-face/MultiModifyFaceFactory';

export interface MatchFaceParams {
    grow: c3d.FaceGrowType;
    sense: boolean;
}

export class MatchFaceFactory extends ModifyFaceFactory implements MatchFaceParams, MultiplyableFactory<c3d.Shell, visual.Shell> {
    sense = false;

    private _replacement!: { view: visual.Face, model: c3d.Face };
    @derive(visual.Face) get replacement(): visual.Face { throw '' }
    set replacement(replacement: visual.Face | c3d.Face) { }

    async calculate() {
        const { _shell: { model: shell }, _faces: { models: faces }, _replacement: { model: replacement }, sense } = this;
        const options = new c3d.FaceChangeOptions(this.grow);
        const { surface } = replacement.GetSurface();
        const operation = new c3d.FaceChangeReplaceOperation(surface, sense);
        const tracking = await shell.ReplaceFaces_async(faces, operation, options);
        this.tracking = tracking;
        return shell;
    }

    override get originalItems() { return super.originalItems }
    override calculatePhantoms(partition: c3d.Partition) { return super.calculatePhantoms(partition) }
}


export default class MultiMatchFaceFactory extends MultiModifyFaceFactory<MatchFaceFactory> implements MatchFaceParams {
    @delegate replacement!: visual.Face;
    @delegate.default(false) sense!: boolean;

    protected makeFactory(db: Database, materials: MaterialDatabase, signals: EditorSignals): MatchFaceFactory {
        return new MatchFaceFactory(db, materials, signals);
    }
}