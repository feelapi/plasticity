import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import * as c3d from '../../kernel/kernel';
import { MatchFaceParams } from "./MatchFaceFactory";

export class MatchFaceDialog extends AbstractDialog<MatchFaceParams> {
    name = "Match face";

    constructor(protected readonly params: MatchFaceParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { grow, sense } = this.params;

        render(
            <>
                <ol>
                    <plasticity-prompt name="Select surface" description="to replace with"></plasticity-prompt>
                </ol>
                <ul>
                    <li>
                        <label for="grow">Grow</label>
                        <div class="fields">
                            <input type="radio" hidden name="grow" id="moving" value={c3d.FaceGrowType.Moving} checked={grow === c3d.FaceGrowType.Moving} onClick={this.onChange}></input>
                            <label for="moving">Moving</label>

                            <input type="radio" hidden name="grow" id="fixed" value={c3d.FaceGrowType.Fixed} checked={grow === c3d.FaceGrowType.Fixed} onClick={this.onChange}></input>
                            <label for="fixed">Fixed</label>

                            <input type="radio" hidden name="grow" id="none" value={c3d.FaceGrowType.None} checked={grow === c3d.FaceGrowType.None} onClick={this.onChange}></input>
                            <label for="none">None</label>
                        </div>
                    </li>
                    <li>
                        <label for="sense">Side</label>
                        <div class="fields">
                            <input type="checkbox" hidden id="sense" name="sense" checked={sense} onClick={this.onChange}></input>
                            <label for="sense">Front</label>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('replace-face-dialog', MatchFaceDialog);
