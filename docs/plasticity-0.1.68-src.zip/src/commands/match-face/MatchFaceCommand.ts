import * as THREE from "three";
import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { SelectionMode } from "../../selection/SelectionModeSet";
import { MatchFaceDialog } from "./MatchFaceDialog";
import MultiMatchFaceFactory from "./MatchFaceFactory";

export class MatchFaceCommand extends Command {
    point?: THREE.Vector3;

    async execute(): Promise<void> {
        const { editor: { selection, selection: { selected }, db, materials, signals } } = this;

        const replace = new MultiMatchFaceFactory(db, materials, signals).resource(this);
        replace.faces = [...selected.faces];

        const dialog = new MatchFaceDialog(replace, signals);

        dialog.execute(async params => {
            await replace.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        GetFaces: {
            const objectPicker = new ObjectPicker(this.editor);

            const replacement = await dialog.prompt("Select surface", () => {
                return objectPicker.shift(SelectionMode.Face).resource(this);
            })();
            replace.replacement = replacement.first;
            await replace.update();

            dialog.replace("Select surface", () => {
                const objectPicker = new ObjectPicker(this.editor);
                return objectPicker.execute(delta => {
                    replace.replacement = objectPicker.selection.selected.faces.first;
                    replace.update();
                }, 1, 1, SelectionMode.Face).resource(this);
            });
        }

        await this.finished;

        await replace.commit();
        const newFaces = replace.selection;
        selection.selected.add(newFaces);
    }
}

