import Command, { EditorLike } from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { DisableOptions } from "../../editor/db/Database";
import { AxisSnap } from "../../editor/snaps/AxisSnap";
import { ModifiesSelection } from "../../selection/SelectionDatabase";
import { SelectionMode } from "../../selection/SelectionModeSet";
import { PhantomLineFactory } from '../line/LineFactory';
import { MirrorDialog } from "./MirrorDialog";
import { MirrorFactory, MultiSymmetryFactory, SymmetryFactory } from "./MirrorFactory";
import { MirrorGizmo } from "./MirrorGizmo";
import { FreestyleMirrorKeyboardGizmo, MirrorKeyboardGizmo } from "./MirrorKeyboardGizmo";

export class MirrorCommand extends Command {
    async execute(): Promise<void> {
        const mirror = MakeMirrorFactory(this.editor, this.editor.selection.selected).resource(this);

        const gizmo = new MirrorGizmo(mirror, this.editor);
        const dialog = new MirrorDialog(mirror, this.editor.signals);
        const keyboard = new MirrorKeyboardGizmo(this.editor);

        dialog.execute(async (params) => {
            await mirror.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        gizmo.execute(s => {
            mirror.update();
        }).resource(this);
        gizmo.position.copy(this.editor.activeViewport!.constructionPlane.p);
        gizmo.quaternion.copy(this.editor.activeViewport!.constructionPlane.orientation);

        keyboard.execute(async (s) => {
            switch (s) {
                case 'free':
                    this.cancel();
                    const command = new FreestyleMirrorCommand(this.editor);
                    command.agent = this.agent;
                    this.editor.exec(command);
                    break;
                case 'union':
                    mirror.shouldUnion = !mirror.shouldUnion;
                    await mirror.update();
                    dialog.render();
                    break;
            }
        }).resource(this);

        const objectPicker = new ObjectPicker(this.editor);
        objectPicker.execute(async delta => {
            const selection = objectPicker.selection.selected;
            if (selection.faces.size === 0) return;
            mirror.move = 0;
            mirror.face = selection.faces.first;
            gizmo.render(mirror);
            mirror.update();
        }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Face).resource(this);

        await this.finished;

        const result = await mirror.commit();
        this.editor.selection.selected.add(result);
    }
}

export class FreestyleMirrorCommand extends Command {
    async execute(): Promise<void> {
        const mirror = MakeMirrorFactory(this.editor, this.editor.selection.selected).resource(this);

        const dialog = new MirrorDialog(mirror, this.editor.signals);
        const keyboard = new FreestyleMirrorKeyboardGizmo(this.editor);

        dialog.execute(async (params) => {
            await mirror.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const pointPicker = new PointPicker(this.editor);
        pointPicker.straightSnaps.delete(AxisSnap.Z);
        const { point: p1, info: { constructionPlane } } = await pointPicker.execute().resource(this);
        pointPicker.restrictToPlaneThroughPoint(p1);

        mirror.origin.copy(p1);

        const line = new PhantomLineFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        line.p1 = p1;

        await pointPicker.execute(({ point: p2 }) => {
            line.p2 = p2;
            line.update();

            mirror.normal.copy(p2).sub(p1).cross(constructionPlane.n).normalize();
            mirror.update();
        }).resource(this);

        line.cancel();

        keyboard.execute(async (s) => {
            switch (s) {
                case 'union':
                    mirror.shouldUnion = !mirror.shouldUnion;
                    await mirror.update();
                    dialog.render();
                    break;
            }
        }).resource(this);

        await this.finished;

        await mirror.commit();
    }
}

function MakeMirrorFactory(editor: EditorLike, selected: ModifiesSelection) {
    let mirror: SymmetryFactory | MultiSymmetryFactory | MirrorFactory;
    if (selected.shells.size > 0) {
        mirror = new MultiSymmetryFactory(editor.db, editor.materials, editor.signals);
        mirror.shells = [...selected.shells];
        editor.db.disable(mirror.shells, DisableOptions.KeepPointSnaps);
        return mirror;
    } else if (selected.curves.size > 0) {
        mirror = new MirrorFactory(editor.db, editor.materials, editor.signals);
        mirror.items = [...selected.curves];
        editor.db.disable(mirror.items, DisableOptions.KeepPointSnaps);
        return mirror;
    } else {
        throw new Error("Invalid selection");
    }
}