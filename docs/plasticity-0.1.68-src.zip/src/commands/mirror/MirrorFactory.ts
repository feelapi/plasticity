import * as THREE from "three";
import { delegate, derive } from "../../command/FactoryBuilder";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import { MultiGeometryFactory } from "../../command/MultiFactory";
import { MaterialOverride } from "../../editor/DatabaseLike";
import * as c3d from '../../kernel/kernel';
import { Z } from "../../util/Constants";
import { point2point, vec2vec } from '../../util/Conversion';
import { VectorProxy } from "../../util/VectorProxy";
import * as visual from '../../visual_model/VisualModel';
import { phantom_red } from "../boolean/BooleanFactory";

export interface MirrorParams {
    shouldCut: boolean;
    shouldUnion: boolean;
    get origin(): THREE.Vector3;
    get normal(): THREE.Vector3;
    face: visual.Face;
    move: number;
}

// NOTE: This class works with more than just shells, whereas the others don't.
export class MirrorFactory extends GeometryFactory<c3d.Body, visual.Item, []> implements MirrorParams {
    readonly origin = new THREE.Vector3();
    readonly normal = new THREE.Vector3();
    shouldCut = true;
    shouldUnion = false;
    move = 0;

    protected _items!: { views: visual.Item[]; models: c3d.Body[]; };
    @derive([visual.Item]) get items(): visual.Item[] { throw ''; }
    set items(items: visual.Item[] | c3d.Body[]) { }

    set face(face: visual.Face) {
        const model = this.db.lookupTopologyItem(face);
        const { u, v, position } = model.GetAnyPointOn();
        const { normal } = model.EvalBasis(u, v);
        this.origin.copy(point2point(position));
        this.normal.copy(vec2vec(normal, 1));
    }

    async calculate() {
        const { origin, normal, move, _items: { models: items } } = this;
        if (origin === undefined || normal === undefined) throw new NoOpError();

        const options = new c3d.TransformOptions();
        const result = items.map(async item => {
            const offset = origin.clone().add(normal.clone().multiplyScalar(move))
            const mat = c3d.Transform.CreateReflection(point2point(offset), vec2vec(normal, 1));
            const copy = item.Copy();
            await copy.Transform_async(mat, options);
            // NOTE: this was added so that cuts of open curves that are mirrored have the same orientation as the original.
            if (copy instanceof c3d.Wire) copy.ReverseOrientation();
            return copy;
        });

        return Promise.all(result);
    }
}

export class SymmetryFactory extends GeometryFactory<c3d.Body, visual.Item, []> {
    readonly origin = new THREE.Vector3();
    readonly normal = new THREE.Vector3();
    shouldCut = true;
    shouldUnion = false;
    move = 0;

    private _shell!: { view: visual.Shell, model: c3d.Shell, bbox: THREE.Box3 };
    get shell(): visual.Shell { return this._shell.view }
    set shell(shell: visual.Shell) {
        const model = this.db.lookup(shell);
        const { min, max } = model.FindBox();
        this._shell = { view: shell, model, bbox: new THREE.Box3(point2point(min), point2point(max)) };
    }

    set face(face: visual.Face) {
        const model = this.db.lookupTopologyItem(face);
        const { u, v, position } = model.GetAnyPointOn();
        const { normal } = model.EvalBasis(u, v);
        this.origin.copy(point2point(position));
        this.normal.copy(vec2vec(normal, 1));
    }

    private async makeHalves(shell: c3d.Shell) {
        const { shouldCut } = this;
        let cutter = await this.makeCutter();

        let cut, toBeMirrored;
        if (shouldCut) {
            const params = new c3d.SectionOptions();
            const { front, back } = await shell.SectionWithSheet_async(cutter, params);
            cut = front[0] ?? back[0];
            toBeMirrored = cut.Copy();
        } else {
            cut = shell;
            toBeMirrored = shell.Copy();
        }

        const { z, offsetOrigin } = this.basis;
        const options = new c3d.TransformOptions();
        const mat = c3d.Transform.CreateReflection(point2point(offsetOrigin), vec2vec(z, 1));
        await toBeMirrored.Transform_async(mat, options);

        return { cutAndMirrored: toBeMirrored, cut };
    }

    async calculatePhantoms(partition: c3d.Partition) {
        const phantom = await this.makeCutter(partition)
        return [{ material: phantom_red, phantom }]
    }

    async calculate() {
        const { shouldCut, shouldUnion, _shell: { model: shell } } = this;

        const { cutAndMirrored, cut } = await this.makeHalves(shell);

        if (shouldCut && shouldUnion) {
            const options = new c3d.BooleanOptions(c3d.OperationType.Union);
            const unioned = await cut.Boolean_async([cutAndMirrored], options);
            return unioned;
        } else if (!shouldCut && !shouldUnion) return [cutAndMirrored]; // actually, its just mirrored in this case
        else if (shouldCut && !shouldUnion) return [cut, cutAndMirrored];
        else if (!shouldCut && shouldUnion) {
            const options = new c3d.BooleanOptions(c3d.OperationType.Union);
            const unioned = await cut.Boolean_async([cutAndMirrored], options);
            return unioned;
        } else throw new Error('unreachable');
    }

    override get materialOverride(): MaterialOverride { return phantom_blue }

    get shouldHideOriginalItemDuringUpdate(): boolean {
        return this.shouldCut || this.shouldUnion;
    }

    get shouldRemoveOriginalItemOnCommit(): boolean {
        return this.shouldCut || this.shouldUnion;
    }

    private readonly x = new THREE.Vector3();
    private readonly y = new THREE.Vector3();
    private readonly z = new THREE.Vector3();
    private readonly offsetOrigin = new THREE.Vector3();
    private readonly quaternion = new THREE.Quaternion();
    get basis() {
        const { normal, move, origin, } = this;

        const { x, y, z, offsetOrigin, quaternion } = this;
        quaternion.setFromUnitVectors(Z, normal);
        offsetOrigin.set(0, 0, move / 2).applyQuaternion(quaternion).add(origin);
        x.set(-1, 0, 0).applyQuaternion(quaternion).normalize();
        z.set(0, 0, 1).applyQuaternion(quaternion).normalize();

        y.crossVectors(x, z).normalize();
        return { x, y, z, offsetOrigin };
    }

    private placement = new c3d.Basis();
    private readonly p1 = new THREE.Vector3();
    private readonly p2 = new THREE.Vector3();
    private async makeCutter(partition = this.partition) {
        const { _shell: { bbox }, placement } = this;
        const { x, z, offsetOrigin } = this.basis;
        const { p1, p2 } = this;
        const planey = new THREE.Plane().setFromNormalAndCoplanarPoint(z, offsetOrigin);
        planey.projectPoint(bbox.min, p1);
        planey.projectPoint(bbox.max, p2);

        const distance1 = Math.ceil(offsetOrigin.manhattanDistanceTo(p1));
        const distance2 = Math.ceil(offsetOrigin.manhattanDistanceTo(p2));
        const distance3 = Math.ceil(bbox.min.manhattanDistanceTo(bbox.max));

        placement.Location.Set(offsetOrigin.x, offsetOrigin.y, offsetOrigin.z);
        placement.Axis.Set(z.x, z.y, z.z);
        placement.Ref.Set(x.x, x.y, x.z);
        const radius = Math.max(distance1, distance2, distance3);
        const sheet = partition.SheetBody.CreateCircle(radius, placement);

        // The parasolid API (I think!) does not guarantee the orientation of the sheet. So check if it's oriented with z.
        const faces = sheet.GetFaces();
        if (faces.Size() !== 1) throw new Error('expected 1 face');
        const face = faces.Get(0);
        const { normal } = face.EvalBasis(0.5, 0.5);
        if (vec2vec(normal, 1).dot(z) < 0) {
            sheet.ReverseOrientation();
        }

        return sheet;
    }

    get originalItems() { return [this.shell] }
}

export class MultiSymmetryFactory extends MultiGeometryFactory<SymmetryFactory, c3d.Body, visual.Item, []> implements MirrorParams {
    get items(): visual.Shell[] { return this.shells }
    private _shells!: visual.Shell[];
    get shells(): visual.Shell[] { return this._shells }
    set shells(shells: visual.Shell[]) {
        this._shells = shells;
        const factories = [];
        for (const shell of shells) {
            const factory = new SymmetryFactory(this.db, this.materials, this.signals);
            factory.shell = shell;
            factories.push(factory);
        }
        this.factories = factories;
    }

    readonly normal = new VectorProxy(axis => {
        this.factories.forEach(f => f.normal.copy(axis));
    });
    readonly origin = new VectorProxy(axis => {
        this.factories.forEach(f => f.origin.copy(axis));
    });


    @delegate move!: number;
    @delegate.default(true) shouldCut!: boolean;
    @delegate.default(false) shouldUnion!: boolean;

    @delegate.register
    set face(face: visual.Face) {
        const model = this.db.lookupTopologyItem(face);
        const { u, v, position } = model.GetAnyPointOn();
        const { normal } = model.EvalBasis(u, v);
        this.origin.copy(point2point(position));
        this.normal.copy(vec2vec(normal, 1));
    }

    get shouldHideOriginalItemDuringUpdate() { return this.shouldCut || this.shouldUnion }
    get shouldRemoveOriginalItemOnCommit() { return this.shouldCut || this.shouldUnion }

    override calculatePhantoms(partition: c3d.Partition) {
        return this.factories[0].calculatePhantoms(partition);
    }
}

const mesh_blue = new THREE.MeshBasicMaterial();
mesh_blue.color.setHex(0x0000ff);
mesh_blue.opacity = 0.1;
mesh_blue.transparent = true;
mesh_blue.fog = false;
mesh_blue.polygonOffset = true;
mesh_blue.polygonOffsetFactor = 0.1;
mesh_blue.polygonOffsetUnits = 1;

const phantom_blue: MaterialOverride = {
    mesh: mesh_blue
}
