import * as THREE from "three";
import { EditorLike, Mode } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { AngleGizmo } from "../../command/MiniGizmos";
import { CancellablePromise } from "../../util/CancellablePromise";
import { DraftFaceParams } from "./DraftFaceFactory";

export class DraftFaceGizmo extends CompositeGizmo<DraftFaceParams> {
    private readonly angle = new AngleGizmo("offset-face:angle", this.editor, this.editor.gizmos.white);

    constructor(params: DraftFaceParams, editor: EditorLike, private readonly hint?: THREE.Vector3) {
        super(params, editor);
    }

    prepare() {
        this.angle.relativeScale.setScalar(0.3);
        this.position.copy(this.params.origin);
    }

    execute(cb: (params: DraftFaceParams) => void, finishFast: Mode = Mode.Persistent): CancellablePromise<void> {
        const { angle, params } = this;

        this.add(angle);

        this.addGizmo(angle, angle => {
            params.angle = angle;
        });

        return super.execute(cb, finishFast);
    }
}