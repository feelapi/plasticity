import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import * as c3d from '../../kernel/kernel';
import { DraftFaceParams } from "./DraftFaceFactory";

export class DraftFaceDialog extends AbstractDialog<DraftFaceParams> {
    name = "Draft face";

    constructor(protected readonly params: DraftFaceParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { degrees, grow } = this.params;

        render(
            <>
                <ol>
                    <plasticity-prompt name="Select plane" description="as a reference"></plasticity-prompt>
                    <plasticity-prompt name="Select faces" description="to draft"></plasticity-prompt>
                </ol>
                <ul>
                    <li>
                        <label for="degrees">Degrees</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="degrees" value={degrees} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="grow">Grow</label>
                        <div class="fields">
                            <input type="radio" hidden name="grow" id="moving" value={c3d.FaceGrowType.Moving} checked={grow === c3d.FaceGrowType.Moving} onClick={this.onChange}></input>
                            <label for="moving">Moving</label>

                            <input type="radio" hidden name="grow" id="fixed" value={c3d.FaceGrowType.Fixed} checked={grow === c3d.FaceGrowType.Fixed} onClick={this.onChange}></input>
                            <label for="fixed">Fixed</label>

                            <input type="radio" hidden name="grow" id="none" value={c3d.FaceGrowType.None} checked={grow === c3d.FaceGrowType.None} onClick={this.onChange}></input>
                            <label for="none">None</label>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('draft-face-dialog', DraftFaceDialog);
