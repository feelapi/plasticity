import * as THREE from 'three';
import { delegate } from '../../command/FactoryBuilder';
import { NoOpError } from '../../command/GeometryFactory';
import { MultiplyableFactory } from '../../command/MultiFactory';
import { Database } from '../../editor/db/Database';
import { EditorSignals } from '../../editor/EditorSignals';
import MaterialDatabase from '../../editor/MaterialDatabase';
import * as c3d from '../../kernel/kernel';
import { X, Y } from '../../util/Constants';
import { point2point, vec2vec } from '../../util/Conversion';
import * as visual from "../../visual_model/VisualModel";
import { ModifyFaceFactory } from '../offset-face/ModifyFaceFactory';
import { MultiModifyFaceFactory } from "../offset-face/MultiModifyFaceFactory";

export interface DraftFaceParams {
    angle: number;
    degrees: number;
    get origin(): THREE.Vector3;
    grow: c3d.FaceGrowType;
}

export class DraftFaceFactory extends ModifyFaceFactory implements DraftFaceParams, MultiplyableFactory<c3d.Shell, visual.Shell> {
    readonly origin = new THREE.Vector3();
    readonly normal = new THREE.Vector3();
    angle = 0;

    set reference(reference: visual.Face) {
        const model = this.db.lookupTopologyItem(reference);
        const { u, v, position } = model.GetAnyPointOn();
        const { normal } = model.EvalBasis(u, v);
        this.origin.copy(point2point(position));
        this.normal.copy(vec2vec(normal, 1));
    }

    get degrees() { return THREE.MathUtils.radToDeg(this.angle) }
    set degrees(degrees: number) {
        this.angle = THREE.MathUtils.degToRad(degrees);
    }

    private readonly ref = new THREE.Vector3;
    async calculate() {
        const { _shell: { model: shell }, _faces: { models: faces }, angle, origin, normal } = this;
        const { ref } = this;
        if (Math.abs(angle) < 10e-4) throw new NoOpError();

        ref.copy(normal).cross(X);
        if (ref.lengthSq() < 10e-6) ref.copy(normal).cross(Y);
        ref.normalize();

        const options = new c3d.FaceChangeOptions(this.grow);
        const basis = new c3d.Basis(point2point(origin), vec2vec(normal, 1), vec2vec(ref, 1));
        const operation = new c3d.FaceChangeDraftOperation(angle, basis);
        const tracking = await shell.DraftFaces_async(faces, operation, options);
        this.tracking = tracking;
        return shell;
    }

    get selection() {
        const { state } = this.state;
        if (state.tag !== 'committed') throw new Error("invalid state");
        const shell = state.result;
        const ids = this.tracking.GetChangedFaces().GetIds();
        const names = [...ids].map(id => visual.Face.simpleName(shell.simpleName, id));
        return names.map(name => this.db.lookupTopologyItemById(name).view);
    }

    override get originalItems() { return super.originalItems }
    override calculatePhantoms(partition: c3d.Partition) { return super.calculatePhantoms(partition) }
}

export class MultiDraftFaceFactory extends MultiModifyFaceFactory<DraftFaceFactory> implements DraftFaceParams {
    @delegate.default(0) angle!: number;

    readonly origin = new THREE.Vector3();
    readonly normal = new THREE.Vector3();
    private _reference!: visual.Face;
    @delegate.register
    get reference() { return this._reference };
    set reference(reference: visual.Face) {
        this._reference = reference;
        const model = this.db.lookupTopologyItem(reference);
        const { u, v, position } = model.GetAnyPointOn();
        const { normal } = model.EvalBasis(u, v);
        this.origin.copy(point2point(position));
        this.normal.copy(vec2vec(normal, 1));
        for (const factory of this.factories) {
            factory.reference = reference;
        }
    }

    get degrees() { return THREE.MathUtils.radToDeg(this.angle) }
    set degrees(degrees: number) {
        this.angle = THREE.MathUtils.degToRad(degrees);
    }

    protected makeFactory(db: Database, materials: MaterialDatabase, signals: EditorSignals): DraftFaceFactory {
        return new DraftFaceFactory(db, materials, signals);
    }
}