import { Quasimode } from "../../command/Quasimode";
import * as THREE from "three";
import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { SelectionMode } from "../../selection/SelectionModeSet";
import { DraftFaceDialog } from "./DraftFaceDialog";
import { MultiDraftFaceFactory } from "./DraftFaceFactory";
import { DraftFaceGizmo } from "./DraftFaceGizmo";
import { CancellablePromise } from "../../util/CancellablePromise";
import { HasSelection } from "../../selection/SelectionDatabase";


export class DraftFaceCommand extends Command {
    point?: THREE.Vector3;

    async execute(): Promise<void> {
        const { editor: { selection, selection: { selected }, db, materials, signals } } = this;

        const draft = new MultiDraftFaceFactory(db, materials, signals).resource(this);

        const gizmo = new DraftFaceGizmo(draft, this.editor, this.point);
        const dialog = new DraftFaceDialog(draft, signals);

        dialog.execute(async (params) => {
            await draft.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const objectPicker = new ObjectPicker(this.editor);
        objectPicker.copy(this.editor.selection);

        GetNeutralPlane: {
            const plane = await dialog.prompt("Select plane", () => {
                return objectPicker.shift(SelectionMode.Face).resource(this);
            })();
            draft.reference = plane.first;
        }

        let g: CancellablePromise<void> | undefined;
        let p: CancellablePromise<HasSelection> | undefined;
        let q: CancellablePromise<void> | undefined;

        const stopPicker = () => { p?.finish(); p = undefined }
        const stopQuasimode = () => { q?.finish(); q = undefined }

        const startQuasimode = async () => {
            if (q !== undefined) return;
            const quasiPicker = new ObjectPicker(this.editor, objectPicker.selection, 'viewport-selector[quasimode]');
            const quasimode = new Quasimode("modify-selection", this.editor, draft);
            q = quasimode.execute(() =>
                quasiPicker.execute(delta => {
                    draft.faces = [...quasiPicker.selection.selected.faces];
                }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Face).resource(this)
            ).resource(this);
        };

        const startPicker = () => {
            if (p !== undefined) return;
            p = objectPicker.execute(async delta => {
                draft.faces = [...objectPicker.selection.selected.faces];
                draft.update();
            }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Face).resource(this);
            return p;
        }

        GetFaces: {
            const faces = await dialog.prompt("Select faces", () => {
                return objectPicker.slice(SelectionMode.Face, 1, Number.MAX_SAFE_INTEGER).resource(this);
            })();
            draft.faces = [...faces];

            dialog.replace("Select faces", () => {
                stopQuasimode();
                startPicker();
                return p!;
            }, () => {
                stopQuasimode();
                objectPicker.selection.selected.removeAll();
                draft.faces = [];
                draft.update();
            });
        }

        gizmo.execute(async (params) => {
            if (params.angle !== 0) {
                startQuasimode();
                stopPicker();
            }
            await draft.update();
            dialog.render();
        }).resource(this);

        await this.finished;

        await draft.commit();
        const newFaces = draft.selection;
        selection.selected.add(newFaces);
    }
}
