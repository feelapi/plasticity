import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { unit } from "../../util/Conversion";
import * as visual from '../../visual_model/VisualModel';

export interface ExtendSheetParams {
    distance: number;
    type: c3d.BodyExtensionType;
    shape: c3d.ExtensionShape;
    edges: visual.CurveEdge[];
}

export default class ExtendSheetFactory extends GeometryFactory implements ExtendSheetParams {
    distance = 0;
    type = c3d.BodyExtensionType.Distance;
    shape = c3d.ExtensionShape.Linear;

    protected _sheet!: { view: visual.Sheet, model: c3d.Sheet };
    @derive(visual.Sheet) get sheet(): visual.Sheet { throw '' }
    set sheet(sheet: visual.Sheet | c3d.Sheet) { }

    protected _edges!: { views: visual.CurveEdge[]; models: c3d.Edge[]; };
    @derive([visual.CurveEdge]) get edges(): visual.CurveEdge[] { throw ''; }
    set edges(edges: visual.CurveEdge[] | c3d.Edge[]) { }

    async calculate() {
        const { _sheet: { model: sheet }, _edges: { models: edges }, type, shape, distance } = this;

        if (Math.abs(distance) < 1e-5) throw new NoOpError();

        const options = new c3d.SheetBodyExtendOptions();
        // @ts-expect-error
        options.Shape = shape;
        options.Distance = unit(distance);

        await sheet.Extend_async(edges, options);
        return sheet;
    }

    get originalItem() { return this.sheet }
}
