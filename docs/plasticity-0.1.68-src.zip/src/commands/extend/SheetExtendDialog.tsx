import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import * as c3d from '../../kernel/kernel';
import { ExtendSheetParams } from "./ExtendSheetFactory";

export class ExtendSheetDialog extends AbstractDialog<ExtendSheetParams> {
    name = "Extend sheet";

    constructor(protected readonly params: ExtendSheetParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { distance, shape, type } = this.params;

        render(
            <>
                <ul>
                    <li>
                        <label for="shape">Shape</label>

                        <div class="fields">
                            <input type="radio" hidden name="shape" id="linear" value={c3d.ExtensionShape.Linear} checked={shape === c3d.ExtensionShape.Linear} onClick={this.onChange}></input>
                            <label class="btn" for="linear">Linear</label>

                            <input type="radio" hidden name="shape" id="soft" value={c3d.ExtensionShape.Soft} checked={shape === c3d.ExtensionShape.Soft} onClick={this.onChange}></input>
                            <label class="btn" for="soft">Soft</label>

                            <input type="radio" hidden name="shape" id="reflective" value={c3d.ExtensionShape.Reflective} checked={shape === c3d.ExtensionShape.Reflective} onClick={this.onChange}></input>
                            <label class="btn" for="reflective">Reflective</label>
                        </div>
                    </li>
                    <li>
                        <label for="distance">Distance</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="distance" value={distance} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('extend-sheet-dialog', ExtendSheetDialog);
