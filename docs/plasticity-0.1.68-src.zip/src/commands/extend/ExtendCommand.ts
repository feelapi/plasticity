import Command from "../../command/Command";
import { ExtendSheetDialog } from "./SheetExtendDialog";
import ExtendSheetFactory from "./ExtendSheetFactory";
import { ExtendSheetGizmo } from "./ExtendSheetGizmo";
import * as visual from '../../visual_model/VisualModel';

export class ExtendCommand extends Command {
    point?: THREE.Vector3;

    async execute(): Promise<void> {
        const extension = new ExtendSheetFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        const edge = this.editor.selection.selected.edges.first;
        const sheet = edge.parentItem as visual.Sheet;
        extension.sheet = sheet;
        extension.edges = [...this.editor.selection.selected.edges];

        const dialog = new ExtendSheetDialog(extension, this.editor.signals);
        const gizmo = new ExtendSheetGizmo(extension, this.editor, this.point);

        dialog.execute(async (params) => {
            await extension.update();
            gizmo.render(params.distance);
        }).resource(this).then(() => this.finish(), () => this.cancel());

        gizmo.execute(params => {
            extension.update();
            dialog.render();
        }).resource(this);

        await this.finished;

        const result = await extension.commit();
        this.editor.selection.selected.add(result);
    }
}
