import * as THREE from "three";
import { Line2 } from "three/examples/jsm/lines/Line2";
import { EditorLike, Mode } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { AbstractAxisGizmo, AxisHelper, CompositeHelper, lineGeometry, MagnitudeStateMachine, NumberHelper, sphereGeometry } from "../../command/MiniGizmos";
import { CancellablePromise } from "../../util/CancellablePromise";
import { Y } from "../../util/Constants";
import { point2point, vec2vec } from "../../util/Conversion";
import { Helper } from "../../util/Helpers";
import { ExtendSheetParams } from "./ExtendSheetFactory";

export class ExtendSheetGizmo extends CompositeGizmo<ExtendSheetParams> {
    private readonly main = new FilletMagnitudeGizmo("extend-sheet:distance", this.editor);

    constructor(params: ExtendSheetParams, editor: EditorLike, private readonly hint?: THREE.Vector3) {
        super(params, editor);
    }

    prepare() {
        const { main } = this;
        const { point, normal } = this.placement(this.hint);

        main.quaternion.setFromUnitVectors(Y, normal);
        main.position.copy(point);

        main.relativeScale.setScalar(0.8);

        this.add(main);
    }

    execute(cb: (params: ExtendSheetParams) => void): CancellablePromise<void> {
        const { main, params } = this;

        this.addGizmo(main, length => {
            params.distance = length;
        });

        return super.execute(cb, Mode.Persistent);
    }

    render(length: number) {
        this.main.render(length * Math.tan(Math.PI / 4));
    }

    private placement(hint?: THREE.Vector3): { point: THREE.Vector3, normal: THREE.Vector3 } {
        const { params: { edges }, editor: { db } } = this;
        const models = edges.map(view => db.lookupTopologyItem(view));
        const curveEdge = models[models.length - 1];
        const faces = curveEdge.GetFaces();
        if (faces.Size() !== 1) throw new Error("expected one face");
        const face = faces.GetFaces()[0];

        let basis, tangent, position;
        if (hint !== undefined) {
            const { t, exact } = curveEdge.FindPointNear(point2point(hint));
            position = exact;
            tangent = curveEdge.EvalBasis(t).tangent;
            const { u, v } = face.FindPointNear(point2point(hint));
            basis = face.EvalBasis(u, v);
        } else {
            position = curveEdge.GetPoint(0.5);
            tangent = curveEdge.EvalBasis(0.5).tangent;
            const { u, v, exact } = face.FindPointNear(position);
            basis = face.EvalBasis(u, v);
        }

        const normal = vec2vec(basis.normal, 1);
        normal.cross(vec2vec(tangent, 1));
        normal.multiplyScalar(-1);

        return { point: point2point(position), normal };
    }

    get shouldRescaleOnZoom() { return false }
}

export class FilletMagnitudeGizmo extends AbstractAxisGizmo {
    readonly state = new MagnitudeStateMachine(0);
    protected material = this.editor.gizmos.default;
    readonly helper = new CompositeHelper([new AxisHelper(this.material.line), new NumberHelper()]);
    readonly tip = new THREE.Mesh(sphereGeometry, this.material.mesh);
    protected readonly shaft = new THREE.Mesh();
    protected readonly knob = new THREE.Mesh(new THREE.SphereGeometry(0.2), this.editor.gizmos.invisible);
    private readonly line = new Line2(lineGeometry, this.material.line2);

    constructor(name: string, editor: EditorLike) {
        super(name, editor);
        this.setup();
        this.add(this.helper);
        this.tip.add(this.line);
        this.line.position.set(0, - 0.5, 0);
    }

    onInterrupt(cb: (radius: number) => void) {
        this.state.push();
    }

    render(length: number) {
        this.tip.position.set(0, length, 0);
        this.knob.position.copy(this.tip.position);
    }

    protected accumulate(original: number, sign: number, dist: number): number {
        return original + dist
    }


    protected override scaleIndependentOfZoom(camera: THREE.Camera) {
        // Rather than scaling the parent, we scale the children, so that the position (set in render)
        // is in world space
        this.tip.scale.copy(this.relativeScale);
        this.knob.scale.copy(this.relativeScale);
        this.helper.scale.copy(this.relativeScale);
        Helper.scaleIndependentOfZoom(this.tip, camera, this.worldPosition);
        Helper.scaleIndependentOfZoom(this.knob, camera, this.worldPosition);
        Helper.scaleIndependentOfZoom(this.helper, camera, this.worldPosition);
    }
}