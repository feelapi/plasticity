import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { freeze } from '../../util/Constants';
import * as visual from '../../visual_model/VisualModel';

export const GrowTypes = freeze([c3d.FaceGrowType.Moving, c3d.FaceGrowType.Fixed, c3d.FaceGrowType.None]);

export interface ModifyFaceParams {
    grow: c3d.FaceGrowType;
}

export abstract class ModifyFaceFactory extends GeometryFactory<c3d.Shell, visual.Shell> {
    protected _shell!: { view: visual.Shell; model: c3d.Shell; };
    @derive(visual.Shell) get shell(): visual.Shell { throw ''; }
    set shell(shell: visual.Shell | c3d.Shell) { }

    protected _faces!: { views: visual.Face[]; models: c3d.Face[]; };
    @derive([visual.Face]) get faces(): visual.Face[] { throw ''; }
    set faces(faces: visual.Face[] | c3d.Face[]) { }

    get originalItem() { return this.shell }

    grow = c3d.FaceGrowType.Moving;
    toggle() {
        let index = GrowTypes.indexOf(this.grow);
        index = (index + 1) % GrowTypes.length;
        this.grow = GrowTypes[index];
    }

    tracking!: c3d.FaceChangeTrackRecord;
    get selection() {
        const { state } = this.state;
        if (state.tag !== 'committed') throw new Error("invalid state");
        const shell = state.result;
        const ids = this.tracking.GetChangedFaces().GetIds();
        const names = [...ids].map(id => visual.Face.simpleName(shell.simpleName, id));
        return names.map(name => this.db.lookupTopologyItemById(name).view);
    }
}
