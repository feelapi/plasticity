import { render } from 'preact';
import { EditorSignals } from "../../editor/EditorSignals";
import { AbstractDialog } from "../../command/AbstractDialog";
import { OffsetFaceParams } from "./OffsetFaceFactory";
import { Agent } from '../../editor/DatabaseLike';
import * as c3d from '../../kernel/kernel';

export class OffsetFaceDialog extends AbstractDialog<OffsetFaceParams> {
    name = "Offset face";

    constructor(protected readonly params: OffsetFaceParams, private readonly agent: Agent, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { agent } = this;
        const { distance, degrees, grow } = this.params;

        render(
            <>
                <ul>
                    {agent === 'user' &&
                        <ol>
                            <plasticity-prompt name="Select edges" description="to fillet or chamfer"></plasticity-prompt>
                        </ol>
                    }
                    <li>
                        <label for="distance">Distance</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="distance" value={distance} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="degrees">Degrees</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="degrees" value={degrees} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="grow">Grow</label>
                        <div class="fields">
                            <input type="radio" hidden name="grow" id="moving" value={c3d.FaceGrowType.Moving} checked={grow === c3d.FaceGrowType.Moving} onClick={this.onChange}></input>
                            <label for="moving">Moving</label>

                            <input type="radio" hidden name="grow" id="fixed" value={c3d.FaceGrowType.Fixed} checked={grow === c3d.FaceGrowType.Fixed} onClick={this.onChange}></input>
                            <label for="fixed">Fixed</label>

                            <input type="radio" hidden name="grow" id="none" value={c3d.FaceGrowType.None} checked={grow === c3d.FaceGrowType.None} onClick={this.onChange}></input>
                            <label for="none">None</label>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('offset-face-dialog', OffsetFaceDialog);
