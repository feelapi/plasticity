import { CommandKeyboardInput, EditorLike } from "../../command/CommandKeyboardInput";

export class ChangeFaceKeyboardGizmo  extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('move', editor, [
            'keyboard:change-face:toggle',
        ]);
    }
}
