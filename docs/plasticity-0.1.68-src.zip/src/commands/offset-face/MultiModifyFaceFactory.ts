import { delegate } from '../../command/FactoryBuilder';
import { groupBy, MultiGeometryFactory, MultiplyableFactory } from '../../command/MultiFactory';
import { Database } from '../../editor/db/Database';
import { EditorSignals } from '../../editor/EditorSignals';
import MaterialDatabase from '../../editor/MaterialDatabase';
import * as c3d from '../../kernel/kernel';
import * as visual from "../../visual_model/VisualModel";
import { GrowTypes, ModifyFaceFactory } from './ModifyFaceFactory';


export abstract class MultiModifyFaceFactory<T extends ModifyFaceFactory & MultiplyableFactory<c3d.Shell, visual.Shell>> extends MultiGeometryFactory<T, c3d.Shell, visual.Shell> {
    @delegate.default(c3d.FaceGrowType.Moving) grow!: c3d.FaceGrowType;
    toggle() {
        let index = GrowTypes.indexOf(this.grow);
        index = (index + 1) % GrowTypes.length;
        this.grow = GrowTypes[index];
    }

    protected _faces!: { views: visual.Face[]; models: c3d.Face[]; };
    @delegate.update
    get faces() { return this._faces.views; }
    set faces(faces: visual.Face[]) {
        const { db } = this;
        for (const factory of this.factories)
            factory.cancel();
        this._faces = { views: faces, models: faces.map(face => db.lookupTopologyItem(face)) };
        const individuals = [];
        const map = groupBy('parentItem', faces);
        for (const [shell, faces] of map.entries()) {
            const individual = this.makeFactory(this.db, this.materials, this.signals);
            individual.shell = shell;
            individual.faces = faces;
            individuals.push(individual);
        }
        this.factories = individuals;
    }

    get shells() {
        return this.factories.map(f => f.shell);
    }

    override async calculate() {
        const { factories } = this;
        const result = [];
        for (const factory of factories) {
            result.push(await factory.calculate());
        }
        return result.flat();
    }

    get selection() {
        const { state } = this.state;
        if (state.tag !== 'committed')
            throw new Error("invalid state");
        const result = [];
        for (let i = 0; i < this.factories.length; i++) {
            const factory = this.factories[i];
            const shell = state.result[i];
            const ids = factory.tracking.GetChangedFaces().GetIds();
            const names = [...ids].map(id => visual.Face.simpleName(shell.simpleName, id));
            result.push(names.map(name => this.db.lookupTopologyItemById(name).view));
        }
        return result.flat();
    }

    protected abstract makeFactory(db: Database, materials: MaterialDatabase, signals: EditorSignals): T;
}
