import * as THREE from 'three';
import { delegate } from '../../command/FactoryBuilder';
import { NoOpError } from '../../command/GeometryFactory';
import { MultiplyableFactory } from '../../command/MultiFactory';
import { Database } from '../../editor/db/Database';
import { EditorSignals } from '../../editor/EditorSignals';
import MaterialDatabase from '../../editor/MaterialDatabase';
import * as c3d from '../../kernel/kernel';
import * as visual from "../../visual_model/VisualModel";
import { ModifyFaceFactory } from './ModifyFaceFactory';
import { MultiModifyFaceFactory } from './MultiModifyFaceFactory';

export interface OffsetFaceParams {
    distance: number;
    angle: number;
    degrees: number;
    faces: visual.Face[];
    grow: c3d.FaceGrowType;
}

export class OffsetFaceFactory extends ModifyFaceFactory implements OffsetFaceParams, MultiplyableFactory<c3d.Shell, visual.Shell> {
    distance = 0;
    angle = 0;

    get degrees() { return THREE.MathUtils.radToDeg(this.angle) }
    set degrees(degrees: number) {
        this.angle = THREE.MathUtils.degToRad(degrees);
    }

    async calculate() {
        const { _shell: { model: shell }, _faces: { models: faces }, distance, angle } = this;

        if (Math.abs(distance) < 10e-6 && Math.abs(angle) < 10e-4) throw new NoOpError();

        const options = new c3d.FaceChangeOptions(this.grow);

        let tracking = await shell.OffsetFaces_async(faces, new c3d.FaceChangeOffsetOperation(distance), options);
        if (Math.abs(angle) > 10e-4) {
            tracking = await shell.DraftAdjacentFaces_async(faces, new c3d.FaceChangeDraftOperation(angle, new c3d.Basis()), options);
        }
        this.tracking = tracking;
        return shell;
    }

    get selection() {
        const { state } = this.state;
        if (state.tag !== 'committed') throw new Error("invalid state");
        const shell = state.result;
        const ids = this.tracking.GetChangedFaces().GetIds();
        const names = [...ids].map(id => visual.Face.simpleName(shell.simpleName, id));
        return names.map(name => this.db.lookupTopologyItemById(name).view);
    }

    override get originalItems() { return super.originalItems }
    override calculatePhantoms(partition: c3d.Partition) { return super.calculatePhantoms(partition) }
}

export class MultiOffsetFaceFactory extends MultiModifyFaceFactory<OffsetFaceFactory> implements OffsetFaceParams {
    @delegate.default(0) distance!: number;
    @delegate.default(0) angle!: number;

    get degrees() { return THREE.MathUtils.radToDeg(this.angle) }
    set degrees(degrees: number) {
        this.angle = THREE.MathUtils.degToRad(degrees);
    }

    protected makeFactory(db: Database, materials: MaterialDatabase, signals: EditorSignals) {
        return new OffsetFaceFactory(db, materials, signals);
    }
}