import * as THREE from "three";
import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { Quasimode } from "../../command/Quasimode";
import { DisableOptions } from "../../editor/db/Database";
import { HasSelection } from "../../selection/SelectionDatabase";
import { SelectionMode } from "../../selection/SelectionModeSet";
import { CancellablePromise } from "../../util/CancellablePromise";
import * as visual from '../../visual_model/VisualModel';
import { CopyFilletRadiusPicker } from "../fillet/CopyFilletRadiusPicker";
import { MultiRefilletFaceFactory } from "../fillet/RefilletFaceFactory";
import { ChangeFaceKeyboardGizmo } from "./ChangeFaceKeyboardGizmo";
import { OffsetFaceDialog } from "./OffsetFaceDialog";
import { MultiOffsetFaceFactory } from "./OffsetFaceFactory";
import { OffsetFaceGizmo } from "./OffsetFaceGizmo";
import { RefilletGizmo } from "./RefilletGizmo";

export class PushFaceCommand extends Command {
    point?: THREE.Vector3;

    async execute(): Promise<void> {
        const { editor, editor: { selection: { selected }, db, materials, signals }, agent } = this;
        const faces = [...selected.faces];
        const refillet = new MultiRefilletFaceFactory(db, materials, signals).resource(this);
        refillet.faces = faces;
        const shouldRefillet = await refillet.areFilletFaces();
        const command = shouldRefillet ? new RefilletFaceCommand(this.editor) : new OffsetFaceCommand(this.editor);
        command.agent = agent;
        command.point = this.point;
        editor.exec(command);
    }
}

export class RefilletFaceCommand extends Command {
    point?: THREE.Vector3;

    async execute(): Promise<void> {
        const { editor: { selection: { selected }, db, materials, signals } } = this;
        const faces = [...selected.faces];

        const refillet = new MultiRefilletFaceFactory(db, materials, signals).resource(this);
        refillet.faces = faces;
        db.disable(refillet.shells);

        const gizmo = new RefilletGizmo(refillet, this.editor, this.point);

        let r: CancellablePromise<HasSelection> | undefined;

        const startRadius = () => {
            if (r !== undefined) return;
            const objectPicker = new CopyFilletRadiusPicker(this.editor);
            r = objectPicker.execute(async selection => {
                const face = selection.faces.first;
                refillet.copyFaceRadius(face);
                refillet.mode = 'absolute';
                refillet.update();
                objectPicker.selection.selected.removeAll();
            }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Face).resource(this);
        }

        gizmo.execute(async (params) => {
            startRadius();
            refillet.mode = 'delta';
            await refillet.update();
        }).resource(this);

        await this.finished;

        const result = await refillet.commit();
        selected.add(result);
    }
}

export class OffsetFaceCommand extends Command {
    point?: THREE.Vector3;

    async execute(): Promise<void> {
        const { editor: { selection, selection: { selected }, db, materials, signals } } = this;

        const offset = new MultiOffsetFaceFactory(db, materials, signals).resource(this);
        const faces = [...selected.faces];
        offset.faces = faces;
        db.disable(offset.shells, DisableOptions.KeepPointSnaps);

        const gizmo = new OffsetFaceGizmo(offset, this.editor, this.point);
        const dialog = new OffsetFaceDialog(offset, this.agent, signals);
        const keyboard = new ChangeFaceKeyboardGizmo(this.editor);

        let q: CancellablePromise<void> | undefined;
        let k: CancellablePromise<void> | undefined;

        dialog.execute(async (params) => {
            await offset.update();
            startKeybord();
            startQuasimode();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        gizmo.execute(async (params) => {
            await offset.update();
            dialog.render();
            startKeybord();
            startQuasimode();
        }).resource(this);

        const startKeybord = () => {
            if (k !== undefined) return;
            k = keyboard.execute(s => {
                switch (s) {
                    case 'toggle':
                        offset.toggle();
                        offset.update();
                        dialog.render()
                }
            }).resource(this);
        }

        const startQuasimode = () => {
            if (q !== undefined) return;
            const quasiPicker = new ObjectPicker(this.editor, undefined, 'viewport-selector[quasimode]');
            quasiPicker.copy(selection);
            const quasimode = new Quasimode("modify-selection", this.editor, offset);

            q = quasimode.execute(() =>
                quasiPicker.execute(delta => {
                    offset.faces = [...quasiPicker.selection.selected.faces];
                }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Face).resource(this)
            ).resource(this);
        }

        await this.finished;

        await offset.commit();
        const newFaces = offset.selection;
        selection.selected.add(newFaces);
    }
}
