import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';


export class DeleteEdgeFactory extends GeometryFactory {
    protected _shell!: { view: visual.Shell; model: c3d.Shell; };
    @derive(visual.Shell) get shell(): visual.Shell { throw ''; }
    set shell(shell: visual.Shell | c3d.Shell) { }

    protected _edges!: { views: visual.CurveEdge[]; models: c3d.Edge[]; };
    @derive([visual.CurveEdge]) get edges(): visual.CurveEdge[] { throw ''; }
    set edges(edges: visual.CurveEdge[] | c3d.Edge[]) { }

    get originalItem() { return this.shell; }

    async calculate() {
        const { _shell: { model: shell }, _edges: { models: edges } } = this;

        await shell.DeleteEdges_async(edges, new c3d.EdgeDeleteOptions());
        return shell;
    }
}
