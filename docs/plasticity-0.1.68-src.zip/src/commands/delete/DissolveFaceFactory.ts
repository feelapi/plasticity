import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import { groupBy } from '../../command/MultiFactory';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';

export class DissolveFaceFactory extends GeometryFactory<c3d.Shell, visual.Shell> {
    private _shell!: { view: visual.Shell; model: c3d.Shell; };
    @derive(visual.Shell) get shell(): visual.Shell { throw ''; }
    set shell(shell: visual.Shell | c3d.Shell) { }

    private _faces!: { views: visual.Face[]; models: c3d.Face[]; };
    @derive([visual.Face]) get faces(): visual.Face[] { throw ''; }
    set faces(faces: visual.Face[] | c3d.Face[]) { }

    get originalItem() { return this.shell }

    async calculate(partition: c3d.Partition = this.partition) {
        const { _shell: { model: shell }, _faces: { models: faces } } = this;

        await shell.DissolveFaces_async(faces, new c3d.FaceDissolveOptions());
        return shell;
    }
}

export class MultiDissolveFaceFactory extends GeometryFactory<c3d.Shell, visual.Shell, []> {
    private readonly factories = new Map<visual.Shell, DissolveFaceFactory>();

    private _faces!: { views: visual.Face[]; models: c3d.Face[]; };
    get faces(): visual.Face[] { return this._faces.views }
    set faces(faces: visual.Face[]) {
        for (const [, factory] of this.factories) {
            factory.cancel();
        }

        this.factories.clear();

        const parent2faces = groupBy('parentItem', faces);
        for (const [shell, faces] of parent2faces) {
            const factory = new DissolveFaceFactory(this.db, this.materials, this.signals);
            factory.faces = faces;
            factory.shell = shell;
            this.factories.set(shell, factory);
        }

        const models = faces.map(face => this.db.lookupTopologyItem(face));
        this._faces = { views: faces, models };
    }

    async calculate(partition: c3d.Partition = this.partition) {
        const { factories } = this;
        const result = [];
        for (const [, factory] of factories) {
            result.push(await factory.calculate(partition));
        }
        return result.flat();
    }

    get originalItems() {
        const result = [];
        for (const factory of this.factories.values()) {
            result.push(factory.originalItem);
        }
        return result;
    }
}