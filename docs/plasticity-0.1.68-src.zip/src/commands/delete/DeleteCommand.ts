import Command from "../../command/Command";
import { TransactionBuilder } from "../../editor/db/DatabaseTransaction";
import { DeleteControlPointFactory } from "../modify_curve/DeleteVertexFactory";
import { DeleteEdgeFactory } from "./DeleteEdgeFactory";
import { DeleteFaceFactory } from "./DeleteFaceFactory";
import { MultiDissolveFaceFactory } from "./DissolveFaceFactory";


export class DeleteCommand extends Command {
    readonly remember = false;

    async execute(): Promise<void> {
        const selected = this.editor.selection.selected;
        if (selected.faces.size > 0) {
            const command = new DissolveFaceCommand(this.editor);
            await command.execute();
        }
        if (selected.edges.size > 0) {
            const command = new DeleteEdgeCommand(this.editor);
            await command.execute();
        }
        if (selected.solids.size > 0 || selected.sheets.size > 0 || selected.curves.size > 0) {
            const command = new RemoveItemCommand(this.editor);
            await command.execute();
        }
        if (selected.vertices.size > 0 || selected.cvs.size > 0) {
            const command = new DeleteControlPointCommand(this.editor);
            await command.execute();
        }
        if (selected.groups.size > 0) {
            const command = new RemoveGroupCommand(this.editor);
            await command.execute();
        }
        if (selected.empties.size > 0) {
            const command = new RemoveEmptyCommand(this.editor);
            await command.execute();
        }
    }
}

export class RemoveItemCommand extends Command {
    async execute(): Promise<void> {
        const items = [...this.editor.selection.selected.curves, ...this.editor.selection.selected.solids, ...this.editor.selection.selected.sheets];
        const txn = new TransactionBuilder(this.editor.db);
        for (const item of items) txn.delete(item);
        await this.editor.db.commit(txn);
    }
}

export class RemoveGroupCommand extends Command {
    async execute(): Promise<void> {
        for (const group of this.editor.selection.selected.groups) {
            await this.editor.db.deleteGroup(group);
        }
    }
}

export class RemoveEmptyCommand extends Command {
    async execute(): Promise<void> {
        for (const empty of this.editor.selection.selected.empties) {
            await this.editor.db.removeEmpty(empty);
        }
    }
}

export class DissolveFaceCommand extends Command {
    async execute(): Promise<void> {
        const faces = [...this.editor.selection.selected.faces];
        const shell = faces[0].parentItem;
        if (shell.faces.length === 1){
            const txn = new TransactionBuilder(this.editor.db);
            txn.delete(shell);
            await this.editor.db.commit(txn);
        } else {
            const removeFace = new MultiDissolveFaceFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
            removeFace.faces = faces;
    
            await removeFace.commit();
        }
    }
}

export class DeleteFaceCommand extends Command {
    async execute(): Promise<void> {
        const faces = [...this.editor.selection.selected.faces];
        const shell = faces[0].parentItem;
        const removeFace = new DeleteFaceFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        removeFace.shell = shell;
        removeFace.faces = faces;

        await removeFace.commit();
    }
}

export class DeleteEdgeCommand extends Command {
    async execute(): Promise<void> {
        const edges = [...this.editor.selection.selected.edges];
        const shell = edges[0].parentItem;
        const removeEdge = new DeleteEdgeFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        removeEdge.shell = shell;
        removeEdge.edges = edges;

        await removeEdge.commit();
    }
}
export class DeleteControlPointCommand extends Command {
    async execute(): Promise<void> {
        const { editor: { db, materials, signals, selection: { selected } } } = this;
        const vertices = [...selected.vertices];
        const cvs = [...selected.cvs];
        const curve = (vertices[0] || cvs[0]).parentItem;
        const remove = new DeleteControlPointFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        remove.vertices = vertices;
        remove.cvs = cvs;
        remove.curve = curve;

        await remove.commit();
    }
}

