import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';


export class DeleteFaceFactory extends GeometryFactory<c3d.Shell | c3d.Wire, visual.Shell | visual.SpaceInstance, []> {
    protected _shell!: { view: visual.Shell; model: c3d.Shell; };
    @derive(visual.Shell) get shell(): visual.Shell { throw ''; }
    set shell(shell: visual.Shell | c3d.Shell) { }

    protected _faces!: { views: visual.Face[]; models: c3d.Face[]; };
    @derive([visual.Face]) get faces(): visual.Face[] { throw ''; }
    set faces(faces: visual.Face[] | c3d.Face[]) { }

    get originalItem() { return this.shell; }

    async calculate() {
        const { _shell: { model: shell }, _faces: { models: faces } } = this;

        // NOTE: this is one of the few commands that can change the body type;
        // the original body should be considered 'deleted' even though it technically is not.
        const results = await shell.DeleteFaces_async(faces, new c3d.FaceDeleteOptions());
        return results;
    }
}
