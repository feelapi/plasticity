import Command from "../../command/Command";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { AxisSnap } from "../../editor/snaps/AxisSnap";
import { booleanTargets } from "../box/BoxCommand";
import { KnifeKeyboardGizmo } from "../circle/KnifeKeyboardGizmo";
import { KnifePolygonFactory } from "./PolygonFactory";
import { PolygonKeyboardGizmo } from "./PolygonKeyboardGizmo";

export class PolygonCommand extends Command {
    async execute(): Promise<void> {
        const polygon = new KnifePolygonFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);

        const keyboard = new PolygonKeyboardGizmo(this.editor);
        const knife = new KnifeKeyboardGizmo('polygon', this.editor);

        keyboard.execute(e => {
            switch (e) {
                case 'add-vertex':
                    polygon.vertexCount++;
                    break;
                case 'subtract-vertex':
                    polygon.vertexCount--;
                    break;
                case 'mode':
                    polygon.toggleMode();
                    break;
            }
            polygon.update();
        }).resource(this);

        knife.execute(e => {
            switch (e) {
                case 'knife':
                    polygon.isKnife = !polygon.isKnife;
                    polygon.update();
            }
        }).resource(this);

        const pointPicker = new PointPicker(this.editor);
        pointPicker.facePreferenceMode = 'strong';
        pointPicker.straightSnaps.delete(AxisSnap.Z);
        const { point, info: { snap: snap1 } } = await pointPicker.execute().resource(this);
        polygon.center = point;
        pointPicker.restrictToPlaneThroughPoint(point, snap1);

        const targets1 = booleanTargets(snap1)
        if (targets1.length > 0) polygon.target = targets1[0];

        const { info: { snap: snap2 } } = await pointPicker.execute(({ point, info: { orientation } }) => {
            polygon.orientation = orientation;
            polygon.p2 = point;
            polygon.update();
        }).resource(this);

        const targets2 = booleanTargets(snap1, snap2)
        if (targets2.length > 0) polygon.target = targets2[0];

        await polygon.commit();

        this.editor.selection.selected.removeAll();
        const newSelection = polygon.selection;
        this.editor.selection.selected.add(newSelection);
    }
}
