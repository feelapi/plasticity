import * as THREE from "three";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { Z } from "../../util/Constants";
import { point2point, vec2vec } from "../../util/Conversion";
import * as visual from '../../visual_model/VisualModel';
import { CenterCircleFactory, CircleMode } from "../circle/CircleFactory";
import { PlanarKnifeFactory } from "../circle/KnifeFactory";

export class PolygonFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> {
    mode = CircleMode.Horizontal;
    toggleMode() {
        this.mode = this.mode === CircleMode.Vertical ? CircleMode.Horizontal : CircleMode.Vertical;
    }

    center!: THREE.Vector3;
    p2!: THREE.Vector3;
    private _vertexCount = 5;
    orientation = new THREE.Quaternion();

    get vertexCount() { return this._vertexCount }
    set vertexCount(count: number) {
        this._vertexCount = Math.max(0, count);
    }

    async calculate() {
        const { center, p2, vertexCount, normal } = this;
        const [x, , z] = CenterCircleFactory.orientHorizontalOrVertical(this.p2, this.center, normal, this.mode);
        const placement = new c3d.Basis();
        placement.Axis.Copy(vec2vec(z, 1));
        placement.Ref.Copy(vec2vec(x, 1));
        placement.Location.Copy(point2point(center));
        const radius = p2.distanceTo(center);
        if (radius < 1e-6) throw new NoOpError();
        const polygon = c3d.ActionCurve3D.RegularPolygon(radius, vertexCount, placement);
        // NOTE: associate construction geometry so that if the polygon is trimmed such that it is no longer uniquely planar,
        // it still has a plane associated with it
        const plane = c3d.Plane.Create(placement);
        polygon.AddConstructionGeometry(plane);
        return polygon;
    }

    private readonly _normal = new THREE.Vector3();
    private get normal() {
        return this._normal.copy(Z).applyQuaternion(this.orientation);
    }
}

export class KnifePolygonFactory extends PlanarKnifeFactory(PolygonFactory) { }
