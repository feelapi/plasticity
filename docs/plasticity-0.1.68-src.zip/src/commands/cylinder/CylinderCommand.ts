import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { DisableOptions } from "../../editor/db/Database";
import { AxisSnap } from "../../editor/snaps/AxisSnap";
import * as c3d from '../../kernel/kernel';
import { SelectionMode } from "../../selection/SelectionModeSet";
import { Z } from "../../util/Constants";
import { PossiblyBooleanKeyboardGizmo } from "../boolean/BooleanKeyboardGizmo";
import { booleanTargets } from "../box/BoxCommand";
import { CenterCircleFactory } from '../circle/CircleFactory';
import { CircleKeyboardGizmo } from "../circle/CircleKeyboardGizmo";
import { PossiblyBooleanCylinderFactory } from "./CylinderFactory";
import { EditCylinderGizmo } from "./CylinderGizmo";
import { EditCylinderDialog } from "./EditCylinderDialog";

export class CylinderCommand extends Command {
    async execute(): Promise<void> {
        const constructionPlane = this.editor.activeViewport?.constructionPlane;

        const cylinder = new PossiblyBooleanCylinderFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        const selection = this.editor.selection.selected;

        const dialog = new EditCylinderDialog(cylinder, this.editor.signals);
        const gizmo = new EditCylinderGizmo(cylinder, this.editor);
        const mode = new CircleKeyboardGizmo(this.editor);

        dialog.execute(params => {
            gizmo.render(params);
            cylinder.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const circle = new CenterCircleFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        let pointPicker = new PointPicker(this.editor);
        const { point: p1, info: { snap: snap1, orientation: o1 } } = await pointPicker.execute().resource(this);
        circle.center = p1;
        cylinder.p0 = p1;

        cylinder.targets = booleanTargets(snap1);

        const m = mode.execute(e => {
            switch (e) {
                case 'mode':
                    circle.toggleMode();
                    circle.update();
            }
        }).resource(this);

        pointPicker = new PointPicker(this.editor);
        pointPicker.straightSnaps.delete(AxisSnap.Z);
        pointPicker.addAxesAt(p1, o1);
        pointPicker.restrictToPlaneThroughPoint(p1, snap1);
        const { point: p2, info: { snap: snap2, orientation } } = await pointPicker.execute(({ point: p2, info: { orientation } }) => {
            circle.point = p2;
            circle.orientation = orientation;
            dialog.render();
            circle.update();
        }).resource(this);
        cylinder.p1 = p2;
        cylinder.mode = circle.mode;
        cylinder.orientation = circle.orientation;
        circle.cancel();
        m.finish();

        cylinder.targets = booleanTargets(snap1, snap2);
        this.editor.db.disable(cylinder.targets, DisableOptions.KeepPointSnaps);

        const keyboard = new PossiblyBooleanKeyboardGizmo("cylinder", this.editor);
        keyboard.prepare(cylinder).resource(this);

        gizmo.quaternion.setFromUnitVectors(Z, cylinder.axis);
        gizmo.position.copy(cylinder.p0);
        gizmo.execute(async (params) => {
            dialog.render();
            await cylinder.update();
        }).resource(this);
        if (!gizmo.startHeight()) {
            cylinder.height = 1;
            await cylinder.update();
            dialog.render();
            gizmo.render(cylinder);
        }

        const startSelect = dialog.prompt("Select target bodies", () => {
            const objectPicker = new ObjectPicker(this.editor);
            objectPicker.selection.selected.add(cylinder.targets);
            return objectPicker.execute(async delta => {
                const targets = [...objectPicker.selection.selected.solids];
                cylinder.targets = targets;
                if (cylinder.operationType === undefined) cylinder.operationType = c3d.OperationType.Difference;
                await cylinder.update();
            }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Solid).resource(this)
        }, async () => {
            cylinder.targets = [];
            await cylinder.update();
        });
        keyboard.startSelect = startSelect;

        await this.finished;

        const results = await cylinder.commit();
        selection.removeAll();
        selection.add(results);
    }
}
