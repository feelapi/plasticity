import { Mode } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { DistanceGizmo } from "../../command/MiniGizmos";
import { CancellablePromise } from "../../util/CancellablePromise";
import { Y, Z } from "../../util/Constants";
import { EditCylinderParams } from "./CylinderFactory";

export class EditCylinderGizmo extends CompositeGizmo<EditCylinderParams> {
    private readonly radiusGizmo = new RadiusDistanceGizmo("cylinder:radius", this.editor);
    private readonly heightGizmo = new ExtrudeDistanceGizmo("cylinder:height", this.editor);

    protected prepare(mode: Mode) {
        const { radiusGizmo, heightGizmo, params } = this;
        radiusGizmo.relativeScale.setScalar(0.8);
        heightGizmo.relativeScale.setScalar(0.8);

        radiusGizmo.value = params.radius;
        heightGizmo.value = params.height
        heightGizmo.quaternion.setFromUnitVectors(Y, Z);

        this.add(radiusGizmo, heightGizmo);
    }

    execute(cb: (params: EditCylinderParams) => void, finishFast: Mode = Mode.Persistent): CancellablePromise<void> {
        const { radiusGizmo, heightGizmo, params } = this;

        this.addGizmo(radiusGizmo, radius => {
            params.radius = radius;
        });

        this.addGizmo(heightGizmo, height => {
            params.height = height;
        });

        return super.execute(cb, finishFast);
    }

    get shouldRescaleOnZoom() { return false }

    render(params: EditCylinderParams) {
        this.radiusGizmo.value = params.radius;
        this.heightGizmo.value = params.height;
    }

    startHeight() {
        if (!this.heightGizmo.visible) return false;
        this.start('gizmo:cylinder:height');
        return true;
    }
}

class ExtrudeDistanceGizmo extends DistanceGizmo {
    onInterrupt(cb: (radius: number) => void) {
        this.state.push();
    }

    onDeactivate() { this.visible = false }
    onActivate() {
        if (!this.stateMachine?.isEnabled) return;
        this.visible = true;
    }

    protected override onIsFacingCamera(dot: number) {
        this.visible = Math.abs(dot) < AXIS_HIDE_TRESHOLD;
    }
}

const AXIS_HIDE_TRESHOLD = 0.99;

export class RadiusDistanceGizmo extends ExtrudeDistanceGizmo { }
