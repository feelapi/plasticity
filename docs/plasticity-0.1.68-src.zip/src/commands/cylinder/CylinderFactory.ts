import * as THREE from "three";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { X, Y, Z } from "../../util/Constants";
import { point2point, vec2vec } from '../../util/Conversion';
import * as visual from '../../visual_model/VisualModel';
import { PossiblyBoolean } from "../boolean/PossiblyBooleanFactory";
import { CenterCircleFactory, CircleMode } from "../circle/CircleFactory";

export interface EditCylinderParams {
    radius: number;
    height: number;
}

interface CylinderFactoryLike extends GeometryFactory {
    p0: THREE.Vector3;
    p1: THREE.Vector3;
}

export class CylinderFactory extends GeometryFactory<c3d.Solid, visual.Solid> implements CylinderFactoryLike {
    p0!: THREE.Vector3;
    p1!: THREE.Vector3;
    p2!: THREE.Vector3;

    private readonly x = new THREE.Vector3();
    private readonly z = new THREE.Vector3();
    private readonly cross = new THREE.Vector3();

    async calculate(partition: c3d.Partition = this.partition) {
        const { p0, p1, p2 } = this;
        const { x, z, cross } = this;

        x.copy(p1).sub(p0);
        z.copy(p2).sub(p0);
        const radius = x.length();
        const height = z.length();

        if (radius < 10e-6 || height < 10e-6) throw new NoOpError()

        x.divideScalar(radius);
        z.divideScalar(height);

        if (1 - Math.abs(x.dot(z)) < 10e-6) {
            if (1 - Math.abs(X.dot(z)) < 10e-6) x.copy(Y);
            else x.copy(X);
        }

        cross.crossVectors(x, z).normalize();
        x.copy(z).cross(cross).normalize();

        const basis = new c3d.Basis();
        basis.Axis.Copy(vec2vec(z, 1));
        basis.Ref.Copy(vec2vec(x, 1));
        basis.Location.Copy(point2point(p0));

        return partition.SolidBody.CreateCylinder(radius, height, basis);
    }
}

export class EditableCylinderFactory extends GeometryFactory<c3d.Solid, visual.Solid> implements CylinderFactoryLike, EditCylinderParams {
    private readonly cylinder = new CylinderFactory(this.db, this.materials, this.signals);

    mode = CircleMode.Horizontal;
    toggleMode() {
        this.mode = this.mode === CircleMode.Vertical ? CircleMode.Horizontal : CircleMode.Vertical;
    }

    get height() {
        const { p0, _height } = this;
        if (p0 === undefined) return 0;
        return _height.distanceTo(p0);
    }
    private readonly _height = new THREE.Vector3();
    set height(h: number) {
        const { _height, axis, p0 } = this;
        _height.copy(axis).multiplyScalar(h).add(p0);
    }

    get radius() {
        const { p0, p1, _radius } = this;
        if (p1 === undefined && _radius) return 0;

        return _radius.distanceTo(p0);
    }
    private readonly _radius = new THREE.Vector3();
    set radius(r: number) {
        const { _radius, radial: radialAxis, p0 } = this;
        _radius.copy(radialAxis).multiplyScalar(r).add(p0);
    }

    readonly axis = new THREE.Vector3();
    private radial = new THREE.Vector3();

    private _p0!: THREE.Vector3;
    get p0() { return this._p0 }
    set p0(p0: THREE.Vector3) { this._p0 = p0 }

    private _p1!: THREE.Vector3;
    get p1() { return this._p1 }
    set p1(p1: THREE.Vector3) {
        this._p1 = p1;
        this._radius.copy(p1);
        this.radial.copy(p1).sub(this.p0).normalize();
    }

    private _orientation = new THREE.Quaternion();
    get orientation() { return this._orientation }
    set orientation(orientation: THREE.Quaternion) {
        this.axis.copy(Z).applyQuaternion(orientation).normalize();
        const [x, , z] = CenterCircleFactory.orientHorizontalOrVertical(this.p1, this.p0, this.axis, this.mode);
        this.axis.copy(z);
        this.height = 0;
    }

    async calculate(partition: c3d.Partition = this.partition) {
        const { cylinder, p0, _radius, _height } = this;
        cylinder.p0 = p0;
        cylinder.p1 = _radius;
        cylinder.p2 = _height;
        return cylinder.calculate(partition);
    }
}

export class PossiblyBooleanCylinderFactory extends PossiblyBoolean(EditableCylinderFactory) {

}