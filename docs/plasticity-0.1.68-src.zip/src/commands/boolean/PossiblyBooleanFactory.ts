import { GeometryFactory } from '../../command/GeometryFactory';
import { TemporaryObject } from '../../editor/DatabaseLike';
import { MutableComputeTemporaryInput } from '../../editor/db/transforms/ComputeTemporary';
import * as c3d from '../../kernel/kernel';
import { toArray } from '../../util/Conversion';
import { GConstructor } from '../../util/Util';
import * as visual from '../../visual_model/VisualModel';
import { BooleanPhantomStrategy, materialForOperation } from './BooleanFactory';

export interface PossiblyBooleanParams {
    operationType?: c3d.OperationType | 'new-body';
    keepTools: boolean;
};

export function PossiblyBoolean<A extends undefined | [], GF extends GConstructor<GeometryFactory<c3d.Shell, visual.Shell, A>>>(base: GF) {
    return class PossiblyBoolean extends base {
        operationType?: c3d.OperationType | 'new-body';
        keepTools = false;
        private computedOperationType?: c3d.OperationType;

        protected _targets: { views: visual.Shell[]; models: c3d.Shell[]; copies: c3d.Shell[] } = { views: [], models: [], copies: [] };
        get targets(): visual.Shell[] { return this._targets.views }
        set targets(targets: visual.Shell[]) {
            const models = targets.map(t => this.db.lookup(t))
            const copies = models.map(m => m.CopyTo(this.phantomPartition));
            this._targets = { views: targets, models, copies };
            this.booleanPhantoms.targets = targets;
        }

        async calculate(partition: c3d.Partition = this.partition) {
            const { _targets: { models: targets }, keepTools } = this;
            let { operationType } = this;
            const created = toArray(await super.calculate(partition));

            let result;
            if (this.shouldPerformBoolenOperation) {
                if (operationType === undefined) {
                    operationType = this.computedOperationType = await this.clash(created, targets);
                }
                if (operationType === undefined) {
                    result = created;
                } else {

                    let keptTools: c3d.Shell[] = [];
                    if (keepTools) {
                        keptTools = created.map(c => c.Copy());
                    }

                    const collection = new c3d.BodyCollection(targets.map(t => t.Id()));
                    const options = new c3d.BooleanOptions(operationType as c3d.OperationType);
                    const { modified, unmodified } = await collection.Boolean_async(created, options);
                    result = [...modified, ...unmodified, ...keptTools];
                }
            } else {
                result = created;
            }
            // NOTE: we are abusing the type system a bit to make this mixin convert the type of the derived class to return an array
            return result as any;
        }

        private readonly booleanPhantoms = new BooleanPhantomStrategy(this.db);
        override async doPhantoms(abortEarly: () => boolean): Promise<TemporaryObject[]> {
            const { _targets: { copies: targets }, operationType } = this;

            if (!this.shouldPerformBoolenOperation) {
                this.cleanupPhantoms();
                return [];
            }

            let created = toArray(await super.calculate(this.phantomPartition));
            if (abortEarly()) return [];

            const computedOperationType = (operationType as c3d.OperationType | undefined) ?? await this.clash(created, targets);

            if (computedOperationType === undefined) {
                this.cleanupPhantoms();
                return [];
            }

            const txn: MutableComputeTemporaryInput = { added: [], replaced: [] };
            for (const model of created) {
                txn.added.push({ model, material: materialForOperation(computedOperationType) });
            }

            const computePhantomResult = await this.computePhantom.calculate(txn);
            if (abortEarly()) return [];

            const updatePhantomResult = this.updatePhantom.calculate(computePhantomResult);
            if (abortEarly()) return [];

            const phantoms = updatePhantomResult.added.map(x => x.temp);

            this.cleanupPhantoms();
            return this.phants = this.showTemps([...phantoms]);
        }


        get originalItems() { return this.targets }

        protected get shouldRemoveOriginalItemOnCommit() {
            return this.shouldPerformBoolenOperation && (this.operationType !== undefined || this.computedOperationType !== undefined);
        }

        get shouldPerformBoolenOperation(): boolean {
            if (this.targets.length === 0) return false;
            if (this.operationType === 'new-body') return false;
            return true;
        }

        private async clash(tools: c3d.Shell[], targets: c3d.Shell[]): Promise<c3d.OperationType | undefined> {
            const toolCollection = new c3d.BodyCollection(tools.map(t => t.Id()));
            const targetCollection = new c3d.BodyCollection(targets.map(t => t.Id()));
            const options = new c3d.ClashOptions(true, true);
            const { types } = await toolCollection.Clash_async(targetCollection, options);
            let result: c3d.OperationType | undefined = undefined;
            for (const type of types) {
                if (type === c3d.ClashType.AbutNoClass) {
                    result = c3d.OperationType.Union;
                } else {
                    result = c3d.OperationType.Difference;
                    break;
                }
            }
            return result;
        }
    }
}
