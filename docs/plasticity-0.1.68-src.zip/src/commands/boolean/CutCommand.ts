import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { SelectionMode } from "../../selection/SelectionModeSet";
import { CutDialog } from "./CutDialog";
import { MultiCutFactory } from "./CutFactory";
import { CutGizmo } from "./CutGizmo";
import { CutKeyboardGizmo } from "./CutKeyboardGizmo";

export class CutCommand extends Command {
    async execute(): Promise<void> {
        const cut = new MultiCutFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        cut.constructionPlane = this.editor.activeViewport?.constructionPlane;
        cut.isOrthoMode = this.editor.activeViewport?.isOrthoMode ?? false;

        const keyboard = new CutKeyboardGizmo(this.editor);
        const gizmo = new CutGizmo(cut, this.editor);
        const dialog = new CutDialog(cut, this.editor.signals);
        const objectPicker = new ObjectPicker(this.editor);
        objectPicker.copy(this.editor.selection);

        dialog.execute(async params => {
            await cut.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        gizmo.execute(async params => {
            await cut.update();
        }).resource(this);

        keyboard.execute(async e => {
            switch (e) {
                case 'screen-space':
                    const camera = this.editor.activeViewport?.camera;
                    if (camera === undefined) return;
                    cut.direction.set(0, 0, 1).applyQuaternion(camera.quaternion);
                    await cut.update();
            }
        }).resource(this);

        GetTargetBodies: {
            const getTarget = dialog.prompt("Select target bodies", () => {
                return objectPicker.slice(SelectionMode.Shell, 1, Number.MAX_SAFE_INTEGER).resource(this);
            });
            const shells = await getTarget();
            cut.shells = [...shells];

            dialog.replace("Select target bodies", () => {
                const objectPicker = new ObjectPicker(this.editor);
                objectPicker.selection.selected.add(cut.shells);
                return objectPicker.execute(delta => {
                    const shells = [...objectPicker.selection.selected.shells];
                    cut.shells = shells;
                    cut.update();
                }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Shell).resource(this);
            }, () => {
                cut.shells = [];
                cut.update();
            });
        }

        GetCutters: {
            cut.curves = [...this.editor.selection.selected.curves];
            cut.faces = [...this.editor.selection.selected.faces];
            await cut.update();

            dialog.prompt("Select cutters", () => {
                const objectPicker = new ObjectPicker(this.editor);
                objectPicker.mode.set(SelectionMode.Curve, SelectionMode.Face);
                objectPicker.selection.selected.add(cut.faces);
                objectPicker.selection.selected.add(cut.curves);
                return objectPicker.execute(async delta => {
                    const selected = objectPicker.selection.selected;
                    cut.faces = [...selected.faces];
                    cut.curves = [...selected.curves];
                    cut.update();
                }, 1, Number.MAX_SAFE_INTEGER).resource(this);
            }, () => {
                cut.faces = []; cut.curves = [];
                cut.update();
            })();
        }

        await this.finished;

        await cut.commit();
        const { front, back } = cut.selection;

        this.editor.selection.selected.removeAll();
        this.editor.selection.selected.add(back);
        this.editor.selection.selected.add(cut.curves);
    }
}
