import * as THREE from "three";
import Command, { EditorLike } from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import * as c3d from '../../kernel/kernel';
import { SelectionMode } from "../../selection/SelectionModeSet";
import { CancellablePromise } from "../../util/CancellablePromise";
import { computeCentroid } from "../../util/Util";
import * as visual from "../../visual_model/VisualModel";
import { MoveGizmo } from '../translate/MoveGizmo';
import { TransformMode } from "../translate/MultiTransformFactory";
import { RotateGizmo } from "../translate/RotateGizmo";
import { ScaleGizmo } from "../translate/ScaleGizmo";
import { BooleanDialog } from "./BooleanDialog";
import { BooleanFactory } from './BooleanFactory';
import { BooleanKeyboardGizmo } from "./BooleanKeyboardGizmo";

export class BooleanCommand extends Command {
    async execute(): Promise<void> {
        const { editor } = this;
        const boolean = new BooleanFactory(editor.db, editor.materials, editor.signals);
        boolean.resource(this);

        const gizmo = new TransformGizmo(boolean, editor);
        const dialog = new BooleanDialog(boolean, editor.signals);
        const keyboard = new BooleanKeyboardGizmo(this.editor);
        const objectPicker = new ObjectPicker(this.editor);
        objectPicker.copy(this.editor.selection);

        dialog.execute(async (params) => {
            boolean.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        keyboard.execute(e => {
            let operationType: c3d.OperationType | undefined, mode: TransformMode | undefined;
            switch (e) {
                case 'slice': operationType = c3d.OperationType.Merge; break;
                case 'union': operationType = c3d.OperationType.Union; break;
                case 'difference': operationType = c3d.OperationType.Difference; break;
                case 'intersect': operationType = c3d.OperationType.Intersection; break;
                case 'move': mode = 'move'; break;
                case 'rotate': mode = 'rotate'; break;
                case 'scale': mode = 'scale'; break;
                case 'keep-tools': boolean.keepTools = !boolean.keepTools; break;
                default: throw new Error('invalid case');
            }
            if (operationType !== undefined) boolean.operationType = operationType;
            if (mode !== undefined) gizmo.updateMode(mode)?.resource(this);
            boolean.update();
            dialog.render();
        }).resource(this);

        GetTargetBodies: {
            const getTarget = dialog.prompt("Select target bodies", () => {
                return objectPicker.shift(SelectionMode.Shell, 1).resource(this)
            });
            const shells = await getTarget();
            boolean.targets = [...shells];

            dialog.replace("Select target bodies", () => {
                const objectPicker = new ObjectPicker(this.editor);
                objectPicker.selection.selected.add(boolean.targets);
                objectPicker.prohibit(boolean.tools);
                return objectPicker.execute(delta => {
                    const targets = [...objectPicker.selection.selected.solids];
                    boolean.targets = targets;
                    boolean.update();
                }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Shell).resource(this)
            }, () => {
                boolean.targets = [];
                boolean.update();
            });
        }

        GetToolBodies: {
            const setToolsAndGizmo = async (tools: visual.Shell[]) => {
                gizmo.updateTools(tools)?.resource(this);
                boolean.tools = tools;
                await boolean.update();
                return true;
            }

            const set = await setToolsAndGizmo([...objectPicker.selection.selected.shells]);
            if (!set) await boolean.update();

            dialog.prompt("Select tool bodies", () => {
                const objectPicker = new ObjectPicker(this.editor);
                objectPicker.selection.selected.add(boolean.tools);
                objectPicker.prohibit(boolean.targets);
                return objectPicker.execute(async delta => {
                    await setToolsAndGizmo([...objectPicker.selection.selected.solids]);
                }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Shell).resource(this)
            }, () => setToolsAndGizmo([]))();
        }

        await this.finished;

        const results = await boolean.commit();
        editor.selection.selected.add(results);
    }
}


class TransformGizmo {
    private g: CancellablePromise<void> | undefined = undefined;
    private centroid: THREE.Vector3 | undefined;

    constructor(private readonly boolean: BooleanFactory, private readonly editor: EditorLike) {

    }

    updateTools(tools: visual.Shell[]): CancellablePromise<void> | undefined {
        const { g, boolean } = this;

        if (this.centroid === undefined) this.centroid = new THREE.Vector3();
        computeCentroid(tools, this.centroid);

        if (g === undefined) {
            if (tools.length > 0) {
                const gizmo = this.makeGizmo();
                const g = gizmo.execute(s => {
                    boolean.update();
                });
                this.g = g;
                return g;
            }
        } else if (tools.length === 0) {
            g.finish();
            this.g = undefined;
            boolean.clearTransform();
            this.centroid = undefined;
            return undefined;
        }
    }

    get mode() { return this.boolean.mode }
    updateMode(mode: TransformMode) {
        const { boolean, g: old } = this;
        if (old !== undefined) {
            old.finish();
            boolean.push();
        }
        this.g = undefined;
        boolean.mode = mode;
        if (this.centroid === undefined) return;

        const gizmo = this.makeGizmo();
        const g = gizmo.execute(s => {
            boolean.update();
        });
        this.g = g;
        return g;
    }

    private makeGizmo(): MoveGizmo | RotateGizmo | ScaleGizmo {
        const { mode, centroid, boolean } = this;
        if (centroid === undefined) throw new Error('invalid state: centroid is undefined');
        let gizmo;
        switch (mode) {
            case 'move': gizmo = new MoveGizmo(this.boolean, this.editor); break;
            case 'rotate': gizmo = new RotateGizmo(this.boolean, this.editor); break;
            case 'scale': gizmo = new ScaleGizmo(this.boolean, this.editor); break;
            default: throw new Error('invalid case');
        }
        const pivot = centroid.clone().applyMatrix4(boolean.matrix);
        gizmo.position.copy(pivot);
        boolean.pivot.copy(pivot);
        return gizmo;
    }
}