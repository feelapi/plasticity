import { CommandKeyboardInput, EditorLike } from "../../command/CommandKeyboardInput";

export class CutKeyboardGizmo extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('cut', editor, [
            'gizmo:cut:screen-space',
        ]);
    }
}