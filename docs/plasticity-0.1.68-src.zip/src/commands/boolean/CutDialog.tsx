import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import { CutParams } from "./CutFactory";


export class CutDialog extends AbstractDialog<CutParams> {
    name = "Cut";

    constructor(protected readonly params: CutParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { } = this.params;
        render(
            <>
                <ol>
                    <plasticity-prompt name="Select target bodies" description="to cut or join into"></plasticity-prompt>
                    <plasticity-prompt name="Select cutters" description="— curves or faces to cut with"></plasticity-prompt>
                </ol>
            </>, this);
    }
}

customElements.define('cut-dialog', CutDialog);
