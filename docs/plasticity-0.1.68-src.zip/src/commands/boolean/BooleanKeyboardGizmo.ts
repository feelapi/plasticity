import { AbstractCommandKeyboardInput, CommandKeyboardInput, EditorLike } from "../../command/CommandKeyboardInput";
import * as c3d from '../../kernel/kernel';
import { HasSelection } from "../../selection/SelectionDatabase";
import { CancellablePromise } from "../../util/CancellablePromise";
import { PossiblyBooleanParams } from "./PossiblyBooleanFactory";

export type BooleanKeyboardEvent = { tag: 'boolean', type: number } | { tag: 'new-body' | 'keep-tools' };

export class PossiblyBooleanKeyboardGizmo extends AbstractCommandKeyboardInput<(e: BooleanKeyboardEvent) => void> {
    private map = commands(this.name).map;

    constructor(private readonly name: string, editor: EditorLike) {
        super(name, editor, commands(name).commands);
    }

    protected resolve(cb: (e: BooleanKeyboardEvent) => void, command: string) {
        switch (command) {
            case `keyboard:${this.name}:new-body`:
                cb({ tag: 'new-body' });
                break;
            case `keyboard:${this.name}:keep-tools`:
                cb({ tag: 'keep-tools' });
                break;
            default:
                cb({ tag: 'boolean', type: this.map[command] });
        }
    }

    startSelect: () => CancellablePromise<HasSelection> | undefined = () => undefined;

    prepare(factory: PossiblyBooleanParams & { update(): Promise<void> }) {
        let s: CancellablePromise<HasSelection> | undefined;
        const stopSelect = () => { s?.finish(); s = undefined }

        return this.execute(e => {
            switch (e.tag) {
                case 'boolean':
                    factory.operationType = e.type;
                    s ??= this.startSelect();
                    factory.update();
                    break;
                case 'new-body':
                    factory.operationType = 'new-body';
                    stopSelect();
                    factory.update();
                    break;
                case 'keep-tools':
                    factory.keepTools = !factory.keepTools;
                    factory.update();
                    break;
            }
        })
    }
}

export class BooleanKeyboardGizmo extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('boolean', editor, [
            'gizmo:boolean:slice',
            'gizmo:boolean:union',
            'gizmo:boolean:difference',
            'gizmo:boolean:intersect',
            'gizmo:boolean:keep-tools',
            'keyboard:boolean:move',
            'keyboard:boolean:rotate',
            'keyboard:boolean:scale',
        ]);
    }
}

function commands(name: string) {
    const commands = new Array<string>();
    const map: Record<string, number> = {};

    map[`keyboard:${name}:slice`] = c3d.OperationType.Merge;
    map[`keyboard:${name}:union`] = c3d.OperationType.Union;
    map[`keyboard:${name}:difference`] = c3d.OperationType.Difference;
    map[`keyboard:${name}:intersect`] = c3d.OperationType.Intersection;
    for (const key in map) commands.push(key);
    commands.push(`keyboard:${name}:new-body`);
    commands.push(`keyboard:${name}:keep-tools`);
    return { commands, map }
}