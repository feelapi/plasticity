import * as THREE from "three";
import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory, PhantomInfo } from '../../command/GeometryFactory';
import { ConstructionPlane } from "../../editor/snaps/ConstructionPlaneSnap";
import { PlaneSnap } from "../../editor/snaps/PlaneSnap";
import * as c3d from '../../kernel/kernel';
import { X, Y, Z } from "../../util/Constants";
import { axis2line, plane2plane, point2point } from '../../util/Conversion';
import { isParallel } from "../../util/Util";
import { VectorProxy } from "../../util/VectorProxy";
import * as visual from '../../visual_model/VisualModel';
import { ExtrudeSurfaceFactory } from "../extrude/ExtrudeSurfaceFactory";

export interface CutParams {
    constructionPlane?: ConstructionPlane;
    get direction(): THREE.Vector3;
}

type CutMode =
    { tag: 'contour', curve: c3d.Wire, z: THREE.Vector3, distance1: number, distance2: number } |
    { tag: 'surface', surface: c3d.Surface, uMin: number, uMax: number, vMin: number, vMax: number }

const marginOfError = 1.75;
export class CutFactory extends GeometryFactory<c3d.Shell, visual.Shell, []> implements CutParams {
    constructionPlane?: PlaneSnap;
    isOrthoMode = false;
    protected mode!: CutMode;

    private fantom = new ExtrudeSurfaceFactory(this.db, this.materials, this.signals);

    protected _shell!: { view: visual.Shell, model: c3d.Shell };
    @derive(visual.Shell) get shell(): visual.Shell { throw '' }
    set shell(shell: visual.Shell | c3d.Shell) { }

    set cutter(cutter: visual.Face | visual.SpaceInstance) {
        if (cutter instanceof visual.Face) {
            this.face = cutter;
        } else {
            this.curve = cutter;
        }
    }

    set face(face: visual.Face) {
        const model = this.db.lookupTopologyItem(face);
        const { surface: surf, uMin, vMin, uMax, vMax } = model.GetSurface();
        this.mode = { tag: 'surface', surface: surf, uMin, vMin, uMax, vMax }
    }

    readonly direction = new VectorProxy(direction => {
        if (direction.manhattanLength() === 0) return;

        const { mode } = this;
        if (mode.tag === 'contour') {
            const bbox = this.bbox;
            this.setContour(mode.curve, direction, bbox);
        }
    });

    private setContour(curve: c3d.Wire, direction: THREE.Vector3, bbox: THREE.Box3) {
        const { min, max } = curve.FindBox();
        _curveBox.set(point2point(min), point2point(max));
        _plane.setFromNormalAndCoplanarPoint(direction, _curveBox.getCenter(_center));
        const z = _plane.normal;
        const bboxDistMax = Math.max(_curveBox.min.distanceTo(bbox.max), _curveBox.max.distanceTo(bbox.min));
        const distance = marginOfError * bboxDistMax;
        const distance1 = distance;
        const distance2 = -distance;
        this.mode = { tag: 'contour', curve: curve, z, distance1, distance2 };
    }

    set curve(view: visual.SpaceInstance) {
        const { db, constructionPlane, isOrthoMode, _shell: { model: shell } } = this;
        const curve = db.lookup(view);
        let plane: THREE.Plane | undefined;
        const bbox = this.bbox;

        // NOTE: the goal is to find a direction to extrude the curve; always prioritize orthomode cplane.
        // If not in orthomode, if this is a planar curve (NOT A LINE), usethe curve's planar basis.
        // If it's a line, we can try plane associated with the construction geometry, if it exists. Otherwise,
        // try x,y,z axes, checking to see if we can find an intersection.
        const basis = curve.FindPlanarBasis();
        const axis = curve.FindLinearAxis()
        if (constructionPlane !== undefined && isOrthoMode) {
            plane = constructionPlane.plane;
        } else if (basis !== undefined && axis === undefined) {
            plane = plane2plane(basis);
        } else {
            const geos = curve.GetConstructionGeometry();
            const geo = geos[0] as c3d.Geometry | undefined;
            if (geo instanceof c3d.Plane) {
                const wasConstructedOn = plane2plane(geo.GetInfo());
                if (wouldCut(wasConstructedOn, bbox)) plane = wasConstructedOn;
            }
            if (plane === undefined) {
                const axis = curve.FindLinearAxis();
                if (axis !== undefined) {
                    const hint = bestPlacementForCut(bbox, axis2line(axis), constructionPlane?.n);
                    if (hint !== undefined) {
                        plane = hint;
                    }
                }
            }
        }
        plane ||= new THREE.Plane();
        const z = plane.normal;
        this.setContour(curve, z, bbox);
    }

    private get bbox() {
        const { _shell: { model: shell } } = this;
        const { min, max } = shell.FindBox();
        return _shellBox.set(point2point(min), point2point(max));
    }

    async calculatePhantoms(partition: c3d.Partition): Promise<PhantomInfo[]> {
        const material = { surface: surface_red };
        const { mode, fantom } = this;
        let phantom;
        switch (mode.tag) {
            case 'contour': {
                fantom.curve = mode.curve;
                fantom.direction = mode.z;
                fantom.distance1 = mode.distance1;
                fantom.distance2 = mode.distance2;

                phantom = await fantom.calculate(partition);
                break;
            }
            case 'surface': {
                const surface = mode.surface;
                let { uMin, vMin, uMax, vMax } = surface.GetUVBox();

                if (surface.IsPlanar()) {
                    const centerU = (mode.uMin + mode.uMax) / 2;
                    const centerV = (mode.vMin + mode.vMax) / 2;
                    const center_ = surface.GetPoint(centerU, centerV);
                    const center = point2point(center_);
                    const bbox = this.bbox;
                    const { min, max } = bbox;
                    const radius = (center.manhattanDistanceTo(min) + center.manhattanDistanceTo(max)) / 2;
                    const { normal, uDirection } = surface.EvalBasis(centerU, centerV);
                    const basis = new c3d.Basis(center_, normal, uDirection);
                    phantom = partition.SheetBody.CreateCircle(radius, basis);
                } else {
                    uMin = Math.max(uMin, mode.uMin);
                    vMin = Math.max(vMin, mode.vMin);
                    uMax = Math.min(uMax, 2 * mode.uMax);
                    vMax = Math.min(vMax, 2 * mode.vMax);
                    phantom = partition.SheetBody.MakeFromSurfaceTrimmed(surface, uMin, vMin, uMax, vMax);
                }
                break;
            }
        }
        return [{ phantom, material }];
    }

    protected async getSheet(partition: c3d.Partition) {
        const { mode, fantom } = this;

        switch (mode.tag) {
            case 'contour': {
                fantom.curve = mode.curve;
                fantom.direction = mode.z;
                fantom.distance1 = mode.distance1;
                fantom.distance2 = mode.distance2;

                return fantom.calculate(partition);
            }
            case 'surface': {
                return partition.SheetBody.MakeFromSurface(mode.surface);
            }
        }
    }

    private tracking!: { front: c3d.Shell[], back: c3d.Shell[] };
    async calculate(partition: c3d.Partition) {
        const { _shell: { model: shell } } = this;

        const sheet = await this.getSheet(partition);
        const options = new c3d.SectionOptions();
        const { front, back } = await shell.SectionWithSheet_async(sheet, options);

        // If there is no cut, then we define nothing as front or back
        this.tracking = (front.length === 0 || back.length === 0)
            ? { front: [], back: [] }
            : { front, back }

        return [...front, ...back];
    }

    get originalItem() { return this.shell }

    get selection() {
        if (this.tracking === undefined) throw new Error("invalid state");
        return this.tracking;
    }
}

export class MultiCutFactory extends GeometryFactory<c3d.Shell, visual.Shell, []> implements CutParams {
    constructionPlane?: PlaneSnap;
    isOrthoMode = false;

    protected _shells!: { views: visual.Shell[]; models: c3d.Shell[]; };
    @derive([visual.Shell]) get shells(): visual.Shell[] { throw ''; }
    set shells(solids: visual.Shell[] | c3d.Shell[]) { }

    protected _curves!: { views: visual.SpaceInstance[]; models: c3d.Wire[]; };
    @derive([visual.SpaceInstance]) get curves(): visual.SpaceInstance[] { throw ''; }
    set curves(curves: visual.SpaceInstance[] | c3d.Wire[]) { }

    protected _faces!: { views: visual.Face[]; models: c3d.Face[]; };
    @derive([visual.Face]) get faces(): visual.Face[] { throw ''; }
    set faces(faces: visual.Face[] | c3d.Face[]) { }

    readonly direction = new THREE.Vector3();

    private tracking!: { front: c3d.Shell[], back: c3d.Shell[] }[];
    async calculate(partition: c3d.Partition) {
        const { _shells: { models: shells }, _curves: { views: curves }, _faces: { views: faces }, constructionPlane, isOrthoMode } = this;

        const cutters = [...faces, ...curves];
        let targets = [...shells];
        let tracking: { front: c3d.Shell[], back: c3d.Shell[] }[] = [];
        for (const cutter of cutters) {
            const iteration: c3d.Shell[][] = [];
            for (const target of targets) {
                const cut = new CutFactory(this.db, this.materials, this.signals);
                cut.constructionPlane = constructionPlane;
                cut.isOrthoMode = isOrthoMode;
                cut.shell = target;
                cut.cutter = cutter;
                cut.direction.copy(this.direction);
                const result = await cut.calculate(partition);
                iteration.push(result);
                tracking.push(cut.selection);
            }
            targets = iteration.flat();
        }
        this.tracking = tracking;
        return targets;
    }

    override async calculatePhantoms(partition: c3d.Partition): Promise<PhantomInfo[]> {
        const { _shells: { models: shells }, _curves: { views: curves }, _faces: { views: faces }, constructionPlane, isOrthoMode } = this;

        const cutters = [...faces, ...curves];
        const results = [];
        const first = shells[0]
        for (const cutter of cutters) {
            const cut = new CutFactory(this.db, this.materials, this.signals);
            cut.constructionPlane = constructionPlane;
            cut.isOrthoMode = isOrthoMode;
            cut.shell = first;
            cut.cutter = cutter;
            cut.direction.copy(this.direction);
            const result = await cut.calculatePhantoms(partition);
            results.push(result);
        }
        return results.flat();
    }

    get originalItems() { return this.shells }

    get selection() {
        const { state } = this.state;
        if (state.tag !== 'committed') throw new Error("invalid state");
        const shells = state.result;
        const frontIds: Set<c3d.BodyId> = new Set(), backIds: Set<c3d.BodyId> = new Set();
        for (const { front, back } of this.tracking) {
            for (const f of front) frontIds.add(f.Id());
            for (const b of back) backIds.add(b.Id());
        }
        const front: visual.Shell[] = [], back: visual.Shell[] = [];
        for (const s of shells) {
            const model = this.db.lookup(s);
            if (backIds.has(model.Id())) back.push(s);
            else if (frontIds.has(model.Id())) front.push(s);
        }
        return { front, back };
    }
}

const mesh_red = new THREE.MeshBasicMaterial();
mesh_red.color.setHex(0xff0000);
mesh_red.opacity = 0.1;
mesh_red.transparent = true;
mesh_red.fog = false;
mesh_red.polygonOffset = true;
mesh_red.polygonOffsetFactor = 0.1;
mesh_red.polygonOffsetUnits = 1;

const surface_red = mesh_red.clone();
surface_red.side = THREE.DoubleSide;

export function wouldCut(plane: THREE.Plane, bbox: THREE.Box3): boolean {
    return plane.normal.manhattanLength() > 0 && plane.intersectsBox(bbox)
}

const x = new THREE.Plane();
const y = new THREE.Plane();
const z = new THREE.Plane();
const tmp = new THREE.Vector3();

export function bestPlacementForCut(bbox: THREE.Box3, line: THREE.Line3, prefer: THREE.Vector3 = Z): THREE.Plane | undefined {
    x.setFromCoplanarPoints(line.start, line.end, tmp.copy(line.end).add(X));
    y.setFromCoplanarPoints(line.start, line.end, tmp.copy(line.end).add(Y));
    z.setFromCoplanarPoints(line.start, line.end, tmp.copy(line.end).add(Z));
    const possibilities = [];
    if (wouldCut(x, bbox)) possibilities.push(x.setFromNormalAndCoplanarPoint(X, line.start));
    if (wouldCut(y, bbox)) possibilities.push(y.setFromNormalAndCoplanarPoint(Y, line.start));
    if (wouldCut(z, bbox)) possibilities.push(z.setFromNormalAndCoplanarPoint(Z, line.start));

    if (possibilities.length === 0) return undefined;
    if (possibilities.length === 1) return possibilities[0];
    for (const possibility of possibilities) {
        if (isParallel(possibility.normal, prefer)) {
            return possibility;
        }
    }

    return possibilities[0];
}

const _center = new THREE.Vector3();
const _plane = new THREE.Plane();
const _curveBox = new THREE.Box3();
const _shellBox = new THREE.Box3();
