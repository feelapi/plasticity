import * as THREE from "three";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import { MaterialOverride, TemporaryObject } from "../../editor/DatabaseLike";
import { Database } from "../../editor/db/Database";
import * as c3d from '../../kernel/kernel';
import { AtomicRef } from "../../util/Util";
import * as visual from '../../visual_model/VisualModel';
import { MultiTransformFactory, TransformMode } from "../translate/MultiTransformFactory";

export interface MultiBooleanLikeFactory extends GeometryFactory<c3d.Shell, visual.Shell, []> {
    set targets(targets: visual.Shell[]);
    set tool(target: visual.Shell | c3d.Shell);
    set tools(target: visual.Shell[] | c3d.Shell[]);

    operationType: c3d.OperationType;
}

export interface BooleanParams {
    operationType: c3d.OperationType;
    keepTools: boolean;
}

export class BooleanFactory extends GeometryFactory<c3d.Shell, visual.Shell, []> implements BooleanParams {
    keepTools = false;

    private readonly transform = new MultiTransformFactory(this.db, this.materials, this.signals);
    get mode() { return this.transform.mode }
    set mode(mode: TransformMode) { this.transform.mode = mode }
    get move() { return this.transform.move }
    set angle(angle: number) { this.transform.angle = angle }
    get pivot() { return this.transform.pivot }
    get axis() { return this.transform.axis }
    set degrees(degrees: number) { this.transform.degrees = degrees }
    get scale() { return this.transform.scale }
    get matrix() { return this.transform.matrix }
    get quaternion() { return this.transform.quaternion }
    clearTransform() { this.transform.clearTransform() }
    push() { this.transform.push() }

    operationType = c3d.OperationType.Difference;

    protected _targets: { views: visual.Shell[]; models: c3d.Shell[]; } = { views: [], models: [] };
    get targets(): visual.Shell[] { return this._targets.views }
    set targets(targets: visual.Shell[]) {
        this._targets = { views: targets, models: targets.map(t => this.db.lookup(t)) };
        this.phantoms.targets = targets;
    }

    protected _tools: { views: visual.Shell[]; models: c3d.Shell[]; } = { views: [], models: [] };
    get tools(): visual.Shell[] { return this._tools.views }
    set tools(tools: visual.Shell[]) {
        this._tools = { views: tools, models: tools.map(t => this.db.lookup(t)) };
        this.phantoms.tools = tools;
        this.transform.items = tools;
    }

    set tool(tool: visual.Shell) { this.tools = [tool] }

    async calculate() {
        const { _targets: { models: targets }, operationType, keepTools } = this;

        const moved = await this.moveTools();
        let keptTools: c3d.Shell[] = [];
        if (keepTools) {
            keptTools = moved.map(m => m.Copy());
        }

        const collection = new c3d.BodyCollection(targets.map(t => t.Id()));
        const options = new c3d.BooleanOptions(operationType);
        const { modified, unmodified } = await collection.Boolean_async(moved, options);
        return [...modified, ...unmodified, ...keptTools] as c3d.Shell[];
    }

    private readonly phantoms = new BooleanPhantomStrategy(this.db);
    override async doPhantoms(abortEarly: () => boolean): Promise<TemporaryObject[]> {
        const { phantoms } = this;
        phantoms.operationType = this.operationType;
        phantoms.matrix.copy(this.transform.matrix);
        const temps = phantoms.doPhantoms();
        return this.showTemps(temps);
    }

    get originalItems() {
        return [...this.targets, ...this.tools];
    }

    private async moveTools(): Promise<c3d.Shell[]> {
        const { transform } = this;
        try {
            return await transform.calculate() as c3d.Shell[];
        } catch (e) {
            if (e instanceof NoOpError) return this._tools.models;
            throw e;
        }
    }
}

type ToolAndTargetPhantoms = { tools: TemporaryObject[], targets: TemporaryObject[], dirty: boolean };

export class BooleanPhantomStrategy {
    readonly matrix = new THREE.Matrix4();

    constructor(private readonly db: Database) { }

    private _operationType = c3d.OperationType.Difference;
    get operationType() { return this._operationType }
    set operationType(operationType: c3d.OperationType) {
        if (operationType === this._operationType) return;
        this._operationType = operationType;
        this.dirty();
    }

    private _tools!: { views: readonly visual.Shell[] };
    get tools() { return this._tools.views }
    set tools(tools: readonly visual.Shell[]) {
        this._tools = { views: tools };
        this.dirty();
    }

    private _targets: { views: readonly visual.Shell[] } = { views: [] };
    get targets() { return this._targets.views }
    set targets(targets: readonly visual.Shell[]) {
        this._targets = { views: targets };
        this.dirty();
    }

    private calculateToolPhantoms() {
        const { operationType, tools } = this;

        const material = materialForOperation(operationType);

        const result = [];
        for (const view of tools) {
            result.push(view.makePhantom(material));
        }
        return result;
    }

    private calculateTargetPhantoms() {
        return this.targets.map((target, i) => target.makePhantom(phantom_blue));
    }

    private readonly phantoms = new AtomicRef<ToolAndTargetPhantoms | undefined>(undefined);

    doPhantoms() {
        const { clock, value } = this.phantoms.get();
        if (value === undefined || value.dirty) {
            const toolInfos = this.calculateToolPhantoms();
            const targetInfos = this.calculateTargetPhantoms();

            const tools = toolInfos.map(tool => this.db.addPhantom(tool));
            const targets = targetInfos.map(target => this.db.addPhantom(target));

            if (value?.dirty) {
                value.tools.forEach(t => t.cancel());
                value.targets.forEach(t => t.cancel());
            }
            this.phantoms.compareAndSet(clock, { tools, targets, dirty: false });
        }
        const { tools, targets } = this.phantoms.get().value!;
        MovePhantomsOnUpdate: {
            for (const [i, phantom] of tools.entries()) {
                transformTemporary(phantom.underlying, this.matrix);
                transformTemporary(this.tools[i], this.matrix);
            }
        }
        return [...tools, ...targets];
    }

    dirty() {
        const phantoms = this.phantoms.get().value;
        if (phantoms !== undefined) {
            phantoms.dirty = true;
        }
    }
}

const mesh_red = new THREE.MeshBasicMaterial();
mesh_red.color.setHex(0xff0000);
mesh_red.opacity = 0.1;
mesh_red.transparent = true;
mesh_red.fog = false;
mesh_red.polygonOffset = true;
mesh_red.polygonOffsetFactor = 0.1;
mesh_red.polygonOffsetUnits = 1;

const surface_red = mesh_red.clone();
surface_red.side = THREE.DoubleSide;

export const phantom_red: MaterialOverride = {
    mesh: mesh_red,
    surface: surface_red,
}

const mesh_green = new THREE.MeshBasicMaterial();
mesh_green.color.setHex(0x00ff00);
mesh_green.opacity = 0.1;
mesh_green.transparent = true;
mesh_green.fog = false;
mesh_green.polygonOffset = true;
mesh_green.polygonOffsetFactor = 0.1;
mesh_green.polygonOffsetUnits = 1;

const surface_green = mesh_green.clone();
surface_green.side = THREE.DoubleSide;

export const phantom_green: MaterialOverride = {
    mesh: mesh_green,
    surface: surface_green,
}

const mesh_blue = new THREE.MeshBasicMaterial();
mesh_blue.color.setHex(0x0000ff);
mesh_blue.opacity = 0.1;
mesh_blue.transparent = true;
mesh_blue.fog = false;
mesh_blue.polygonOffset = true;
mesh_blue.polygonOffsetFactor = 0.1;
mesh_blue.polygonOffsetUnits = 1;

const surface_blue = mesh_blue.clone();
surface_blue.side = THREE.DoubleSide;

export const phantom_blue: MaterialOverride = {
    mesh: mesh_blue,
    surface: surface_blue,
}

function transformTemporary(item: THREE.Object3D, mat: THREE.Matrix4) {
    item.matrixAutoUpdate = false;
    item.matrix.copy(mat);
    item.matrix.decompose(item.position, item.quaternion, item.scale);
    item.updateMatrixWorld(true);
}

export function materialForOperation(operationType: c3d.OperationType) {
    let material: MaterialOverride;
    if (operationType === c3d.OperationType.Difference) material = phantom_red
    else if (operationType === c3d.OperationType.Intersection) material = phantom_green;
    else material = phantom_blue;
    return material;
}