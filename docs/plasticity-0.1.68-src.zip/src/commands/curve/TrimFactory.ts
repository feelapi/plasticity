import { GeometryFactory } from '../../command/GeometryFactory';
import { groupBy } from '../../command/MultiFactory';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';
import { Interval } from './Interval';

interface Fragment {
    infos: visual.FragmentInfo[];
    curve: c3d.Wire;
}

export default class TrimFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance, []> {
    set fragment(fragment: visual.SpaceInstance) {
        this.fragments = [fragment];
    }

    private infos: Map<visual.SpaceInstance, Fragment> = new Map();
    private _originals: visual.SpaceInstance[] = [];
    set fragments(fragments: visual.SpaceInstance[]) {
        const result = new Map<visual.SpaceInstance, Fragment>();
        for (const fragment of fragments) {
            if (!fragment.isFragment) throw new Error("not a fragment");
            const fragmentInfo = fragment.fragmentInfo;
            if (fragmentInfo === undefined) throw new Error("invalid precondition");
            const untrimmed = fragmentInfo.untrimmedAncestor;
            const curve = this.db.lookup(untrimmed);
            if (!result.has(untrimmed)) {
                result.set(untrimmed, { infos: [], curve });
            }
            const info = result.get(untrimmed)!;
            info.infos.push(fragmentInfo);
        }
        this._originals = [...result.keys()];
        this.infos = result;
    }

    async calculate() {
        const { infos } = this;

        const results = [];
        for (const [_, fragment] of infos) {
            const { infos } = fragment;
            if (infos.length === 1) { // FIXME: need more robust
                const { start, stop } = infos[0];
                if (start === -1 && stop === -1) continue;
            }

            results.push(this.trimGeneral(fragment));
        }
        return (await Promise.all(results)).flat();
    }

    private async trimGeneral(fragment: Fragment): Promise<c3d.Wire[]> {
        const { infos, curve } = fragment;
        const edge2infos = groupBy('edgeId', infos);
        const edges: c3d.Edge[] = [];
        const keeps: number[] = [];
        for (const [edgeId, infos] of edge2infos) {
            const edge = new c3d.Edge(edgeId);
            const interval = edge2interval(edge);
            const ks = interval.multitrim(infos.map(({ start, stop }) => [start, stop]));
            if (ks.length === 0) {
                edges.push(edge);
                keeps.push(0, 0);
            } else {
                for (const k of ks) {
                    edges.push(edge);
                    keeps.push(k.start, k.end);
                }
            }
        }

        return await curve.Trim_async(edges, keeps);
    }

    get originalItems() { return this._originals }
}

function edge2interval(edge: c3d.Edge) {
    const { tmin, tmax } = edge.GetInterval();
    return new Interval(tmin, tmax, edge.IsPeriodic());
}
