import { CommandKeyboardInput, EditorLike } from "../../command/CommandKeyboardInput";

export class CurveKeyboardGizmo extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('curve', editor, [
            'gizmo:curve:toggle',
            'gizmo:curve:undo',
        ]);
    }
}

export class LineKeyboardGizmo extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('line', editor, [
            'gizmo:line:undo',
        ]);
    }
}