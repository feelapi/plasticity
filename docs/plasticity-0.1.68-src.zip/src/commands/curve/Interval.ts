export class Interval {
    constructor(readonly start: number, readonly end: number, readonly cyclic: boolean = false) {
        if (Math.abs(start - end) < 10e-5) {
            this.start = this.end = 0;
        }
    }

    trim(from: number, to: number): Interval[] {
        const { start, end, cyclic } = this;
        if (Math.abs(from - to) <= 10e-4) return [this];
        if (!this.cyclic && from > to) throw new Error("invalid precondition: " + from + " > " + to + " for non-cyclic interval");
        if (from <= start && to >= end && start < end) return [];
        // if (from >= start && to >= end && this.start > this.end) return [];

        if (!cyclic) {
            if (from >= end && to >= end && start < end) return [this];
            if (from <= start && to <= start && start < end) return [this];
            if (from <= start && to <= start && from >= end && start > end) return [this];

            if (from <= start) {
                if (start < end) {
                    return [new Interval(to, end)];
                } else {
                    if (from < start && to <= start) {
                        return [new Interval(start, from)];
                    } else {
                        return [new Interval(to, end)];
                    }
                }
            } else if (to >= end) {
                return [new Interval(start, from)];
            } else {
                return [new Interval(start, from), new Interval(to, end)];
            }
        } else {
            if (from <= start) {
                return [new Interval(to, end - (start - from))];
            } else if (to >= end) {
                return [new Interval(start + (to - end), from)];
            } else {
                return [new Interval(to, from)];
            }
        }
    }

    multitrim(trims: [from: number, to: number][]): Interval[] {
        let work: Interval[] = [this];
        for (const trim of trims) {
            const [from, to] = trim;
            let next: Interval[] = [];
            while (work.length > 0) {
                const job = work.pop()!;
                next = next.concat(job.trim(from, to));
            }
            work = next;
        }
        return work;
    }
}
