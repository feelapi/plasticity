import * as THREE from "three";
import { LineMaterial } from "three/examples/jsm/lines/LineMaterial";
import { GeometryFactory, NoOpError, PhantomInfo } from '../../command/GeometryFactory';
import { MaterialOverride } from "../../editor/DatabaseLike";
import { Database } from "../../editor/db/Database";
import { EditorSignals } from "../../editor/EditorSignals";
import MaterialDatabase from "../../editor/MaterialDatabase";
import { ConstructionPlane } from "../../editor/snaps/ConstructionPlaneSnap";
import { PlaneSnap } from "../../editor/snaps/PlaneSnap";
import { Snap } from "../../editor/snaps/Snap";
import { CurveEdgeSnap, CurvePointSnap, EdgePointSnap, FaceCenterPointSnap, FaceSnap, TanTanSnap } from "../../editor/snaps/Snaps";
import * as c3d from '../../kernel/kernel';
import { plane2plane, point2point, vec2vec } from "../../util/Conversion";
import { needsResolution } from "../../visual_model/RenderedSceneBuilder";
import * as visual from '../../visual_model/VisualModel';
import { NonPlanarKnifeFactory } from "../circle/KnifeFactory";

export enum CurveType {
    Polyline, NURBS
}

export default class CurveFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> {
    constructionPlane?: ConstructionPlane;

    points: THREE.Vector3[] = [];
    type: CurveType = CurveType.NURBS;
    closed = false;
    splineThrough = true;

    get startPoint() { return this.points[0] }
    get otherPoints() { return this.points.slice(1) }

    async calculate(partition: c3d.Partition) {
        const { points, type, splineThrough: through, snap, hasEnoughPoints, closed, constructionPlane } = this;

        if (!hasEnoughPoints) throw new NoOpError();
        if (points[points.length - 2].manhattanDistanceTo(points[points.length - 1]) < 10e-5) throw new NoOpError();

        const cartPoints = points.map(p => point2point(p));
        const wire = splineCurve(partition, cartPoints, closed, type, through);
        const constructionGeometry = await getBestConstructionPlane(wire, snap, constructionPlane);
        if (constructionGeometry !== undefined && constructionGeometry.GetPartition().Id() === partition.Id())
            wire.AddConstructionGeometry(constructionGeometry);
        wire.Simplify();
        return wire;
    }

    calculateForUpdate(partition: c3d.Partition): Promise<c3d.Wire> { return this.calculate(partition) }

    get hasEnoughPoints() {
        const { points: { length } } = this;

        if (length < 2) return false;
        return true;
    }

    wouldBeClosed(p: THREE.Vector3) {
        return this.points.length >= 2 && p.manhattanDistanceTo(this.startPoint) < 10e-6;
    }

    private snap!: Snap;
    temp?: THREE.Vector3;
    push(point: THREE.Vector3, snap: Snap) {
        const { points } = this;
        this.snap = snap;
        points.push(point);
        if (points.length > 2) {
            this.temp = undefined;
            return;
        }
        if (snap instanceof TanTanSnap) {
            if (this.temp === undefined) this.temp = points[points.length - 2];
            points[points.length - 2] = snap.point1;
        } else if (this.temp !== undefined) {
            points[this.points.length - 2] = this.temp;
            this.temp = undefined;
        }
    }

    toggle() { this.splineThrough = !this.splineThrough }
}

export interface CurveWithPreviewFactoryLike {
    get canBeClosed(): boolean;
    get otherPoints(): THREE.Vector3[];
    get startPoint(): THREE.Vector3;
    get points(): THREE.Vector3[];
}

export class CurveWithPreviewFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> {
    protected readonly _actual = new CurveFactory(this.db, this.materials, this.signals);
    protected readonly _preview = new CurveFactory(this.db, this.materials, this.signals);
    private readonly _poly = new CurveFactory(this.db, this.materials, this.signals);

    constructor(
        protected readonly db: Database,
        protected readonly materials: MaterialDatabase,
        protected readonly signals: EditorSignals
    ) {
        super(db, materials, signals);
        this._preview.points = [new THREE.Vector3()];
        this._poly.type = CurveType.Polyline;
    }

    set constructionPlane(constructionPlane: ConstructionPlane | undefined) {
        this._actual.constructionPlane = constructionPlane;
        this._preview.constructionPlane = constructionPlane;
    }

    set type(t: CurveType) {
        this._actual.type = t;
        this._preview.type = t;
    }

    undo() {
        const { _actual: underlying, _preview: preview } = this;

        const last = preview.points.pop()!;
        preview.points.pop();
        preview.points.push(last);

        underlying.points.pop();
    }

    get canBeClosed() {
        return this._actual.points.length >= 3;
    }

    get startPoint() { return this._actual.startPoint }
    get otherPoints() { return this._actual.otherPoints }
    get points() { return this._actual.points }

    wouldBeClosed(p: THREE.Vector3) {
        return this._actual.wouldBeClosed(p);
    }

    set closed(c: boolean) {
        this._actual.closed = c;
    }

    push(p: THREE.Vector3, snap: Snap) {
        this._actual.push(p, snap);
        this._preview.push(p.clone(), snap);
    }

    preview(p: THREE.Vector3, snap: Snap) {
        if (this._preview.wouldBeClosed(p)) {
            this._preview.closed = true;
            this._preview.points = [...this._actual.points];
            this._poly.points = [...this._actual.points];
        } else {
            this._preview.closed = false;
            this._preview.points = [...this._actual.points];
            this._preview.push(p, snap);
            this._poly.points = [...this._actual.points, p];
        }
    }

    // The material behavior is a bit confusing here.
    // For polylines we don't want to do anything special. For NURBS "through" (i.e,. splining through points)
    // we want to hide control points of the preview (phantom) and the actual curve; instead we make a polyline
    // passing through the spline points; we hide the line but show the points.
    // For NURBS "!through" we show the points+hull for the preview but not actual.
    async calculatePhantoms(partition: c3d.Partition): Promise<PhantomInfo[]> {
        if (!this._preview.hasEnoughPoints) return [];

        const replaceHull = CurveType.NURBS && this.splineThrough;

        const material: MaterialOverride = {
            line: this.lineMaterial,
            lineDashed: line_invisible,
            occludedControlPoint: points_invisible,
            hull: replaceHull ? hull_invisible : undefined,
            controlPoint: replaceHull ? points_invisible : undefined,
        };
        try {
            const preview = await this._preview.calculate(partition);
            const phantoms = [{ material, phantom: preview }];
            if (replaceHull) {
                const poly = await this._poly.calculate(partition);
                phantoms.push({ material: { line: line_invisible, lineDashed: line_invisible }, phantom: poly });
            }
            return phantoms;
        } catch {
            // NOTE: the line can fail if the user adds point n+1=n.
            return [];
        }
    }
    protected get lineMaterial() { return line_phantom }

    async calculateForUpdate(partition: c3d.Partition) {
        return this._actual.calculateForUpdate(partition);
    }

    override get materialOverride(): MaterialOverride | undefined {
        if (this.type === CurveType.Polyline) return undefined;

        return {
            hull: hull_invisible,
            controlPoint: points_invisible,
            occludedControlPoint: points_invisible,
        }
    }

    async doCommit() {
        this._preview.cancel();
        return this._actual.commit();
    }

    get splineThrough() { return this._actual.splineThrough; }

    doCancel() {
        this._actual.cancel();
        this._preview.cancel();
    }

    toggle() {
        this._actual.toggle();
        this._preview.toggle();
    }
}

class KnifeCurveFactory extends NonPlanarKnifeFactory(CurveFactory) { }

export class KnifeCurveWithPreviewFactory extends CurveWithPreviewFactory {
    protected readonly _actual = new KnifeCurveFactory(this.db, this.materials, this.signals);

    override get lineMaterial() { return this.isKnife ? line_phantom_knife : line_phantom }

    get isKnife() { return this._actual.isKnife }
    set isKnife(isKnife: boolean) {
        this._actual.isKnife = isKnife;
    }

    get target() { return this._actual.target }
    set target(target: visual.Shell) {
        this._actual.target = target;
    }

    // @ts-ignore
    get originalItem() { return this.isKnife ? this.target : undefined; }
    get shouldHideOriginalItemDuringUpdate() { return false; }

    get selection() { return this._actual.selection }
}


async function getBestConstructionPlane(curve: c3d.Wire, snap: Snap, constructionPlane?: ConstructionPlane): Promise<c3d.Surface | undefined> {
    const axis = curve.FindLinearAxis();
    if (axis !== undefined) {
        if (snap instanceof PlaneSnap || snap instanceof FaceSnap || snap instanceof FaceCenterPointSnap) {
            return projectOntoPlaneSnap(axis, snap) ?? projectOntoConstructionPlane(axis, constructionPlane);
        } else if (snap instanceof CurveEdgeSnap) {
            return projectOntoCurveEdgeSnap(axis, snap) ?? projectOntoConstructionPlane(axis, constructionPlane);
        } else if (snap instanceof EdgePointSnap) {
            return projectOntoCurveEdgeSnap(axis, snap.edgeSnap) ?? projectOntoConstructionPlane(axis, constructionPlane);
        } else if (snap instanceof CurvePointSnap) {
            return projectOntoCurvePointSnap(axis, snap) ?? projectOntoConstructionPlane(axis, constructionPlane);
        } else {
            return projectOntoConstructionPlane(axis, constructionPlane);
        }
    }
}

function projectOntoCurveEdgeSnap(axis: c3d.Axis, snap: CurveEdgeSnap): c3d.Plane | undefined {
    const planeSnaps = snap.planes;
    for (const snap of planeSnaps) {
        const result = projectOntoPlaneSnap(axis, snap);
        if (result !== undefined) return result;
    }
}

function projectOntoCurvePointSnap(axis: c3d.Axis, snap: CurvePointSnap): c3d.Plane | undefined {
    // TODO: when snapping to a wirebody, if the wirebody is planar and we are compatible with that plane,
    // then we should use that plane.
    return undefined;
}

function projectOntoPlaneSnap(axis: c3d.Axis, snap: PlaneSnap | FaceSnap | FaceCenterPointSnap | ConstructionPlane): c3d.Plane | undefined {
    const basis = snap.placement;
    if (basis === undefined) return undefined;
    const plane = plane2plane(basis);
    const pos = point2point(axis.Location);
    if (Math.abs(plane.distanceToPoint(pos)) > 10e-6) return;
    pos.add(vec2vec(axis.Direction, 1));
    if (Math.abs(plane.distanceToPoint(pos)) > 10e-6) return;
    return c3d.Plane.Create(basis);
}

function projectOntoConstructionPlane(axis: c3d.Axis, constructionPlane?: ConstructionPlane): c3d.Plane | undefined {
    if (constructionPlane === undefined) return;
    return projectOntoPlaneSnap(axis, constructionPlane);
}

function splineCurve(partition: c3d.Partition, points: c3d.Point[], closed: boolean, type: CurveType, through: boolean) {
    if (type === CurveType.Polyline) {
        return partition.WireBody.CreatePolyline(points, closed);
    } else {
        const options = new c3d.CreateSplineOptions(closed);
        options.Through = through;
        const spline = partition.BCurve.CreateSpline(points, options);
        return partition.WireBody.CreateFromCurves([spline]);
    }
}

export const line_phantom = new LineMaterial({ color: 0x00ff00, linewidth: 1.1, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
line_phantom.depthFunc = THREE.AlwaysDepth;
needsResolution.push(line_phantom);

export const line_phantom_knife = new LineMaterial({ color: 0xffff00, linewidth: 1.1, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
line_phantom_knife.depthFunc = THREE.AlwaysDepth;
needsResolution.push(line_phantom_knife);

const line_invisible = new LineMaterial();
line_invisible.visible = false;

const hull_invisible = new THREE.LineBasicMaterial();
hull_invisible.visible = false;

const hull_phantom = new LineMaterial({ color: 0xffffff, linewidth: 0.5 });
hull_phantom.depthTest = false;
hull_phantom.opacity = 0.25;
hull_phantom.transparent = true;
needsResolution.push(hull_phantom);

const points_invisible = new THREE.PointsMaterial();
points_invisible.color = new THREE.Color(0x00ff00);
points_invisible.vertexColors = false;
points_invisible.visible = false;