import * as THREE from "three";
import Command from "../../command/Command";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { PointAxisSnap } from "../../editor/snaps/AxisSnap";
import { PickedPointSnap, PointSnap } from "../../editor/snaps/PointSnap";
import { Finish } from "../../util/Cancellable";
import * as visual from "../../visual_model/VisualModel";
import { booleanTargets } from "../box/BoxCommand";
import { KnifeKeyboardGizmo } from "../circle/KnifeKeyboardGizmo";
import { CurveType, CurveWithPreviewFactoryLike, KnifeCurveWithPreviewFactory } from "./CurveFactory";
import { CurveKeyboardGizmo, LineKeyboardGizmo } from "./CurveKeyboardGizmo";

export class CurveCommand extends Command {
    protected type = CurveType.NURBS;
    protected get keyboard() { return new CurveKeyboardGizmo(this.editor); };

    async execute(): Promise<void> {
        this.editor.layers.showControlPoints();
        this.ensure(() => this.editor.layers.refresh());

        const curve = new KnifeCurveWithPreviewFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        curve.type = this.type;
        curve.constructionPlane = this.editor.activeViewport?.constructionPlane;

        const keyboard = this.keyboard;
        const knife = new KnifeKeyboardGizmo(keyboard.title, this.editor);

        knife.execute(e => {
            switch (e) {
                case 'knife':
                    curve.isKnife = !curve.isKnife;
                    curve.update();
            }
        }).resource(this);

        const pointPicker = new PointPicker(this.editor);
        pointPicker.facePreferenceMode = 'weak';
        keyboard.execute(e => {
            switch (e) {
                case 'toggle':
                    curve.toggle();
                    curve.update();
                    break;
                case 'undo':
                    pointPicker.undo();
                    curve.undo();
                    curve.update();
                    addSnaps(curve, pointPicker);
                    break;
            }
        }).resource(this);

        const snaps = [];
        while (true) {
            await addSnaps(curve, pointPicker);
            try {
                const { point, info: { snap } } = await pointPicker.execute(async ({ point, info: { snap } }) => {
                    curve.preview(point, snap);
                    await curve.update();
                }, { rejectOnFinish: true }).resource(this);
                if (curve.wouldBeClosed(point)) {
                    curve.closed = true;
                    throw new Finish();
                }
                curve.push(point, snap);

                snaps.push(snap);
                const targets = booleanTargets(...snaps)
                if (targets.length > 0) curve.target = targets[0];

                await curve.update();
            } catch (e) {
                if (!(e instanceof Finish)) throw e;
                break;
            }
        }

        await curve.commit();

        this.editor.selection.selected.removeAll();
        const newSelection = curve.selection;
        this.editor.selection.selected.add(newSelection);
    }
}

export class LineCommand extends CurveCommand {
    protected type = CurveType.Polyline;
    protected get keyboard() { return new LineKeyboardGizmo(this.editor); };
}

async function addSnaps(curve: CurveWithPreviewFactoryLike, pointPicker: PointPicker) {
    pointPicker.clearAddedSnaps();
    if (curve.canBeClosed) {
        for (const point of curve.otherPoints) {
            pointPicker.addSnap(new PickedPointSnap(point));
        }
        pointPicker.addSnap(new ClosedPointSnap(curve.startPoint));
    }
    if (curve.points.length >= 2) {
        const lastPoint = curve.points[curve.points.length - 1];
        const secondLastPoint = curve.points[curve.points.length - 2];
        const n = lastPoint.clone().sub(secondLastPoint).normalize();
        const axis = new PointAxisSnap("Parallel", n, lastPoint);
        await pointPicker.addAxis(axis);
    }
    if (curve.points.length >= 3) {
        const lastPoint = curve.points[curve.points.length - 1];
        const secondLastPoint = curve.points[curve.points.length - 2];
        const thirdLastPoint = curve.points[curve.points.length - 3];
        const n = secondLastPoint.clone().sub(thirdLastPoint).normalize();
        const axis = new PointAxisSnap("Parallel", n, lastPoint);
        await pointPicker.addAxis(axis);
    }
    if (curve.points.length >= 4) {
        for (let i = 0; i < curve.points.length - 3; i++) {
            const p1 = curve.points[i];
            const p2 = curve.points[i + 1];
            const n = p2.clone().sub(p1).normalize();
            const axis = new PointAxisSnap("Parallel", n, p1);
            await pointPicker.addAxis(axis);
        }
    }
}

const overlayLayer = new THREE.Layers();
overlayLayer.set(visual.Layers.Overlay);

class ClosedPointSnap extends PointSnap {
    get layers() { return overlayLayer }

    constructor(point: THREE.Vector3) {
        super("Closed", point);
    }
}