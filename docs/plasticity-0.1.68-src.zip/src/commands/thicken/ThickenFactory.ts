import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { point2point, vec2vec } from "../../util/Conversion";
import * as visual from '../../visual_model/VisualModel';

export interface ThickenSheetParams {
    front: number;
    back: number;
}

export class ThickenSheetFactory extends GeometryFactory implements ThickenSheetParams {
    protected _sheet!: { view: visual.Sheet, model: c3d.Sheet };
    @derive(visual.Sheet) get sheet(): visual.Sheet { throw '' }
    set sheet(sheet: visual.Sheet | c3d.Sheet) { }

    front = 0;
    back = 0;

    async calculate() {
        const { _sheet: { model: sheet }, front, back } = this;
        const options = new c3d.ThickenOptions();
        return sheet.Thicken_async(front, back, options);
    }

    get info() {
        const { _sheet: { model: sheet }, front, back } = this;
        const face = sheet.GetFaces().Get(0);
        const { u, v, position } = face.GetAnyPointOn();
        const { normal } = face.EvalBasis(u, v);
        return { point: point2point(position), normal: vec2vec(normal, 1) };
}

    get originalItem() { return this.sheet }
}

// export class ThickFaceFactory extends GeometryFactory implements ThinSolidParams {
//     private readonly thinSolid = new ThinSolidFactory(this.db, this.materials, this.signals);
//     set solid(solid: visual.Solid) {
//         this.thinSolid.solid = solid;
//     }

//     set thickness1(thickness1: number) { this.thinSolid.thickness1 = thickness1 }
//     set thickness2(thickness2: number) { this.thinSolid.thickness2 = thickness2 }

//     set faces(faces: visual.Face[]) {
//         const solid = this.db.lookup(this.thinSolid.solid);
//         const models = solid.GetFaces();
//         const map = new Map<number, c3d.Face>(models.entries());
//         for (const face of faces) {
//             map.delete(face.index);
//         }
//         this.thinSolid.faces = [...map.values()];
//     }

//     calculate() {
//         return this.thinSolid.calculate();
//     }

// }