import Command from "../../command/Command";
import { Y } from "../../util/Constants";
// import { MultilineCommand } from "../curve/MultilineCommand";
import { FilletMagnitudeGizmo } from '../fillet/FilletGizmo';
import { ThickenDialog } from "./ThickenDialog";
import { ThickenSheetFactory } from "./ThickenFactory";


export class ThickenCommand extends Command {
    async execute(): Promise<void> {
        const selected = this.editor.selection.selected;
        if (selected.sheets.size > 0) {
            const command = new ThickenSheetCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.faces.size > 0) {
            // const command = new MultilineCommand(this.editor);
            // command.agent = this.agent;
            // this.editor.exec(command);
        }
    }
}

export class ThickenSheetCommand extends Command {
    async execute(): Promise<void> {
        const thick = new ThickenSheetFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        thick.sheet = this.editor.selection.selected.sheets.first;

        const gizmo = new FilletMagnitudeGizmo("thicken-sheet:thickness", this.editor);
        const dialog = new ThickenDialog(thick, this.editor.signals);

        dialog.execute(async (params) => {
            gizmo.render(params.front);
            await thick.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const { point, normal } = thick.info;
        gizmo.quaternion.setFromUnitVectors(Y, normal);
        gizmo.position.copy(point);

        gizmo.execute(thickness => {
            thick.front = thickness;
            dialog.render();
            thick.update();
        }).resource(this);

        await this.finished;

        await thick.commit();
    }
}
