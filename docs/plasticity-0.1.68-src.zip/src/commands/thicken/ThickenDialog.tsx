import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import { ThickenSheetParams } from "./ThickenFactory";

export class ThickenDialog extends AbstractDialog<ThickenSheetParams> {
    name = "Thicken";

    constructor(protected readonly params: ThickenSheetParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        let { front, back } = this.params;

        render(
            <>
                <ul>
                    <li>
                        <label>Thickness</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="front" value={front} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber name="back" value={back} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('plasticity-thicken-dialog', ThickenDialog);
