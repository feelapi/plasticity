import Command from "../../command/Command";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { AxisSnap } from "../../editor/snaps/AxisSnap";
import { Y } from "../../util/Constants";
import { booleanTargets } from "../box/BoxCommand";
import { CircleDialog } from "./CircleDialog";
import { KnifeCenterCircleFactory, KnifeTwoPointCircleFactory } from './CircleFactory';
import { CircleGizmo } from "./CircleGizmo";
import { CircleKeyboardGizmo } from "./CircleKeyboardGizmo";
import { KnifeKeyboardGizmo } from "./KnifeKeyboardGizmo";

export class CenterCircleCommand extends Command {
    async execute(): Promise<void> {
        const circle = new KnifeCenterCircleFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);

        const keyboard = new CircleKeyboardGizmo(this.editor);
        const knife = new KnifeKeyboardGizmo('circle', this.editor);
        const gizmo = new CircleGizmo(circle, this.editor);
        const dialog = new CircleDialog(circle, this.editor.signals);

        knife.execute(e => {
            switch (e) {
                case 'knife':
                    circle.isKnife = !circle.isKnife;
                    circle.update();
            }
        }).resource(this);

        const pointPicker = new PointPicker(this.editor);
        pointPicker.facePreferenceMode = 'strong';
        pointPicker.straightSnaps.delete(AxisSnap.Z);
        const { point: p1, info: { snap: snap1 } } = await pointPicker.execute().resource(this);
        circle.center = p1;

        dialog.execute(params => {
            gizmo.render(circle);
            circle.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const targets1 = booleanTargets(snap1)
        if (targets1.length > 0) circle.target = targets1[0];

        keyboard.execute(e => {
            switch (e) {
                case 'mode':
                    circle.toggleMode();
                    circle.update();
            }
        }).resource(this);

        pointPicker.restrictToPlaneThroughPoint(p1, snap1);
        const { point: p2, info: { snap: snap2 } } = await pointPicker.execute(({ point: p2, info: { orientation } }) => {
            circle.point = p2;
            circle.orientation = orientation;
            dialog.render();
            circle.update();
        }).resource(this);

        const targets2 = booleanTargets(snap1, snap2)
        if (targets2.length > 0) circle.target = targets2[0];

        gizmo.position.copy(circle.center);
        gizmo.quaternion.setFromUnitVectors(Y, p2.sub(p1).normalize());
        await gizmo.execute(params => {
            dialog.render();
            circle.update();
        }).resource(this);

        await circle.commit();

        this.editor.selection.selected.removeAll();
        const newSelection = circle.selection;
        this.editor.selection.selected.add(newSelection);
    }
}

export class TwoPointCircleCommand extends Command {
    async execute(): Promise<void> {
        const circle = new KnifeTwoPointCircleFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);

        const keyboard = new CircleKeyboardGizmo(this.editor);
        const knife = new KnifeKeyboardGizmo('circle', this.editor);

        keyboard.execute(e => {
            switch (e) {
                case 'mode':
                    circle.toggleMode();
                    circle.update();
                    break;
            }
        }).resource(this);

        knife.execute(e => {
            switch (e) {
                case 'knife':
                    circle.isKnife = !circle.isKnife;
                    circle.update();
            }
        }).resource(this);

        const pointPicker = new PointPicker(this.editor);
        pointPicker.straightSnaps.delete(AxisSnap.Z);
        const { point: p1, info: { snap: snap1 } } = await pointPicker.execute().resource(this);
        circle.p1 = p1;

        const targets1 = booleanTargets(snap1)
        if (targets1.length > 0) circle.target = targets1[0];

        pointPicker.restrictToPlaneThroughPoint(p1, snap1);
        const { info: { snap: snap2 } } = await pointPicker.execute(({ point: p2, info: { orientation } }) => {
            circle.p2 = p2;
            circle.orientation = orientation;
            circle.update();
        }).resource(this);

        const targets2 = booleanTargets(snap1, snap2)
        if (targets2.length > 0) circle.target = targets2[0];

        await circle.commit();

        this.editor.selection.selected.removeAll();
        const newSelection = circle.selection;
        this.editor.selection.selected.add(newSelection);
    }
}