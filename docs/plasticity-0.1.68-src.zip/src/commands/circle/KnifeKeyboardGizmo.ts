import { CommandKeyboardInput, EditorLike } from "../../command/CommandKeyboardInput";


export class KnifeKeyboardGizmo extends CommandKeyboardInput {
    constructor(name: string, editor: EditorLike) {
        super(name, editor, [
            `gizmo:${name}:knife`,
        ]);
    }
}
