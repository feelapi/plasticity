import * as THREE from "three";
import { LineMaterial } from "three/examples/jsm/lines/LineMaterial";
import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { AGConstructor } from "../../util/Util";
import { needsResolution } from "../../visual_model/RenderedSceneBuilder";
import * as visual from '../../visual_model/VisualModel';

type WireFactory2ShellFactory = GeometryFactory<c3d.Wire | c3d.Shell, visual.SpaceInstance | visual.Shell>;

export function PlanarKnifeFactory<T extends AGConstructor<WireFactory2ShellFactory>>(klass: T) {
    abstract class Anon extends klass {
        isKnife = false;

        protected _target!: { view: visual.Shell; model: c3d.Shell; };
        @derive(visual.Shell) get target(): visual.Shell { throw ''; }
        set target(target: visual.Shell | c3d.Shell) { }

        async calculatePhantoms(partition: c3d.Partition = this.phantomPartition) {
            if (this.isKnife) {
                const phantom = await super.calculate(partition);
                return [{ phantom, material: { line: line_phantom } }];
            } else
                return super.calculatePhantoms(partition);
        }

        async calculateForUpdate(partition: c3d.Partition = this.partition) {
            const { isKnife } = this;
            const curve = await super.calculate(partition) as c3d.Wire;
            if (isKnife) throw new NoOpError();
            else return curve;
        }

        async calculateForCommit(partition: c3d.Partition = this.partition) {
            const { isKnife, _target: { model: target } } = this;
            const curve = await super.calculate(partition) as c3d.Wire;
            if (isKnife) {
                const options = new c3d.ProjectCurveOptions();
                options.Method = c3d.ProjectionMethod.Normal;
                options.MaxDist = 1e-4;
                this._tracking = await target.ImprintWires_async([curve], options);
                return target;
            } else
                return curve;
        }

        get originalItem() { return this.isKnife ? this.target : undefined; }
        get shouldHideOriginalItemDuringUpdate() { return false; }

        private _tracking: c3d.ImprintWiresTrackRecord | undefined;
        get selection() {
            const { state } = this.state;
            if (state.tag !== 'committed') throw new Error("invalid state");
            if (this._tracking === undefined) return [state.result];
            const shell = state.result;
            const ids = this._tracking.GetNewFaces().GetIds();
            const names = [...ids].map(id => visual.Face.simpleName(shell.simpleName, id));
            return names.map(name => this.db.lookupTopologyItemById(name).view);
        }

    }

    return Anon;
}

export function NonPlanarKnifeFactory<T extends AGConstructor<WireFactory2ShellFactory>>(klass: T) {
    abstract class Anon extends klass {
        isKnife = false;

        protected _target!: { view: visual.Shell; model: c3d.Shell; };
        @derive(visual.Shell) get target(): visual.Shell { throw ''; }
        set target(target: visual.Shell | c3d.Shell) { }

        async calculatePhantoms(partition: c3d.Partition = this.phantomPartition) {
            const phantoms = await super.calculatePhantoms(partition);
            if (this.isKnife) {
                const phantom = await super.calculate(partition);
                return [{ phantom, material: { line: line_phantom } }, ...phantoms];
            } else
                return phantoms;
        }

        async calculateForUpdate(partition: c3d.Partition = this.partition) {
            const { isKnife, _target: { model: target } } = this;
            const curve = await super.calculate(partition) as c3d.Wire;
            return curve;
        }

        async calculateForCommit(partition: c3d.Partition = this.partition) {
            const { isKnife, _target: { model: target } } = this;
            const curve = await super.calculate(partition) as c3d.Wire;
            if (isKnife) {
                const options = new c3d.ProjectCurveOptions();
                options.Method = c3d.ProjectionMethod.Normal;
                this._tracking = await target.ImprintWires_async([curve], options);
                return target;
            } else
                return curve;
        }

        get originalItem() { return this.isKnife ? this.target : undefined; }
        get shouldHideOriginalItemDuringUpdate() { return false; }

        private _tracking: c3d.ImprintWiresTrackRecord | undefined;
        get selection() {
            const { state } = this.state;
            if (state.tag !== 'committed') throw new Error("invalid state");
            if (this._tracking === undefined) return [state.result];
            const shell = state.result;
            const ids = this._tracking.GetNewFaces().GetIds();
            const names = [...ids].map(id => visual.Face.simpleName(shell.simpleName, id));
            return names.map(name => this.db.lookupTopologyItemById(name).view);
        }

    }

    return Anon;
}

const line_phantom = new LineMaterial({ color: 0xffff00, linewidth: 1.1, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
line_phantom.depthFunc = THREE.AlwaysDepth;
needsResolution.push(line_phantom);