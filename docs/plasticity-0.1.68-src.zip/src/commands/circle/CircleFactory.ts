// TODO:
// - make center/point readonly
import * as THREE from "three";
import { GeometryFactory, NoOpError, ValidationError } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { Z } from "../../util/Constants";
import { point2point, vec2vec } from "../../util/Conversion";
import * as visual from '../../visual_model/VisualModel';
import { PlanarKnifeFactory } from "./KnifeFactory";

export enum CircleMode { Horizontal, Vertical }

export interface EditCircleParams {
    radius: number;
}

export class CenterCircleFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> implements EditCircleParams {
    center!: THREE.Vector3;
    point!: THREE.Vector3;
    orientation = new THREE.Quaternion();

    get radius() { return this.point?.distanceTo(this.center) ?? 0 }
    set radius(r: number) {
        if (this.point === undefined) {
            this.point = this.center.clone().add(radial.set(r, 0, 0).applyQuaternion(this.orientation));
        } else {
            this.point = this.point.clone().sub(this.center).normalize().multiplyScalar(r).add(this.center);
        }
    }

    mode = CircleMode.Horizontal;
    toggleMode() {
        this.mode = this.mode === CircleMode.Vertical ? CircleMode.Horizontal : CircleMode.Vertical;
    }

    async calculate(partition: c3d.Partition = this.partition) {
        const { radius, basis } = this;

        if (radius < 0) throw new ValidationError();
        if (radius < 10e-6) throw new NoOpError();

        return partition.WireBody.CreateCircle(radius, basis);
    }

    private get basis() {
        const { mode, center, point, orientation } = this;

        unorientedNormal.copy(Z).applyQuaternion(orientation);

        const [x, , z] = CenterCircleFactory.orientHorizontalOrVertical(point, center, unorientedNormal, mode);
        const basis = new c3d.Basis();
        basis.Axis.Copy(vec2vec(z, 1));
        basis.Ref.Copy(vec2vec(x, 1));
        basis.Location.Copy(point2point(center));

        return basis;
    }

    get normal() {
        const { mode, center, point, orientation } = this;
        unorientedNormal.copy(Z).applyQuaternion(orientation);
        const [, , z] = CenterCircleFactory.orientHorizontalOrVertical(point, center, unorientedNormal, mode);
        return z;
    }

    private static localY = new THREE.Vector3();
    private static localZ = new THREE.Vector3();
    static orientHorizontalOrVertical(p1: THREE.Vector3, p2: THREE.Vector3, n: THREE.Vector3, mode: CircleMode) {
        const { localY, localZ } = this;

        localY.copy(p1).sub(p2).normalize();
        localZ.copy(n).cross(localY);

        if (mode === CircleMode.Vertical) {
            return [n, localY, localZ];
        } else {
            return [localY, localZ, n];
        }
    }
}

export class TwoPointCircleFactory extends CenterCircleFactory {
    p1!: THREE.Vector3
    private radial = new THREE.Vector3();

    set p2(point: THREE.Vector3) {
        const { p1, radial } = this;
        this.point = point;
        radial.copy(point).sub(p1).multiplyScalar(0.5);
        this.center = new THREE.Vector3().copy(p1).add(radial);
    }
}

const unorientedNormal = new THREE.Vector3();
const radial = new THREE.Vector3();

export class KnifeCenterCircleFactory extends PlanarKnifeFactory(CenterCircleFactory) { }
export class KnifeTwoPointCircleFactory extends PlanarKnifeFactory(TwoPointCircleFactory) { }
