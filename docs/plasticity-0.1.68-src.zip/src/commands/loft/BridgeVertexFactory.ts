import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';

export interface BridgeVertexParams {
    startCurvature: c3d.ContinuityType;
    endCurvature: c3d.ContinuityType;
    tension1: number;
    tension2: number;
}

export class BridgeVertexFactory extends GeometryFactory implements BridgeVertexParams {
    get hasClamps() { return false }

    tension1 = 1;
    tension2 = 1;
    startCurvature = c3d.ContinuityType.G3;
    endCurvature = c3d.ContinuityType.G3;

    protected _vertex1!: { view: visual.SpaceInstance; model: c3d.Vertex; };
    @derive(visual.Vertex) get vertex1(): visual.Vertex { throw ''; }
    set vertex1(vertex1: visual.Vertex | c3d.Vertex) { }

    protected _vertex2!: { view: visual.SpaceInstance; model: c3d.Vertex; };
    @derive(visual.Vertex) get vertex2(): visual.Vertex { throw ''; }
    set vertex2(vertex2: visual.Vertex | c3d.Vertex) { }

    async calculate(partition: c3d.Partition) {
        const { _vertex1: { model: vertex1 }, _vertex2: { model: vertex2 }, startCurvature, endCurvature, tension1, tension2 } = this;
        const p1 = vertex1.GetPoint();
        const p2 = vertex2.GetPoint();
        const n1 = continuity2deriviative(startCurvature);
        // NOTE: if the vertex isn't spur, then we can get derivatives from multiple edges
        const n2 = continuity2deriviative(endCurvature);
        const d1 = vertex1.EvalDerivatives(n1).slice(0, n1);
        const d2 = vertex2.EvalDerivatives(n2).slice(0, n2);
        d2.forEach(d => d.MultiplyScalar(-1));
        d1.forEach(d => d.MultiplyScalar(tension1));
        d2.forEach(d => d.MultiplyScalar(tension2));
        const options = new c3d.CreateSplineOptions(closed);
        options.Through = true;
        options.Degree = 0;
        options.DerivativeConditions = [new c3d.SplineDerivativeCondition(d1), new c3d.SplineDerivativeCondition(d2)];
        const spline = partition.BCurve.CreateSpline([p1, p2], options);
        return partition.WireBody.CreateFromCurves([spline]);
    }
}

function continuity2deriviative(continuity: c3d.ContinuityType) {
    switch (continuity) {
        case c3d.ContinuityType.G1: return 1;
        case c3d.ContinuityType.G2: return 2;
        case c3d.ContinuityType.G3: return 3;
        default: return 0;
    }
}