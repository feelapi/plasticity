import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import { LoftGuideParams } from './LoftGuideFactory';

export class LoftGuideDialog extends AbstractDialog<LoftGuideParams> {
    name = "Loft";

    constructor(protected readonly params: LoftGuideParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        render(
            <>
                <ol>
                    <plasticity-prompt name="Select guides" description="to loft along"></plasticity-prompt>
                </ol>

            </>, this);
    }
}

customElements.define('loft-guide-dialog', LoftGuideDialog);
