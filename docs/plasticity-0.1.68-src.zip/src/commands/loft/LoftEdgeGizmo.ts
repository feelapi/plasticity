import * as THREE from "three";
import { AbstractGizmo, EditorLike, Intersector, Mode, MovementInfo } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { sphereGeometry } from "../../command/MiniGizmos";
import * as c3d from '../../kernel/kernel';
import { CancellablePromise } from "../../util/CancellablePromise";
import { point2point } from "../../util/Conversion";
import { EdgeLoftParams } from "./LoftFactory";
import * as visual from '../../visual_model/VisualModel';

export class LoftEdgeGizmo extends CompositeGizmo<EdgeLoftParams> {
    private readonly limits: EdgeSideGizmo[] = [];

    constructor(params: EdgeLoftParams, editor: EditorLike, private readonly edges: visual.CurveEdge[]) {
        super(params, editor);
    }

    prepare() { }

    execute(cb: (params: EdgeLoftParams) => void): CancellablePromise<void> {
        for (const edge of this.edges) {
            const model = this.editor.db.lookupTopologyItem(edge);
            const gizmo = this.addLimit(model);
            this.addGizmo(gizmo, side => {
                this.params.setSide(edge, side);
            });
        }

        return super.execute(cb, Mode.Persistent);
    }

    addLimit(edge: c3d.Edge): EdgeSideGizmo {
        const point = edge.GetPoint(0.5);
        const gizmo = new EdgeSideGizmo(`loft:side:${this.limits.length}`, this.editor);
        gizmo.relativeScale.setScalar(0.5);
        gizmo.position.copy(point2point(point));
        this.limits.push(gizmo);

        return gizmo;
    }

    get shouldRescaleOnZoom() { return false }
}


class EdgeSideGizmo extends AbstractGizmo<boolean> {
    private state = true;
    protected offMaterial = this.editor.gizmos.cyan;
    protected onMaterial = this.editor.gizmos.magenta;
    readonly tip = new THREE.Mesh(sphereGeometry, this.offMaterial.mesh);
    protected readonly knob = new THREE.Mesh(new THREE.SphereGeometry(0.2), this.editor.gizmos.invisible);

    constructor(name: string, editor: EditorLike) {
        super(name, editor);
        this.setup();
    }

    protected setup() {
        this.handle.add(this.tip);
        this.picker.add(this.knob);
    }

    onPointerEnter(intersect: Intersector) {
        this.tip.material = this.state ? this.onMaterial.hover.mesh : this.offMaterial.hover.mesh;
    }

    onPointerLeave(intersect: Intersector) {
        this.tip.material = this.state ? this.onMaterial.hover.mesh : this.offMaterial.mesh;
    }

    onPointerMove(cb: (i: boolean) => void, intersector: Intersector, info: MovementInfo): boolean | undefined {
        return this.state;
    }

    onPointerDown(cb: (i: boolean) => void, intersect: Intersector, info: MovementInfo): void {
        this.state = !this.state;
        cb(this.state);
    }

    onPointerUp(cb: (i: boolean) => void, intersect: Intersector, info: MovementInfo): void {
    }

    onInterrupt(cb: (i: boolean) => void): void { }
}