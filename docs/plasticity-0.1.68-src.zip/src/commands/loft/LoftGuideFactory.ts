import * as THREE from "three";
import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from "../../command/GeometryFactory";
import * as c3d from '../../kernel/kernel';
import { point2point } from '../../util/Conversion';
import * as visual from '../../visual_model/VisualModel';

export interface LoftGuideParams {

}

export class LoftGuideFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance, []> {
    protected _guides: { views: visual.SpaceInstance[]; models: c3d.Wire[]; } = { views: [], models: [] };
    @derive([visual.SpaceInstance]) get guides(): visual.SpaceInstance[] { throw ''; }
    set guides(guides: visual.SpaceInstance[] | c3d.Wire[]) { }

    protected _curves!: { views: visual.SpaceInstance[]; models: c3d.Wire[]; };
    @derive([visual.SpaceInstance]) get curves(): visual.SpaceInstance[] { throw ''; }
    set curves(curves: visual.SpaceInstance[] | c3d.Wire[]) { }

    readonly splits: Map<c3d.Edge, THREE.Vector3[]> = new Map();
    addVertexAt(segment: visual.CurveSegment, point: THREE.Vector3) {
        const model = this.db.lookupTopologyItem(segment);
        const ps = this.splits.get(model) ?? [];
        ps.push(point);
        this.splits.set(model, ps);
    }

    async calculate() {
        const { _curves: { models }, splits, _guides: { models: guides } } = this;

        for (const [segment, ps] of splits) {
            for (const p of ps) {
                const { t } = segment.FindPointNear(point2point(p));
                const { newEdge } = segment.SplitAt(t);
            }
        }

        const coll = await c3d.ProfileCollection.Create_async(models, guides);
        const vertss = coll.GetPathVertices();
        const lines = [];
        for (const verts of vertss) {
            const points = verts.GetPoints().GetPoints();
            const line = c3d.Wire.CreatePolyline(points, false);
            lines.push(line);
        }
        return [...lines, ...models];
    }

    get profiles() { return this.curves }

    get originalItems() { return this.curves }
}
