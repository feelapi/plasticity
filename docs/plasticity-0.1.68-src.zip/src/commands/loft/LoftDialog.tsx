import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import { LoftParams } from "./LoftFactory";
import * as c3d from '../../kernel/kernel';

export class LoftDialog extends AbstractDialog<LoftParams> {
    name = "Loft";

    constructor(protected readonly params: LoftParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { thickness1, thickness2, closed, startCurvature, endCurvature, hasClamps, startMagnitude, endMagnitude } = this.params;

        render(
            <>
                <ol>
                    <plasticity-prompt name="Select guides" description="to loft along"></plasticity-prompt>
                </ol>

                <ul>
                    {hasClamps && <>
                        <li>
                            <label>Start Continuity</label>
                            <div class="fields">
                                <input type="radio" hidden name="startCurvature" id="start_g0" value={c3d.LoftCurvatureType.Natural} checked={startCurvature === c3d.LoftCurvatureType.Natural} onClick={this.onChange}></input>
                                <label for="start_g0">G0</label>

                                <input type="radio" hidden name="startCurvature" id="start_g1" value={c3d.LoftCurvatureType.Unconstrained} checked={startCurvature === c3d.LoftCurvatureType.Unconstrained} onClick={this.onChange}></input>
                                <label for="start_g1">G1</label>

                                <input type="radio" hidden name="startCurvature" id="start_g2" value={c3d.LoftCurvatureType.Clamped} checked={startCurvature === c3d.LoftCurvatureType.Clamped} onClick={this.onChange}></input>
                                <label for="start_g2">G2</label>
                            </div>
                        </li>
                        <li>
                            <label>End Continuity</label>
                            <div class="fields">
                                <input type="radio" hidden name="endCurvature" id="end_g0" value={c3d.LoftCurvatureType.Natural} checked={endCurvature === c3d.LoftCurvatureType.Natural} onClick={this.onChange}></input>
                                <label for="end_g0">G0</label>

                                <input type="radio" hidden name="endCurvature" id="end_g1" value={c3d.LoftCurvatureType.Unconstrained} checked={endCurvature === c3d.LoftCurvatureType.Unconstrained} onClick={this.onChange}></input>
                                <label for="end_g1">G1</label>

                                <input type="radio" hidden name="endCurvature" id="end_g2" value={c3d.LoftCurvatureType.Clamped} checked={endCurvature === c3d.LoftCurvatureType.Clamped} onClick={this.onChange}></input>
                                <label for="end_g2">G2</label>
                            </div>
                        </li>
                        <li>
                            <label>Tension</label>
                            <div class="fields">
                                <plasticity-number-scrubber disabled={0} default={1} name="startMagnitude" value={startMagnitude} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                                <plasticity-number-scrubber disabled={0} default={1} name="endMagnitude" value={endMagnitude} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            </div>
                        </li>
                    </>
                    }
                    {/* <li>
                        <label>Thickness</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="thickness1" value={thickness1} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber name="thickness2" value={thickness2} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li> */}

                    <li>
                        <label for="closed">
                            Loop
                            <plasticity-tooltip>If there are three or more profiles, a loft can loop back on itself to create something like a ring</plasticity-tooltip>
                        </label>
                        <div class="fields">
                            <input type="checkbox" hidden id="closed" name="closed" checked={closed} onClick={this.onChange}></input>
                            <label for="closed">Loop</label>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}

customElements.define('loft-dialog', LoftDialog);
