import { render } from 'preact';
import { EditorSignals } from "../../editor/EditorSignals";
import { AbstractDialog } from "../../command/AbstractDialog";
import { BridgeVertexParams } from './BridgeVertexFactory';
import * as c3d from '../../kernel/kernel';

export class BridgeVertexDialog extends AbstractDialog<BridgeVertexParams> {
    name = "Bridge Vertex";

    constructor(protected readonly params: BridgeVertexParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { tension1, tension2, startCurvature, endCurvature } = this.params;

        render(
            <>
                <ul>
                    <li>
                        <label for="tension1">Tension 1</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="tension1" value={tension1} min={0} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="tension2">Tension 2</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="tension2" value={tension2} min={0} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="startCurvature">Start curvature</label>
                        <div class="fields">
                            <input type="radio" hidden name="startCurvature" id="startCurvature_g1" value={c3d.ContinuityType.G1} checked={startCurvature === c3d.ContinuityType.G1} onClick={this.onChange}></input>
                            <label class="btn" for="startCurvature_g1">Tangent</label>

                            <input type="radio" hidden name="startCurvature" id="startCurvature_g2" value={c3d.ContinuityType.G2} checked={startCurvature === c3d.ContinuityType.G2} onClick={this.onChange}></input>
                            <label class="btn" for="startCurvature_g2">G2</label>

                            <input type="radio" hidden name="startCurvature" id="startCurvature_g3" value={c3d.ContinuityType.G3} checked={startCurvature === c3d.ContinuityType.G3} onClick={this.onChange}></input>
                            <label class="btn" for="startCurvature_g3">G3</label>
                        </div>
                    </li>
                    <li>
                        <label for="endCurvature">End curvature</label>
                        <div class="fields">
                            <input type="radio" hidden name="endCurvature" id="endCurvature_g1" value={c3d.ContinuityType.G1} checked={endCurvature === c3d.ContinuityType.G1} onClick={this.onChange}></input>
                            <label class="btn" for="endCurvature_g1">Tangent</label>

                            <input type="radio" hidden name="endCurvature" id="endCurvature_g2" value={c3d.ContinuityType.G2} checked={endCurvature === c3d.ContinuityType.G2} onClick={this.onChange}></input>
                            <label class="btn" for="endCurvature_g2">G2</label>

                            <input type="radio" hidden name="endCurvature" id="endCurvature_g3" value={c3d.ContinuityType.G3} checked={endCurvature === c3d.ContinuityType.G3} onClick={this.onChange}></input>
                            <label class="btn" for="endCurvature_g3">G3</label>
                        </div>
                    </li>
                </ul></>, this);
    }
}
customElements.define('plasticity-bridge-vertex-dialog', BridgeVertexDialog);
