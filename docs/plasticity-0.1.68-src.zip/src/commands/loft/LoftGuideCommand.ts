import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { SelectionMode } from "../../selection/SelectionModeSet";
import { LoftGuideDialog } from "./LoftGuideDialog";
import { LoftGuideFactory } from "./LoftGuideFactory";
import { LoftGuideKeyboardGizmo } from "./LoftGuideKeyboardGizmo";

export class LoftGuideCommand extends Command {
    async execute(): Promise<void> {
        const { db, materials, signals, selection: { selected } } = this.editor;

        const guide = new LoftGuideFactory(db, materials, signals).resource(this);
        guide.curves = [...selected.curves];

        const dialog = new LoftGuideDialog(guide, this.editor.signals);
        const keyboard = new LoftGuideKeyboardGizmo(this.editor);
        // const gizmo = new LoftGuideGizmo(guide, this.editor, guide.edges);
        // const dialog = new LoftGuideDialog(guide, signals);

        dialog.execute(async params => {
            await guide.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        GetGuides: {
            dialog.prompt("Select guides", () => {
                const objectPicker = new ObjectPicker(this.editor);
                return objectPicker.execute(delta => {
                    guide.guides = [...objectPicker.selection.selected.curves];
                    guide.update();
                }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Curve).resource(this);
            })();
        }

        await guide.update();

        keyboard.execute(async (s) => {
            switch (s) {
                case 'add-vertex':
                    await this.addVertex(guide);
            }
        }).resource(this);

        await this.finished;

        const result = await guide.commit();

        selected.removeAll();
        selected.add(result);
    }

    private async addVertex(guide: LoftGuideFactory) {
        const resume = guide.pause(false);
        const variable = new PointPicker(this.editor);
        const edges = variable.restrictToCurves(guide.curves);
        variable.raycasterParams.Line2.threshold = 50;

        const { point, info: { restriction } } = await variable.execute().resource(this);
        const match = edges.find(restriction);
        const { view } = match;
        guide.addVertexAt(view, point);

        resume.dispose();
        await guide.update();
    }
}

export class LiveLoftCommand extends Command {
    async execute(): Promise<void> {
        const { db, materials, signals, selection: { selected }, lofts } = this.editor;
        const curves = [...selected.curves];
        lofts.create(curves);
        const txn = db.makeTransaction();
        await db.commit(txn);
    }   
}