import Command, { EditorLike } from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { SelectionMode } from "../../selection/SelectionModeSet";
import { BridgeVertexDialog } from "./BridgeVertexDialog";
import { BridgeVertexFactory } from "./BridgeVertexFactory";
import { LoftDialog } from "./LoftDialog";
import { LoftEdgeGizmo } from "./LoftEdgeGizmo";
import { CurveLoftFactory, EdgeLoftFactory, FaceLoftFactory, RegionLoftFactory } from "./LoftFactory";

export class LoftCommand extends Command {
    async execute(): Promise<void> {
        const selected = this.editor.selection.selected;

        if (selected.vertices.size > 0) {
            const command = new BridgeVertexCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.edges.size > 0) {
            const command = new LoftEdgeCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else {
            const command = new LoftSurfaceCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        }
    }
}

export class BridgeVertexCommand extends Command {
    async execute(): Promise<void> {
        const { editor: { selection, db, materials, signals } } = this;
        if (selection.selected.vertices.size !== 2) throw new Error("Select two vertices");
        const bridge = new BridgeVertexFactory(db, materials, signals);
        bridge.vertex1 = selection.selected.vertices.first;
        bridge.vertex2 = selection.selected.vertices.last!;

        await bridge.update();

        const dialog = new BridgeVertexDialog(bridge, signals);
        dialog.execute(() => {
            bridge.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        await this.finished;

        const result = await bridge.commit();
    }
}

export class LoftSurfaceCommand extends Command {
    async execute(): Promise<void> {
        const loft = LoftFactory(this.editor).resource(this);

        // const gizmo = new MagnitudeGizmo("loft:thickness", this.editor);
        const dialog = new LoftDialog(loft, this.editor.signals);

        dialog.execute(async (params) => {
            await loft.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        GetGuides: {
            dialog.prompt("Select guides", () => {
                const objectPicker = new ObjectPicker(this.editor);
                return objectPicker.execute(delta => {
                    loft.guides = [...objectPicker.selection.selected.curves];
                    loft.update();
                }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Curve).resource(this);
            })();
        }

        await loft.update();

        // const { point, z } = loft.info;
        // gizmo.position.copy(point);
        // gizmo.quaternion.setFromUnitVectors(Z, z);
        // await gizmo.execute(async thickness => {
        //     loft.thickness = thickness;
        //     dialog.render();
        //     loft.update();
        // }, Mode.Persistent).resource(this);

        await this.finished;

        const result = await loft.commit();
        for (const profile of loft.profiles) {
            this.editor.selection.selected.remove(profile);
        }
        this.editor.selection.selected.add(result);
    }
}

export class LoftEdgeCommand extends Command {
    async execute(): Promise<void> {
        const { db, materials, signals, selection: { selected } } = this.editor;

        const loft = new EdgeLoftFactory(db, materials, signals).resource(this);
        loft.edges = [...selected.edges];

        const gizmo = new LoftEdgeGizmo(loft, this.editor, loft.edges);
        const dialog = new LoftDialog(loft, signals);

        dialog.execute(async (params) => {
            await loft.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        GetGuides: {
            dialog.prompt("Select guides", () => {
                const objectPicker = new ObjectPicker(this.editor);
                return objectPicker.execute(delta => {
                    loft.guides = [...objectPicker.selection.selected.curves];
                    loft.update();
                }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Curve).resource(this);
            })();
        }

        await loft.update();

        gizmo.execute(async thickness => {
            loft.update();
        }).resource(this);

        await this.finished;

        const result = await loft.commit();

        for (const profile of loft.profiles) {
            this.editor.selection.selected.remove(profile);
        }
        this.editor.selection.selected.add(result);
    }
}

function LoftFactory(editor: EditorLike) {
    const { db, materials, signals, selection: { selected } } = editor;

    if (selected.regions.size >= 2) {
        const loft = new RegionLoftFactory(db, materials, signals);
        loft.sketch = selected.regions.first.parentItem;
        loft.regions = [...selected.regions];
        return loft;
    } else if (selected.curves.size >= 2) {
        const loft = new CurveLoftFactory(db, materials, signals);
        loft.curves = [...selected.curves];
        return loft;
    } else if (selected.faces.size >= 2) {
        const loft = new FaceLoftFactory(db, materials, signals);
        loft.faces = [...selected.faces];
        return loft;
    } else if (selected.edges.size >= 2) {
        const loft = new EdgeLoftFactory(db, materials, signals);
        loft.edges = [...selected.edges];
        return loft;
    } else throw new Error("no profiles");
}