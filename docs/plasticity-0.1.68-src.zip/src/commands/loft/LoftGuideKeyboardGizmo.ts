import { CommandKeyboardInput, EditorLike } from "../../command/CommandKeyboardInput";

export class LoftGuideKeyboardGizmo extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super("loft-guide", editor,
            ['gizmo:loft-guide:add-vertex']);
    }
}
