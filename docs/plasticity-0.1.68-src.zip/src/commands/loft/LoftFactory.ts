import * as THREE from "three";
import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import { groupBy } from '../../command/MultiFactory';
import * as c3d from '../../kernel/kernel';
import { point2point, vec2vec } from '../../util/Conversion';
import { computeBoxCentroid } from '../../util/Util';
import * as visual from '../../visual_model/VisualModel';

export interface LoftParams {
    thickness1: number;
    thickness2: number;
    thickness: number;
    closed: boolean;
    startCurvature: c3d.LoftCurvatureType;
    endCurvature: c3d.LoftCurvatureType;
    startMagnitude: number;
    endMagnitude: number;
    get hasClamps(): boolean;
}

export abstract class AbstractLoftFactory extends GeometryFactory implements LoftParams {
    get hasClamps() { return false }

    thickness1 = 0;
    thickness2 = 0;
    closed = false;
    startCurvature = c3d.LoftCurvatureType.Unconstrained;
    endCurvature = c3d.LoftCurvatureType.Unconstrained;
    startMagnitude = 0;
    endMagnitude = 0;

    abstract get info(): { point: THREE.Vector3, z: THREE.Vector3 };

    protected _guides: { views: visual.SpaceInstance[]; models: c3d.Wire[]; } = { views: [], models: [] };
    @derive([visual.SpaceInstance]) get guides(): visual.SpaceInstance[] { throw ''; }
    set guides(guides: visual.SpaceInstance[] | c3d.Wire[]) { }

    get thickness() { return this.thickness1 }
    set thickness(thickness: number) {
        this.thickness1 = this.thickness2 = thickness;
    }

    abstract get profiles(): visual.Item[] | visual.TopologyItem[];
}

export class CurveLoftFactory extends AbstractLoftFactory {
    protected _curves!: { views: visual.SpaceInstance[]; models: c3d.Wire[]; };
    @derive([visual.SpaceInstance]) get curves(): visual.SpaceInstance[] { throw ''; }
    set curves(curves: visual.SpaceInstance[] | c3d.Wire[]) { }

    private readonly centroid = new THREE.Vector3();
    get info(): { point: THREE.Vector3, z: THREE.Vector3 } {
        const { _curves: { models } } = this;
        const { centroid } = this;
        const wire = models[0];
        const { min, max } = wire.FindBox();
        const bbox = new THREE.Box3(point2point(min), point2point(max));
        bbox.getCenter(centroid);
        const basis = wire.FindPlanarBasis();
        const z = vec2vec(basis?.Axis ?? c3d.Z, 1);
        return { point: centroid, z };
    }

    async calculate() {
        const { thickness1, thickness2, _curves: { models }, closed, _guides: { models: guides } } = this;

        const options = new c3d.LoftOptions();
        // options.thickness1 = unit(thickness1);
        // options.thickness2 = unit(thickness2);
        // options.shellClosed = true;
        options.IsPeriodic = closed;


        const coll = await await c3d.ProfileCollection.Create_async(models, guides);
        // const vertss = coll.GetPathVertices();
        // const lines = [];
        // for (const verts of vertss) {
        //     const points = verts.GetPoints().GetPoints();
        //     const line = c3d.Wire.CreatePolyline(points, false);
        //     lines.push(line);
        // }
        // return [...lines];
        return coll.Loft_async(options);
    }

    get profiles() { return this.curves }
}

export class RegionLoftFactory extends AbstractLoftFactory {
    private direction!: THREE.Vector3;
    private centroid!: THREE.Vector3;

    protected _sketch!: { view: visual.SketchIsland; model: c3d.RegionBody; };
    get sketch(): visual.SketchIsland { return this._sketch.view }
    set sketch(sketch: visual.SketchIsland) {
        const model = this.db.lookup(sketch) as c3d.RegionBody;
        this._sketch = { view: sketch, model };
        const basis = this._sketch.model.GetBasis();
        const z = basis.Axis;
        this.direction = vec2vec(z, 1);
        this.centroid = point2point(basis.Location);
    }

    protected _regions!: { views: visual.Region[]; models: c3d.Region[]; };
    @derive([visual.Region]) get regions(): visual.Region[] { throw ''; }
    set regions(regions: visual.Region[] | c3d.Region[]) { }

    get info(): { point: THREE.Vector3, z: THREE.Vector3 } {
        return { point: this.centroid, z: this.direction };
    }

    async calculate() {
        const { thickness1, thickness2, _regions: { models, views }, closed, _guides: { models: guides } } = this;

        const map = groupBy('parentItem', views);
        const stack = [];
        for (const [key, value] of map) {
            const options = new c3d.SheetBodyMakeFromFacesOptions();
            const faces = value.map(v => this.db.lookupTopologyItem(v));
            const { sheets } = await c3d.Sheet.MakeFromFaces_async(faces, options);
            stack.push(sheets[0]);
        }

        const options = new c3d.LoftOptions();
        // options.thickness1 = unit(thickness1);
        // options.thickness2 = unit(thickness2);
        // options.shellClosed = true;
        options.IsPeriodic = closed;

        const coll = await c3d.ProfileCollection.Create_async(stack, guides);
        const vertss = coll.GetPathVertices();
        const lines = [];
        for (const verts of vertss) {
            const points = verts.GetPoints().GetPoints();
            const line = c3d.Wire.CreatePolyline(points, false);
            lines.push(line);
        }
        return coll.Loft_async(options);
        // return lines;
    }

    get profiles() { return this.regions }
}

export class FaceLoftFactory extends AbstractLoftFactory {
    override get hasClamps() { return true }

    private direction!: THREE.Vector3;
    private centroid!: THREE.Vector3;

    protected _faces!: { views: visual.Face[], models: c3d.Face[] };
    get faces() { return this._faces.views }
    set faces(faces: visual.Face[]) {
        if (faces.length === 0)
            return;

        const models = faces.map(f => this.db.lookupTopologyItem(f));
        this._faces = { views: faces, models: models };

        const map = groupBy('parentItem', faces);
        const [, fs] = map.entries().next().value as [visual.Solid, visual.Face[]];

        const box = new THREE.Box3();
        const centroid = computeBoxCentroid(fs.map(f => f.getBoundingBox(box)));
        this.centroid = centroid;

        const f = fs[0];
        const m = this.db.lookupTopologyItem(f);
        const { normal } = m.EvalBasis(0.5, 0.5);
        this.direction = vec2vec(normal, 1);
    }


    get info(): { point: THREE.Vector3, z: THREE.Vector3 } {
        return { point: this.centroid, z: this.direction };
    }

    async calculate() {
        const { thickness1, thickness2, _faces: { models, views }, closed, _guides: { models: guides }, startCurvature, endCurvature, startMagnitude, endMagnitude } = this;

        const map = groupBy('parentItem', views);
        const stack = [];
        const records = [];
        for (const [, value] of map) {
            const options = new c3d.SheetBodyMakeFromFacesOptions();
            options.Track = true;
            const faces = value.map(v => this.db.lookupTopologyItem(v));
            const { sheets, record } = await c3d.Sheet.MakeFromFaces_async(faces, options);
            for (const sheet of sheets) stack.push(sheet);
            records.push(record);
        }

        const options = new c3d.LoftOptions();
        if (startCurvature !== c3d.LoftCurvatureType.Natural) {
            const record = records[0];
            const profile = stack[0];
            const { edges, faces } = record.GetOriginalBoundary(profile);
            if (faces.Size() > 0) {
                options.Start.Type = c3d.LoftClampType.Face;
                options.Start.FaceClamp.Faces = faces;
                options.Start.FaceClamp.Edges = edges;
                if (Math.abs(startMagnitude) > 0) {
                    options.Start.FaceClamp.Magnitudes = [startMagnitude];
                }
                options.Start.Curvature = startCurvature;
            }
        }
        if (endCurvature !== c3d.LoftCurvatureType.Natural) {
            const record = records[records.length - 1];
            const profile = stack[stack.length - 1];
            const { edges, faces } = record.GetOriginalBoundary(profile);
            if (faces.Size() > 0) {
                options.End.Type = c3d.LoftClampType.Face;
                options.End.FaceClamp.Faces = faces;
                options.End.FaceClamp.Edges = edges;
                if (Math.abs(endMagnitude) > 0) {
                    options.End.FaceClamp.Magnitudes = [endMagnitude];
                }
                options.End.Curvature = endCurvature;
            }
        }
        // options.thickness1 = unit(thickness1);
        // options.thickness2 = unit(thickness2);
        // options.shellClosed = true;
        // options.closed = closed;

        const coll = await c3d.ProfileCollection.Create_async(stack, guides);
        return coll.Loft_async(options);
    }

    get profiles() { return this.faces }
}

export interface EdgeLoftParams extends LoftParams {
    setSide(edge: visual.CurveEdge, side: boolean): void;
}

export class EdgeLoftFactory extends AbstractLoftFactory implements EdgeLoftParams {
    override get hasClamps() { return true }

    private direction!: THREE.Vector3;
    private centroid!: THREE.Vector3;

    private side1: 'primary' | 'secondary' = 'primary';
    private side2: 'primary' | 'secondary' = 'primary';

    setSide(edge: visual.CurveEdge, side: boolean) {
        const { _edges: { views } } = this;
        const index = views.indexOf(edge);
        if (index === 0) {
            this.side1 = side ? 'primary' : 'secondary';
        } else if (index === views.length - 1) {
            this.side2 = side ? 'primary' : 'secondary';
        }
    }

    protected _edges!: { views: visual.CurveEdge[], models: c3d.Edge[] };
    get edges() { return this._edges.views }
    set edges(edges: visual.CurveEdge[]) {
        if (edges.length === 0)
            return;

        const models = edges.map(e => this.db.lookupTopologyItem(e));
        this._edges = { views: edges, models };

        const map = groupBy('parentItem', edges);
        const [, es] = map.entries().next().value as [visual.Solid, visual.CurveEdge[]];

        const e = es[0];
        const m = this.db.lookupTopologyItem(e);
        const position = m.GetPoint(0.5);
        const { normal } = m.EvalBasis(0.5);
        this.direction = vec2vec(normal, 1);
        this.centroid = point2point(position);
    }

    get info(): { point: THREE.Vector3, z: THREE.Vector3 } {
        return { point: this.centroid, z: this.direction };
    }

    async calculate() {
        const { thickness1, thickness2, _edges: { models: edges, views }, closed, _guides: { models: guides }, startCurvature, endCurvature, side1, side2 } = this;
        let { startMagnitude, endMagnitude } = this;

        const shell2edge = groupBy('parentItem', views);
        if (shell2edge.size === 0) throw new NoOpError();

        const stack = [];
        const records = [];
        if (shell2edge.size > 1) {
            for (const [, value] of shell2edge) {
                const edges = value.map(v => this.db.lookupTopologyItem(v));
                const options = new c3d.WireBodyCreateFromEdgesOptions();
                options.Track = true;
                const { wires, record } = await c3d.Wire.CreateFromEdges_async(edges, options);
                stack.push(wires[0]);
                records.push(record);
            }
        } else {
            const [, value] = shell2edge.entries().next().value as [string, visual.CurveEdge[]];
            const edges = value.map(v => this.db.lookupTopologyItem(v));
            const options = new c3d.WireBodyCreateFromEdgesOptions();
            options.Track = true;
            for (const edge of edges) {
                const { wires, record } = await c3d.Wire.CreateFromEdges_async([edge], options);
                stack.push(wires[0]);
                records.push(record);
            }
        }

        const options = new c3d.LoftOptions();
        if (startCurvature !== c3d.LoftCurvatureType.Natural) {
            const record = records[0];
            const profile = stack[0];
            const { productEdges, originalEdges } = record.GetOriginalBoundary(profile);
            const { primary, secondary } = originalEdges.GetPrimaryAndSecondaryFaces()
            // const faces = side1 === 'primary' ? primary : secondary;
            let faces;
            if (side1 === 'primary') {
                faces = primary;
            } else if (secondary.Size() === 0) {
                faces = primary;
                startMagnitude = startMagnitude === 0 ? 1 : startMagnitude;
                startMagnitude *= -1;
            } else {
                faces = secondary;
            }
            if (faces.Size() > 0) {
                options.Start.Type = c3d.LoftClampType.Face;
                options.Start.FaceClamp.Faces = faces;
                options.Start.FaceClamp.Edges = productEdges;
                options.Start.Curvature = startCurvature;
                if (Math.abs(startMagnitude) > 0) {
                    options.Start.FaceClamp.Magnitudes = [startMagnitude];
                }
            }
        }
        if (endCurvature !== c3d.LoftCurvatureType.Natural) {
            const record = records[records.length - 1];
            const profile = stack[stack.length - 1];
            const { productEdges, originalEdges } = record.GetOriginalBoundary(profile);
            const { primary, secondary } = originalEdges.GetPrimaryAndSecondaryFaces()
            let faces;
            if (side2 === 'primary') {
                faces = primary;
            } else if (secondary.Size() === 0) {
                faces = primary;
                endMagnitude = endMagnitude === 0 ? 1 : endMagnitude;
                endMagnitude *= -1;
            } else {
                faces = secondary;
            }
            if (faces.Size() > 0) {
                options.End.Type = c3d.LoftClampType.Face;
                options.End.FaceClamp.Faces = faces;
                options.End.FaceClamp.Edges = productEdges;
                options.End.Curvature = endCurvature;
                if (Math.abs(endMagnitude) > 0) {
                    options.End.FaceClamp.Magnitudes = [endMagnitude];
                }

            }
        }

        // options.thickness1 = unit(thickness1);
        // options.thickness2 = unit(thickness2);
        // options.shellClosed = true;
        // options.closed = closed;

        const coll = await c3d.ProfileCollection.Create_async(stack, guides);
        return coll.Loft_async(options);
    }

    get profiles() { return this.edges }
}