import { CommandKeyboardInput, EditorLike } from "../../command/CommandKeyboardInput";

export class ImprintKeyboardGizmo extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('import', editor, [
            'gizmo:imprint:screen-space',
        ]);
    }
}