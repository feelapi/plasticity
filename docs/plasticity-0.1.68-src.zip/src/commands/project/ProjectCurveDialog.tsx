import { render } from 'preact';
import { EditorSignals } from "../../editor/EditorSignals";
import { AbstractDialog } from "../../command/AbstractDialog";
import { ProjectCurveParams } from "./ProjectFactory";
import * as c3d from '../../kernel/kernel';

export class ProjectCurveDialog extends AbstractDialog<ProjectCurveParams> {
    name = "Project Curve";

    constructor(protected readonly params: ProjectCurveParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { method, direction, bidirectional, occlude } = this.params;

        render(
            <>
                <ol>
                    <plasticity-prompt name="Select target body" description="to project onto"></plasticity-prompt>
                    <plasticity-prompt name="Select curves" description="to project"></plasticity-prompt>
                </ol>
                <ul>
                    <li>
                        <label for="method">Method</label>
                        <div class="fields">
                            <input type="radio" hidden name="method" id="normal" value={c3d.ProjectionMethod.Normal} checked={method === c3d.ProjectionMethod.Normal} onClick={this.onChange}></input>
                            <label for="normal">Normal</label>

                            <input type="radio" hidden name="method" id="vector" value={c3d.ProjectionMethod.Vector} checked={method === c3d.ProjectionMethod.Vector} onClick={this.onChange}></input>
                            <label for="vector">Vector</label>
                        </div>
                    </li>
                    <li>
                        <label for="direction">Direction</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="direction.x" min={-1} max={1} value={direction.x} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber name="direction.y" min={-1} max={1} value={direction.y} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber name="direction.z" min={-1} max={1} value={direction.z} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="bidirectional">Bidirectional</label>
                        <div class="fields">
                            <input type="checkbox" hidden id="bidirectional" name="bidirectional" disabled={method === c3d.ProjectionMethod.Normal} checked={bidirectional} onClick={this.onChange}></input>
                            <label for="bidirectional">Bidirectional</label>
                        </div>
                    </li>
                    <li>
                        <label for="occlude">X-Ray</label>
                        <div class="fields">
                            <input type="checkbox" hidden id="occlude" name="occlude" checked={occlude} onClick={this.onChange}></input>
                            <label for="occlude">Hide occlusion</label>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('project-curve-dialog', ProjectCurveDialog);

export class ImprintCurveDialog extends ProjectCurveDialog {
    name = "Imprint Curve";
}
customElements.define('imprint-curve-dialog', ImprintCurveDialog);
