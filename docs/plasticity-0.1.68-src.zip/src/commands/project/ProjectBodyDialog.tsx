import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import { ProjectBodyBodyParams } from "./ProjectFactory";

export class ProjectBodyDialog extends AbstractDialog<ProjectBodyBodyParams> {
    name = "Project Body";

    constructor(protected readonly params: ProjectBodyBodyParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        render(
            <>
                <ol>
                    <plasticity-prompt name="Select target body" description="to project onto"></plasticity-prompt>
                    <plasticity-prompt name="Select tool body" description="to project"></plasticity-prompt>
                </ol>
            </>, this);
    }
}
customElements.define('project-body-dialog', ProjectBodyDialog);

export class ImprintBodyDialog extends ProjectBodyDialog {
    name = "Imprint Body";
}
customElements.define('imprint-body-dialog', ImprintBodyDialog);
