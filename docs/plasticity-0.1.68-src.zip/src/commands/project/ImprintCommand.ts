import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { SelectionMode } from "../../selection/SelectionModeSet";
import * as visual from "../../visual_model/VisualModel";
import { ImprintBodyBodyFactory, ImprintCurveBodyFactory } from "./ImprintFactory";
import { ImprintKeyboardGizmo } from "./ImprintKeyboardGizmo";
import { ImprintBodyDialog } from "./ProjectBodyDialog";
import { ImprintCurveDialog } from "./ProjectCurveDialog";

export class ImprintCommand extends Command {
    async execute(): Promise<void> {
        const selected = this.editor.selection.selected;
        if ((selected.solids.size + selected.sheets.size) === 2) {
            const command = new ImprintBodyBodyCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else {
            const command = new ImprintCurveBodyCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        }
    }
}

export class ImprintBodyBodyCommand extends Command {
    async execute(): Promise<void> {
        const project = new ImprintBodyBodyFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);

        const dialog = new ImprintBodyDialog(project, this.editor.signals);
        dialog.execute(params => {
            project.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const objectPicker = new ObjectPicker(this.editor);
        objectPicker.copy(this.editor.selection);

        GetTargetBody: {
            const getTarget = dialog.prompt("Select target body", () => {
                return objectPicker.shift(SelectionMode.Shell).resource(this);
            });
            const target = await getTarget();
            project.target = target.first;
        }

        GetToolBody: {
            const getTool = dialog.prompt("Select tool body", () => {
                return objectPicker.shift(SelectionMode.Shell).resource(this);
            });
            const tool = await getTool();
            project.tool = tool.first;
            await project.update();
        }

        const result = await project.commit() as visual.SpaceInstance;
        this.editor.selection.selected.removeAll();
        this.editor.selection.selected.addCurve(result);
    }
}

export class ImprintCurveBodyCommand extends Command {
    async execute(): Promise<void> {
        const project = new ImprintCurveBodyFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        project.constructionPlane = this.editor.activeViewport?.constructionPlane;
        project.isOrthoMode = this.editor.activeViewport?.isOrthoMode ?? false;

        const keyboard = new ImprintKeyboardGizmo(this.editor);
        const dialog = new ImprintCurveDialog(project, this.editor.signals);
        dialog.execute(async (params) => {
            await project.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        keyboard.execute(async e => {
            switch (e) {
                case 'screen-space':
                    const camera = this.editor.activeViewport?.camera;
                    if (camera === undefined) return;
                    project.direction.set(0, 0, 1).applyQuaternion(camera.quaternion);
                    dialog.render();
                    await project.update();
            }
        }).resource(this);

        GetTargetBody: {
            const objectPicker = new ObjectPicker(this.editor);
            objectPicker.copy(this.editor.selection);

            const getTarget = dialog.prompt("Select target body", () => {
                return objectPicker.shift(SelectionMode.Shell).resource(this);
            });
            const target = await getTarget();
            project.target = target.first;

            dialog.replace("Select target body", () => {
                const objectPicker = new ObjectPicker(this.editor);
                objectPicker.selection.selected.add(project.target);
                return objectPicker.execute(delta => {
                    if (objectPicker.selection.selected.shells.size === 0) return;
                    const target = objectPicker.selection.selected.shells.first;
                    project.target = target;
                    dialog.render();
                    project.update();
                }, 1, 1, SelectionMode.Shell).resource(this);
            });
        }

        GetCutters: {
            const objectPicker = new ObjectPicker(this.editor);
            objectPicker.copy(this.editor.selection);

            const getCurves = dialog.prompt("Select curves", () => {
                return objectPicker.slice(SelectionMode.Curve, 1, Number.MAX_SAFE_INTEGER).resource(this);
            });
            const curves = await getCurves();
            project.curves = [...curves];
            dialog.render();
            await project.update();

            dialog.replace("Select curves", () => {
                const objectPicker = new ObjectPicker(this.editor);
                objectPicker.mode.set(SelectionMode.Curve);
                objectPicker.selection.selected.add(project.curves);
                return objectPicker.execute(async (delta) => {
                    const selected = objectPicker.selection.selected;
                    project.curves = [...selected.curves];
                    dialog.render();
                    project.update();
                }, 1, Number.MAX_SAFE_INTEGER).resource(this);
            }, () => {
                project.curves = [];
                project.update();
            })();
        }

        await this.finished;

        const results = await project.commit();

        this.editor.selection.selected.removeAll();
        this.editor.selection.selected.add(results);
    }
}