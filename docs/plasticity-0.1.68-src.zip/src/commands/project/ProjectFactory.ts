import * as THREE from "three";
import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory, NoOpError } from "../../command/GeometryFactory";
import { PlaneSnap } from "../../editor/snaps/PlaneSnap";
import * as c3d from '../../kernel/kernel';
import { Z } from "../../util/Constants";
import { axis2line, plane2plane, point2point, vec2vec } from "../../util/Conversion";
import * as visual from "../../visual_model/VisualModel";
import { bestPlacementForCut, wouldCut } from "../boolean/CutFactory";
import { ExtrudeSurfaceFactory } from "../extrude/ExtrudeSurfaceFactory";

export class ProjectCurveCurveFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> {
    private extrude1 = new ExtrudeSurfaceFactory(this.db, this.materials, this.signals);
    private extrude2 = new ExtrudeSurfaceFactory(this.db, this.materials, this.signals);

    isOrthoMode = false;
    constructionPlane?: PlaneSnap;

    protected _curve1!: { view: visual.SpaceInstance, model: c3d.Wire };
    @derive(visual.SpaceInstance) get curve1(): visual.SpaceInstance { throw '' }
    set curve1(curve1: visual.SpaceInstance | c3d.Wire) { }

    protected _curve2!: { view: visual.SpaceInstance, model: c3d.Wire };
    @derive(visual.SpaceInstance) get curve2(): visual.SpaceInstance { throw '' }
    set curve2(curve2: visual.SpaceInstance | c3d.Wire) { }

    async calculate(partition: c3d.Partition) {
        const { _curve1: { model: curve1 }, _curve2: { model: curve2 }, constructionPlane } = this;
        const { extrude1, extrude2 } = this;
        const e1 = computeExtrusionInfo(curve1);
        const e2 = computeExtrusionInfo(curve2);
        extrude1.curve = curve1;
        extrude1.direction = e1 !== undefined ? vec2vec(e1.Axis, 1) : constructionPlane?.n ?? Z;
        extrude1.distance1 = 400;
        extrude1.distance2 = -400;
        extrude2.curve = curve2;
        extrude2.direction = e2 !== undefined ? vec2vec(e2.Axis, 1) : constructionPlane?.n ?? Z;
        extrude2.distance1 = 400;
        extrude2.distance2 = -400;
        const extrusion1 = await extrude1.calculate(partition);
        const extrusion2 = await extrude2.calculate(partition);
        return extrusion1.CreateIntersectionCurve_async(extrusion2, new c3d.BodyIntersectionCurveOptions());
    }

    get originalItems() { return [] }
}

function computeExtrusionInfo(curve: c3d.Wire) {
    const basis = curve.FindPlanarBasis();
    if (basis !== undefined) return basis;
    const geos = curve.GetConstructionGeometry();
    const geo = geos[0] as c3d.Geometry | undefined;
    if (geo instanceof c3d.Plane) return geo.GetInfo();
}

export interface ProjectBodyBodyParams {

}

export class ProjectBodyBodyFactory extends GeometryFactory {
    private _target!: { view: visual.Shell, model: c3d.Shell };
    @derive(visual.Shell) get target(): visual.Shell { throw '' }
    set target(target: visual.Shell | c3d.Shell) { }

    private _tool!: { view: visual.Shell, model: c3d.Shell };
    @derive(visual.Shell) get tool(): visual.Shell { throw '' }
    set tool(tool: visual.Shell | c3d.Shell) { }

    async calculate() {
        const { _target: { model: target }, _tool: { model: tool } } = this;
        const options = new c3d.BodyIntersectionCurveOptions();
        return target.CreateIntersectionCurve_async(tool, options);
    }
}

export interface ProjectCurveParams {
    bidirectional: boolean;
    method: c3d.ProjectionMethod;
    direction: THREE.Vector3;
    occlude: boolean;
}

export class AbstractProjectCurveBodyFactory<M extends c3d.Shell | c3d.Wire, V extends visual.Shell | visual.SpaceInstance, A extends undefined | [] = undefined> extends GeometryFactory<M, V, A> implements ProjectCurveParams {
    constructionPlane?: PlaneSnap;

    private _isOrthoMode = false;
    get isOrthoMode() { return this._isOrthoMode }
    set isOrthoMode(isOrthoMode: boolean) {
        this._isOrthoMode = isOrthoMode;
        if (isOrthoMode) {
            this.method = c3d.ProjectionMethod.Vector;
            this.bidirectional = true;
        }
    }

    bidirectional = true;
    occlude = false;
    method = c3d.ProjectionMethod.Vector;
    direction = Z;

    protected _target!: { view: visual.Shell, model: c3d.Shell };
    @derive(visual.Shell) get target(): visual.Shell { throw '' }
    set target(target: visual.Shell | c3d.Shell) { }

    protected _curves!: { views: visual.SpaceInstance[]; models: c3d.Wire[]; };
    get curves() { return this._curves.views }
    set curves(curves: visual.SpaceInstance[]) {
        const { db, constructionPlane, isOrthoMode, _target: { model: shell } } = this;
        if (curves.length === 0) {
            this._curves = { views: [], models: [] };
            return;
        }

        const { min, max } = shell.FindBox();
        const bbox = new THREE.Box3(point2point(min), point2point(max));

        const models = curves.map(c => db.lookup(c));
        this._curves = { views: curves, models };

        const first = models[0];
        const basis = first.FindPlanarBasis();
        const axis = first.FindLinearAxis()
        let direction;
        if (constructionPlane !== undefined && isOrthoMode) {
            direction = constructionPlane.n;
        } else if (basis !== undefined && axis === undefined) {
            direction = vec2vec(basis.Axis, 1);
        } else {
            const geos = first.GetConstructionGeometry();
            const geo = geos[0] as c3d.Geometry | undefined;
            if (geo instanceof c3d.Plane) {
                const wasConstructedOn = plane2plane(geo.GetInfo());
                if (wouldCut(wasConstructedOn, bbox))
                    direction = vec2vec(geo.GetInfo().Axis);
            }
            if (direction === undefined) {
                const axis = first.FindLinearAxis();
                if (axis !== undefined) {
                    const hint = bestPlacementForCut(bbox, axis2line(axis), constructionPlane?.n);
                    if (hint !== undefined) {
                        direction = hint.normal;
                    }
                }
            }
            if (direction === undefined) {
                direction = constructionPlane?.n ?? Z;
            }
        }
        this.direction = direction;
    }

}

export class ProjectCurveBodyFactory extends AbstractProjectCurveBodyFactory<c3d.Wire, visual.SpaceInstance, []> implements ProjectCurveParams {
    async calculate() {
        const { _target: { model: target }, _curves: { models: curves }, bidirectional, method, direction, occlude } = this;
        if (curves.length === 0) throw new NoOpError();

        const options = new c3d.ProjectCurveOptions();
        options.Bidirectional = bidirectional;
        if (method === c3d.ProjectionMethod.Normal) options.Bidirectional = false;
        options.Method = method;
        options.Direction = vec2vec(direction, 1);
        options.Occlude = occlude;
        return target.ProjectWires_async(curves, options);
    }
}