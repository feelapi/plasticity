import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory, NoOpError } from "../../command/GeometryFactory";
import * as c3d from '../../kernel/kernel';
import { vec2vec } from "../../util/Conversion";
import * as visual from "../../visual_model/VisualModel";
import { AbstractProjectCurveBodyFactory } from "./ProjectFactory";

export class ImprintBodyBodyFactory extends GeometryFactory {
    private _target!: { view: visual.Shell, model: c3d.Shell };
    @derive(visual.Shell) get target(): visual.Shell { throw '' }
    set target(target: visual.Shell | c3d.Shell) { }

    private _tool!: { view: visual.Shell, model: c3d.Shell };
    @derive(visual.Shell) get tool(): visual.Shell { throw '' }
    set tool(tool: visual.Shell | c3d.Shell) { }

    async calculate() {
        const { _target: { model: target }, _tool: { model: tool } } = this;
        const options = new c3d.BodyIntersectionCurveOptions();
        await target.ImprintIntersectionCurve_async(tool, options);
        return target;
    }

    get originalItem() { return this.target }
}

export class ImprintCurveBodyFactory extends AbstractProjectCurveBodyFactory<c3d.Shell, visual.Shell> {
    async calculate() {
        const { _target: { model: target }, _curves: { models: curves }, bidirectional, method, direction, occlude } = this;
        if (curves.length === 0) throw new NoOpError();
        const options = new c3d.ProjectCurveOptions();
        options.Bidirectional = bidirectional;
        if (method === c3d.ProjectionMethod.Normal) options.Bidirectional = false;
        options.Method = method;
        options.Occlude = occlude;
        options.Direction = vec2vec(direction, 1);
        await target.ImprintWires_async(curves, options);
        return target;
    }

    get originalItem() { return this.target }
}