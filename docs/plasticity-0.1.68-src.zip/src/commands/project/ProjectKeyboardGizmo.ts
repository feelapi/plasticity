import { CommandKeyboardInput, EditorLike } from "../../command/CommandKeyboardInput";

export class ProjectKeyboardGizmo extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('project', editor, [
            'gizmo:project:screen-space',
        ]);
    }
}