import { GeometryFactory } from "../../command/GeometryFactory";
import * as visual from "../../visual_model/VisualModel";
import * as c3d from '../../kernel/kernel';
import { derive } from "../../command/FactoryBuilder";

export class ExtendEdgeFactory extends GeometryFactory<c3d.Shell, visual.Shell> {
    protected _shell!: { view: visual.Shell; model: c3d.Shell; };
    @derive(visual.Shell) get shell(): visual.Shell { throw ''; }
    set shell(shell: visual.Shell | c3d.Shell) { }

    protected _edges!: { views: visual.CurveEdge[]; models: c3d.Edge[]; };
    @derive([visual.CurveEdge]) get edges(): visual.CurveEdge[] { throw ''; }
    set edges(edges: visual.CurveEdge[] | c3d.Edge[]) { }

    async calculate() {
        const { _shell: { model: shell }, _edges: { models: edges } } = this;

        await shell.ExtendEdges_async(edges);
        return shell;
    }

    get originalItem() { return this.shell; }
}
