import * as THREE from "three";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { point2point, unit } from "../../util/Conversion";
import * as visual from '../../visual_model/VisualModel';
import { PossiblyBoolean } from "../boolean/PossiblyBooleanFactory";

export interface SphereParams {
    center: THREE.Vector3;
    radius: number;
}

export class SphereFactory extends GeometryFactory<c3d.Solid, visual.Solid> implements SphereParams {
    readonly center = new THREE.Vector3();
    radius: number = 0;

    async calculate(partition: c3d.Partition = this.partition) {
        const { center, radius } = this;

        if (radius < 10e-6) throw new NoOpError();

        const basis = new c3d.Basis();
        basis.Location = point2point(center);
        return partition.SolidBody.CreateSphere(unit(radius), basis);
    }
}

export class PossiblyBooleanSphereFactory extends PossiblyBoolean(SphereFactory) { }