import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { DisableOptions } from "../../editor/db/Database";
import * as c3d from '../../kernel/kernel';
import { SelectionMode } from "../../selection/SelectionModeSet";
import { PossiblyBooleanKeyboardGizmo } from "../boolean/BooleanKeyboardGizmo";
import { booleanTargets } from "../box/BoxCommand";
import { SphereDialog } from "./SphereDialog";
import { PossiblyBooleanSphereFactory } from "./SphereFactory";
import { SphereGizmo } from "./SphereGizmo";

export class SphereCommand extends Command {
    async execute(): Promise<void> {
        const sphere = new PossiblyBooleanSphereFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        const selection = this.editor.selection.selected;

        const dialog = new SphereDialog(sphere, this.editor.signals);
        const gizmo = new SphereGizmo(sphere, this.editor);

        dialog.execute(params => {
            gizmo.render(params);
            sphere.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const pointPicker = new PointPicker(this.editor);
        const { point: p1, info: { snap: snap1 } } = await pointPicker.execute().resource(this);
        sphere.center.copy(p1);

        sphere.targets = booleanTargets(snap1);
        this.editor.db.disable(sphere.targets, DisableOptions.KeepPointSnaps);

        const keyboard = new PossiblyBooleanKeyboardGizmo("sphere", this.editor);
        keyboard.prepare(sphere).resource(this);

        pointPicker.restrictToPlaneThroughPoint(p1, snap1);
        const { info: { snap: snap2 } } = await pointPicker.execute(({ point: p2 }) => {
            const radius = p1.distanceTo(p2);
            sphere.radius = radius;
            dialog.render();
            sphere.update();
        }).resource(this);

        sphere.targets = booleanTargets(snap1, snap2);

        gizmo.position.copy(sphere.center);
        gizmo.execute(async (params) => {
            dialog.render();
            await sphere.update();
        }).resource(this);

        const startSelect = dialog.prompt("Select target bodies", () => {
            const objectPicker = new ObjectPicker(this.editor);
            objectPicker.selection.selected.add(sphere.targets);
            return objectPicker.execute(async delta => {
                const targets = [...objectPicker.selection.selected.solids];
                sphere.targets = targets;
                if (sphere.operationType === undefined) sphere.operationType = c3d.OperationType.Difference;
                await sphere.update();
            }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Solid).resource(this)
        }, async () => {
            sphere.targets = [];
            await sphere.update();
        });
        keyboard.startSelect = startSelect;

        await this.finished;

        const results = await sphere.commit();
        selection.removeAll();
        selection.add(results);
    }
}
