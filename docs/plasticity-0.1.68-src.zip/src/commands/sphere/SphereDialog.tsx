import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import { SphereParams } from "./SphereFactory";

export class SphereDialog extends AbstractDialog<SphereParams> {
    name = "Sphere";

    constructor(protected readonly params: SphereParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { radius } = this.params;

        render(
            <>
                <ol>
                    <plasticity-prompt name="Select target bodies" description="to cut or join into"></plasticity-prompt>
                </ol>

                <ul>
                    <li>
                        <label for="radius">Radius</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="radius" value={radius} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>

                </ul>
            </>, this);
    }
}
customElements.define('sphere-dialog', SphereDialog);
