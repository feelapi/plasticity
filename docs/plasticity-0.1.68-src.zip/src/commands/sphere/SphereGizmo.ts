import { Mode } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { DistanceGizmo } from "../../command/MiniGizmos";
import { CancellablePromise } from "../../util/CancellablePromise";
import { SphereParams } from "./SphereFactory";

export class SphereGizmo extends CompositeGizmo<SphereParams> {
    private readonly radiusGizmo = new RadiusDistanceGizmo("cylinder:radius", this.editor);

    protected prepare(mode: Mode) {
        const { radiusGizmo, params } = this;
        radiusGizmo.relativeScale.setScalar(0.8);

        radiusGizmo.value = params.radius;

        this.add(radiusGizmo);
    }

    execute(cb: (params: SphereParams) => void, finishFast: Mode = Mode.Persistent): CancellablePromise<void> {
        const { radiusGizmo, params } = this;

        this.addGizmo(radiusGizmo, radius => {
            params.radius = radius;
        });

        return super.execute(cb, finishFast);
    }

    get shouldRescaleOnZoom() { return false }

    render(params: SphereParams) {
        this.radiusGizmo.value = params.radius;
    }
}

class RadiusDistanceGizmo extends DistanceGizmo {
    onInterrupt(cb: (radius: number) => void) {
        this.state.push();
    }

    onDeactivate() { this.visible = false }
    onActivate() {
        if (!this.stateMachine?.isEnabled) return;
        this.visible = true;
    }

    protected override onIsFacingCamera(dot: number) {
        this.visible = Math.abs(dot) < AXIS_HIDE_TRESHOLD;
    }
}

const AXIS_HIDE_TRESHOLD = 0.99;
