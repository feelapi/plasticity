import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { SelectionMode } from "../../selection/SelectionModeSet";
import { CancellablePromise } from "../../util/CancellablePromise";
import { PlaceGizmo } from "../place/PlaceGizmo";
import { SweepToolDialog } from "./SweepToolDialog";
import { SweepToolFactory } from "./SweepToolFactory";

export class SweepToolCommand extends Command {
    async execute(): Promise<void> {
        const { editor, editor: { selection: { selected } } } = this;

        const sweep = new SweepToolFactory(editor.db, editor.materials, editor.signals).resource(this);

        const dialog = new SweepToolDialog(sweep, editor.signals);
        const objectPicker = new ObjectPicker(this.editor);
        objectPicker.copy(this.editor.selection);

        dialog.execute(async (params) => {
            await sweep.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const getSolid = dialog.prompt("Select solid", () => {
            return objectPicker.shift(SelectionMode.Solid, 1).resource(this)
        });
        const selection = await getSolid();
        sweep.solid = selection.first;

        const gizmo = new PlaceGizmo(sweep, editor);
        let g: CancellablePromise<void> | undefined = undefined;
        const startGizmo = () => {
            if (g !== undefined) return;
            gizmo.disable();
            g = gizmo.execute(s => {
                sweep.update();
            }).resource(this);
        }

        const pointPicker = new PointPicker(this.editor);
        const { point: origin, info: { orientation: originOrientation } } = await pointPicker.execute(({ point, info: { orientation } }) => {
            startGizmo();
            gizmo.position.copy(point);
            gizmo.quaternion.copy(orientation);
        }).resource(this);
        sweep.origin = origin;
        sweep.originOrientation = originOrientation;

        const getSpine = dialog.prompt("Select spine", () => {
            objectPicker.mode.set(SelectionMode.Curve);
            return objectPicker.execute(() => { }, 1, 1).resource(this);
        });
        const spine = await getSpine();
        sweep.spine = spine.curves.first;

        sweep.update();

        await this.finished;

        const result = await sweep.commit();

        selected.removeAll();
        editor.selection.selected.add(result);
    }
}