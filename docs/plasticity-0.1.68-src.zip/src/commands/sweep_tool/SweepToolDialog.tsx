import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import { SweepToolParams } from './SweepToolFactory';

export class SweepToolDialog extends AbstractDialog<SweepToolParams> {
    readonly name = "Sweep";

    constructor(protected readonly params: SweepToolParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { } = this.params;

        render(
            <>
                <ol>
                    <plasticity-prompt name="Select solid" description="to sweep"></plasticity-prompt>
                    <plasticity-prompt name="Select spine" description="to sweep along"></plasticity-prompt>
                </ol>

                <ul>
                </ul></>, this);
    }
}
customElements.define('plasticity-sweep-tool-dialog', SweepToolDialog);
