import * as THREE from "three";
import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { Z } from "../../util/Constants";
import { point2point, vec2vec } from '../../util/Conversion';
import * as visual from '../../visual_model/VisualModel';
import { PlaceParams } from '../place/PlaceFactory';


export interface SweepToolParams extends PlaceParams { }

export class SweepToolFactory extends GeometryFactory<c3d.Solid, visual.Solid> implements SweepToolParams {
    origin!: THREE.Vector3;
    originOrientation!: THREE.Quaternion;
    angle = 0;
    get degrees() { return THREE.MathUtils.radToDeg(this.angle) }
    set degrees(degrees: number) {
        this.angle = THREE.MathUtils.degToRad(degrees);
    }
    scale = 1;
    offset = 0;

    destination!: THREE.Vector3;
    destinationOrientation!: THREE.Quaternion;
    flip = false;

    tangent = new THREE.Vector3();

    protected _solid!: { view: visual.Solid, model: c3d.Solid };
    @derive(visual.Solid) get solid(): visual.Solid { throw '' }
    set solid(solid: visual.Solid | c3d.Solid) { }

    private _spine!: { view: visual.SpaceInstance; model: c3d.Wire; };
    get spine(): visual.SpaceInstance { return this._spine.view; }
    set spine(spine: visual.SpaceInstance) {
        const model = this.db.lookup(spine)!;
        this._spine = { view: spine, model };

        const first = model.FindFirstEdge();
        const { position, tangent } = first.GetPointAndTangent(0);
        this.tangent = vec2vec(tangent, 1);
    }

    async calculate() {
        const { _spine: { model: spine }, _solid: { model: solid }, origin, originOrientation } = this;

        const z = Z.clone();
        z.applyQuaternion(originOrientation);

        const options = new c3d.SweptToolOptions();
        const swept = await solid.SweepTool_async(point2point(origin), vec2vec(z, 1), spine, options);
        return swept;
    }
}
