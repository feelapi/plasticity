import * as THREE from "three";
import * as c3d from '../../kernel/kernel';
import { point2point } from "../../util/Conversion";
import { GeometryFactory, NoOpError, PhantomInfo } from '../../command/GeometryFactory';
import * as visual from '../../visual_model/VisualModel';

export default class LineFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> {
    p1!: THREE.Vector3;
    p2!: THREE.Vector3;

    async calculate() {
        const { p1, p2 } = this;
        return c3d.ActionCurve3D.Polyline([point2point(p1), point2point(p2)]);
    }
}

export class PhantomLineFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance, []> {
    p1!: THREE.Vector3;
    p2!: THREE.Vector3;

    async calculate() { return [] }

    async calculatePhantoms(partition: c3d.Partition): Promise<PhantomInfo[]> {
        const { p1, p2 } = this;
        if (p1.manhattanDistanceTo(p2) < 1e-6) throw new NoOpError();

        let phantom = partition.WireBody.CreatePolyline([point2point(p1), point2point(p2)], false);
        const material = { line: this.materials.lineDashed() };
        return [
            { phantom, material }
        ]
    }

    // FIXME: This class is very brittle and predates Parasolid. It's not safe to have two concurrent
    // factories because one can the rollbacks can conflict. It should be safe as long as the main partition
    // is not the global default partition
    get partition() { return this.phantomPartition }
}