import * as THREE from "three";
import { GeometryFactory, ValidationError } from "../../command/GeometryFactory";
import * as c3d from '../../kernel/kernel';
import { point2point, vec2vec } from "../../util/Conversion";
import * as visual from '../../visual_model/VisualModel';
import { PossiblyBoolean } from "../boolean/PossiblyBooleanFactory";
import { ThreePointRectangleFactory } from "../rect/RectangleFactory";
import { BoxParams, EditBoxParams } from "./BoxFactory";

export class ThreePointBoxFactory extends GeometryFactory<c3d.Solid, visual.Solid> implements BoxParams, EditBoxParams {
    p1!: THREE.Vector3;
    p2!: THREE.Vector3;
    p3!: THREE.Vector3;
    p4!: THREE.Vector3;

    width!: number;
    length!: number;
    height!: number;

    private static readonly height = new THREE.Vector3();
    private static readonly p1 = new THREE.Vector3();
    private static readonly p2 = new THREE.Vector3();
    private static readonly p3 = new THREE.Vector3();

    async calculate(partition: c3d.Partition = this.partition) {
        const { p1, p2, p3, p4 } = this.orthogonal();

        const placement = new c3d.Basis();
        const x = p2.clone().sub(p1);
        const y = p3.clone().sub(p2);
        const z = p4.clone().sub(p3);
        placement.Axis.Copy(vec2vec(z.clone().normalize(), 1));
        placement.Ref.Copy(vec2vec(x.clone().normalize(), 1));
        placement.Location.Copy(point2point(x.clone().add(y).multiplyScalar(0.5).add(p1)));
        return partition.SolidBody.CreateBlock(x.length(), y.length(), z.length(), placement);
    }

    private orthogonal() {
        const { p1, p2, p3 } = ThreePointRectangleFactory.orthogonal(this.p1, this.p2, this.p3);
        return ThreePointBoxFactory.reorientHeight(p1, p2, p3, this.p4);
    }

    get corner1() { return this.p1 }

    private static readonly AB = new THREE.Vector3();
    private static readonly BC = new THREE.Vector3();
    private static readonly _heightNormal = new THREE.Vector3();

    static heightNormal(p1: THREE.Vector3, p2: THREE.Vector3, p3: THREE.Vector3) {
        const { AB, BC, _heightNormal } = this;
        AB.copy(p2).sub(p1)
        BC.copy(p3).sub(p2);
        return _heightNormal.copy(AB).cross(BC).normalize();
    }

    static reorientHeight(_p1: THREE.Vector3, _p2: THREE.Vector3, _p3: THREE.Vector3, upper: THREE.Vector3) {
        const { height } = this;
        const { p1, p2, p3 } = this;
        p1.copy(_p1); p2.copy(_p2); p3.copy(_p3);

        const heightNormal = this.heightNormal(p1, p2, p3);
        let h = height.copy(upper).sub(p3).dot(heightNormal);

        if (Math.abs(h) < 10e-5)
            throw new ValidationError("invalid height");

        const p4 = heightNormal.multiplyScalar(h).add(p3);

        return { p1, p2, p3, p4, h };
    }

    get info(): { x: THREE.Vector3, y: THREE.Vector3, z: THREE.Vector3, location: THREE.Vector3 } {
        // @ts-ignore
        return undefined;
    }

    get heightNormal(): THREE.Vector3 {
        return ThreePointBoxFactory.heightNormal(this.p1, this.p2, this.p3);
    }

    get location() {
        return this.info.location;
    }
}

export class PossiblyBooleanThreePointBoxFactory extends PossiblyBoolean(ThreePointBoxFactory) {
}