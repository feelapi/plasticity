import * as THREE from "three";
import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { PointPicker, PointResult } from "../../command/point-picker/PointPicker";
import { DisableOptions } from "../../editor/db/Database";
import { AxisSnap } from "../../editor/snaps/AxisSnap";
import { FaceConstructionPlaneSnap } from "../../editor/snaps/ConstructionPlaneSnap";
import { NamedPointSnap, PickedPointSnap } from "../../editor/snaps/PointSnap";
import { Restriction, Snap } from "../../editor/snaps/Snap";
import { AxisAxisCrossPointSnap, CurveEdgeSnap, EdgePointSnap, FaceCenterPointSnap, FaceSnap } from "../../editor/snaps/Snaps";
import * as c3d from '../../kernel/kernel';
import { SelectionMode } from "../../selection/SelectionModeSet";
import * as visual from '../../visual_model/VisualModel';
import { PossiblyBooleanKeyboardGizmo } from "../boolean/BooleanKeyboardGizmo";
import { CenterRectangleFactory, CornerRectangleFactory } from '../rect/RectangleFactory';
import { RectangleModeKeyboardGizmo } from "../rect/RectangleModeKeyboardGizmo";
import { BoxDialog } from "./BoxDialog";
import { PossiblyBooleanCenterBoxFactory, PossiblyBooleanCornerBoxFactory } from './BoxFactory';
import { CenterBoxGizmo, EditBoxGizmo } from "./BoxGizmo";

export class CornerBoxCommand extends Command {
    pr1?: PointResult;
    pr2?: PointResult;

    async execute(): Promise<void> {
        const { editor } = this;

        const box = new PossiblyBooleanCornerBoxFactory(editor.db, editor.materials, editor.signals).resource(this);
        const selection = editor.selection.selected;
        let { pr1, pr2 } = this;

        const dialog = new BoxDialog(box, editor.signals);
        const gizmo = new EditBoxGizmo(box, editor);

        dialog.execute(params => {
            gizmo.render(params);
            box.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        let pointPicker = new PointPicker(editor);
        const { point: p1, info: { snap: snap1, orientation: o1 } } = pr1 = await pointPicker.execute({ result: pr1 }).resource(this);

        box.targets = booleanTargets(snap1);

        const mode = new RectangleModeKeyboardGizmo(editor);
        const m = mode.execute(e => {
            switch (e) {
                case 'mode':
                    const command = new CenterBoxCommand(editor);
                    command.agent = this.agent;
                    command.pr1 = pr1;
                    command.pr2 = pr2;
                    editor.exec(command);
            }
        }).resource(this);

        const rect = new CornerRectangleFactory(editor.db, editor.materials, editor.signals).resource(this);
        rect.constructionPlane = editor.activeViewport?.constructionPlane;;
        rect.p1 = p1;
        box.p1 = p1;

        pointPicker = new PointPicker(editor);
        const planar = pointPicker.restrictToPlaneThroughPoint(p1, snap1);
        addSquareSnaps(planar, p1, o1, pointPicker);

        const { point: p2, info: { snap: snap2, orientation: orientation2 } } = pr2 = await pointPicker.execute(result => {
            const { point: p2, info: { orientation } } = pr2 = result;
            rect.p2 = p2;
            rect.orientation = orientation;
            dialog.render();
            rect.update();
        }, { result: pr2 }).resource(this);
        rect.cancel();
        m.finish();
        box.orientation = orientation2;
        box.p2 = p2;

        box.targets = booleanTargets(snap1, snap2);
        editor.db.disable(box.targets, DisableOptions.KeepPointSnaps);

        const keyboard = new PossiblyBooleanKeyboardGizmo("box", editor);
        keyboard.prepare(box).resource(this);

        const startSelect = dialog.prompt("Select target bodies", () => {
            const objectPicker = new ObjectPicker(editor);
            objectPicker.selection.selected.add(box.targets);
            return objectPicker.execute(async delta => {
                const targets = [...objectPicker.selection.selected.solids];
                box.targets = targets;
                if (box.operationType === undefined) box.operationType = c3d.OperationType.Difference;
                await box.update();
            }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Solid).resource(this)
        }, async () => {
            box.targets = [];
            await box.update();
        });
        keyboard.startSelect = startSelect;

        gizmo.basis = box.basis;
        gizmo.execute(async params => {
            dialog.render();
            await box.update();
        }).resource(this);
        if (!gizmo.startHeight()) {
            box.height = 1;
            await box.update();
            dialog.render();
            gizmo.render(box);
        }

        await this.finished;

        const results = await box.commit();
        selection.removeAll();
        selection.add(results);
    }
}

export class CenterBoxCommand extends Command {
    pr1?: PointResult;
    pr2?: PointResult;

    async execute(): Promise<void> {
        const { editor } = this;

        const box = new PossiblyBooleanCenterBoxFactory(editor.db, editor.materials, editor.signals).resource(this);
        const selection = editor.selection.selected;
        let { pr1, pr2 } = this;

        const dialog = new BoxDialog(box, editor.signals);
        const gizmo = new CenterBoxGizmo(box, editor);

        dialog.execute(params => {
            gizmo.render(params);
            box.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        let pointPicker = new PointPicker(editor);
        const { point: p1, info: { snap: snap1, orientation: o1 } } = pr1 = await pointPicker.execute({ result: pr1 }).resource(this);

        box.targets = booleanTargets(snap1);

        const mode = new RectangleModeKeyboardGizmo(editor);
        const m = mode.execute(e => {
            switch (e) {
                case 'mode':
                    const command = new CornerBoxCommand(editor);
                    command.agent = this.agent;
                    command.pr1 = pr1;
                    command.pr2 = pr2;
                    editor.exec(command);
            }
        }).resource(this);

        const rect = new CenterRectangleFactory(editor.db, editor.materials, editor.signals).resource(this);
        rect.p1 = p1;
        box.p1 = p1;

        pointPicker = new PointPicker(editor);
        const planar = pointPicker.restrictToPlaneThroughPoint(p1, snap1);
        addSquareSnaps(planar, p1, o1, pointPicker);

        const { point: p2, info: { snap: snap2, orientation: orientation2 } } = pr2 = await pointPicker.execute(({ point: p2, info: { orientation } }) => {
            rect.p2 = p2;
            rect.constructionPlane = editor.activeViewport?.constructionPlane;
            rect.orientation = orientation;
            dialog.render();
            rect.update();
        }, { result: pr2 }).resource(this);
        rect.cancel();
        m.finish();
        box.orientation = orientation2;
        box.p2 = p2;

        box.targets = booleanTargets(snap1, snap2);

        const keyboard = new PossiblyBooleanKeyboardGizmo("box", editor);
        keyboard.prepare(box).resource(this);

        const startSelect = dialog.prompt("Select target bodies", () => {
            const objectPicker = new ObjectPicker(editor);
            objectPicker.selection.selected.add(box.targets);
            return objectPicker.execute(async delta => {
                const targets = [...objectPicker.selection.selected.solids];
                box.targets = targets;
                if (box.operationType === undefined) box.operationType = c3d.OperationType.Difference;
                await box.update();
            }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Solid).resource(this)
        }, async () => {
            box.targets = [];
            await box.update();
        });
        keyboard.startSelect = startSelect;

        gizmo.basis = box.basis;
        gizmo.execute(async params => {
            dialog.render();
            await box.update();
        }).resource(this);
        if (!gizmo.startHeight()) {
            box.height = 1;
            await box.update();
            dialog.render();
            gizmo.render(box);
        }

        await this.finished;

        const results = await box.commit();
        selection.removeAll();
        selection.add(results);
    }
}

const square1 = new AxisSnap("Square", new THREE.Vector3(1, 1, 0).normalize());
const square2 = new AxisSnap("Square", new THREE.Vector3(1, -1, 0).normalize());
const cubePoint = new THREE.Vector3();

export async function addSquareSnaps(restriction: Restriction | undefined, point: THREE.Vector3, orientation: THREE.Quaternion, pp: PointPicker) {
    const squares = [square1, square2].map(snap => snap.rotate(orientation));
    const axes = new PickedPointSnap(point).axes(squares);
    if (restriction === undefined || restriction.isPlanar) {
        for (const axis of axes) await pp.addAxis(axis);
    }
}

export function booleanTargets(...snaps: Snap[]): visual.Shell[] {
    const targets: Set<visual.Shell> = new Set();
    for (const snap of snaps) {
        if (snap instanceof FaceSnap) targets.add(snap.view.parentItem);
        else if (snap instanceof FaceConstructionPlaneSnap) targets.add(snap.faceSnap.view.parentItem);
        else if (snap instanceof FaceCenterPointSnap) targets.add(snap.faceSnap.view.parentItem);
        else if (snap instanceof CurveEdgeSnap) targets.add(snap.view.parentItem);
        else if (snap instanceof EdgePointSnap) targets.add(snap.edgeSnap.view.parentItem);
    }

    return [...targets];
}

function addCubeSnap(snap2: Snap, box: PossiblyBooleanCornerBoxFactory, p2: THREE.Vector3, p1: THREE.Vector3, pointPicker: PointPicker, isCenter: boolean = false) {
    if (
        snap2.name === "square"
        || snap2 instanceof AxisAxisCrossPointSnap && snap2.axis1.name === "square"
        || snap2 instanceof AxisAxisCrossPointSnap && snap2.axis2.name === "square"
    ) {
        cubePoint.copy(box.normal).multiplyScalar(p2.distanceTo(p1)).multiplyScalar(Math.SQRT1_2).multiplyScalar(isCenter ? 2 : 1).add(p2);
        pointPicker.addSnap(new NamedPointSnap("Cube", cubePoint, box.normal));
    }
}
