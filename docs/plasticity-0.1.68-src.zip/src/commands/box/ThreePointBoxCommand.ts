import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { PointPicker } from "../../command/point-picker/PointPicker";
import * as c3d from '../../kernel/kernel';
import { SelectionMode } from "../../selection/SelectionModeSet";
import { PossiblyBooleanKeyboardGizmo } from "../boolean/BooleanKeyboardGizmo";
import LineFactory from '../line/LineFactory';
import { ThreePointRectangleFactory } from '../rect/RectangleFactory';
import { BoxDialog } from "./BoxDialog";
import { booleanTargets } from "./BoxCommand";
import { PossiblyBooleanThreePointBoxFactory } from "./ThreePointBoxFactory";


export class ThreePointBoxCommand extends Command {
    async execute(): Promise<void> {
        const selection = this.editor.selection.selected;
        const box = new PossiblyBooleanThreePointBoxFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);

        const dialog = new BoxDialog(box, this.editor.signals);

        dialog.execute(params => {
            box.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        dialog.prompt("Select target bodies", () => {
            const objectPicker = new ObjectPicker(this.editor);
            objectPicker.selection.selected.add(box.targets);
            return objectPicker.execute(async (delta) => {
                const targets = [...objectPicker.selection.selected.solids];
                box.targets = targets;
                if (box.operationType === undefined)
                    box.operationType = c3d.OperationType.Difference;
                await box.update();
            }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Solid).resource(this);
        }, async () => {
            box.targets = [];
            await box.update();
        });

        const line = new LineFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        const pointPicker = new PointPicker(this.editor);
        pointPicker.facePreferenceMode = 'strong';
        const { point: p1, info: { snap: snap1 } } = await pointPicker.execute().resource(this);
        line.p1 = p1;

        box.targets = booleanTargets(snap1);

        const { point: p2, info: { snap: snap2 } } = await pointPicker.execute(({ point: p2 }) => {
            line.p2 = p2;
            line.update();
        }).resource(this);
        line.cancel();

        box.targets = booleanTargets(snap1, snap2);

        const rect = new ThreePointRectangleFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        rect.p1 = p1;
        rect.p2 = p2;
        const { point: p3, info: { snap: snap3 } } = await pointPicker.execute(({ point: p3 }) => {
            rect.p3 = p3;
            rect.update();
        }).resource(this);
        rect.cancel();

        box.targets = booleanTargets(snap1, snap2, snap3);

        const keyboard = new PossiblyBooleanKeyboardGizmo("box", this.editor);
        keyboard.prepare(box).resource(this);

        box.p1 = p1;
        box.p2 = p2;
        box.p3 = p3;
        await pointPicker.execute(({ point: p4 }) => {
            box.p4 = p4;
            box.update();
        }).resource(this);

        const results = await box.commit();
        selection.removeAll();
        selection.add(results);
    }
}
