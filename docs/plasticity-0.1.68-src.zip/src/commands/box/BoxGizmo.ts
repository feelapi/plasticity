import * as THREE from "three";
import { Line2 } from "three/examples/jsm/lines/Line2";
import { EditorLike, Mode } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { AbstractAxisGizmo, AxisHelper, CompositeHelper, lineGeometry, MagnitudeStateMachine, NumberHelper, sphereGeometry } from "../../command/MiniGizmos";
import { CancellablePromise } from "../../util/CancellablePromise";
import { Y, _Y } from "../../util/Constants";
import { Helper } from "../../util/Helpers";
import { EditBoxParams } from "./BoxFactory";

const x = new THREE.Vector3();
const y = new THREE.Vector3();
const z = new THREE.Vector3();

export class EditBoxGizmo extends CompositeGizmo<EditBoxParams> {
    protected factor = 1 / 2;

    private readonly widthLeftGizmo = new ExtrudeDistanceGizmo("box:width-left", this.editor);
    private readonly widthRightGizmo = new ExtrudeDistanceGizmo("box:width-right", this.editor);
    private readonly lengthLeftGizmo = new ExtrudeDistanceGizmo("box:length-left", this.editor);
    private readonly lengthRightGizmo = new ExtrudeDistanceGizmo("box:length-right", this.editor);
    private readonly heightGizmo = new ExtrudeDistanceGizmo("box:height", this.editor);

    basis!: THREE.Matrix4;

    protected prepare(mode: Mode) {
        const { widthLeftGizmo, widthRightGizmo, lengthLeftGizmo, lengthRightGizmo, heightGizmo, params, basis } = this;
        basis.extractBasis(x, y, z);

        widthLeftGizmo.relativeScale.setScalar(0.8);
        widthRightGizmo.relativeScale.setScalar(0.8);
        lengthLeftGizmo.relativeScale.setScalar(0.8);
        lengthRightGizmo.relativeScale.setScalar(0.8);
        heightGizmo.relativeScale.setScalar(0.8);

        widthLeftGizmo.quaternion.setFromUnitVectors(Y, x);
        widthRightGizmo.quaternion.setFromUnitVectors(_Y, x);
        lengthLeftGizmo.quaternion.setFromUnitVectors(Y, y);
        lengthRightGizmo.quaternion.setFromUnitVectors(_Y, y);
        heightGizmo.quaternion.setFromUnitVectors(Y, z);

        this.updatePositions();
        this.updateValues();

        this.add(widthLeftGizmo, widthRightGizmo, lengthLeftGizmo, lengthRightGizmo, heightGizmo);
    }

    execute(cb: (params: EditBoxParams) => void, finishFast: Mode = Mode.Persistent): CancellablePromise<void> {
        const { widthLeftGizmo, widthRightGizmo, lengthLeftGizmo, lengthRightGizmo, heightGizmo, params } = this;

        this.addGizmo(widthLeftGizmo, width => {
            width = Math.max(0, width);
            params.width = width;
            this.widthRightGizmo.value = width;
            this.updatePositions();
        });

        this.addGizmo(widthRightGizmo, width => {
            width = Math.max(0, width);
            params.width = -width;
            this.widthLeftGizmo.value = width;
            this.updatePositions();
        });

        this.addGizmo(lengthLeftGizmo, length => {
            length = Math.max(0, length);
            params.length = length;
            this.lengthRightGizmo.value = length;
            this.updatePositions();
        });

        this.addGizmo(lengthRightGizmo, length => {
            length = Math.max(0, length);
            params.length = -length;
            this.lengthLeftGizmo.value = length;
            this.updatePositions();
        });

        this.addGizmo(heightGizmo, height => {
            params.height = height;
            this.updatePositions();
        });

        return super.execute(cb, finishFast);
    }

    private updatePositions() {
        const { widthLeftGizmo, widthRightGizmo, lengthLeftGizmo, lengthRightGizmo, heightGizmo, factor, params } = this;

        this.position.copy(params.corner1);

        widthLeftGizmo.position.set(0, params.length * factor, params.height * factor).applyMatrix4(this.basis);
        widthRightGizmo.position.set(params.width, params.length * factor, params.height * factor).applyMatrix4(this.basis);

        lengthLeftGizmo.position.set(params.width * factor, 0, params.height * factor).applyMatrix4(this.basis);
        lengthRightGizmo.position.set(params.width * factor, params.length, params.height * factor).applyMatrix4(this.basis);

        heightGizmo.position.set(params.width * factor, params.length * factor, 0).applyMatrix4(this.basis);

        widthLeftGizmo.resetInitialWorldPosition();
        widthRightGizmo.resetInitialWorldPosition();
        lengthLeftGizmo.resetInitialWorldPosition();
        lengthRightGizmo.resetInitialWorldPosition();
        heightGizmo.resetInitialWorldPosition();
    }

    private updateValues() {
        const { widthLeftGizmo, widthRightGizmo, lengthLeftGizmo, lengthRightGizmo, heightGizmo, params } = this;
        widthLeftGizmo.value = params.width;
        widthRightGizmo.value = params.width;
        lengthLeftGizmo.value = params.length;
        lengthRightGizmo.value = params.length;
        heightGizmo.value = params.height;
    }

    get shouldRescaleOnZoom() { return false }

    render(params: EditBoxParams) {
        this.updatePositions();
        this.updateValues();
    }

    startHeight() {
        if (!this.heightGizmo.visible) return false;
        this.start('gizmo:box:height');
        return true;
    }
}

class ExtrudeDistanceGizmo extends AbstractAxisGizmo {
    private minShaft = 0;

    readonly state = new MagnitudeStateMachine(0);
    readonly tip: THREE.Mesh<any, any> = new THREE.Mesh(sphereGeometry, this.editor.gizmos.default.mesh);
    protected readonly shaft = new Line2(lineGeometry, this.editor.gizmos.default.line2);
    protected readonly knob = new THREE.Mesh(new THREE.SphereGeometry(0.2), this.editor.gizmos.invisible);
    protected material = this.editor.gizmos.default;
    readonly helper = new CompositeHelper([new AxisHelper(this.material.line), new NumberHelper()]);

    constructor(name: string, editor: EditorLike) {
        super(name, editor);
        this.setup();
        this.add(this.helper);
    }

    private _length!: number;
    render(length: number) {
        this._length = length;
        super.render(length);
    }

    protected accumulate(original: number, sign: number, dist: number): number {
        return original + dist
    }

    protected override scaleIndependentOfZoom(camera: THREE.Camera, worldPosition: THREE.Vector3) {
        const { relativeScale, tip, knob, shaft, _length } = this;
        tip.scale.copy(relativeScale);
        knob.scale.copy(relativeScale);
        Helper.scaleIndependentOfZoom(tip, camera, worldPosition);
        const factor = Helper.scaleIndependentOfZoom(knob, camera, worldPosition);
        const shaftLength = _length + this.minShaft * factor;
        shaft.scale.y = shaftLength;
        tip.position.set(0, shaftLength, 0);
        knob.position.copy(tip.position);
    }

    onInterrupt(cb: (radius: number) => void) {
        this.state.push();
    }

    onDeactivate() { this.visible = false }
    onActivate() {
        if (!this.stateMachine?.isEnabled) return;
        this.visible = true;
    }

    protected override onIsFacingCamera(dot: number) {
        if (!this.stateMachine?.isEnabled) return;
        if (!this.stateMachine?.isActive) return;
        this.visible = Math.abs(dot) < AXIS_HIDE_TRESHOLD;
    }
}

export class CenterBoxGizmo extends EditBoxGizmo {
    override factor = 0.5;
}

const AXIS_HIDE_TRESHOLD = 0.99;
