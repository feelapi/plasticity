import * as THREE from "three";
import { Vector3 } from "three";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import { ConstructionPlane } from "../../editor/snaps/ConstructionPlaneSnap";
import * as c3d from '../../kernel/kernel';
import { Z } from "../../util/Constants";
import { point2point, vec2vec } from "../../util/Conversion";
import * as visual from '../../visual_model/VisualModel';
import { PossiblyBoolean } from "../boolean/PossiblyBooleanFactory";
import { DiagonalRectangleFactory } from "../rect/RectangleFactory";

export interface BoxParams {
    p1: THREE.Vector3;
    p2: THREE.Vector3;
}

export interface EditBoxParams {
    corner1: THREE.Vector3;
    location: THREE.Vector3;
    width: number;
    length: number;
    height: number;
}

interface DiagonalBoxParams extends BoxParams {
    orientation: THREE.Quaternion;
}

abstract class DiagonalBoxFactory extends GeometryFactory<c3d.Solid, visual.Solid> implements BoxParams, DiagonalBoxParams, EditBoxParams {
    p1!: THREE.Vector3;
    constructionPlane?: ConstructionPlane;
    abstract get location(): THREE.Vector3;
    abstract get info(): { x: THREE.Vector3; y: THREE.Vector3; z: THREE.Vector3; location: THREE.Vector3 };

    protected _width?: number;
    protected __width: number = 0;
    get width() { return this._width ?? this.__width }
    set width(width: number) {
        const old = this.width;
        this._width = Math.abs(width);
        const delta = this.width - old;
        if (width < 0) {
            const { x } = this.info;
            x.normalize();
            this.p1.sub(x.multiplyScalar(delta));
        }
    }

    protected _length?: number;
    protected __length: number = 0;
    get length() { return this._length ?? this.__length }
    set length(length: number) {
        const old = this.length;
        this._length = Math.abs(length);
        const delta = this.length - old;
        if (length < 0) {
            const { y } = this.info;
            y.normalize();
            this.p1.sub(y.multiplyScalar(delta));
        }
    }

    protected _height = 0;
    get height() { return this._height }
    set height(height: number) { this._height = height }

    abstract get corner1(): THREE.Vector3;

    set orientation(orientation: THREE.Quaternion) {
        this._normal.copy(Z).applyQuaternion(orientation);
    }

    private readonly _normal = Z.clone();
    get normal() { return this._normal }

    set p2(_p2: THREE.Vector3) {
        const { corner1, normal } = this;
        const { p1, p2, p3 } = DiagonalRectangleFactory.orthogonal(corner1, _p2, normal, this.constructionPlane?.x);
        this.__width = p2.distanceTo(p1);
        this.__length = p3.distanceTo(p2);

        const AB = p2.clone().sub(p1).normalize();
        const BC = p3.clone().sub(p2).normalize();
        this.basis.makeBasis(AB, BC, normal);
    }

    readonly basis = new THREE.Matrix4();
}

export class CornerBoxFactory extends DiagonalBoxFactory {
    p1!: THREE.Vector3;

    async calculate(partition: c3d.Partition = this.partition) {
        const { x, y, z, location } = this.info;
        const xLength = x.length();
        const yLength = y.length();
        const zLength = z.length();
        if (xLength < 1e-6 || yLength < 1e-6 || zLength < 1e-6) throw new NoOpError();

        const basis = new c3d.Basis();
        basis.Axis.Copy(vec2vec(z.clone().normalize(), 1));
        basis.Ref.Copy(vec2vec(x.clone().normalize(), 1));
        basis.Location.Copy(point2point(location));
        return partition.SolidBody.CreateBlock(xLength, yLength, zLength, basis);
    }

    get info() {
        const { corner1 } = this;
        const x = new THREE.Vector3(), y = new THREE.Vector3(), z = new THREE.Vector3();
        this.basis.extractBasis(x, y, z);
        x.multiplyScalar(this.width);
        y.multiplyScalar(this.length);
        z.multiplyScalar(this.height);
        const location = x.clone().add(y).multiplyScalar(0.5).add(corner1);
        return { x, y, z, location };
    }

    get location() { return this.info.location }
    get corner1() { return this.p1 }
}

export class CenterBoxFactory extends DiagonalBoxFactory {
    p1!: Vector3;

    async calculate(partition: c3d.Partition = this.partition) {
        const { width, length } = this;
        let { height } = this;
        const { x, y, z, location } = this.info;
        height = Math.abs(height);

        if (width < 1e-6 || length < 1e-6 || height < 1e-6) throw new NoOpError();

        const placement = new c3d.Basis();
        placement.Axis.Copy(vec2vec(z.normalize(), 1));
        placement.Ref.Copy(vec2vec(x.normalize(), 1));
        placement.Location.Copy(point2point(location));
        return partition.SolidBody.CreateBlock(width, length, height, placement);
    }

    get location() { return this.info.location }
    get corner1() {
        const { x, y, location } = this.info;
        return location.sub(x.multiplyScalar(0.5)).sub(y.multiplyScalar(0.5));
    }

    get info() {
        const { p1 } = this;
        const x = new THREE.Vector3(), y = new THREE.Vector3(), z = new THREE.Vector3();
        this.basis.extractBasis(x, y, z);
        x.multiplyScalar(this.width);
        y.multiplyScalar(this.length);
        z.multiplyScalar(this.height);
        return { x, y, z, location: p1.clone() };
    }

    get width() { return this._width ?? this.__width }
    set width(width: number) { this._width = Math.abs(width) }

    get length() { return this._length ?? this.__length }
    set length(length: number) { this._length = Math.abs(length) }

    set p2(_p2: THREE.Vector3) {
        const { p1: corner1, normal } = this;
        const { p1, p2, p3 } = DiagonalRectangleFactory.orthogonal(corner1, _p2, normal, this.constructionPlane?.x);
        this.__width = p2.distanceTo(p1) * 2;
        this.__length = p3.distanceTo(p2) * 2;

        const AB = p2.clone().sub(p1).normalize();
        const BC = p3.clone().sub(p2).normalize();
        this.basis.makeBasis(AB, BC, normal);
    }
}

export class PossiblyBooleanCenterBoxFactory extends PossiblyBoolean(CenterBoxFactory) {
}

export class PossiblyBooleanCornerBoxFactory extends PossiblyBoolean(CornerBoxFactory) {
}
