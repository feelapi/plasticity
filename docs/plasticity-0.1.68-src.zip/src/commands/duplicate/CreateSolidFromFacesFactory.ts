import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';


export class CreateSolidFromFacesFactory extends GeometryFactory<c3d.Solid, visual.Solid, []> {
    protected _solid!: { view: visual.Solid; model: c3d.Solid; };
    @derive(visual.Solid) get solid(): visual.Solid { throw ''; }
    set solid(solid: visual.Solid | c3d.Solid) { }

    protected _faces!: { views: visual.Face[]; models: c3d.Face[]; };
    @derive([visual.Face]) get faces(): visual.Face[] { throw ''; }
    set faces(faces: visual.Face[] | c3d.Face[]) { }

    async calculate() {
        const { _solid: { model: solid }, _faces: { models: faces } } = this;

        return solid.CreateSolidFromFaces_async(faces, new c3d.CreateSolidFromFacesOptions());
    }
}
