import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import { PlaneSnap } from '../../editor/snaps/PlaneSnap';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';
import { faces2boundaryProfiles } from '../evolution/AbstractSweepFactory';


export class CreateCurvesFromRegionsFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance, []> {
    constructionPlane?: PlaneSnap;
    isOrthoMode = false;

    protected _sketch!: { view: visual.SketchIsland; model: c3d.RegionBody; };
    @derive(visual.SketchIsland) get sketch(): visual.SketchIsland { throw ''; }
    set sketch(sketch: visual.SketchIsland | c3d.RegionBody) { }

    protected _regions!: { views: visual.Region[]; models: c3d.Region[]; };
    @derive([visual.Region]) get regions(): visual.Region[] { throw ''; }
    set regions(regions: visual.Region[] | c3d.Region[]) { }

    async calculate(partition = this.partition): Promise<c3d.Wire[]> {
        const { _regions: { models: regions }, isOrthoMode, constructionPlane } = this;
        const profiles = await faces2boundaryProfiles(partition, regions);
        const options = new c3d.WireBodyCreateFromEdgesOptions();
        const promises = profiles.map(profile => partition.WireBody.CreateFromEdges_async(profile.GetEdges().GetEdges(), options));
        const creations = await Promise.all(promises);
        const wires = creations.map(c => c.wires).flat();
        let result: c3d.Wire[];
        if (isOrthoMode && constructionPlane !== undefined) {
            result = [];
            const basis = constructionPlane.placement;
            for (const wire of wires) {
                const planarized = wire.Planarize(basis);
                result.push(planarized);
            }
        } else result = wires;
        return result;
    }
}
