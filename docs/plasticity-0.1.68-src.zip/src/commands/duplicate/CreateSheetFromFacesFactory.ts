import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';


export class CreateSheetFromFacesFactory extends GeometryFactory<c3d.Shell, visual.Sheet, []> {
    protected _faces!: { views: visual.Face[]; models: c3d.Face[]; };
    @derive([visual.Face]) get faces(): visual.Face[] { throw ''; }
    set faces(faces: visual.Face[] | c3d.Face[]) { }

    protected _regions!: { views: visual.Region[]; models: c3d.Region[]; };
    @derive([visual.Region]) get regions(): visual.Region[] { throw ''; }
    set regions(regions: visual.Region[] | c3d.Region[]) { }


    async calculate() {
        const { _faces: { models: faces }, _regions: { models: regions } } = this;

        const { sheets } = await c3d.Sheet.MakeFromFaces_async([...faces, ...regions], new c3d.SheetBodyMakeFromFacesOptions());
        return sheets;
    }
}
