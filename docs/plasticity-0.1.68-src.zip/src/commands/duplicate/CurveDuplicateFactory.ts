import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import { PlaneSnap } from '../../editor/snaps/PlaneSnap';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';


export class CurveDuplicateFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance, []> {
    constructionPlane?: PlaneSnap;
    isOrthoMode = false;

    protected _curves!: { views: visual.SpaceInstance[]; models: c3d.Wire[]; };
    @derive([visual.SpaceInstance]) get curves(): visual.SpaceInstance[] { throw ''; }
    set curves(curves: visual.SpaceInstance[] | c3d.Wire[]) { }

    async calculate(): Promise<c3d.Wire[]> {
        const { _curves: { models: curves }, constructionPlane, isOrthoMode } = this;

        let result: c3d.Wire[] = [];

        let basis: c3d.Basis | undefined;
        if (isOrthoMode && constructionPlane !== undefined)
            basis = constructionPlane.placement;
        // if (basis !== undefined) {
        //     for (const curve of curves) {
        //         const planarized = curve.Planarize(basis);
        //         result.push(planarized);
        //     }
        // } else {
            result = curves.map(curve => curve.Copy());
        // }
        return result;
    }
}
