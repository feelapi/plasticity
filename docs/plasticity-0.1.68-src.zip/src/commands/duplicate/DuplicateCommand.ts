// TODO:
// - Optimize to use db transactions
import Command from "../../command/Command";
import { Selectable } from "../../selection/SelectionDatabase";
import * as visual from "../../visual_model/VisualModel";
import { MoveCommand } from "../translate/TransformCommand";
import { CreateCurveFromEdgesFactory } from "./CreateCurveFromEdgesFactory";
import { CreateCurvesFromRegionsFactory } from "./CreateCurveFromRegionsFactory";
import { CreateSheetFromFacesFactory } from "./CreateSheetFromFacesFactory";
import { CreateSolidFromFacesFactory } from "./CreateSolidFromFacesFactory";
import { CurveDuplicateFactory } from "./CurveDuplicateFactory";

export class DuplicateCommand extends Command {
    async execute(): Promise<void> {
        const { editor: { db, materials, signals, empties: emptyDb, nodes, selection: { selected, selected: { solids, curves, edges, faces, empties, regions, sheets } }, activeViewport } } = this;

        let results: Selectable[] = [];
        results = results.concat(await db.duplicate(...solids));
        results = results.concat(await db.duplicate(...sheets));

        let wiresFromRegions: visual.SpaceInstance[] = [];
        if (regions.size > 0) {
            const createWire = new CreateCurvesFromRegionsFactory(db, materials, signals).resource(this);
            createWire.constructionPlane = activeViewport?.constructionPlane;
            createWire.isOrthoMode = activeViewport?.isOrthoMode ?? false;
            createWire.regions = [...regions];
            const result = await createWire.commit();
            wiresFromRegions = result;
        }

        let copiedCurves: visual.SpaceInstance[] = [];
        if (curves.size > 0) {
            const copy = new CurveDuplicateFactory(db, materials, signals).resource(this);
            copy.constructionPlane = activeViewport?.constructionPlane;
            copy.isOrthoMode = activeViewport?.isOrthoMode ?? false;
            copy.isOrthoMode = false;
            copy.curves = [...curves];
            copiedCurves = await copy.commit();
        }

        for (const empty of empties) {
            const dup = emptyDb.duplicate(empty);
            const transform = nodes.getTransform(empty);
            if (transform !== undefined) nodes.setTransform(dup, transform);
            results.push(dup);
        }

        let sheetsFromFaces: visual.Sheet[] = [];
        if (faces.size > 0) {
            const createFace = new CreateSheetFromFacesFactory(db, materials, signals).resource(this);
            createFace.faces = [...faces];
            const result = await createFace.commit();
            sheetsFromFaces = result;
        }

        let wiresFromEdges: visual.SpaceInstance[] = [];
        if (edges.size > 0) {
            const createWire = new CreateCurveFromEdgesFactory(db, materials, signals).resource(this);
            createWire.constructionPlane = activeViewport?.constructionPlane;
            createWire.isOrthoMode = activeViewport?.isOrthoMode ?? false;
            createWire.edges = [...edges];
            const result = await createWire.commit();
            wiresFromEdges = result;
        }

        let objects = results;
        objects = objects.concat(sheetsFromFaces, wiresFromEdges, wiresFromRegions, copiedCurves);

        selected.removeAll();
        selected.add(objects);

        const command = new MoveCommand(this.editor);
        command.agent = 'automatic';
        this.editor.enqueue(command);
    }
}

export class CreateSolidFromFacesCommand extends Command {
    async execute(): Promise<void> {
        const { editor: { db, materials, signals, selection: { selected: { faces, regions }, selected } } } = this;

        const create = new CreateSolidFromFacesFactory(db, materials, signals).resource(this);
        create.faces = [...faces];
        create.solid = faces.first.parentItem as visual.Solid;

        const result = await create.commit();

        selected.remove([...faces, ...regions]);
        selected.add(result);
    }
}