import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import { PlaneSnap } from '../../editor/snaps/PlaneSnap';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';


export class CreateCurveFromEdgesFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance, []> {
    constructionPlane?: PlaneSnap;
    isOrthoMode = false;

    protected _edges!: { views: visual.CurveEdge[]; models: c3d.Edge[]; };
    @derive([visual.CurveEdge]) get edges(): visual.CurveEdge[] { throw ''; }
    set edges(edges: visual.CurveEdge[] | c3d.Edge[]) { }

    async calculate(): Promise<c3d.Wire[]> {
        const { _edges: { models: edges }, constructionPlane, isOrthoMode } = this;
        const options = new c3d.WireBodyCreateFromEdgesOptions();
        options.Simplify = true;
        const { wires } = await c3d.Wire.CreateFromEdges_async(edges, options);
        let result: c3d.Wire[];
        // if (isOrthoMode && constructionPlane !== undefined) {
        //     result = [];
        //     const basis = constructionPlane.placement;
        //     for (const wire of wires) {
        //         const planarized = wire.Planarize(basis);
        //         result.push(planarized);
        //     }
        // } else result = wires;
        result = wires;
        return result;
    }
}
