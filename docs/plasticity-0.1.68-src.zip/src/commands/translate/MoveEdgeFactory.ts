import * as THREE from "three";
import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { Z } from "../../util/Constants";
import { point2point, vec2vec } from "../../util/Conversion";
import * as visual from '../../visual_model/VisualModel';

export interface MoveEdgeParams {
    get move(): THREE.Vector3;
    get centroid(): THREE.Vector3;
    get edges(): visual.CurveEdge[];
}

export class MoveEdgeFactory extends GeometryFactory<c3d.Shell, visual.Shell> {
    readonly move = new THREE.Vector3();

    protected _shell!: { view: visual.Shell; model: c3d.Shell; };
    @derive(visual.Shell) get shell(): visual.Shell { throw ''; }
    set shell(shell: visual.Shell | c3d.Shell) { }

    protected _edges!: { views: visual.CurveEdge[]; models: c3d.Edge[]; };
    @derive([visual.CurveEdge]) get edges(): visual.CurveEdge[] { throw ''; }
    set edges(edges: visual.CurveEdge[] | c3d.Edge[]) { }

    get centroid() {
        const { _edges: { models: edges } } = this;
        const edge = edges[0];
        return point2point(edge.GetPoint(0.5));
    }

    async calculate() {
        const { move, _shell: { model: shell }, _edges: { models: edges } } = this;

        if (edges.length === 0) throw new NoOpError();

        const operation = new c3d.EdgeChangeTransformOperation(move.x, move.y);
        const options = new c3d.FaceChangeOptions(c3d.FaceGrowType.Fixed);
        await shell.TransformEdges_async(edges, operation, options);
        return shell;
    }

    get originalItem() { return this.shell }
}
