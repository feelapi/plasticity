import Command from "../../command/Command";
import { DisableOptions } from "../../editor/db/Database";
import { GConstructor } from "../../util/Util";
import { ChangeFaceKeyboardGizmo } from "../offset-face/ChangeFaceKeyboardGizmo";
import { AbstractRotateCommand, choosePivot, onKeyPress, PivotCommand } from "./AbstractTransformCommand";
import { FreestyleMoveItemCommand } from "./FreestyleTransformItemCommand";
import { MoveEdgeFactory } from "./MoveEdgeFactory";
import { MoveEdgeGizmo } from "./MoveEdgeGizmo";
import { MoveFaceDialog } from "./MoveFaceDialog";
import { MoveGizmo } from './MoveGizmo';
import { MoveKeyboardGizmo } from "./MoveKeyboardGizmo";
import { RotateFaceDialog } from "./RotateFaceDialog";
import { RotateGizmo } from './RotateGizmo';
import { RotateKeyboardGizmo } from "./RotateKeyboardGizmo";
import { MultiMoveFaceFactory, MultiRotateFaceFactory } from "./TransformFaceFactory";


export class MoveFaceCommand extends Command {
    choosePivot = false;

    async execute(): Promise<void> {
        const { editor, editor: { selection: { selected }, db, materials, signals } } = this;
        const faces = [...selected.faces];
        const face = faces[0];

        const move = new MultiMoveFaceFactory(db, materials, signals).resource(this);
        move.faces = faces;
        db.disable(move.shells, DisableOptions.KeepPointSnaps);

        const dialog = new MoveFaceDialog(move, signals);
        const gizmo = new MoveGizmo(move, editor);
        const keyboard = new MoveKeyboardGizmo(editor);
        const change = new ChangeFaceKeyboardGizmo(this.editor);

        dialog.execute(async (params) => {
            await move.update();
            gizmo.render(params);
        }).resource(this).then(() => this.finish(), () => this.cancel());

        gizmo.execute(s => {
            move.update();
            dialog.render();
        }).resource(this);

        const point = move.centroid;
        gizmo.position.copy(point);
        await choosePivot.call(this, this.choosePivot, point, move, gizmo);

        keyboard.execute(onKeyPress(this.constructor as GConstructor<PivotCommand>, gizmo, FreestyleMoveItemCommand).bind(this)).resource(this);
        change.execute(s => {
            switch (s) {
                case 'toggle':
                    move.toggle();
                    move.update();
                    dialog.render()
            }
        }).resource(this);

        await this.finished;

        await move.commit();
        const newFaces = move.selection;
        selected.add(newFaces);
    }
}


export class RotateFaceCommand extends Command {
    choosePivot = false;

    async execute(): Promise<void> {
        const { editor, editor: { selection: { selected }, db, materials, signals } } = this;
        const faces = [...selected.faces];

        const rotate = new MultiRotateFaceFactory(editor.db, materials, signals).resource(this);
        rotate.faces = faces;
        db.disable(rotate.shells, DisableOptions.KeepPointSnaps);

        const gizmo = new RotateGizmo(rotate, editor);
        const dialog = new RotateFaceDialog(rotate, signals);
        const keyboard = new RotateKeyboardGizmo(editor);
        const change = new ChangeFaceKeyboardGizmo(this.editor);

        dialog.execute(async (params) => {
            await rotate.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        gizmo.execute(s => {
            rotate.update();
            dialog.render();
        }).resource(this);

        const point = rotate.centroid;
        gizmo.position.copy(point);
        await choosePivot.call(this, this.choosePivot, point, rotate, gizmo);

        // FIXME: FreestyleRotateFaceCommand
        keyboard.execute(onKeyPress(this.constructor as GConstructor<AbstractRotateCommand>, gizmo, RotateFaceCommand).bind(this)).resource(this);
        change.execute(s => {
            switch (s) {
                case 'toggle':
                    rotate.toggle();
                    rotate.update();
                    dialog.render()
            }
        }).resource(this);

        await this.finished;

        await rotate.commit();
        const newFaces = rotate.selection;
        selected.add(newFaces);
    }
}

export class MoveEdgeCommand extends Command {
    async execute(): Promise<void> {
        const { editor, editor: { selection: { selected }, db, materials, signals } } = this;
        const move = new MoveEdgeFactory(db, materials, signals).resource(this);
        move.edges = [...selected.edges];
        move.shell = selected.edges.first.parentItem;
        
        const gizmo = new MoveEdgeGizmo(move, editor);

        gizmo.execute(s => {
            move.update();
        }).resource(this);

        await this.finished;

        await move.commit();
    }
}
