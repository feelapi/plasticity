import { computeCentroid, GConstructor } from "../../util/Util";
import { AbstractFreestyleMoveCommand, AbstractFreestyleRotateCommand, AbstractFreestyleScaleCommand } from "./AbstractFreestyleTranformCommand";
import { AbstractMoveCommand, AbstractRotateCommand, AbstractScaleCommand } from "./AbstractTransformCommand";
import { ProjectingFreestyleScaleFactory } from "./PlanarizeCurveFactory";
import { MoveItemCommand, RotateItemCommand, ScaleItemCommand } from "./TransformItemCommand";
import { MoveItemFactory, RotateItemFactory } from "./TransformItemFactory";
import { MoveFactoryLike } from "./TransformMixins";

export class FreestyleMoveItemCommand extends AbstractFreestyleMoveCommand {
    protected async makeFactory(): Promise<MoveFactoryLike> {
        const { editor } = this;
        const objects = [...editor.selection.selected.solids, ...editor.selection.selected.sheets, ...editor.selection.selected.curves];

        const centroid = computeCentroid(objects);

        const move = new MoveItemFactory(editor.db, editor.materials, editor.signals).resource(this);
        move.pivot.copy(centroid);
        move.items = objects;
        return move;
    }

    protected getNextCommand(): GConstructor<AbstractMoveCommand> {
        return MoveItemCommand;
    }
}

export class FreestyleScaleItemCommand extends AbstractFreestyleScaleCommand {
    protected async makeFactory() {
        const { editor } = this;
        const objects = [...editor.selection.selected.solids, ...editor.selection.selected.sheets, ...editor.selection.selected.curves];


        const scale = new ProjectingFreestyleScaleFactory(editor.db, editor.materials, editor.signals).resource(this);
        scale.items = objects;

        return scale;
    }

    protected getNextCommand(): GConstructor<AbstractScaleCommand> {
        return ScaleItemCommand;
    }
}

export class FreestyleRotateItemCommand extends AbstractFreestyleRotateCommand {
    protected async makeFactory(): Promise<RotateItemFactory> {
        const { editor } = this;
        const objects = [...editor.selection.selected.solids, ...editor.selection.selected.sheets, ...editor.selection.selected.curves];

        const rotate = new RotateItemFactory(editor.db, editor.materials, editor.signals).resource(this);
        rotate.items = objects;
        return rotate;
    }

    protected getNextCommand(): GConstructor<AbstractRotateCommand> {
        return RotateItemCommand;
    }
}
