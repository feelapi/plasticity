import * as THREE from "three";
import { Line2 } from "three/examples/jsm/lines/Line2";
import { EditorLike, Mode } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { GizmoMaterial } from "../../command/GizmoMaterials";
import { AbstractAxisGizmo, arrowGeometry, AxisHelper, CompositeHelper, lineGeometry, MagnitudeStateMachine, NumberHelper } from "../../command/MiniGizmos";
import { CancellablePromise } from "../../util/CancellablePromise";
import { Y, _Z } from "../../util/Constants";
import { point2point, vec2vec } from "../../util/Conversion";
import { MoveEdgeParams } from "./MoveEdgeFactory";
import { PlanarMoveGizmo } from "./MoveGizmo";

export class MoveEdgeGizmo extends CompositeGizmo<MoveEdgeParams> {
    private readonly materials = this.editor.gizmos;
    private readonly red = this.materials.red;
    private readonly green = this.materials.green;
    private readonly yellow = this.materials.yellow;
    private readonly x = new MoveAxisGizmo("move:x", this.editor, this.red);
    private readonly y = new MoveAxisGizmo("move:y", this.editor, this.green);
    private readonly xy = new PlanarMoveGizmo("move:xy", this.editor, this.yellow);

    readonly pivot = new THREE.Vector3();

    private flip = false;
    protected prepare(mode: Mode) {
        const { x, y, xy } = this;

        for (const o of [x, y, xy]) o.relativeScale.setScalar(0.5);
        this.add(x, y, xy);

        const { point, faceNormal1, faceNormal2, tangent } = this.placement();
        this.flip = faceNormal1.clone().cross(faceNormal2).dot(tangent) > 0;
        this.position.copy(point);
        x.quaternion.setFromUnitVectors(Y, faceNormal1);
        y.quaternion.setFromUnitVectors(Y, faceNormal2);

        faceNormal1.cross(faceNormal2).normalize();
        xy.quaternion.setFromUnitVectors(_Z, faceNormal1);

        this.pivot.copy(this.position);
    }

    private placement() {
        const { params: { edges }, editor: { db } } = this;
        const models = edges.map(view => db.lookupTopologyItem(view));
        const curveEdge = models[models.length - 1];

        const fins = curveEdge.GetOrientedEdges();
        if (fins.length !== 2) throw new Error("Expected two fins");
        const fin1 = fins[0], fin2 = fins[1];

        const { faceNormal1, faceNormal2, tangent } = curveEdge.EvalBasis(0.5);
        const hint = point2point(curveEdge.GetPoint(0.5));

        const { tangent: tangent1 } = fin1.GetPointAndTangent(0.5);
        const { tangent: tangent2 } = fin2.GetPointAndTangent(0.5);
        const tau1 = vec2vec(tangent1, 1);
        const tau2 = vec2vec(tangent2, 1);

        return {
            point: hint,
            faceNormal1: vec2vec(faceNormal1, 1).cross(tau1).normalize(),
            faceNormal2: vec2vec(faceNormal2, 1).cross(tau2).normalize(),
            tangent: vec2vec(tangent, 1)
        };
    }

    execute(cb: (params: MoveEdgeParams) => void, mode: Mode = Mode.Persistent): CancellablePromise<void> {
        const { x, y, xy, params } = this;

        const set = () => {
            params.move.set(x.value, y.value, 0);
            params.move.x -= xy.value.z;
            params.move.y -= xy.value.x;
            if (this.flip) params.move.negate();

            const deltaX = new THREE.Vector3(0, x.value, 0);
            deltaX.applyQuaternion(x.quaternion);
            const deltaY = new THREE.Vector3(0, y.value, 0);
            deltaY.applyQuaternion(y.quaternion);

            this.position.copy(this.pivot).add(deltaX).add(deltaY);
            this.position.add(xy.value);
        }

        this.addGizmo(x, set);
        this.addGizmo(y, set);
        this.addGizmo(xy, set);

        return super.execute(cb, mode);
    }

    render(params: MoveEdgeParams) {
        this.x.value = params.move.x;
        this.y.value = params.move.y;
        this.position.copy(this.pivot).add(params.move);
    }
}

export class MoveAxisGizmo extends AbstractAxisGizmo {
    readonly state = new MagnitudeStateMachine(0);
    readonly tip = new THREE.Mesh(arrowGeometry, this.material.mesh);
    protected readonly shaft = new Line2(lineGeometry, this.material.line2);
    protected readonly knob = new THREE.Mesh(new THREE.SphereGeometry(0.2), this.editor.gizmos.invisible);
    readonly helper = new CompositeHelper([new AxisHelper(this.material.line), new NumberHelper()]);

    constructor(name: string, editor: EditorLike, protected readonly material: GizmoMaterial) {
        super(name, editor);
        this.setup();
        this.add(this.helper);
    }

    protected accumulate(original: number, sign: number, dist: number): number {
        return original + dist
    }

    render(length: number) { }

}
