import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import * as c3d from '../../kernel/kernel';
import { RotateFaceParams } from './TransformFaceFactory';

export class RotateFaceDialog extends AbstractDialog<RotateFaceParams> {
    name = "Rotate";

    constructor(protected readonly params: RotateFaceParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { axis, degrees, grow, step } = this.params;

        render(
            <>
                <ul>
                    <li>
                        <label for="degrees">Angle</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="degrees" min={-360} max={360} value={degrees} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="axis">Axis</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="axis.x" min={0} max={1} value={axis.x} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber name="axis.y" min={0} max={1} value={axis.y} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber name="axis.z" min={0} max={1} value={axis.z} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="grow">Grow</label>
                        <div class="fields">
                            <input type="radio" hidden name="grow" id="moving" value={c3d.FaceGrowType.Moving} checked={grow === c3d.FaceGrowType.Moving} onClick={this.onChange}></input>
                            <label for="moving">Moving</label>

                            <input type="radio" hidden name="grow" id="fixed" value={c3d.FaceGrowType.Fixed} checked={grow === c3d.FaceGrowType.Fixed} onClick={this.onChange}></input>
                            <label for="fixed">Fixed</label>

                            <input type="radio" hidden name="grow" id="none" value={c3d.FaceGrowType.None} checked={grow === c3d.FaceGrowType.None} onClick={this.onChange}></input>
                            <label for="none">None</label>
                        </div>
                    </li>
                    <li>
                        <label for="step">Step</label>
                        <div class="fields">
                            <input type="radio" hidden name="step" id="smooth-site" value={c3d.FaceTransformStep.SmoothSite} checked={step === c3d.FaceTransformStep.SmoothSite} onClick={this.onChange}></input>
                            <label for="smooth-site">Prefer Grow</label>

                            <input type="radio" hidden name="step" id="not-coincident" value={c3d.FaceTransformStep.NotCoincident} checked={step === c3d.FaceTransformStep.NotCoincident} onClick={this.onChange}></input>
                            <label for="not-coincident">Prefer Step</label>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('rotate-face-dialog', RotateFaceDialog);