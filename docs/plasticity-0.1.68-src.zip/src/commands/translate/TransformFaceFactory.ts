import * as THREE from 'three';
import { delegate } from '../../command/FactoryBuilder';
import { NoOpError } from '../../command/GeometryFactory';
import { MultiplyableFactory } from '../../command/MultiFactory';
import { Database } from '../../editor/db/Database';
import { EditorSignals } from '../../editor/EditorSignals';
import MaterialDatabase from '../../editor/MaterialDatabase';
import * as c3d from '../../kernel/kernel';
import { mat2mat, point2point, vec2vec } from '../../util/Conversion';
import { QuaternionProxy, VectorProxy } from '../../util/VectorProxy';
import * as visual from "../../visual_model/VisualModel";
import { ModifyFaceFactory, ModifyFaceParams } from '../offset-face/ModifyFaceFactory';
import { MultiModifyFaceFactory } from "../offset-face/MultiModifyFaceFactory";
import { TransformFactory } from './TransformFactory';
import { HasRotationParams, MoveParams, RotateFactory, RotateParams } from "./TransformMixins";

export interface TransformFaceParams extends ModifyFaceParams {
    step: c3d.FaceTransformStep;
}

abstract class TransformFaceFactory extends ModifyFaceFactory implements MultiplyableFactory<c3d.Shell, visual.Shell> {
    private _step: c3d.FaceTransformStep = c3d.FaceTransformStep.SmoothSite;
    get step() { return this._step }
    set step(step: c3d.FaceTransformStep) { this._step = step }

    protected abstract get transform(): c3d.Transform;

    async calculate() {
        const { _shell: { model: shell }, _faces: { models: faces }, transform, step } = this;

        const options = new c3d.FaceChangeOptions(this.grow);
        const transformOptions = new c3d.FaceChangeTransformOperation(transform);
        const tracking = await shell.TransformFaces_async(faces, transformOptions, options);
        this.tracking = tracking;
        return shell;
    }

    get centroid() {
        const { _faces: { models: faces } } = this;
        const centroid = new THREE.Vector3();
        for (const face of faces) {
            centroid.add(point2point(face.GetPoint(0.5, 0.5)));
        }
        centroid.divideScalar(faces.length);
        return centroid;
    }

    override get originalItems() { return super.originalItems }
    override calculatePhantoms(partition: c3d.Partition) { return super.calculatePhantoms(partition) }
}

abstract class MultiTransformFaceFactory<T extends TransformFaceFactory> extends MultiModifyFaceFactory<T> implements ModifyFaceParams {
    @delegate.default(c3d.FaceTransformStep.SmoothSite) step!: c3d.FaceTransformStep;

    get centroid() {
        const centroid = new THREE.Vector3();
        for (const factory of this.factories) {
            centroid.add(factory.centroid);
        }
        centroid.divideScalar(this.factories.length);
        return centroid;
    }
}

export interface MoveFaceParams extends MoveParams, TransformFaceParams { }

export class MoveFaceFactory extends TransformFaceFactory implements MoveFaceParams {
    readonly pivot = new THREE.Vector3();

    private readonly _move = new THREE.Vector3();
    get move() { return this._move }

    override get transform(): c3d.Transform {
        const { move } = this;
        if (move.manhattanLength() < 1e-6) throw new NoOpError();
        return c3d.Transform.CreateTranslation(vec2vec(move));
    }
}

export class MultiMoveFaceFactory extends MultiTransformFaceFactory<MoveFaceFactory> implements MoveFaceParams {
    readonly move = new VectorProxy(move => {
        this.factories.forEach(f => f.move.copy(move));
    });

    readonly pivot = new VectorProxy(pivot => {
        this.factories.forEach(f => f.pivot.copy(pivot));
    });

    makeFactory(db: Database, materials: MaterialDatabase, signals: EditorSignals) {
        return new MoveFaceFactory(db, materials, signals);
    }
}

export interface RotateFaceParams extends RotateParams, TransformFaceParams { }

export class RotateFaceFactory extends RotateFactory(TransformFactory(TransformFaceFactory)) implements RotateFaceParams {
    readonly pivot = new THREE.Vector3();

    override get transform(): c3d.Transform {
        return c3d.Transform.CreateFromMatrix(mat2mat(this.matrix));
    }
}

export class MultiRotateFaceFactory extends HasRotationParams(MultiTransformFaceFactory<RotateFaceFactory>) implements RotateFaceParams {
    push() {
        for (const factory of this.factories) {
            factory.push();
        }
    }

    readonly pivot = new VectorProxy(pivot => {
        this.factories.forEach(f => f.pivot.copy(pivot));
    });

    makeFactory(db: Database, materials: MaterialDatabase, signals: EditorSignals): RotateFaceFactory {
        return new RotateFaceFactory(db, materials, signals);
    }

    override readonly quaternion = new QuaternionProxy(quaternion => {
        this.factories.forEach(f => f.quaternion.copy(quaternion));
    });
}