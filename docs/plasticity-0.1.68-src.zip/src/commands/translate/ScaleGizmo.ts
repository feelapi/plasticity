import * as THREE from "three";
import { Line2 } from "three/examples/jsm/lines/Line2";
import { CancellablePromise } from "../../util/CancellablePromise";
import { EditorLike, Intersector, Mode, MovementInfo } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { GizmoMaterial } from "../../command/GizmoMaterials";
import { AbstractAxialScaleGizmo, AxisHelper, boxGeometry, CircularGizmo, CompositeHelper, DashedLineMagnitudeHelper, InputMode, lineGeometry, MagnitudeStateMachine, NumberHelper, PlanarGizmo } from "../../command/MiniGizmos";
import { ScaleParams } from "./TransformMixins";
import { X, Y, Z, _X, _Y } from "../../util/Constants";
import { KeyboardInterpreter, TextCalculator } from "../../command/KeyboardInterpreter";

interface HasQuaternion {
    get quaternion(): THREE.Quaternion;
}

export class ScaleGizmo extends CompositeGizmo<ScaleParams & HasQuaternion> {
    private readonly materials = this.editor.gizmos;
    private readonly red = this.materials.red;
    private readonly green = this.materials.green;
    private readonly blue = this.materials.blue;
    private readonly yellow = this.materials.yellow;
    private readonly magenta = this.materials.magenta;
    private readonly cyan = this.materials.cyan;
    private readonly x = new ScaleAxisGizmo("scale:x", this.editor, this.red);
    private readonly y = new ScaleAxisGizmo("scale:y", this.editor, this.green);
    private readonly z = new ScaleAxisGizmo("scale:z", this.editor, this.blue);
    private readonly xy = new PlanarScaleGizmo("scale:xy", this.editor, this.yellow);
    private readonly yz = new PlanarScaleGizmo("scale:yz", this.editor, this.cyan);
    private readonly xz = new PlanarScaleGizmo("scale:xz", this.editor, this.magenta);
    private readonly xyz = new CircleScaleGizmo("scale:xyz", this.editor);

    get pivot() { return this.position }

    prepare() {
        const { x, y, z, xyz, xy, yz, xz } = this;
        for (const o of [x, y, z]) o.relativeScale.setScalar(0.8);
        for (const o of [xy, yz, xz]) o.relativeScale.setScalar(0.8);
        xyz.relativeScale.setScalar(0.25);

        this.add(x, y, z, xy, yz, xz, xyz);

        x.quaternion.setFromUnitVectors(Y, X);
        y.quaternion.setFromUnitVectors(Y, Y);
        z.quaternion.setFromUnitVectors(Y, Z);

        yz.quaternion.setFromUnitVectors(Z, _X);
        xz.quaternion.setFromUnitVectors(Z, _Y);
    }

    private readonly _scale = new THREE.Vector3();

    execute(cb: (params: ScaleParams & HasQuaternion) => void, mode: Mode = Mode.Persistent): CancellablePromise<void> {
        const { x, y, z, xy, yz, xz, xyz, params, _scale } = this;

        const set = () => {
            _scale.set(
                xy.value * xz.value * x.value,
                xy.value * yz.value * y.value,
                xz.value * yz.value * z.value).multiplyScalar(xyz.value);
            // FIXME: find a better solution than this
            _scale.set(_scale.x, _scale.y, _scale.z);
            params.scale.copy(_scale);
            params.quaternion.copy(this.quaternion);
        }

        this.addGizmo(x, set);
        this.addGizmo(y, set);
        this.addGizmo(z, set);
        this.addGizmo(xy, set);
        this.addGizmo(yz, set);
        this.addGizmo(xz, set);
        this.addGizmo(xyz, set);

        return super.execute(cb, mode);
    }

    render(params: ScaleParams) {
        this.x.value = params.scale.x;
        this.y.value = params.scale.y;
        this.z.value = params.scale.z;
    }

    resetPivot() {
        this.quaternion.identity();
        this.editor.signals.gizmoChanged.dispatch();
    }
}

export class CircleScaleGizmo extends CircularGizmo<number> {
    protected mode: InputMode = 'pointer';
    readonly helper = new CompositeHelper([new DashedLineMagnitudeHelper(), new NumberHelper()]);
    private denominator = 1;
    readonly state = new MagnitudeStateMachine(1);

    constructor(name: string, editor: EditorLike) {
        super(name, editor, editor.gizmos.white);
        this.setup();
        this.render(this.state.current);
    }

    onPointerDown(cb: (radius: number) => void, intersect: Intersector, info: MovementInfo) {
        const { pointStart2d, center2d } = info;
        this.denominator = pointStart2d.distanceTo(center2d);
        this.state.start();
    }


    onPointerUp(cb: (radius: number) => void, intersect: Intersector, info: MovementInfo) {
        super.onPointerUp(cb, intersect, info);
        this.mode = 'pointer';
    }

    onPointerMove(cb: (radius: number) => void, intersect: Intersector, info: MovementInfo) {
        if (this.mode !== 'pointer') return this.state.current;

        const { pointEnd2d, center2d } = info;
        const magnitude = this.state.original * pointEnd2d.distanceTo(center2d) / this.denominator!;
        this.state.current = magnitude;
        this.render(this.state.current);
        cb(this.state.current);
        return magnitude;
    }

    render(magnitude: number) {
        this.torus.scale.setScalar(magnitude);
        this.circle.scale.setScalar(magnitude);
    }

    override onKeyDown(cb: (distance: number) => void, text: KeyboardInterpreter) {
        const distance = TextCalculator.calculate(text.state);
        if (distance === undefined) {
            this.mode = 'pointer';
            return this.state.current;
        }

        this.state.current = distance;
        this.render(this.state.current);
        cb(distance);
        this.mode = 'keyboard';
        return distance;
    }
}

export class ScaleAxisGizmo extends AbstractAxialScaleGizmo {
    readonly state = new MagnitudeStateMachine(1);
    readonly tip: THREE.Mesh<any, any> = new THREE.Mesh(boxGeometry, this.material.mesh);
    protected readonly shaft = new Line2(lineGeometry, this.material.line2);
    protected readonly knob = new THREE.Mesh(new THREE.SphereGeometry(0.2), this.editor.gizmos.invisible);
    readonly helper = new CompositeHelper<number>([new DashedLineMagnitudeHelper(), new AxisHelper(this.material.line), new NumberHelper()]);
    protected readonly handleLength = 0;

    constructor(name: string, editor: EditorLike, protected readonly material: GizmoMaterial) {
        super(name, editor, material);
        this.add(this.helper);
        this.setup();
    }

    protected accumulate(original: number, dist: number, denom: number, sign: number): number {
        // return sign * original * dist / denom;
        return original * dist / denom;
    }
}

export class PlanarScaleGizmo extends PlanarGizmo<number> {
    readonly state = new MagnitudeStateMachine(1);
    readonly helper = new DashedLineMagnitudeHelper();

    onPointerMove(cb: (value: number) => void, intersect: Intersector, info: MovementInfo) {
        const { plane, denominator, state } = this;

        const planeIntersect = intersect.raycast(plane);
        if (planeIntersect === undefined) return; // this only happens when the user is dragging through different viewports.

        let magnitude = planeIntersect.point.clone().sub(this.worldPosition).length();
        magnitude *= state.original;
        magnitude /= denominator;

        this.state.current = magnitude;
        this.render(magnitude);
        cb(magnitude);
        return magnitude;
    }

    render(magnitude: number) {
        this.square.position.set(0.3 * magnitude, 0.3 * magnitude, 0);
        this.knob.position.copy(this.square.position);
    }
}