import * as THREE from "three";
import { AbstractFactory } from "../../command/AbstractFactory";
import { NoOpError } from "../../command/GeometryFactory";
import { TemporaryObject } from "../../editor/DatabaseLike";
import { EditorSignals } from "../../editor/EditorSignals";
import { Empty } from "../../editor/Empties";
import MaterialDatabase from "../../editor/MaterialDatabase";
import { NodeIdentityTransform, Nodes } from "../../editor/Nodes";
import { identityMatrix } from "../../util/Constants";
import { TransformFactory, TransformFactoryLike } from "./TransformFactory";
import { transformTemporary } from "./TransformItemFactory";
import { BasicScale, FreestyleScale, FreestyleScaleFactoryLike, MoveFactory, MoveFactoryLike, RotateFactory, RotateFactoryLike, ScaleFactoryLike } from "./TransformMixins";

type State =
    { tag: 'none' }
    | { tag: 'updated' }
    | { tag: 'cancelled' }
    | { tag: 'committed', result: Empty[] }

abstract class EmptyFactory extends AbstractFactory<Empty> {
    private _state: State = { tag: 'none' };
    get state() { return this._state }
    set state(state: State) {
        this._state = state;
        this.changed.dispatch();
    }

    constructor(
        protected readonly nodes: Nodes,
        protected readonly materials: MaterialDatabase,
        protected readonly signals: EditorSignals,
    ) { super() }

    override async update(): Promise<void> {
        switch (this.state.tag) {
            case 'none':
            case 'updated':
                await this.doUpdate(() => false);
                this.state = { tag: 'updated' };
                return;
            default: throw new Error("invalid state");
        }
    }

    override async cancel(): Promise<void> {
        switch (this.state.tag) {
            case 'none':
            case 'updated':
                this.doCancel();
                this.state = { tag: 'cancelled' };
                return;
            default: throw new Error("invalid state");
        }
    }

    override async commit(): Promise<Empty[]> {
        switch (this.state.tag) {
            case 'none':
            case 'updated':
                const result = await this.doCommit() as Empty[];
                this.state = { tag: 'committed', result };
                return result;
            default: throw new Error("invalid state");
        }
    }
}

abstract class TransformEmptyFactory extends TransformFactory(EmptyFactory) implements TransformFactoryLike {
    _items!: Empty[];
    protected originalTransforms!: THREE.Matrix4[];
    get items() { return this._items }
    set items(items: Empty[]) {
        const originalTransforms = [];
        this._items = items;
        for (const item of items) {
            const tx = this.nodes.getTransform(item) ?? NodeIdentityTransform;
            const mat = new THREE.Matrix4().compose(tx.position, tx.quaternion, tx.scale);
            originalTransforms.push(mat);
        }
        this.originalTransforms = originalTransforms;
    }

    get centroid() {
        const centroid = new THREE.Vector3();
        for (const item of this.items) {
            const tx = this.nodes.getTransform(item) ?? NodeIdentityTransform;
            centroid.add(tx.position);
        }
        return centroid.divideScalar(this.items.length);
    }

    async doUpdate(abortEarly: () => boolean) {
        const { items, originalTransforms, matrix } = this;
        let result: TemporaryObject[] = [];
        for (const [i, item] of items.entries()) {
            tmp.copy(matrix).multiply(originalTransforms[i]);
            const temp = transformTemporary(item, tmp)[0];
            result.push(temp);
        }
        return await Promise.all(result);
    }

    protected async doCommit() {
        const { items, originalTransforms, matrix, nodes } = this;
        if (matrix.equals(identityMatrix)) throw new NoOpError();

        for (const [i,] of items.entries()) {
            const transform = { position: new THREE.Vector3(), quaternion: new THREE.Quaternion(), scale: new THREE.Vector3 };
            tmp.copy(matrix).multiply(originalTransforms[i]).decompose(transform.position, transform.quaternion, transform.scale)
            nodes.setTransform(items[i], transform);
        }
        this.finalize();
        return this.items;
    }

    get selection() {
        if (this.state.tag !== 'committed') throw new Error("invalid state");
        return this.state.result;
    }

    get originalItems() { return this.items }

    async showPhantoms(): Promise<void> { }
}

const tmp = new THREE.Matrix4();

export class MoveEmptyFactory extends MoveFactory(TransformEmptyFactory) implements MoveFactoryLike {
}


export class BasicScaleEmptyFactory extends BasicScale(TransformEmptyFactory) implements ScaleFactoryLike {
}

export class FreestyleScaleEmptyFactory extends FreestyleScale(TransformEmptyFactory) implements FreestyleScaleFactoryLike {
}
export class RotateEmptyFactory extends RotateFactory(TransformEmptyFactory) implements RotateFactoryLike {
}

