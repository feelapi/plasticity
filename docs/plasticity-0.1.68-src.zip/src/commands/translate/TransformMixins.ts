import * as THREE from "three";
import { AbstractFactory } from "../../command/AbstractFactory";
import { Selectable } from "../../selection/SelectionDatabase";
import { X } from "../../util/Constants";
import { unit } from "../../util/Conversion";
import { AGConstructor } from "../../util/Util";
import { TransformFactoryLike } from "./TransformFactory";
import { VectorProxy } from "../../util/VectorProxy";


export interface MoveParams {
    get move(): THREE.Vector3;
    get pivot(): THREE.Vector3;
}

export interface MoveFactoryLike extends AbstractFactory<any>, MoveParams {
    showPhantoms(): Promise<void>;
    get centroid(): THREE.Vector3;
    get selection(): Selectable[];
}


export function MoveFactory<T extends AGConstructor<TransformFactoryLike>>(klass: T) {
    abstract class Anon extends klass implements MoveParams {
        readonly pivot = new THREE.Vector3();
        readonly move = new THREE.Vector3();

        protected prepare() {
            const { last, move } = this;
            last.makeTranslation(move.x, move.y, move.z);
        }
    }
    return Anon;
}

export interface RotateParams {
    get quaternion(): THREE.Quaternion;
    get pivot(): THREE.Vector3;
    get axis(): VectorProxy;
    angle: number;
    degrees: number;
    push(): void;
}

export interface RotateFactoryLike extends AbstractFactory<any>, RotateParams {
    showPhantoms(): Promise<void>;
    get centroid(): THREE.Vector3;
    get selection(): Selectable[];
}

export function HasRotationParams<T extends AGConstructor<any>>(klass: T) {
    abstract class Anon extends klass {
        readonly pivot = new THREE.Vector3();

        get degrees() { return THREE.MathUtils.radToDeg(this.angle); }
        set degrees(degrees: number) {
            this.angle = THREE.MathUtils.degToRad(degrees);
        }

        get angle() { return quaternion2axisAngle(this.quaternion).angle }
        set angle(angle: number) {
            const { axis } = quaternion2axisAngle(this.quaternion);
            this.quaternion.setFromAxisAngle(axis, angle);
        }

        private readonly ignore = new THREE.Vector3;
        private readonly _axis = new VectorProxy(axis => {
            const { angle } = quaternion2axisAngle(this.quaternion, this.ignore);
            this.quaternion.setFromAxisAngle(axis, angle);
        });
        get axis() {
            quaternion2axisAngle(this.quaternion, this._axis.underlying);
            return this._axis;
        }

        readonly quaternion = new THREE.Quaternion();
    }
    return Anon
}

export function RotateFactory<T extends AGConstructor<TransformFactoryLike>>(klass: T) {
    abstract class Anon extends HasRotationParams(klass) {
        private readonly m = new THREE.Matrix4();
        protected prepare() {
            const { m } = this;
            const { pivot, last, quaternion } = this;
            m.makeTranslation(-pivot.x, -pivot.y, -pivot.z);
            last.makeRotationFromQuaternion(quaternion);
            last.multiply(m);
            m.makeTranslation(pivot.x, pivot.y, pivot.z);
            last.premultiply(m);
        }
    }
    return Anon;
}

// From: https://www.euclideanspace.com/maths/geometry/rotations/conversions/quaternionToAngle/index.htm
function quaternion2axisAngle(from: THREE.Quaternion, to = new THREE.Vector3()) {
    if (from.w > 1) from.normalize(); // if w>1 acos and sqrt will produce errors, this cant happen if quaternion is normalised
    const angle = 2 * Math.acos(from.w);
    const s = Math.sqrt(1 - from.w * from.w); // assuming quaternion normalised then w is less than 1, so term always positive.
    let x, y, z;
    if (s < 0.001) { // test to avoid divide by zero, s is always positive due to sqrt
        // if s close to zero then direction of axis not important
        x = from.x; // if it is important that axis is normalised then replace with x=1; y=z=0;
        y = from.y;
        z = from.z;
    } else {
        x = from.x / s; // normalise axis
        y = from.y / s;
        z = from.z / s;
    }
    return { angle, axis: to.set(x, y, z) };
}

export interface ScaleParams {
    get scale(): THREE.Vector3;
    get pivot(): THREE.Vector3;
}

export interface FreestyleScaleParams extends ScaleParams {
    length: number;
    isUniform: boolean;
}

export function BasicScale<T extends AGConstructor<TransformFactoryLike>>(klass: T) {
    abstract class Anon extends klass implements ScaleParams {
        readonly scale = new THREE.Vector3(1, 1, 1);
        readonly pivot = new THREE.Vector3();
        readonly quaternion = new THREE.Quaternion();

        private rotateFrom = new THREE.Matrix4();
        private rotateTo = new THREE.Matrix4();
        private translateFrom = new THREE.Matrix4();
        private translateTo = new THREE.Matrix4();
        private scalemat = new THREE.Matrix4();

        protected prepare() {
            const { last, rotateFrom, rotateTo, scalemat, translateFrom, translateTo, scale, quaternion, pivot } = this;
            translateFrom.makeTranslation(-unit(pivot.x), -unit(pivot.y), -unit(pivot.z));
            translateTo.makeTranslation(unit(pivot.x), unit(pivot.y), unit(pivot.z));
            rotateFrom.makeRotationFromQuaternion(quaternion).invert();
            rotateTo.makeRotationFromQuaternion(quaternion);
            scalemat.makeScale(scale.x, scale.y, scale.z);
            last.identity();
            last.premultiply(translateFrom);
            last.premultiply(rotateFrom);
            last.premultiply(scalemat);
            last.premultiply(rotateTo);
            last.premultiply(translateTo);
        }
    }
    return Anon;
}

export interface ScaleFactoryLike extends AbstractFactory<any>, ScaleParams {
    get centroid(): THREE.Vector3;
    get selection(): Selectable[];
}

export interface ScaleFactoryLikeWithQuaternion extends ScaleFactoryLike {
    readonly quaternion: THREE.Quaternion;
}

export interface FreestyleScaleFactoryLike extends ScaleFactoryLike, FreestyleScaleParams {
    from(p1: THREE.Vector3, p2: THREE.Vector3): void;
    to(p1: THREE.Vector3, p2: THREE.Vector3): void;
    get ref(): THREE.Vector3;
    showPhantoms(): Promise<void>;
}

export function FreestyleScale<T extends AGConstructor<TransformFactoryLike>>(klass: T) {
    abstract class Anon extends klass implements FreestyleScaleParams {
        private _isUniform = false;
        get isUniform() { return this._isUniform }
        set isUniform(isUniform: boolean) {
            this._isUniform = isUniform;
            this.updateMatrix();
        }

        get pivot() { return this._pivot }
        set pivot(pivot: THREE.Vector3) {
            this._pivot.copy(pivot);
            const { translateFrom, translateTo } = this;
            translateFrom.makeTranslation(-unit(pivot.x), -unit(pivot.y), -unit(pivot.z));
            translateTo.makeTranslation(unit(pivot.x), unit(pivot.y), unit(pivot.z));
        }

        get matrix() { return this._matrix }

        get scale() {
            const els = this.scalemat.elements;
            return new THREE.Vector3(els[0], els[4], els[8]);
        }

        get ratio() { return this.transMagnitude / this.refMagnitude }
        set ratio(ratio: number) {
            this.transMagnitude = this.refMagnitude * ratio;
            this.updateMatrix();
        }

        readonly ref = new THREE.Vector3();
        private readonly _pivot = new THREE.Vector3();
        private refMagnitude = 1;
        private transMagnitude = 1;
        readonly quaternion = new THREE.Quaternion();
        private rotateFrom = new THREE.Matrix4();
        private rotateTo = new THREE.Matrix4();
        private translateFrom = new THREE.Matrix4();
        private translateTo = new THREE.Matrix4();
        private scalemat = new THREE.Matrix4();

        get length() { return this.transMagnitude; }
        set length(length: number) {
            this.transMagnitude = length;
            this.updateMatrix()
        }

        from(p1: THREE.Vector3, p2: THREE.Vector3) {
            const { ref, quaternion: quat, rotateFrom, rotateTo } = this;
            this.pivot = p1;

            ref.copy(p2).sub(p1);
            this.refMagnitude = ref.length();
            ref.divideScalar(this.refMagnitude);

            quat.setFromUnitVectors(X, ref);

            rotateTo.makeRotationFromQuaternion(quat);
            rotateFrom.copy(rotateTo).transpose();
        }

        to(p1: THREE.Vector3, p3: THREE.Vector3) {
            const transMagnitude = p3.distanceTo(p1);
            this.transMagnitude = transMagnitude;

            this.updateMatrix();
        }

        private updateMatrix() {
            const { _matrix, transMagnitude, refMagnitude, rotateFrom, rotateTo, scalemat: scale, translateFrom, translateTo, _isUniform: isUniform } = this;

            const scaleRatio = transMagnitude / refMagnitude;
            if (isUniform) scale.makeScale(scaleRatio, scaleRatio, scaleRatio);
            else scale.makeScale(scaleRatio, 1, 1);

            const els = scale.elements;

            _matrix.identity();
            _matrix.premultiply(translateFrom);
            _matrix.premultiply(rotateFrom);
            _matrix.premultiply(scale);
            _matrix.premultiply(rotateTo);
            _matrix.premultiply(translateTo);
        }
    }
    return Anon;
}
