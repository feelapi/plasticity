import * as THREE from "three";
import Command from "../../command/Command";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { Quasimode } from "../../command/Quasimode";
import { GConstructor } from "../../util/Util";
import { AbstractFreestyleMoveCommand, AbstractFreestyleRotateCommand, AbstractFreestyleScaleCommand } from "./AbstractFreestyleTranformCommand";
import { ModifyPivotGizmo } from "./ModifyPivotGizmo";
import { MoveGizmo } from './MoveGizmo';
import { MoveItemDialog } from "./MoveItemDialog";
import { MoveKeyboardGizmo } from "./MoveKeyboardGizmo";
import { RotateGizmo } from './RotateGizmo';
import { RotateItemDialog } from "./RotateItemDialog";
import { RotateKeyboardGizmo } from "./RotateKeyboardGizmo";
import { ScaleDialog } from "./ScaleDialog";
import { ScaleGizmo } from "./ScaleGizmo";
import { ScaleKeyboardGizmo } from "./ScaleKeyboardGizmo";
import { MoveFactoryLike, RotateFactoryLike, ScaleFactoryLikeWithQuaternion } from "./TransformMixins";


export interface PivotCommand extends Command {
    choosePivot: boolean;
}

export abstract class AbstractMoveCommand extends Command implements PivotCommand {
    choosePivot = false;

    async execute(): Promise<void> {
        const { editor } = this;

        const move = this.makeFactory();

        const dialog = new MoveItemDialog(move, editor.signals);
        const gizmo = new MoveGizmo(move, editor);
        const keyboard = new MoveKeyboardGizmo(editor);

        dialog.execute(async (params) => {
            await move.update();
            gizmo.render(params);
        }).resource(this).then(() => this.finish(), () => this.cancel());

        gizmo.execute(s => {
            move.update();
            dialog.render();
        }).resource(this);

        const constructionPlane = editor.activeViewport!.constructionPlane;
        if (!constructionPlane.isAxisAligned) {
            gizmo.position.copy(this.editor.activeViewport!.constructionPlane.p);
            gizmo.quaternion.copy(this.editor.activeViewport!.constructionPlane.orientation);
        }

        const centroid = move.centroid;
        await choosePivot.call(this, this.choosePivot, centroid, move, gizmo);
        keyboard.execute(onKeyPress(this.constructor as GConstructor<PivotCommand>, gizmo, this.getFreestyleCommand()).bind(this)).resource(this);

        await this.finished;

        await move.commit();
        this.editor.selection.selected.add(move.selection);
    }

    protected abstract makeFactory(): MoveFactoryLike;
    protected abstract getFreestyleCommand(): GConstructor<AbstractFreestyleMoveCommand>;
}

export abstract class AbstractScaleCommand extends Command implements PivotCommand {
    choosePivot = false;

    async execute(): Promise<void> {
        const { editor } = this;
        const scale = this.makeFactory();

        const gizmo = new ScaleGizmo(scale, editor);
        const dialog = new ScaleDialog(scale, editor.signals);
        const keyboard = new ScaleKeyboardGizmo(editor);

        dialog.execute(async (params) => {
            await scale.update();
            gizmo.render(params);
        }).resource(this).then(() => this.finish(), () => this.cancel());

        gizmo.execute(s => {
            scale.update();
            dialog.render();
        }).resource(this);

        const constructionPlane = editor.activeViewport!.constructionPlane;
        if (!constructionPlane.isAxisAligned) {
            gizmo.position.copy(this.editor.activeViewport!.constructionPlane.p);
            gizmo.quaternion.copy(this.editor.activeViewport!.constructionPlane.orientation);
        }

        const centroid = scale.centroid;
        await choosePivot.call(this, this.choosePivot, centroid, scale, gizmo);
        keyboard.execute(onKeyPress(this.constructor as GConstructor<PivotCommand>, gizmo, this.getFreestyleCommand()).bind(this)).resource(this);

        await this.finished;

        await scale.commit();
        this.editor.selection.selected.add(scale.selection);
    }

    protected abstract makeFactory(): ScaleFactoryLikeWithQuaternion;
    protected abstract getFreestyleCommand(): GConstructor<AbstractFreestyleScaleCommand>;
}

export abstract class AbstractRotateCommand extends Command implements PivotCommand {
    choosePivot = false;

    async execute(): Promise<void> {
        const { editor, agent } = this;

        const rotate = this.makeFactory();

        const gizmo = new RotateGizmo(rotate, editor);
        const dialog = new RotateItemDialog(rotate, editor.signals);
        const keyboard = new RotateKeyboardGizmo(editor);

        dialog.execute(async (params) => {
            await rotate.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        gizmo.execute(s => {
            rotate.update();
            dialog.render();
        }).resource(this);

        const constructionPlane = editor.activeViewport!.constructionPlane;
        if (!constructionPlane.isAxisAligned) {
            gizmo.position.copy(this.editor.activeViewport!.constructionPlane.p);
            gizmo.quaternion.copy(this.editor.activeViewport!.constructionPlane.orientation);
        }

        const centroid = rotate.centroid;
        await choosePivot.call(this, this.choosePivot, centroid, rotate, gizmo);
        keyboard.execute(onKeyPress(this.constructor as GConstructor<AbstractRotateCommand>, gizmo, this.getFreestyleCommand()).bind(this)).resource(this);

        if (editor.activeViewport?.isOrthoMode && agent === 'user') {
            gizmo.start('gizmo:rotate:screen');
        }

        const quasimode = new Quasimode("modify-pivot", this.editor, rotate);
        quasimode.execute(() => {
            const modifyPivot = new ModifyPivotGizmo(gizmo, editor);
            modifyPivot.position.copy(gizmo.position);
            modifyPivot.quaternion.copy(gizmo.quaternion);
            gizmo.disable();
            return modifyPivot.execute(_ => { }).after(() => {
                gizmo.enable();
            }).resource(this);
        }).resource(this);

        await this.finished;

        await rotate.commit();
        this.editor.selection.selected.add(rotate.selection);
    }

    protected abstract makeFactory(): RotateFactoryLike;
    protected abstract getFreestyleCommand(): GConstructor<AbstractFreestyleRotateCommand>;
}

export function onKeyPress(Pivot: GConstructor<PivotCommand>, gizmo: RotateGizmo | MoveGizmo | ScaleGizmo, Freestyle: GConstructor<Command>) {
    // NB: both pivot & freestyle rely on snap points, which are only updated on commit; since move commands update objects
    // it's important to commit and re-enqueue before choosing a pivot or freestyle point.
    return async function (this: Command, s: string) {
        switch (s) {
            case 'pivot':
                gizmo.disable();
                this.finish();
                const command = new Pivot(this.editor);
                command.choosePivot = true;
                this.editor.enqueue(command);
                break;
            case 'free':
                gizmo.disable();
                this.finish();
                this.editor.enqueue(new Freestyle(this.editor));
                break;
            case 'worldspace':
                gizmo.resetPivot();
                break;
        }
    };
}

export async function choosePivot(this: Command, choosePivot: boolean, fallback: THREE.Vector3, factory: { get pivot(): THREE.Vector3; }, gizmo: RotateGizmo | MoveGizmo | ScaleGizmo) {
    if (choosePivot) {
        gizmo.disable();
        const pointPicker = new PointPicker(this.editor);
        const { point: pivot } = await pointPicker.execute(({ point: pivot, info: { snap } }) => {
            const { orientation } = snap.project(pivot);
            gizmo.position.copy(pivot);
            gizmo.quaternion.copy(orientation);
        }).resource(this);
        gizmo.pivot.copy(pivot);
        factory.pivot.copy(pivot);
        gizmo.enable();
    } else {
        factory.pivot.copy(fallback);
        gizmo.position.copy(fallback);
        gizmo.pivot.copy(fallback);
    }
}
