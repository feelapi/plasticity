import Command from "../../command/Command";
import { MoveControlPointCommand, RotateControlPointCommand, ScaleControlPointCommand } from "../modify_curve/TransformControlPointCommand";
import { MoveEmptyCommand, RotateEmptyCommand, ScaleEmptyCommand } from "./TransformEmptyCommand";
import { MoveEdgeCommand, MoveFaceCommand, RotateFaceCommand } from "./TransformFaceCommand";
import { MoveItemCommand, RotateItemCommand, ScaleItemCommand } from "./TransformItemCommand";

export class MoveCommand extends Command {
    async execute(): Promise<void> {
        const selected = this.editor.selection.selected;

        if (selected.faces.size > 0) {
            const command = new MoveFaceCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.solids.size > 0 || selected.sheets.size > 0 || selected.curves.size > 0) {
            const command = new MoveItemCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.vertices.size > 0 || selected.cvs.size > 0) {
            const command = new MoveControlPointCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.empties.size > 0) {
            const command = new MoveEmptyCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.edges.size > 0) {
            const command = new MoveEdgeCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        }
    }
}

export class ScaleCommand extends Command {
    async execute(): Promise<void> {
        const selected = this.editor.selection.selected;
        if (selected.solids.size > 0 || selected.sheets.size > 0 || selected.curves.size > 0) {
            const command = new ScaleItemCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.vertices.size > 0 || selected.cvs.size > 0) {
            const command = new ScaleControlPointCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.empties.size > 0) {
            const command = new ScaleEmptyCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        }
    }
}

export class RotateCommand extends Command {
    async execute(): Promise<void> {
        const selected = this.editor.selection.selected;
        if (selected.faces.size > 0) {
            const command = new RotateFaceCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.solids.size > 0 || selected.sheets.size > 0 || selected.curves.size > 0) {
            const command = new RotateItemCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.vertices.size > 0 || selected.cvs.size > 0) {
            const command = new RotateControlPointCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.empties.size > 0) {
            const command = new RotateEmptyCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        }
    }
}
