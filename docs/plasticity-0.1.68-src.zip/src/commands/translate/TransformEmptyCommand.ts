import { GConstructor } from "../../util/Util";
import { AbstractFreestyleMoveCommand, AbstractFreestyleRotateCommand, AbstractFreestyleScaleCommand } from "./AbstractFreestyleTranformCommand";
import { AbstractMoveCommand, AbstractRotateCommand, AbstractScaleCommand } from "./AbstractTransformCommand";
import { FreestyleMoveEmptyCommand, FreestyleRotateEmptyCommand, FreestyleScaleEmptyCommand } from "./FreestyleTransformEmptyCommand";
import { BasicScaleEmptyFactory, MoveEmptyFactory, RotateEmptyFactory } from "./TransformEmptyFactory";


export class MoveEmptyCommand extends AbstractMoveCommand {
    protected makeFactory(): MoveEmptyFactory {
        const { editor } = this;
        const objects = [...editor.selection.selected.empties];
        const move = new MoveEmptyFactory(editor.nodes, editor.materials, editor.signals).resource(this);
        move.items = objects;
        return move;
    }

    protected getFreestyleCommand(): GConstructor<AbstractFreestyleMoveCommand> {
        return FreestyleMoveEmptyCommand;
    }
}


export class ScaleEmptyCommand extends AbstractScaleCommand {
    makeFactory(): BasicScaleEmptyFactory {
        const { editor } = this;
        const objects = [...editor.selection.selected.empties];
        const scale = new BasicScaleEmptyFactory(editor.nodes, editor.materials, editor.signals).resource(this);
        scale.items = objects;
        return scale;
    }

    protected getFreestyleCommand(): GConstructor<AbstractFreestyleScaleCommand> {
        return FreestyleScaleEmptyCommand;
    }
}


export class RotateEmptyCommand extends AbstractRotateCommand {
    makeFactory(): RotateEmptyFactory {
        const { editor } = this;
        const objects = [...editor.selection.selected.empties];
        const scale = new RotateEmptyFactory(editor.nodes, editor.materials, editor.signals).resource(this);
        scale.items = objects;
        return scale;
    }

    protected getFreestyleCommand(): GConstructor<AbstractFreestyleRotateCommand> {
        return FreestyleRotateEmptyCommand;
    }
}
