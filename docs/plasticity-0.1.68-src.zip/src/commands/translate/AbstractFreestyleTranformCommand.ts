import * as THREE from "three";
import Command from "../../command/Command";
import { AxisHelper } from "../../command/MiniGizmos";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { AxisSnap } from "../../editor/snaps/AxisSnap";
import { PlaneSnap } from "../../editor/snaps/PlaneSnap";
import { PickedPointSnap } from "../../editor/snaps/PointSnap";
import { freeze, origin, Y, Z } from "../../util/Constants";
import { GConstructor } from "../../util/Util";
import { PhantomLineFactory } from '../line/LineFactory';
import { AbstractMoveCommand, AbstractRotateCommand, AbstractScaleCommand } from "./AbstractTransformCommand";
import { MoveItemDialog } from "./MoveItemDialog";
import { RotateGizmo } from './RotateGizmo';
import { RotateItemDialog } from "./RotateItemDialog";
import { FreestyleScaleDialog } from "./ScaleDialog";
import { FreestyleScaleFactoryLike, MoveFactoryLike, RotateFactoryLike } from "./TransformMixins";

export abstract class AbstractFreestyleMoveCommand extends Command {
    async execute(): Promise<void> {
        const { editor } = this;

        const move = await this.makeFactory();
        await move.showPhantoms();

        const dialog = new MoveItemDialog(move, editor.signals);

        dialog.execute(async params => {
            await move.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const defaultPosition = move.centroid;

        const line = new PhantomLineFactory(editor.db, editor.materials, editor.signals).resource(this);
        const pointPicker = new PointPicker(editor);
        pointPicker.addSnap(new PickedPointSnap(defaultPosition));
        const { point: p1 } = await pointPicker.execute({ default: { position: defaultPosition, orientation: defaultOrientation } }).resource(this);
        line.p1 = p1;
        const { point: p2 } = await pointPicker.execute(async ({ point: p2 }) => {
            line.p2 = p2;
            move.move.copy(p2.clone().sub(p1));
            await move.update();
            await line.update();
            dialog.render();
        }, { default: { position: origin, orientation: defaultOrientation } }).resource(this);
        move.move.copy(p2.clone().sub(p1));
        line.cancel();
        dialog.finish();

        await move.commit();
        const selection = move.selection;
        this.editor.selection.selected.add(selection);
        if (selection.length > 0) {
            const command = new (this.getNextCommand())(editor);
            command.agent = 'automatic';
            this.editor.enqueue(command);
        }
    }

    protected abstract makeFactory(): Promise<MoveFactoryLike>;
    protected abstract getNextCommand(): GConstructor<AbstractMoveCommand>;
}

export abstract class AbstractFreestyleScaleCommand extends Command {
    async execute(): Promise<void> {
        const { editor } = this;

        const scale = await this.makeFactory();
        await scale.showPhantoms();

        const dialog = new FreestyleScaleDialog(scale, editor.signals);
        dialog.execute(async params => {
            await scale.update();
            dialog.render();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const referenceLine = new PhantomLineFactory(editor.db, editor.materials, editor.signals).resource(this);
        const pointPicker = new PointPicker(editor);
        pointPicker.addSnap(new PickedPointSnap(scale.centroid));
        const { point: p1 } = await pointPicker.execute().resource(this);
        referenceLine.p1 = p1;
        scale.pivot.copy(p1);

        const { point: p2 } = await pointPicker.execute(({ point: p2 }) => {
            referenceLine.p2 = p2;
            referenceLine.update();
        }).resource(this);
        scale.from(p1, p2);
        pointPicker.addSnap(new PickedPointSnap(p1));

        pointPicker.restrictToLine(p1, scale.ref, false);
        await pointPicker.execute(({ point: p3 }) => {
            scale.to(p1, p3);
            scale.update();
            dialog.render();
        }).resource(this);

        referenceLine.cancel();

        await this.finished;

        const selection = await scale.commit();
        this.editor.selection.selected.add(selection);
    }

    protected abstract makeFactory(): Promise<FreestyleScaleFactoryLike>;
    protected abstract getNextCommand(): GConstructor<AbstractScaleCommand>;
}

export abstract class AbstractFreestyleRotateCommand extends Command {
    async execute(): Promise<void> {
        const { editor } = this;

        const rotate = await this.makeFactory();
        await rotate.showPhantoms();

        const gizmo = new RotateGizmo(rotate, editor);
        const dialog = new RotateItemDialog(rotate, editor.signals);

        dialog.execute(async (params) => {
            await rotate.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        let pointPicker = new PointPicker(editor);
        pointPicker.addSnap(new PickedPointSnap(rotate.centroid));
        const { point: p1 } = await pointPicker.execute().resource(this);
        rotate.pivot.copy(p1);

        const axis = new THREE.Vector3();
        const constructionPlane = this.editor.activeViewport?.constructionPlane;
        const isOrthoMode = this.editor.activeViewport?.isOrthoMode ?? false;
        const axisLine = new PhantomLineFactory(editor.db, editor.materials, editor.signals).resource(this);
        if (constructionPlane !== undefined && isOrthoMode) {
            axis.copy(constructionPlane.n);
        } else {
            const axisLine = new PhantomLineFactory(editor.db, editor.materials, editor.signals).resource(this);
            axisLine.p1 = p1;
            pointPicker.straightSnaps.delete(AxisSnap.Z);

            const { point: p2 } = await pointPicker.execute(({ point: p2 }) => {
                axisLine.p2 = p2;
                axisLine.update();
            }).resource(this);
            axis.copy(p2).sub(p1).normalize();
        }

        const axisHelper = new AxisHelper(this.editor.gizmos.default.line, true).resource(this);
        axisHelper.position.copy(p1);
        axisHelper.quaternion.setFromUnitVectors(Y, axis);
        this.editor.helpers.add(axisHelper);

        const referenceLine = new PhantomLineFactory(editor.db, editor.materials, editor.signals).resource(this);
        referenceLine.p1 = p1;
        const { point: p3 } = await pointPicker.execute(({ point: p3 }) => {
            referenceLine.p2 = p3;
            referenceLine.update();
        }).resource(this);
        referenceLine.cancel();
        const reference = p3.clone().sub(p1).normalize();

        const angleLine = new PhantomLineFactory(editor.db, editor.materials, editor.signals).resource(this);
        angleLine.p1 = p1;

        pointPicker = new PointPicker(this.editor);
        pointPicker.addAxesAt(p1);
        pointPicker.restrictToPlane(new PlaneSnap(axis, p1));
        pointPicker.addSnap(new AxisSnap("180", reference, p1));
        pointPicker.addSnap(new AxisSnap("90", reference.clone().cross(axis).normalize(), p1));

        const transformation = new THREE.Vector3();
        const quat = new THREE.Quaternion().setFromUnitVectors(axis, Z);
        const referenceOnZ = reference.applyQuaternion(quat).normalize();
        await pointPicker.execute(async ({ point: p3 }) => {
            angleLine.p2 = p3;
            await angleLine.update();
            transformation.copy(p3).sub(p1).applyQuaternion(quat);

            const angle = Math.atan2(transformation.y, transformation.x) - Math.atan2(referenceOnZ.y, referenceOnZ.x);
            rotate.quaternion.setFromAxisAngle(axis, angle);
            rotate.update();
            dialog.render();
            gizmo.render(rotate);
        }).resource(this);

        angleLine.cancel();
        axisLine.cancel();
        dialog.finish();

        const selection = await rotate.commit();
        this.editor.selection.selected.add(selection);

        if (selection.length > 0) {
            const command = new (this.getNextCommand())(editor);
            command.agent = 'automatic';
            this.editor.enqueue(command);
        }
    }

    protected abstract makeFactory(): Promise<RotateFactoryLike>;
    protected abstract getNextCommand(): GConstructor<AbstractRotateCommand>;
}

const defaultOrientation = new THREE.Quaternion();
freeze(defaultOrientation);
