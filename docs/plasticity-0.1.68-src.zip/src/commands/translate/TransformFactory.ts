import * as THREE from "three";
import { AbstractFactory } from "../../command/AbstractFactory";
import { GeometryFactory } from "../../command/GeometryFactory";
import { Selectable } from "../../selection/SelectionDatabase";
import { AGConstructor } from "../../util/Util";

export interface TransformFactoryLike {
    get last(): THREE.Matrix4;
    push(): void;
    _matrix: THREE.Matrix4;
}

export function TransformFactory<T extends AGConstructor<AbstractFactory<any>> | AGConstructor<GeometryFactory<any, any, any>>>(base: T) {
    abstract class Transform extends base {
        private readonly transforms: THREE.Matrix4[] = [new THREE.Matrix4()];

        push() {
            this.transforms.push(new THREE.Matrix4());
        }

        undo() {
            this.transforms.pop();
            if (this.transforms.length === 0) this.push();
        }

        get last() {
            return this.transforms[this.transforms.length - 1];
        }

        readonly _matrix = new THREE.Matrix4();
        get matrix(): THREE.Matrix4 {
            const { _matrix } = this;
            this.prepare();
            _matrix.identity();
            for (const transform of this.transforms) {
                _matrix.premultiply(transform);
            }
            return _matrix;
        }

        abstract get centroid(): THREE.Vector3;
        abstract get selection(): Selectable[];
        protected prepare() { };
    }
    return Transform;
}
