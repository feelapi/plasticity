import * as THREE from "three";
import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import { TemporaryObject } from "../../editor/DatabaseLike";
import { MutableComputeTemporaryInput } from "../../editor/db/transforms/ComputeTemporary";
import * as c3d from '../../kernel/kernel';
import { identityMatrix } from "../../util/Constants";
import { mat2mat, point2point } from "../../util/Conversion";
import * as visual from '../../visual_model/VisualModel';
import { TransformFactory } from "./TransformFactory";
import { BasicScale, FreestyleScale, FreestyleScaleFactoryLike, MoveFactory, MoveFactoryLike, RotateFactory, RotateFactoryLike, ScaleParams } from "./TransformMixins";

class ItemFactory extends GeometryFactory<c3d.Body, visual.Item, []> { }

export abstract class TransformItemFactory extends TransformFactory(ItemFactory) {
    protected _items!: { views: visual.Item[]; models: c3d.Body[]; };
    @derive([visual.Item]) get items(): visual.Item[] { throw ''; }
    set items(items: visual.Item[] | c3d.Body[]) { }

    // NOTE: the centroid is often used as a pivot for a transformation, so it is important
    // to use the highest precision available -- i.e., do not compute the centroid in viewspace.
    get centroid() {
        const { _items: { models } } = this;
        const arr = new Int32Array(models.map(m => m.Id()));
        return point2point(new c3d.BodyCollection(arr).GetCentroid());
    }

    async doUpdate(abortEarly: () => boolean) {
        const { db, items, matrix } = this;
        const results: Promise<TemporaryObject>[] = [];
        for (const item of items) {
            const temps = db.optimization(item, async () => {
                return transformTemporary(item, matrix);
            });
            const temp = temps.then(t => t[0]);
            results.push(temp);
        }
        return await Promise.all(results);
    }

    async calculate() {
        const { matrix } = this;
        let { _items: { models } } = this;

        if (models.length === 0) throw new NoOpError();
        if (matrix.equals(identityMatrix)) throw new NoOpError();

        const mat = mat2mat(matrix);

        const result = [];
        const transform = c3d.Transform.CreateFromMatrix(mat);
        const options = new c3d.TransformOptions();
        for (const model of models) {
            await model.Transform_async(transform, options);
            result.push(model);
        }
        return Promise.all(result);
    }

    protected async doCommit() {
        const result = await super.doCommit();
        this.reset();
        return result;
    }

    private reset() {
        for (const phantom of this._phantoms) {
            phantom.cancel();
        }
    }

    get selection() {
        const { state } = this.state;
        if (state.tag !== 'committed') throw new Error("invalid state");
        return state.result;
    }

    get originalItems() { return this.items }

    private _phantoms: TemporaryObject[] = [];
    async showPhantoms() {
        let { _items: { models } } = this;
        const material = { mesh: mesh_blue, line: this.materials.lineDashed() };

        const txn: MutableComputeTemporaryInput = { added: [], replaced: [] };
        for (const model of models) {
            txn.added.push({ model, material });
        }

        const computePhantomResult = await this.computePhantom.calculate(txn);
        const updatePhantomResult = this.updatePhantom.calculate(computePhantomResult);

        const phantoms = updatePhantomResult.added.map(p => p.temp);
        const finished = await Promise.all(phantoms);
        for (const phantom of finished) {
            phantom.show();
            this._phantoms.push(phantom);
        }
    }
}

export class FreestyleScaleItemFactory extends FreestyleScale(TransformItemFactory) implements FreestyleScaleFactoryLike {
}

export class MoveItemFactory extends MoveFactory(TransformItemFactory) implements MoveFactoryLike {
}

export class RotateItemFactory extends RotateFactory(TransformItemFactory) implements RotateFactoryLike {
}

export class BasicScaleItemFactory extends BasicScale(TransformItemFactory) implements ScaleParams {
}

export function transformTemporary(item: THREE.Object3D, mat: THREE.Matrix4) {
    item.matrixAutoUpdate = false;
    item.matrix.copy(mat);
    item.matrix.decompose(item.position, item.quaternion, item.scale);
    item.updateMatrixWorld(true);

    const temp = { underlying: item, show() { }, hide() { }, cancel() { } };
    return [temp] as TemporaryObject[];
}

const mesh_blue = new THREE.MeshBasicMaterial();
mesh_blue.color.setHex(0xff00ff);
mesh_blue.opacity = 0.01;
mesh_blue.transparent = true;
mesh_blue.fog = false;
mesh_blue.polygonOffset = true;
mesh_blue.polygonOffsetFactor = 0.1;
mesh_blue.polygonOffsetUnits = 1;
