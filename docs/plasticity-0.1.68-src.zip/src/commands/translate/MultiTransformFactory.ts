import * as THREE from "three";
import { Z } from "../../util/Constants";
import { ScaleParams, MoveParams, RotateParams, HasRotationParams } from "./TransformMixins";
import { TransformItemFactory } from "./TransformItemFactory";

export type TransformMode = 'move' | 'rotate' | 'scale';

export class MultiTransformFactory extends HasRotationParams(TransformItemFactory) implements MoveParams, RotateParams, ScaleParams {
    mode: TransformMode = 'move';

    readonly pivot = new THREE.Vector3();

    // MOVE:
    readonly move = new THREE.Vector3();

    // SCALE: 
    readonly scale = new THREE.Vector3(1, 1, 1);
    readonly quaternion = new THREE.Quaternion();

    private readonly m = new THREE.Matrix4();
    protected prepare() {
        const { m, pivot, last } = this;
        m.identity(); last.identity();
        switch (this.mode) {
            case 'move':
                const { move } = this;
                last.makeTranslation(move.x, move.y, move.z);
                break;
            case 'rotate':
                const { quaternion } = this;
                m.makeTranslation(-pivot.x, -pivot.y, -pivot.z);
                last.makeRotationFromQuaternion(quaternion);
                last.multiply(m);
                m.makeTranslation(pivot.x, pivot.y, pivot.z);
                last.premultiply(m);
                break;
            case 'scale':
                const { scale } = this;
                m.makeTranslation(-pivot.x, -pivot.y, -pivot.z);
                last.makeScale(scale.x, scale.y, scale.z);
                last.multiply(m);
                m.makeTranslation(pivot.x, pivot.y, pivot.z);
                last.premultiply(m);
                break;
        }
    }

    override push() {
        super.push();
        this.clearTransform();
    }

    clearTransform() {
        this.move.set(0, 0, 0);
        this.angle = 0;
        this.axis.copy(Z);
        this.scale.set(1, 1, 1);
    }
}
