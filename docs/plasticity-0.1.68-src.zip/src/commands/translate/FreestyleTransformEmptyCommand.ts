import * as THREE from "three";
import { GConstructor } from "../../util/Util";
import { AbstractFreestyleMoveCommand, AbstractFreestyleRotateCommand, AbstractFreestyleScaleCommand } from "./AbstractFreestyleTranformCommand";
import { AbstractMoveCommand, AbstractRotateCommand, AbstractScaleCommand } from "./AbstractTransformCommand";
import { MoveEmptyCommand, RotateEmptyCommand, ScaleEmptyCommand } from "./TransformEmptyCommand";
import { FreestyleScaleFactoryLike, MoveFactoryLike } from "./TransformMixins";
import { FreestyleScaleEmptyFactory, MoveEmptyFactory, RotateEmptyFactory } from "./TransformEmptyFactory";


export class FreestyleMoveEmptyCommand extends AbstractFreestyleMoveCommand {
    protected async makeFactory(): Promise<MoveFactoryLike> {
        const { editor } = this;
        const objects = [...editor.selection.selected.solids, ...editor.selection.selected.curves];

        const bbox = new THREE.Box3();
        for (const object of objects)
            bbox.expandByObject(object);
        const centroid = new THREE.Vector3();
        bbox.getCenter(centroid);

        const move = new MoveEmptyFactory(editor.nodes, editor.materials, editor.signals).resource(this);
        move.pivot.copy(centroid);
        move.items = objects;
        return move;
    }

    protected getNextCommand(): GConstructor<AbstractMoveCommand> {
        return MoveEmptyCommand;
    }
}

export class FreestyleScaleEmptyCommand extends AbstractFreestyleScaleCommand {
    protected async makeFactory(): Promise<FreestyleScaleFactoryLike> {
        const { editor } = this;
        const objects = [...editor.selection.selected.empties];

        const bbox = new THREE.Box3();
        for (const object of objects)
            bbox.expandByObject(object);
        const centroid = new THREE.Vector3();
        bbox.getCenter(centroid);

        const scale = new FreestyleScaleEmptyFactory(editor.nodes, editor.materials, editor.signals).resource(this);
        scale.items = objects;

        return scale;
    }

    protected getNextCommand(): GConstructor<AbstractScaleCommand> {
        return ScaleEmptyCommand;
    }
}

export class FreestyleRotateEmptyCommand extends AbstractFreestyleRotateCommand {
    protected async makeFactory() {
        const { editor } = this;
        const objects = [...editor.selection.selected.solids, ...editor.selection.selected.curves];

        const rotate = new RotateEmptyFactory(editor.nodes, editor.materials, editor.signals).resource(this);
        rotate.items = objects;
        return rotate;
    }

    protected getNextCommand(): GConstructor<AbstractRotateCommand> {
        return RotateEmptyCommand;
    }
}
