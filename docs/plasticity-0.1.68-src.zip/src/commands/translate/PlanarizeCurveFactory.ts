import * as THREE from "three";
import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { Z } from "../../util/Constants";
import { point2point, vec2vec } from "../../util/Conversion";
import { findOrthogonal } from "../../util/Util";
import * as visual from '../../visual_model/VisualModel';
import { BasicScaleItemFactory, FreestyleScaleItemFactory } from "./TransformItemFactory";

/**
 * Scaling a curve to zero is the same as projecting onto a plane. Projecting onto a plane is a special,
 * higher fidelity operation than scaling in the geometry kernel. So it's to be preferred.
 */

export class PlanarizeCurveFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance, []> {
    readonly origin = new THREE.Vector3();
    readonly normal = Z.clone();

    protected _curves!: { views: visual.SpaceInstance[]; models: c3d.Wire[]; };
    @derive([visual.SpaceInstance]) get curves(): visual.SpaceInstance[] { throw ''; }
    set curves(curves: visual.SpaceInstance[] | c3d.Wire[]) { }

    private readonly cross = new THREE.Vector3();
    async calculate() {
        const { origin, normal, _curves: { models: curves } } = this;
        const { cross } = this;
        const result = [];
        findOrthogonal(normal, cross);
        cross.normalize();
        const placement = new c3d.Basis(point2point(origin), vec2vec(normal, 1), vec2vec(cross, 1));
        for (const curve of curves) {
            const projected = curve.Planarize(placement);
            result.push(projected);
        }
        return result;
    }
}

function partition(items: c3d.Body[]): [c3d.Wire[], c3d.Body[]] {
    const curves = items.filter(i => i instanceof c3d.Wire) as c3d.Wire[];
    const nonCurves = items.filter(i => !(i instanceof c3d.Wire)) as c3d.Body[];
    return [curves, nonCurves];
}

export class ProjectingBasicScaleFactory extends BasicScaleItemFactory {
    private project = new PlanarizeCurveFactory(this.db, this.materials, this.signals);
    private basic = new BasicScaleItemFactory(this.db, this.materials, this.signals);

    async calculate() {
        const { scale, quaternion, pivot, _items: { models: items } } = this;
        const { project, basic } = this;

        const [curves, nonCurves] = partition(items);
        project.curves = curves;
        basic.items = nonCurves;

        basic.scale.copy(scale);
        basic.pivot.copy(pivot);
        basic.quaternion.copy(quaternion);

        const flattenX = scale.x === 0, flattenY = scale.y === 0, flattenZ = scale.z === 0;
        if (flattenX || flattenY || flattenZ) {
            project.origin.copy(pivot);
            project.normal.set(flattenX ? 1 : 0, flattenY ? 1 : 0, flattenZ ? 1 : 0).applyQuaternion(quaternion).normalize();
            const promises = [];
            promises.push(project.calculate());
            if (nonCurves.length > 0) {
                promises.push(basic.calculate());
            }
            const [curves, rest] = await Promise.all(promises);
            return [...curves, ...(rest ?? [])];
        } else {
            return super.calculate();
        }
    }
}

export class ProjectingFreestyleScaleFactory extends FreestyleScaleItemFactory {
    private project = new PlanarizeCurveFactory(this.db, this.materials, this.signals);
    private freestyle = new FreestyleScaleItemFactory(this.db, this.materials, this.signals);


    async calculate() {
        const { scale, pivot, _items: { models: items } } = this;
        const { project, freestyle } = this;

        const [curves, nonCurves] = partition(items);
        project.curves = curves;
        freestyle.items = nonCurves;

        if (scale.x === 0) {
            project.origin.copy(pivot);
            project.normal.copy(this.ref);
            const promises = [];
            promises.push(project.calculate());
            if (freestyle.items.length > 0)
                promises.push(freestyle.calculate());
            const [curves, rest] = await Promise.all(promises);
            return [...curves, ...(rest ?? [])];
        } else {
            return super.calculate();
        }
    }
}
