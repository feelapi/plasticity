import { AbstractMoveCommand, AbstractRotateCommand, AbstractScaleCommand } from "./AbstractTransformCommand";
import { FreestyleMoveItemCommand, FreestyleRotateItemCommand, FreestyleScaleItemCommand } from "./FreestyleTransformItemCommand";
import { ProjectingBasicScaleFactory as ProjectingBasicScaleItemFactory } from "./PlanarizeCurveFactory";
import { MoveItemFactory, RotateItemFactory } from './TransformItemFactory';

export class MoveItemCommand extends AbstractMoveCommand {
    protected makeFactory(): MoveItemFactory {
        const { editor, editor: { selection: { selected }, db } } = this;
        const objects = [...selected.solids, ...selected.sheets, ...selected.curves];
        const move = new MoveItemFactory(editor.db, editor.materials, editor.signals).resource(this);
        move.changed.addOnce(() => { db.disable(objects) });
        move.items = objects;
        return move;
    }

    protected getFreestyleCommand() {
        return FreestyleMoveItemCommand;
    }
}

export class ScaleItemCommand extends AbstractScaleCommand {
    makeFactory(): ProjectingBasicScaleItemFactory {
        const { editor, editor: { selection: { selected }, db } } = this;
        const objects = [...selected.solids, ...selected.sheets, ...selected.curves];
        const scale = new ProjectingBasicScaleItemFactory(editor.db, editor.materials, editor.signals).resource(this);
        scale.changed.addOnce(() => { db.disable(objects) });
        scale.items = objects;
        return scale;
    }

    protected getFreestyleCommand() {
        return FreestyleScaleItemCommand;
    }
}


export class RotateItemCommand extends AbstractRotateCommand {
    makeFactory(): RotateItemFactory {
        const { editor, editor: { selection: { selected }, db } } = this;
        const objects = [...selected.solids, ...selected.sheets, ...selected.curves];
        const rotate = new RotateItemFactory(editor.db, editor.materials, editor.signals).resource(this);
        rotate.changed.addOnce(() => { db.disable(objects) });
        rotate.items = objects;
        return rotate;
    }

    protected getFreestyleCommand() {
        return FreestyleRotateItemCommand;
    }
}
