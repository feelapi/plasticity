import { render } from 'preact';
import { EditorSignals } from "../../editor/EditorSignals";
import { AbstractDialog } from "../../command/AbstractDialog";
import { FreestyleScaleParams, ScaleParams } from "./TransformMixins";

export class ScaleDialog extends AbstractDialog<ScaleParams> {
    name = "Scale";

    constructor(protected readonly params: ScaleParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { scale } = this.params;

        render(
            <>
                <ul>
                    <li>
                        <label for="scale">XYZ</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="scale.x" value={scale.x} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber name="scale.y" value={scale.y} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber name="scale.z" value={scale.z} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('scale-dialog', ScaleDialog);

export class FreestyleScaleDialog extends AbstractDialog<FreestyleScaleParams> {
    name = "Freestyle Scale";

    constructor(protected readonly params: FreestyleScaleParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { scale, length, isUniform } = this.params;

        render(
            <>
                <ul>
                    <li>
                        <label for="scale">Ratio</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="scale.x" value={scale.x} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="length">Length</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="length" value={length} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="isUniform">Uniform</label>
                        <div class="fields">
                            <input type="checkbox" hidden id="isUniform" name="isUniform" checked={isUniform} onClick={this.onChange}></input>
                            <label for="isUniform">Scale uniformly</label>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('freestyle-scale-dialog', FreestyleScaleDialog);