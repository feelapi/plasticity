import * as THREE from "three";
import * as cmd from "../command/Command";
import { NoOpError } from "../command/GeometryFactory";
import { PointPicker } from "../command/point-picker/PointPicker";
import { NavigationTargetGenerator } from "../components/viewport/NavigationTargetGenerator";
import { TransactionBuilder } from "../editor/db/DatabaseTransaction";
import { ChangeSelectionModifier } from "../selection/ChangeSelectionExecutor";
import { SelectionAccumulator } from "../selection/SelectionAccumulator";
import { freeze, origin } from "../util/Constants";
import * as visual from '../visual_model/VisualModel';
import { ExportDialog } from './export/ExportDialog';
import { ExportFactory } from './export/ExportFactory';

/**
 * These aren't typical commands, with a set of steps and gizmos to perform a geometrical operation.
 * But these represent actions/state-changes that are meant to be atomic (for the purpose of UNDO).
 */


export class SelectAllCommand extends cmd.CommandLike {
    async execute(): Promise<void> {
        const { scene, changeSelection } = this.editor;
        const items = scene.visibility.visibleItems;
        changeSelection.onBoxSelect(new SelectionAccumulator(items), ChangeSelectionModifier.Replace);
    }
}

export class DeselectAllCommand extends cmd.CommandLike {
    async execute(): Promise<void> {
        this.editor.selection.selected.removeAll();
    }

    shouldAddToHistory(selectionChanged: boolean) {
        return selectionChanged;
    }
}

export class LockSelectedCommand extends cmd.CommandLike {
    async execute(): Promise<void> {
        const { solids, sheets, curves, empties } = this.editor.selection.selected;
        const selectedItems = [...solids, ...sheets, ...curves, ...empties];
        for (const item of selectedItems) await this.editor.db.makeUnselectable(item);
        this.editor.selection.selected.removeAll();
    }
}

export class FocusCommand extends cmd.CommandLike {
    async execute(): Promise<void> {
        const db = this.editor.db;
        const { solids, sheets, curves, regions, empties, parentWithSelectedChildrenIds } = this.editor.selection.selected;
        const selectedItems = new Set([...solids.ids, ...curves.ids, ...regions.ids, ...sheets.ids, ...empties.ids, ...parentWithSelectedChildrenIds]);
        if (db.allHidden.length > 0) {
            await db.unhideAll();
        } else {
            const txn = new TransactionBuilder(this.editor.db);
            for (const { view } of db.findAll()) {
                if (!selectedItems.has(view.simpleName)) txn.hide(view);
            }
            await db.commit(txn);
        }
    }
}

export class HideSelectedCommand extends cmd.CommandLike {
    async execute(): Promise<void> {
        const { solids, sheets, curves, empties, regions } = this.editor.selection.selected;
        const selectedItems = [...solids, ...sheets, ...curves, ...empties];

        for (const region of regions) {
            const island = region.parentItem;
            const sketchId = this.editor.sketches.getSketchId(island);
            const curves = this.editor.curves.getCurvesOnSketch(sketchId);
            for (const curve of curves)
                selectedItems.push(curve);
        }

        const txn = new TransactionBuilder(this.editor.db);
        for (const item of selectedItems) txn.hide(item);
        await this.editor.db.commit(txn);
    }
}

export class HideUnselectedCommand extends cmd.CommandLike {
    async execute(): Promise<void> {
        const db = this.editor.db;
        const { solids, sheets, curves, regions, empties, parentWithSelectedChildrenIds } = this.editor.selection.selected;
        const selectedItems = new Set([...solids.ids, ...curves.ids, ...regions.ids, ...sheets.ids, ...empties.ids, ...parentWithSelectedChildrenIds]);
        const txn = new TransactionBuilder(this.editor.db);
        for (const { view } of db.findAll()) {
            if (!selectedItems.has(view.simpleName)) txn.hide(view);
        }
        await this.editor.db.commit(txn);
    }
}

export class InvertHiddenCommand extends cmd.CommandLike {
    async execute(): Promise<void> {
        const { db } = this.editor;
        const txn = new TransactionBuilder(db);
        for (const { view } of db.findAll()) {
            if (db.isHidden(view)) txn.unhide(view);
            else txn.hide(view);
        }
        await this.editor.db.commit(txn);
    }
}

export class UnhideAllCommand extends cmd.CommandLike {
    async execute(): Promise<void> {
        await this.editor.db.unhideAll();
    }
}

export class ExportCommand extends cmd.CommandLike {
    filePath!: string;

    async execute(): Promise<void> {
        const { editor: { factoryCache, db, materials, signals, scene, selection: { selected } } } = this;
        const factory = new ExportFactory(db, materials, signals).resource(this);
        const shells = selected.shells;
        if (shells.size > 0) {
            factory.shells = [...shells];
        } else {
            factory.shells = scene.visibleObjects.filter(o => o instanceof visual.Shell) as visual.Shell[];
        }
        factory.filePath = this.filePath;
        factory.fromJSON(factoryCache.get(ExportFactory));

        const dialog = new ExportDialog(factory, signals);
        await factory.update();
        await dialog.execute(params => {
            factory.update();
            factoryCache.set(ExportFactory, factory.toJSON());
        }).resource(this).then(() => this.finish(), () => this.cancel());

        await factory.commit();
    }

    shouldAddToHistory(_: boolean) { return false }
}

export class ImportCommand extends cmd.CommandLike {
    filePaths!: string[];

    async execute(): Promise<void> {
        await this.editor.importer.import(this.filePaths, this.editor.activeViewport?.constructionPlane);
    }
}

// TODO: bulk these in transactions:

export class GroupSelectedCommand extends cmd.CommandLike {
    async execute(): Promise<void> {
        const { solids, sheets, curves, empties } = this.editor.selection.selected;
        const selectedItems = [...solids, ...sheets, ...curves, ...empties];
        const group = await this.editor.db.createGroup();
        const txn = this.editor.db.makeTransaction();
        for (const item of selectedItems) txn.move(item, group);
        await this.editor.db.commit(txn);
    }
}

export class UngroupSelectedCommand extends cmd.CommandLike {
    async execute(): Promise<void> {
        const { solids, sheets, curves, empties } = this.editor.selection.selected;
        const selectedItems = [...solids, ...sheets, ...curves, ...empties];
        for (const item of selectedItems) await this.editor.db.moveToGroup(item, this.editor.scene.root);
    }
}

export class CreateViewspaceConstructionPlaneAtOrigin extends cmd.CommandLike {
    async execute(): Promise<void> {
        const { db, planes, snaps, nodes, activeViewport } = this.editor;
        if (activeViewport === undefined) throw new NoOpError();

        const generator = new NavigationTargetGenerator(db, planes, snaps, nodes);
        const { cplane } = generator.navigationTargetForCamera(activeViewport.camera, origin);
        activeViewport.constructionPlane = cplane;
    }
}

export class CreateViewspaceConstructionPlane extends cmd.CommandLike {
    async execute(): Promise<void> {
        const { db, planes, snaps, nodes, activeViewport } = this.editor;
        if (activeViewport === undefined) throw new NoOpError();

        const pointPicker = new PointPicker(this.editor);
        const { point } = await pointPicker.execute({ default: { position: origin, orientation: defaultOrientation } }).resource(this);
        const generator = new NavigationTargetGenerator(db, planes, snaps, nodes);
        const { cplane } = generator.navigationTargetForCamera(activeViewport.camera, point);
        activeViewport.constructionPlane = cplane;
    }
}

const defaultOrientation = new THREE.Quaternion();
freeze(defaultOrientation);
