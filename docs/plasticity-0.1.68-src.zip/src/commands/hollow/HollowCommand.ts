import Command from "../../command/Command";
import { ValidationError } from "../../command/GeometryFactory";
import { Y } from "../../util/Constants";
import * as visual from '../../visual_model/VisualModel';
import { FilletMagnitudeGizmo } from '../fillet/FilletGizmo';
import { OffsetFaceGizmo } from "../offset-face/OffsetFaceGizmo";
import { HollowSolidDialog } from "./HollowSolidDialog";
import { HollowSolidFactory } from "./HollowSolidFactory";


export class HollowCommand extends Command {
    async execute(): Promise<void> {
        const selected = this.editor.selection.selected;
        if (selected.solids.size > 0 || selected.faces.size > 0) {
            const command = new HollowSolidCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        }
    }
}

export class HollowSolidCommand extends Command {
    async execute(): Promise<void> {
        const hollow = new HollowSolidFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        let face;
        if (this.editor.selection.selected.faces.size > 0) {
            const faces = [...this.editor.selection.selected.faces];
            face = faces[0];
            const shell = face.parentItem;
            if (!(shell instanceof visual.Solid)) throw new ValidationError("Solid must be selected");
            hollow.solid = shell;
            hollow.faces = faces;
        } else {
            const solid = this.editor.selection.selected.solids.first;
            hollow.solid = solid;
            face = solid.faces.get(0);
        }

        const gizmo = new FilletMagnitudeGizmo("hollow-solid:thickness", this.editor);
        const dialog = new HollowSolidDialog(hollow, this.editor.signals);

        dialog.execute(async params => {
            gizmo.render(params.thickness);
            await hollow.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        const { point, normal } = OffsetFaceGizmo.placement(this.editor.db.lookupTopologyItem(face));
        gizmo.quaternion.setFromUnitVectors(Y, normal);
        gizmo.position.copy(point);

        gizmo.execute(thickness => {
            hollow.thickness = thickness;
            dialog.render();
            hollow.update();
        }).resource(this);

        await this.finished;

        await hollow.commit();
    }
}
