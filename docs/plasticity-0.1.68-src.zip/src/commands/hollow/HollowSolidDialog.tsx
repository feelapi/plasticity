import { render } from 'preact';
import { EditorSignals } from "../../editor/EditorSignals";
import { AbstractDialog } from "../../command/AbstractDialog";
import { HollowSolidParams } from "./HollowSolidFactory";

export class HollowSolidDialog extends AbstractDialog<HollowSolidParams> {
    name = "Hollow solid";

    constructor(protected readonly params: HollowSolidParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        let { thickness, local } = this.params;

        render(
            <>
                <ul>
                    <li>
                        <label>Thickness</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="thickness" value={thickness} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="local">
                            Local
                            <plasticity-tooltip>When "local" is true, ONLY hollow out the selected face -- not the whole body</plasticity-tooltip>
                        </label>
                        <div class="fields">
                            <input type="checkbox" hidden id="local" name="local" checked={local} onClick={this.onChange}></input>
                            <label for="local">Local</label>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('plasticity-thin-solid-dialog', HollowSolidDialog);
