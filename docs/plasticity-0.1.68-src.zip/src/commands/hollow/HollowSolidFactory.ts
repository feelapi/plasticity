import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { unit } from '../../util/Conversion';
import * as visual from '../../visual_model/VisualModel';

export interface HollowSolidParams {
    thickness: number;
    local: boolean;
    grow: c3d.FaceGrowType;
}

export class HollowSolidFactory extends GeometryFactory implements HollowSolidParams {
    protected _solid!: { view: visual.Solid, model: c3d.Solid };
    @derive(visual.Solid) get solid(): visual.Solid { throw '' }
    set solid(solid: visual.Solid | c3d.Solid) { }

    protected _faces!: { views: visual.Face[]; models: c3d.Face[]; };
    @derive([visual.Face]) get faces(): visual.Face[] { throw ''; }
    set faces(faces: visual.Face[] | c3d.Face[]) { }

    thickness = 0;
    local = false;
    grow = c3d.FaceGrowType.Moving;

    async calculate() {
        const { _solid: { model: solid }, _faces: { models: faces }, thickness, local } = this;
        const options = new c3d.HollowOptions();
        options.Local = local;
        await solid.Hollow_async(faces, unit(thickness), options);
        return solid;
    }

    get originalItem() { return this.solid }
}
