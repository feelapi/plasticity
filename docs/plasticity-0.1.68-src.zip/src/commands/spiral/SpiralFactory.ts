import * as THREE from "three";
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { point2point, vec2vec } from "../../util/Conversion";

export interface SpiralParams {
    p1: THREE.Vector3;
    p2: THREE.Vector3;
    p3: THREE.Vector3;
    radius: number;
    turns: number;
    angle: number;
    spiralPitch: number;
    degrees: number;
    handedness: boolean;
    length: number;
}
export class SpiralFactory extends GeometryFactory implements SpiralParams {
    radius!: number;
    turns = 4;
    spiralPitch = 0;
    handedness = true;

    p1!: THREE.Vector3;
    p3!: THREE.Vector3;
    _p2!: THREE.Vector3;
    get p2() { return this._p2; }
    set p2(p2: THREE.Vector3) {
        this._p2 = p2;
        this.length = p2.distanceTo(this.p1);
    }

    private _length!: number;
    set length(length: number) { this._length = length }
    get length() { return this._length }

    get angle() {
        const { radius, length, turns, spiralPitch } = this;
        const helicalPitch = length / turns;
        return Math.atan(helicalPitch * spiralPitch / radius);
    }
    set angle(angle: number) {
        const { radius, length, turns } = this;
        const helicalPitch = length / turns;
        this.spiralPitch = angle == 0 ? 0 : radius / Math.tan(Math.PI / 2 - angle) / helicalPitch;
    }

    get degrees() { return THREE.MathUtils.radToDeg(this.angle) }
    set degrees(degrees: number) {
        this.angle = THREE.MathUtils.degToRad(degrees);
    }

    get placement() {
        const { p1, p2, p3 } = this;
        const axis = p2.clone().sub(p1).normalize();
        const ref = p3.clone().sub(p2).cross(axis).normalize();
        const basis = new c3d.Basis(point2point(p1), vec2vec(axis, 1), vec2vec(ref, 1));
        return basis;
    }

    async calculate() {
        const { placement, length, radius, turns, spiralPitch, handedness } = this;
        return c3d.Wire.CreateHelix(placement, radius, length, turns, spiralPitch, handedness);
    }
}
