import * as THREE from "three";
import { Mode } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { AngleGizmo } from "../../command/MiniGizmos";
import { CancellablePromise } from "../../util/CancellablePromise";
import { X, Y } from "../../util/Constants";
import { ExtrudeDistanceGizmo } from "../extrude/ExtrudeGizmo";
import { FilletMagnitudeGizmo } from "../fillet/FilletGizmo";
import { SpiralParams } from "./SpiralFactory";

export class SpiralGizmo extends CompositeGizmo<SpiralParams> {
    private readonly angleGizmo = new SpiralAngleGizmo("spiral:angle", this.editor);
    private readonly lengthGizmo = new ExtrudeDistanceGizmo("spiral:length", this.editor);
    private readonly radiusGizmo = new FilletMagnitudeGizmo("spiral:radius", this.editor);

    protected prepare(mode: Mode) {
        const { angleGizmo, lengthGizmo, radiusGizmo, params } = this;
        const { p2, p1, radius } = params;

        const axis = new THREE.Vector3().copy(p2).sub(p1);

        lengthGizmo.position.copy(p1);
        const quat = new THREE.Quaternion();
        lengthGizmo.value = p2.distanceTo(p1);
        axis.normalize();
        quat.setFromUnitVectors(Y, axis);
        lengthGizmo.quaternion.copy(quat);
        lengthGizmo.relativeScale.setScalar(0.8);

        radiusGizmo.position.copy(p1);
        quat.setFromUnitVectors(X, axis);
        radiusGizmo.quaternion.copy(quat);
        radiusGizmo.relativeScale.setScalar(0.8);
        radiusGizmo.value = radius;

        lengthGizmo.tip.add(angleGizmo);
        angleGizmo.relativeScale.setScalar(0.3);

        this.add(lengthGizmo, radiusGizmo);
    }

    execute(cb: (params: SpiralParams) => void): CancellablePromise<void> {
        const { angleGizmo, lengthGizmo, radiusGizmo, params } = this;

        this.addGizmo(angleGizmo, angle => {
            params.angle = angle;
            cb(params);
        });
        this.addGizmo(lengthGizmo, length => {
            params.length = length;
            cb(params);
        });
        this.addGizmo(radiusGizmo, radius => {
            params.radius = radius;
            cb(params);
        });

        return super.execute(cb, Mode.Persistent);
    }

    get shouldRescaleOnZoom() { return false }
}

class SpiralAngleGizmo extends AngleGizmo {
    onInterrupt(cb: (radius: number) => void) {
        this.state.push();
    }
}