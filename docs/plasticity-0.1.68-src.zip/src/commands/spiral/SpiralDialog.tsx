import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import { SpiralParams } from './SpiralFactory';

export class SpiralDialog extends AbstractDialog<SpiralParams> {
    name = "Spiral";

    constructor(protected readonly params: SpiralParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { turns, radius, degrees, spiralPitch, handedness } = this.params;

        render(
            <>
                <ul>
                    <li>
                        <label for="turns">Turns</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="turns" value={turns} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="step">Radius</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="radius" value={radius} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="degrees">Angle OR Pitch</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="degrees" value={degrees} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber name="spiralPitch" value={spiralPitch} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="handedness">Handedness</label>
                        <div class="fields">
                            <input type="checkbox" hidden id="handedness" name="handedness" checked={handedness} onClick={this.onChange}></input>
                            <label for="handedness">Left/right</label>
                        </div>
                    </li>
                </ul></>, this);
    }
}
customElements.define('plasticity-spiral-dialog', SpiralDialog);
