import { CommandKeyboardInput, EditorLike } from "../../command/CommandKeyboardInput";

export class OffsetEdgeKeyboardGizmo  extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('offset-edge', editor, [
            'gizmo:offset-edge:toggle',
        ]);
    }
}

export class OffsetFaceKeyboardGizmo  extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('offset-edge', editor, [
            'gizmo:offset-edge:toggle',
            'gizmo:offset-edge:individual',
        ]);
    }
}

export class OffsetRegionKeyboardGizmo  extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super('offset-edge', editor, [
            'gizmo:offset-edge:toggle',
            'gizmo:offset-edge:individual',
        ]);
    }
}
