import { derive } from "../../command/FactoryBuilder";
import { ValidationError } from '../../command/GeometryFactory';
import { MultiGeometryFactory, MultiplyableFactory } from "../../command/MultiFactory";
import { ConstructionPlaneSnap, FaceConstructionPlaneSnap } from "../../editor/snaps/ConstructionPlaneSnap";
import { PlaneSnap } from "../../editor/snaps/PlaneSnap";
import * as c3d from '../../kernel/kernel';
import { point2point, vec2vec } from "../../util/Conversion";
import { computeBoxCentroid } from "../../util/Util";
import * as visual from '../../visual_model/VisualModel';
import { faces2boundaryProfiles, faces2individualProfiles } from "../evolution/AbstractSweepFactory";
import { AbstractOffsetEdgeFactory, gapFillTypes, OffsetEdgeParams } from "./OffsetEdgeFactory";
import * as THREE from 'three';

export interface OffsetPlanarCurveParams extends OffsetEdgeParams {
    orientation: { point: THREE.Vector3; normal: THREE.Vector3; }
}

export class OffsetPlanarCurveFactory extends AbstractOffsetEdgeFactory<c3d.Wire, visual.SpaceInstance, []> implements OffsetPlanarCurveParams, MultiplyableFactory<c3d.Wire, visual.SpaceInstance, []> {
    constructionPlane?: PlaneSnap;
    isOrthoMode = false;

    private placement!: c3d.Basis;
    protected _curve!: { view: visual.SpaceInstance; model: c3d.Wire; };
    get curve(): visual.SpaceInstance { return this._curve.view; }
    set curve(view: visual.SpaceInstance) {
        const model = this.db.lookup(view)!;
        this._curve = { view, model };
        let basis = model.FindPlanarBasis();
        let axis = model.FindLinearAxis();
        if (basis === undefined && axis !== undefined) {
            const geos = model.GetConstructionGeometry();
            const geo = geos[0] as c3d.Geometry | undefined;
            if (geo instanceof c3d.Plane) basis = geo.GetInfo();
        }
        if (basis === undefined && this.constructionPlane !== undefined) {
            basis = this.constructionPlane.placement;
            const planarized = model.Planarize(basis);
            this._curve.model = planarized;
        }
        if (basis === undefined) {
            throw new ValidationError('No basis found');
        }
        this.placement = basis;
    }

    get orientation() {
        const { _curve: { model: curve } } = this;
        const z = vec2vec(this.placement.Axis, 1);
        const edge = curve.GetEdges().Get(0);
        const exact = edge.GetPoint(0.5);
        const { tangent } = edge.EvalBasis(0.5);
        const tan = vec2vec(tangent, 1);
        const normal = tan.cross(z);
        return { point: point2point(exact), normal };
    }

    async calculate() {
        const { _curve: { model: curve }, distance, gapFill, placement } = this;
        const normal = placement.Axis;
        const options = new c3d.OffsetPlanarWireOptions();
        options.GapFill = gapFill;
        const result = await curve.OffsetPlanar_async(distance, normal, options);
        return result;
    }

    get originalItems() { return [] }
    calculatePhantoms() { return super.calculatePhantoms() }
}

export class OffsetRegionFactory extends AbstractOffsetEdgeFactory<c3d.Wire, visual.SpaceInstance, []> implements OffsetPlanarCurveParams {
    isIndividual = true;

    protected _sketch!: { view: visual.SketchIsland; model: c3d.RegionBody; };
    @derive(visual.SketchIsland) get sketch(): visual.SketchIsland { throw ''; }
    set sketch(sketch: visual.SketchIsland | c3d.RegionBody) { }

    protected _regions: { views: visual.Region[]; models: c3d.Face[]; } = { views: [], models: [] };
    get regions() { return this._regions.views }
    set regions(regions: visual.Region[]) {
        if (regions.length === 0)
            return;

        const models = regions.map(r => this.db.lookupTopologyItem(r));
        this._regions = { views: regions, models }

        const box = new THREE.Box3();
        const centroid = computeBoxCentroid(regions.map(r => r.getBoundingBox(box)));
        this._center = centroid;
    }

    protected _center!: THREE.Vector3;
    private get center() { return this._center }

    get orientation() {
        const { _sketch: { model: sketch }, center } = this;
        const normal = vec2vec(sketch.GetBasis().Ref, 1);
        return { point: center, normal };
    }

    async calculate(partition = this.partition) {
        const { _sketch: { model: sketch }, _regions: { models: regions }, distance, gapFill, isIndividual } = this;
        const basis = sketch.GetBasis();
        const normal = basis.Axis;
        const normalInverse = new c3d.Vector(-normal.x, -normal.y, -normal.z);
        const profiles = isIndividual ? await faces2individualProfiles(partition, regions) : await faces2boundaryProfiles(partition, regions);

        const createOptions = new c3d.WireBodyCreateFromEdgesOptions();
        const offsetOptions = new c3d.OffsetPlanarWireOptions();
        offsetOptions.GapFill = gapFill;

        const results: c3d.Wire[] = [];
        for (const profile of profiles) {
            const face = profile.GetFaces().Get(0);
            const insidePoint = face.GetAnyPointOn().position;
            const { wires } = await c3d.Wire.CreateFromEdges_async(profile.GetEdges().GetEdges(), createOptions);
            for (const wire of wires) {
                const ref = wire.GetEdges().Get(0);
                const { tangent } = ref.EvalBasis(0.5);
                const pointOnEdge = ref.GetPoint(0.5);
                pointOnEdge.Sub(insidePoint);
                tangent.Cross(normal)
                const n = tangent.Dot(pointOnEdge) > 0 ? normal : normalInverse;
                const offsets = await wire.OffsetPlanar_async(distance, n, offsetOptions);
                results.push(...offsets);
            }
        }
        return results;
    }
}

export class MultiOffsetPlanarCurveFactory extends MultiGeometryFactory<OffsetPlanarCurveFactory, c3d.Wire, visual.SpaceInstance, []> implements OffsetPlanarCurveParams {
    private _distance = 0;
    get distance() { return this._distance }
    set distance(distance: number) { this._distance = distance; this.updateFactories(); }

    get orientation() { return this.factories[0].orientation }

    private _gapFill = c3d.VertexGapFillType.Round;
    get gapFill() { return this._gapFill }
    set gapFill(gapFill: c3d.VertexGapFillType) { this._gapFill = gapFill; this.updateFactories(); }
    toggle() {
        let index = gapFillTypes.indexOf(this.gapFill);
        index = (index + 1) % gapFillTypes.length;
        this.gapFill = gapFillTypes[index];
    }
    
    private _isOrthoMode = false;
    get isOrthoMode() { return this._isOrthoMode }
    set isOrthoMode(isOrthoMode: boolean) { this._isOrthoMode = isOrthoMode; this.updateFactories(); }

    private _constructionPlane?: ConstructionPlaneSnap | FaceConstructionPlaneSnap | undefined;
    get constructionPlane() { return this._constructionPlane }
    set constructionPlane(constructionPlane: ConstructionPlaneSnap | FaceConstructionPlaneSnap | undefined) { this._constructionPlane = constructionPlane; this.updateFactories(); }

    protected _curves!: { views: visual.SpaceInstance[] };
    get curves(): visual.SpaceInstance[] { return this._curves.views; }
    set curves(curves: visual.SpaceInstance[]) {
        this._curves = { views: curves };
        const factories = [];
        for (const curve of curves) {
            const factory = new OffsetPlanarCurveFactory(this.db, this.materials, this.signals);
            factory.curve = curve;
            factories.push(factory);
        }
        this.factories = factories;
    }

    protected override updateFactories() {
        super.updateFactories();
        for (const factory of this.factories) {
            factory.distance = this.distance;
            factory.gapFill = this.gapFill;
            factory.isOrthoMode = this.isOrthoMode;
            factory.constructionPlane = this.constructionPlane;
        }
    }
}