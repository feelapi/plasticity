import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { EditorSignals } from "../../editor/EditorSignals";
import * as c3d from '../../kernel/kernel';
import { OffsetEdgeParams } from './OffsetEdgeFactory';

export class OffsetEdgeDialog extends AbstractDialog<OffsetEdgeParams> {
    name = "Offset";

    constructor(protected readonly params: OffsetEdgeParams, signals: EditorSignals) {
        super(signals);
    }

    render() {
        const { distance, gapFill } = this.params;

        render(
            <>
                <ul>
                    <li>
                        <label for="distance">Distance</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="distance" value={distance} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    <li>
                        <label for="gapFill">Gap fill</label>
                        <div class="fields">
                            <input type="radio" hidden name="gapFill" id="round" value={c3d.VertexGapFillType.Round} checked={gapFill === c3d.VertexGapFillType.Round} onClick={this.onChange}></input>
                            <label for="round">Round</label>

                            <input type="radio" hidden name="gapFill" id="linear" value={c3d.VertexGapFillType.Linear} checked={gapFill === c3d.VertexGapFillType.Linear} onClick={this.onChange}></input>
                            <label for="linear">Linear</label>

                            <input type="radio" hidden name="gapFill" id="natural" value={c3d.VertexGapFillType.Natural} checked={gapFill === c3d.VertexGapFillType.Natural} onClick={this.onChange}></input>
                            <label for="natural">Natural</label>
                        </div>
                    </li>
                </ul>
            </>, this);
    }
}
customElements.define('offset-edge-dialog', OffsetEdgeDialog);


