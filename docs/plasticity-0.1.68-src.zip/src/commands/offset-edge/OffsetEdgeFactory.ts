import * as THREE from "three";
import { derive } from "../../command/FactoryBuilder";
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import { freeze } from "../../util/Constants";
import { point2point } from "../../util/Conversion";
import * as visual from '../../visual_model/VisualModel';

export interface OffsetEdgeParams {
    distance: number;
    gapFill: c3d.VertexGapFillType;
}

export const gapFillTypes = freeze([c3d.VertexGapFillType.Round, c3d.VertexGapFillType.Linear, c3d.VertexGapFillType.Natural]);

export class AbstractOffsetEdgeFactory<M extends c3d.Body = c3d.Body, V extends visual.Item = visual.Item, A extends undefined | [] = undefined> extends GeometryFactory<M, V, A> implements OffsetEdgeParams {
    distance = 0;
    gapFill = c3d.VertexGapFillType.Round;
    toggle() {
        let index = gapFillTypes.indexOf(this.gapFill);
        index = (index + 1) % gapFillTypes.length;
        this.gapFill = gapFillTypes[index];
    }
}

export class OffsetEdgeFactory extends AbstractOffsetEdgeFactory {
    protected _shell!: { view: visual.Shell; model: c3d.Shell; };
    @derive(visual.Shell) get shell(): visual.Shell { throw ''; }
    set shell(shell: visual.Shell | c3d.Shell) { }

    protected _edges!: { views: visual.CurveEdge[]; models: c3d.Edge[]; };
    @derive([visual.CurveEdge]) get edges(): visual.CurveEdge[] { throw ''; }
    set edges(edges: visual.CurveEdge[] | c3d.Edge[]) { }

    get center() {
        const { _edges: { models: edges } } = this;
        const collection = new c3d.EdgeCollection(new Int32Array(edges.map(e => e.Id())));
        return point2point(collection.GetCentroid());
    }

    async calculate() {
        const { _shell: { model: shell }, _edges: { models: edges }, distance, gapFill } = this;

        const options = new c3d.OffsetEdgeOptions();
        options.GapFill = gapFill;
        await shell.OffsetEdges_async(edges, distance, options);

        return shell;
    }

    get originalItem() { return this.shell }
}

export class OffsetFaceLoopFactory extends AbstractOffsetEdgeFactory {
    isIndividual = true;

    protected _faces!: { views: visual.Face[]; models: c3d.Face[]; };
    @derive([visual.Face]) get faces(): visual.Face[] { throw ''; }
    set faces(faces: visual.Face[] | c3d.Face[]) { }

    protected _shell!: { view: visual.Shell; model: c3d.Shell; };
    @derive(visual.Shell) get shell(): visual.Shell { throw ''; }
    set shell(shell: visual.Shell | c3d.Shell) { }

    get center() {
        const { _faces: { models: faces } } = this;
        const result = new THREE.Vector3();
        for (const face of faces) {
            result.add(point2point(face.GetPoint(0.5, 0.5)));

        }
        return result.divideScalar(faces.length);
    }

    async calculate() {
        const { _shell: { model: shell }, _faces: { models: faces }, distance, gapFill, isIndividual } = this;

        const options = new c3d.OffsetFaceLoopOptions();
        options.IsIndividual = isIndividual;
        options.GapFill = gapFill;
        this._tracking = await shell.OffsetFaceLoops_async(faces, distance, options);

        return shell;
    }

    get originalItem() { return this.shell }

    private _tracking!: c3d.OffsetFaceLoopsTrackRecord;
    get selection() {
        const { state } = this.state;
        if (state.tag !== 'committed') throw new Error("invalid state");
        const shell = state.result;
        const ids = this._tracking.GetNewFaces().GetIds();
        const names = [...ids].map(id => visual.Face.simpleName(shell.simpleName, id));
        return names.map(name => this.db.lookupTopologyItemById(name).view);
    }
}
