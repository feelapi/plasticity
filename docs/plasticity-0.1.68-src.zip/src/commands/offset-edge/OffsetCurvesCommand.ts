import Command from "../../command/Command";
import * as visual from "../../visual_model/VisualModel";
import { OffsetCurveGizmo } from "./OffsetCurveGizmo";
import { OffsetEdgeDialog } from "./OffsetEdgeDialog";
import { OffsetEdgeFactory, OffsetFaceLoopFactory } from "./OffsetEdgeFactory";
import { OffsetEdgeGizmo } from "./OffsetEdgeGizmo";
import { OffsetEdgeKeyboardGizmo, OffsetFaceKeyboardGizmo, OffsetRegionKeyboardGizmo } from "./OffsetEdgeKeyboardGizmo";
import { MultiOffsetPlanarCurveFactory, OffsetPlanarCurveFactory, OffsetRegionFactory } from "./OffsetPlanarCurveFactory";

export class OffsetCurveCommand extends Command {
    point?: THREE.Vector3;

    async execute(): Promise<void> {
        const selected = this.editor.selection.selected;

        let command: Command;
        if (selected.faces.size > 0) {
            command = new OffsetFaceLoopCommand(this.editor);
        } else if (selected.edges.size > 0) {
            command = new OffsetEdgeCommand(this.editor);
        } else if (selected.curves.size > 0) {
            command = new OffsetPlanarCurveCommand(this.editor);
        } else if (selected.regions.size > 0) {
            command = new OffsetRegionCommand(this.editor);
        } else {
            throw new Error("invalid precondition");
        }
        command.agent = this.agent;
        this.editor.exec(command);
    }
}

export class OffsetFaceLoopCommand extends Command {
    async execute(): Promise<void> {
        const faces = this.editor.selection.selected.faces;

        const offset = new OffsetFaceLoopFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        offset.faces = [...faces];
        offset.shell = faces.first.parentItem;

        const dialog = new OffsetEdgeDialog(offset, this.editor.signals);
        const gizmo = new OffsetEdgeGizmo(offset, this.editor);
        const keyboard = new OffsetFaceKeyboardGizmo(this.editor);

        dialog.execute(params => {
            offset.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        keyboard.execute(s => {
            switch (s) {
                case 'toggle':
                    offset.toggle();
                    offset.update();
                    dialog.render();
                case 'individual':
                    offset.isIndividual = !offset.isIndividual;
                    offset.update();
                    dialog.render();
                    break;
            }
        }).resource(this);

        gizmo.position.copy(offset.center);
        gizmo.execute(d => {
            dialog.render();
            offset.update();
        }).resource(this);
        gizmo.start('gizmo:offset-edge:distance');

        await this.finished;

        await offset.commit();

        const newFaces = offset.selection;
        this.editor.selection.selected.add(newFaces);
    }
}

export class OffsetEdgeCommand extends Command {
    async execute(): Promise<void> {
        const edge = this.editor.selection.selected.edges.first;

        const offset = new OffsetEdgeFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        offset.edges = [...this.editor.selection.selected.edges];
        offset.shell = edge.parentItem;

        const dialog = new OffsetEdgeDialog(offset, this.editor.signals);
        const gizmo = new OffsetEdgeGizmo(offset, this.editor);
        const keyboard = new OffsetEdgeKeyboardGizmo(this.editor);

        dialog.execute(params => {
            offset.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        keyboard.execute(s => {
            switch (s) {
                case 'toggle':
                    offset.toggle();
                    offset.update();
                    dialog.render()
            }
        }).resource(this);

        gizmo.position.copy(offset.center);
        gizmo.execute(d => {
            offset.update();
        }).resource(this);
        gizmo.start('gizmo:offset-edge:distance');

        await this.finished;

        await offset.commit() as visual.Item;
    }
}

export class OffsetPlanarCurveCommand extends Command {
    async execute(): Promise<void> {
        const offset = new MultiOffsetPlanarCurveFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        offset.constructionPlane = this.editor.activeViewport?.constructionPlane;
        offset.isOrthoMode = this.editor.activeViewport?.isOrthoMode ?? false;
        offset.curves = [...this.editor.selection.selected.curves];

        const dialog = new OffsetEdgeDialog(offset, this.editor.signals);
        const gizmo = new OffsetCurveGizmo(offset, this.editor);
        const keyboard = new OffsetEdgeKeyboardGizmo(this.editor);

        dialog.execute(params => {
            offset.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        keyboard.execute(s => {
            switch (s) {
                case 'toggle':
                    offset.toggle();
                    offset.update();
                    dialog.render()
            }
        }).resource(this);

        gizmo.execute(d => {
            dialog.render();
            offset.update();
        }).resource(this);
        gizmo.start('gizmo:offset-edge:distance');

        await this.finished;

        const result = await offset.commit();
        this.editor.selection.selected.removeAll();
        this.editor.selection.selected.add(result);
    }
}

export class OffsetRegionCommand extends Command {
    async execute(): Promise<void> {
        const region = this.editor.selection.selected.regions.first;
        const offset = new OffsetRegionFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        offset.sketch = region.parentItem;
        offset.regions = [...this.editor.selection.selected.regions];

        const dialog = new OffsetEdgeDialog(offset, this.editor.signals);
        const gizmo = new OffsetCurveGizmo(offset, this.editor);
        const keyboard = new OffsetRegionKeyboardGizmo(this.editor);

        dialog.execute(params => {
            offset.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        keyboard.execute(s => {
            switch (s) {
                case 'toggle':
                    offset.toggle();
                    offset.update();
                    dialog.render();
                    break;
                case 'individual':
                    offset.isIndividual = !offset.isIndividual;
                    offset.update();
                    dialog.render();
                    break;
            }
        }).resource(this);

        gizmo.execute(d => {
            dialog.render();
            offset.update();
        }).resource(this);
        gizmo.start('gizmo:offset-edge:distance');

        await this.finished;

        const result = await offset.commit();
        this.editor.selection.selected.remove(offset.regions);
        this.editor.selection.selected.add(result);
    }
}