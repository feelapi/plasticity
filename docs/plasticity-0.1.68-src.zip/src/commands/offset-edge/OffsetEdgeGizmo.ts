import { Mode } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { CircularMagnitudeGizmo } from "../../command/MiniGizmos";
import { CancellablePromise } from "../../util/CancellablePromise";
import { OffsetEdgeParams } from "./OffsetEdgeFactory";

export class OffsetEdgeGizmo extends CompositeGizmo<OffsetEdgeParams> {
    private readonly materials = this.editor.gizmos;
    private readonly yellow = this.materials.yellow;
    private readonly distance = new OffsetMagnitudeGizmo('offset-edge:distance', this.editor, this.yellow);

    protected prepare(mode: Mode) {
        const { distance } = this;

        this.add(distance);
    }

    execute(cb: (params: OffsetEdgeParams) => void, mode: Mode = Mode.Persistent): CancellablePromise<void> {
        const { distance: n, params } = this;

        this.addGizmo(n, t => {
            params.distance = t;
        });

        return super.execute(cb, mode);
    }
}

export class OffsetMagnitudeGizmo extends CircularMagnitudeGizmo {
}