import pk from '../../../build/Release/pk.node';
import { delegate } from '../../command/FactoryBuilder';
import { NoOpError } from '../../command/GeometryFactory';
import { MultiplyableFactory } from '../../command/MultiFactory';
import { Database } from '../../editor/db/Database';
import { EditorSignals } from '../../editor/EditorSignals';
import MaterialDatabase from '../../editor/MaterialDatabase';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';
import { ModifyFaceFactory } from '../offset-face/ModifyFaceFactory';
import { MultiModifyFaceFactory } from "../offset-face/MultiModifyFaceFactory";

export interface RefilletFaceParams {
    distance: number;
    faces: visual.Face[];
}

export class RefilletFaceFactory extends ModifyFaceFactory implements RefilletFaceParams, MultiplyableFactory<c3d.Shell, visual.Shell> {
    distance: number = 0;
    mode: 'delta' | 'absolute' = 'delta';

    async areFilletFaces(): Promise<boolean> {
        const { _shell: { model: shell }, _faces: { models: faces } } = this;
        const result = await shell.IdentifyBlends_async(faces, pk.BlendIdentifyType.Within, new c3d.FaceIdentifyBlendsOptions());
        const all = c3d.FaceCollection.Union(result);
        return all.Size() === faces.length;
    }

    copyFaceRadius(face: visual.Face) {
        const model = this.db.lookupTopologyItem(face);
        const radius = model.GetBlendRadius();
        if (radius < 0) throw new Error("invalid precondition");
        this.distance = radius;
    }

    async calculate() {
        const { _shell: { model: shell }, _faces: { models: faces }, distance, mode } = this;

        if (Math.abs(distance) < 10e-6) throw new NoOpError();

        const options = new c3d.FaceChangeOptions(this.grow);
        const operation = new c3d.FaceChangeBlendOperation(distance, mode === 'delta');

        let tracking = await shell.ReblendFaces_async(faces, operation, options);
        this.tracking = tracking;
        return shell;
    }

    get selection() {
        const { state } = this.state;
        if (state.tag !== 'committed') throw new Error("invalid state");
        const shell = state.result;
        const ids = this.tracking.GetChangedFaces().GetIds();
        const names = [...ids].map(id => visual.Face.simpleName(shell.simpleName, id));
        return names.map(name => this.db.lookupTopologyItemById(name).view);
    }

    override get originalItems() { return super.originalItems }
    override calculatePhantoms(partition: c3d.Partition) { return super.calculatePhantoms(partition) }
}

export class MultiRefilletFaceFactory extends MultiModifyFaceFactory<RefilletFaceFactory> implements RefilletFaceParams {
    async areFilletFaces() {
        for (const factory of this.factories) {
            if (!await factory.areFilletFaces()) return false;
        }
        return true;
    }

    @delegate.default(0) distance!: number;
    @delegate.default('delta') mode!: 'delta' | 'absolute';

    copyFaceRadius(face: visual.Face) {
        const model = this.db.lookupTopologyItem(face);
        const radius = model.GetBlendRadius();
        if (radius < 0) throw new Error("invalid precondition");
        this.distance = radius;
    }

    protected makeFactory(db: Database, materials: MaterialDatabase, signals: EditorSignals) {
        return new RefilletFaceFactory(db, materials, signals)
    }
}