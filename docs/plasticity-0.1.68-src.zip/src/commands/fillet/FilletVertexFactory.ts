import * as THREE from 'three';
import { delegate, derive } from "../../command/FactoryBuilder";
import { GeometryFactory, NoOpError } from '../../command/GeometryFactory';
import { groupBy, MultiGeometryFactory, MultiplyableFactory } from "../../command/MultiFactory";
import * as c3d from '../../kernel/kernel';
import { point2point } from "../../util/Conversion";
import * as visual from '../../visual_model/VisualModel';

export interface FilletVertexParams {
    radius: number;
}

export class FilletVertexFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> implements FilletVertexParams, MultiplyableFactory<c3d.Wire, visual.SpaceInstance> {
    radius = 0;

    private _curve!: { view: visual.SpaceInstance, model: c3d.Wire };
    @derive(visual.SpaceInstance) get curve(): visual.SpaceInstance { throw '' }
    set curve(curve: visual.SpaceInstance | c3d.Wire) { }

    private _vertices!: { views: visual.Vertex[]; models: c3d.Vertex[]; };
    @derive([visual.Vertex]) get vertices(): visual.Vertex[] { throw ''; }
    set vertices(vertices: visual.Vertex[] | c3d.Vertex[]) { }

    get centroid() {
        const { _vertices: { models: vertices } } = this;
        const ids = vertices.map(v => v.Id());
        return point2point(new c3d.VertexCollection(ids).GetCentroid());
    }

    async calculate() {
        const { _curve: { model: curve }, _vertices: { models: vertices }, radius } = this;

        if (vertices.length === 0) throw new NoOpError();
        if (Math.abs(radius) < 10e-5) throw new NoOpError();

        await curve.BlendVertices_async(vertices, radius);
        return curve;
    }

    get originalItem() { return this.curve }

    get originalItems() { return super.originalItems }
    calculatePhantoms() { return super.calculatePhantoms() }
}

export class FilletCurveFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> implements FilletVertexParams, MultiplyableFactory<c3d.Wire, visual.SpaceInstance> {
    radius = 0;

    private _curve!: { view: visual.SpaceInstance, model: c3d.Wire };
    @derive(visual.SpaceInstance) get curve(): visual.SpaceInstance { throw '' }
    set curve(curve: visual.SpaceInstance | c3d.Wire) { }

    private get vertices() {
        const { _curve: { model: curve } } = this;
        return curve.GetVertices().GetVertices();
    }

    get centroid() {
        const { vertices } = this;
        const ids = vertices.map(v => v.Id());
        return point2point(new c3d.VertexCollection(ids).GetCentroid());
    }

    async calculate() {
        const { _curve: { model: curve }, vertices, radius } = this;

        if (vertices.length === 0) throw new NoOpError();
        if (Math.abs(radius) < 10e-5) throw new NoOpError();

        await curve.BlendVertices_async(vertices, radius);
        return curve;
    }

    get originalItem() { return this.curve }
    get originalItems() { return super.originalItems }
    calculatePhantoms() { return super.calculatePhantoms() }
}

export class MultiFilletCurveFactory extends MultiGeometryFactory<FilletCurveFactory, c3d.Wire, visual.SpaceInstance> implements FilletVertexParams {
    @delegate.default(0) radius!: number;

    private _curves!: { views: visual.SpaceInstance[] };
    get curves(): visual.SpaceInstance[] { return this._curves.views; }
    set curves(curves: visual.SpaceInstance[]) {
        this._curves = { views: curves };
        const factories = [];
        for (const curve of curves) {
            const factory = new FilletCurveFactory(this.db, this.materials, this.signals);
            factory.curve = curve;
            factories.push(factory);
        }
        this.factories = factories;
    }

    get centroid() {
        const result = new THREE.Vector3();
        for (const factory of this.factories) {
            result.add(factory.centroid);
        }
        return result.divideScalar(this.factories.length);
    }
}

export class MultiFilletVertexFactory extends MultiGeometryFactory<FilletVertexFactory, c3d.Wire, visual.SpaceInstance> {
    @delegate.default(0) radius!: number;

    private _vertices!: { views: visual.Vertex[] };
    get vertices(): visual.Vertex[] { return this._vertices.views; }
    set vertices(vertices: visual.Vertex[]) {
        this._vertices = { views: vertices };

        const factories = [];
        const parent2vertices = groupBy('parentItem', vertices);
        for (const [shell, vertices] of parent2vertices) {
            const factory = new FilletVertexFactory(this.db, this.materials, this.signals);
            factory.curve = shell;
            factory.vertices = vertices;
            factories.push(factory);
        }
        this.factories = factories;
    }

    get centroid() {
        const result = new THREE.Vector3();
        for (const factory of this.factories) {
            result.add(factory.centroid);
        }
        return result.divideScalar(this.factories.length);
    }
}