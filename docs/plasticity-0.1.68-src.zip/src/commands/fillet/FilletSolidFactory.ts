import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory, NoOpError, PhantomInfo } from '../../command/GeometryFactory';
import { groupBy, MultiplyableFactory } from '../../command/MultiFactory';
import * as c3d from '../../kernel/kernel';
import { point2point, trunc, vec2vec } from '../../util/Conversion';
import * as visual from '../../visual_model/VisualModel';

export interface FilletParams {
    edges: visual.CurveEdge[];
    extendedEdges: visual.CurveEdge[];
    distance: number;
    distance1: number;
    distance2: number;
    prolong: boolean;
    shape: c3d.BlendShape;
    get mode(): FilletMode;
}

export enum FilletMode { FilletSolid, ChamferSolid };

type FilletInfo = {
    delta: number;
};

type ChainInfo = {
    variationPoints: Set<c3d.EdgeBlendVariationPoint>;
}

export type FilletFunction = Map<number, FilletInfo>;

type VariableFilletMode = 'constant' | 'variable';
type ChamferMode = 'offset' | 'apex';

export default class FilletSolidFactory extends GeometryFactory<c3d.Shell, visual.Shell> implements FilletParams, MultiplyableFactory<c3d.Shell, visual.Shell>, MultiplyableFactory<c3d.Shell, visual.Shell> {
    private _filletMode: VariableFilletMode = 'constant';
    get filletMode(): VariableFilletMode { return this._filletMode }
    set filletMode(mode: VariableFilletMode) {
        if (this._filletMode === mode) return;
        this._filletMode = mode
        this.addEndpoints();
    }

    private _chamferMode: ChamferMode = 'offset';
    get chamferMode(): ChamferMode { return this._chamferMode }
    set chamferMode(mode: ChamferMode) {
        if (this._chamferMode === mode) return;
        this._chamferMode = mode;
        this.addEndpoints();
    }

    private _shell!: { view: visual.Shell; model: c3d.Shell; };
    @derive(visual.Shell) get shell(): visual.Shell { throw ''; }
    set shell(shell: visual.Shell | c3d.Shell) { }

    protected _edges: { views: visual.CurveEdge[]; models: c3d.Edge[]; collection: c3d.EdgeCollection; } = { views: [], models: [], collection: new c3d.EdgeCollection() };
    get edges() { return this._edges.views }
    set edges(edges: visual.CurveEdge[]) {
        if (edges.length === 0) return;

        const models = edges.map(c => this.db.lookupTopologyItem(c));
        const collection = new c3d.EdgeCollection(new Int32Array(models.map(e => e.Id())));
        this._edges = { views: edges, models, collection };
        this.extendEdges();
    }

    private _prolong = true;
    get prolong() { return this._prolong }
    set prolong(prolong: boolean) {
        if (this._prolong === prolong) return;
        this._prolong = prolong;
        this.extendEdges();
    }

    get distance() { return this.distance1 }
    set distance(d: number) {
        this.distance1 = d;
        this.distance2 = d;
    }

    private _distance1 = 0;
    get distance1() { return this._distance1 }
    set distance1(distance1: number) { this._distance1 = trunc(distance1, 3000) }

    private _distance2 = 0;
    get distance2() { return this._distance2 }
    set distance2(distance2: number) { this._distance2 = trunc(distance2, 3000) }

    shape = c3d.BlendShape.Conic;

    get mode(): FilletMode {
        return this.distance1 < 0 ? FilletMode.ChamferSolid : FilletMode.FilletSolid;
    }

    private readonly chain2info = new Map<c3d.EdgeCollection, ChainInfo>();
    private readonly edge2chain = new Map<c3d.EdgeId, c3d.EdgeCollection>();

    private _extendedEdges!: { views: visual.CurveEdge[]; models: c3d.Edge[]; chains: c3d.EdgeCollection[], firstTs: number[], lastTs: number[] }
    get extendedEdges() { return this._extendedEdges.views }
    private extendEdges() {
        const { _edges: { collection }, prolong } = this;
        const resume = this.pause();
        this.chain2info.clear();
        const extended = prolong ? collection.FindConnectedTangent(tolerance, false) : collection;
        const { chains, firstTs, lastTs } = extended.SortChains();
        for (let i = 0; i < chains.length; i++) {
            const chain = chains[i];
            this.chain2info.set(chain, { variationPoints: new Set<c3d.EdgeBlendVariationPoint>() });
            const edgeIds = chain.GetIds();
            for (const edgeId of edgeIds) {
                this.edge2chain.set(edgeId, chain);
            }
        }

        this._extendedEdges = { models: extended.GetEdges(), views: this.edgeCollection2views(this.shell.simpleName, extended), chains, firstTs, lastTs };
        resume.dispose();
    }

    private endpoints: { point: c3d.EdgeBlendVariationPoint; edge: c3d.Edge; t: number; }[] | undefined;
    addEndpoints(): { point: c3d.EdgeBlendVariationPoint; edge: c3d.Edge; t: number; }[] {
        if (this.endpoints !== undefined) return this.endpoints;

        const { _extendedEdges: { chains, firstTs, lastTs } } = this;
        const result = [];
        for (let i = 0; i < chains.length; i++) {
            const chain = chains[i], firstT = firstTs[i], lastT = lastTs[i];
            const { variationPoints } = this.chain2info.get(chain)!;
            if (chain.Size() === 0) throw new NoOpError();
            if (chain.IsClosed()) continue;
            const firstEdge = chain.Get(0), lastEdge = chain.Get(chain.Size() - 1);
            const startPoint = new c3d.EdgeBlendVariationPoint(firstEdge.GetPoint(firstT), this.distance1, this.distance2);
            const endPoint = new c3d.EdgeBlendVariationPoint(lastEdge.GetPoint(lastT), this.distance1, this.distance2);
            variationPoints.add(startPoint);
            variationPoints.add(endPoint);
            result.push({ point: startPoint, edge: firstEdge, t: firstT }, { point: endPoint, edge: lastEdge, t: lastT });
        }
        return this.endpoints = result;
    }

    private addPseduoEndpoints() {
        if (this.endpoints !== undefined) return this.endpoints;

        const { _extendedEdges: { chains, firstTs, lastTs } } = this;
        const result = [];
        for (let i = 0; i < chains.length; i++) {
            const chain = chains[i]; let firstT = firstTs[i], lastT = lastTs[i];
            const { variationPoints } = this.chain2info.get(chain)!;
            if (chain.Size() === 0) throw new NoOpError();
            const firstEdge = chain.Get(0), lastEdge = chain.Get(chain.Size() - 1);
            if (chain.IsClosed()) {
                const { tmin, tmax } = firstEdge.GetInterval();
                if (chain.Size() === 1) {
                    // ring edge, add two (arbitrary) distinct endpoints.
                    firstT = tmin;
                    lastT = tmin + (tmax - tmin) / 2;
                } else {
                    // loop, last edge ends at first edge start. Pick another startpoint.
                    firstT = tmax;
                }
            }
            const startPoint = new c3d.EdgeBlendVariationPoint(firstEdge.GetPoint(firstT), this.distance1, this.distance2);
            const endPoint = new c3d.EdgeBlendVariationPoint(lastEdge.GetPoint(lastT), this.distance1, this.distance2);
            variationPoints.add(startPoint);
            variationPoints.add(endPoint);
            result.push({ point: startPoint, edge: firstEdge, t: firstT }, { point: endPoint, edge: lastEdge, t: lastT });
        }
        return this.endpoints = result;
    }

    addVariationPoint(to: visual.CurveEdge, position: THREE.Vector3): c3d.EdgeBlendVariationPoint {
        const model = this.db.lookupTopologyItem(to);
        const id = model.Id();
        const chain = this.edge2chain.get(id);
        if (!chain) throw new Error('invalid state');
        const { variationPoints } = this.chain2info.get(chain)!;
        const point = new c3d.EdgeBlendVariationPoint(point2point(position), this.distance1, this.distance2);
        variationPoints.add(point);
        return point;
    }

    readonly limitPoints = new Set<c3d.EdgeBlendLimitPoint>();
    addLimitPoint(edge: visual.CurveEdge, position: THREE.Vector3, direction: THREE.Vector3): c3d.EdgeBlendLimitPoint {
        const model = this.db.lookupTopologyItem(edge);
        const point = new c3d.EdgeBlendLimitPoint(model, point2point(position), vec2vec(direction, 1));
        this.limitPoints.add(point);
        return point;
    }

    copyFaceRadius(face: visual.Face) {
        const model = this.db.lookupTopologyItem(face);
        const radius = model.GetBlendRadius();
        if (radius < 0) throw new Error("invalid precondition");
        this.distance = radius;
    }

    tracking!: c3d.BlendEdgesTrackRecord;
    async calculate(partition: c3d.Partition) {
        const { _shell: { model: shell }, distance1, distance2 } = this;
        if (this.distance1 === 0 || this.distance2 === 0) throw new NoOpError();

        if (this.mode === FilletMode.ChamferSolid) {
            if (this.chamferMode === 'offset') await this.chamferSimple();
            else await this.chamferApex();
        } else {
            switch (this.filletMode) {
                case 'constant': {
                    if (distance1 === distance2) await this.filletSimple();
                    else await this.filletTwoDistance();
                    break;
                }
                case 'variable': {
                    await this.filletVariable();
                    break;
                }
            }
        }
        return shell;
    }

    private async chamferSimple() {
        const { _shell: { model: shell }, distance1, distance2, _extendedEdges: { models: edges }, _edges: { models: preferredEdges }, limitPoints } = this;
        const options = new c3d.ChamferOptions();
        options.LimitPoints = [...limitPoints];
        options.PreferredEdges = preferredEdges;
        const tracking = await shell.ChamferEdges_async(edges, Math.abs(distance1), Math.abs(distance2), options);
        this.tracking = tracking;
    }

    private async chamferApex() {
        const { _shell: { model: shell }, distance1, distance2, _edges: { models: preferredEdges }, limitPoints, chain2info } = this;
        this.addPseduoEndpoints();
        const chains: c3d.EdgeCollection[] = [], optionss: c3d.EdgeBlendOptions[] = [];
        for (const [chain, { variationPoints }] of chain2info) {
            const options = new c3d.EdgeBlendOptions();
            options.Shape = c3d.BlendShape.Chamfer;
            for (const v of variationPoints) {
                v.PrimarySize = Math.abs(distance1);
                v.SecondarySize = Math.abs(distance2);
            }
            options.VariationPoints = [...variationPoints];
            options.LimitPoints = [...limitPoints];
            options.PreferredEdges = preferredEdges;
            optionss.push(options);
            chains.push(chain);
        }
        const tracking = await shell.BlendEdgeChains_async(chains, optionss);
        this.tracking = tracking;
    }

    private async filletSimple() {
        const { _shell: { model: shell }, distance1, shape, _extendedEdges: { models: edges }, _edges: { models: preferredEdges }, limitPoints } = this;
        const options = new c3d.EdgeBlendOptions();
        options.Shape = shape;
        options.LimitPoints = [...limitPoints];
        options.Radius = distance1;
        options.PreferredEdges = preferredEdges;
        const tracking = await shell.BlendEdges_async(edges, options);
        this.tracking = tracking;
    }

    private async filletTwoDistance() {
        const { _shell: { model: shell }, distance1, distance2, _edges: { models: preferredEdges }, limitPoints, chain2info } = this;
        this.addPseduoEndpoints();
        const chains: c3d.EdgeCollection[] = [], optionss: c3d.EdgeBlendOptions[] = [];
        for (const [chain, { variationPoints }] of chain2info) {
            const options = new c3d.EdgeBlendOptions();
            options.Shape = c3d.BlendShape.Conic;
            for (const v of variationPoints) {
                v.PrimarySize = Math.abs(distance1);
                v.SecondarySize = Math.abs(distance2);
            }
            options.VariationPoints = [...variationPoints];
            options.LimitPoints = [...limitPoints];
            options.PreferredEdges = preferredEdges;
            optionss.push(options);
            chains.push(chain);
        }
        const tracking = await shell.BlendEdgeChains_async(chains, optionss);
        this.tracking = tracking;
    }

    private async filletVariable() {
        const { _shell: { model: shell }, distance1, shape, _edges: { models: preferredEdges }, limitPoints, chain2info } = this;
        const chains: c3d.EdgeCollection[] = [], optionss: c3d.EdgeBlendOptions[] = [];
        for (const [chain, { variationPoints }] of chain2info) {
            const options = new c3d.EdgeBlendOptions();
            options.Shape = shape;
            options.VariationPoints = [...variationPoints];
            options.LimitPoints = [...limitPoints];
            options.Radius = distance1;
            options.PreferredEdges = preferredEdges;
            optionss.push(options);
            chains.push(chain);
        }
        const tracking = await shell.BlendEdgeChains_async(chains, optionss);
        this.tracking = tracking;
    }

    get originalItem() { return this.shell }

    private edgeCollection2views(simpleName: visual.SolidId, edges: c3d.EdgeCollection): visual.CurveEdge[] {
        const result = [];
        for (const edgeId of edges.GetIds()) {
            const id = visual.CurveEdge.simpleName(simpleName, edgeId);
            if (this.db.hasTopologyItem(id)) {
                const view = this.db.lookupTopologyItemById(id).view as visual.CurveEdge;
                result.push(view);
            }
        }
        return result;
    }

    get selection(): visual.Face[] {
        const { state } = this.state;
        if (state.tag !== 'committed') throw new Error("invalid state");
        const shell = state.result;
        const ids = this.tracking.GetBlendFaces().GetIds();
        const names = [...ids].map(id => visual.Face.simpleName(shell.simpleName, id));
        return names.map(name => this.db.lookupTopologyItemById(name).view as visual.Face);
    }

    override get originalItems() { return super.originalItems }
    override calculatePhantoms(partition: c3d.Partition) { return super.calculatePhantoms(partition) }
}

export interface FilletSolidFactoryLike extends GeometryFactory<c3d.Shell, visual.Shell, []>, FilletParams {
    addVariationPoint(to: visual.CurveEdge, position: THREE.Vector3): c3d.EdgeBlendVariationPoint;
    addLimitPoint(edge: visual.CurveEdge, position: THREE.Vector3, direction: THREE.Vector3): c3d.EdgeBlendLimitPoint;
    copyFaceRadius(face: visual.Face): void;
    addEndpoints(): { point: c3d.EdgeBlendVariationPoint; edge: c3d.Edge; t: number; }[];
}

export class MultiFilletSolidFactory extends GeometryFactory<c3d.Shell, visual.Shell, []> implements FilletSolidFactoryLike {
    private readonly factories = new Map<visual.Shell, FilletSolidFactory>();

    private _distance1 = 0;
    get distance1() { return this._distance1 }
    set distance1(distance1: number) {
        this._distance1 = trunc(distance1, 3000)
        this.updateFactories();
    }

    private _distance2 = 0;
    get distance2() { return this._distance2 }
    set distance2(distance2: number) {
        this._distance2 = trunc(distance2, 3000)
        this.updateFactories();
    }


    get distance() { return this.distance1 }
    set distance(d: number) {
        this.distance1 = d;
        this.distance2 = d;
        this.updateFactories();
    }

    private _prolong = true;
    get prolong() { return this._prolong }
    set prolong(prolong: boolean) {
        this._prolong = prolong;
        const resume = this.pause();
        this.updateFactories();
        resume.dispose();
    }

    private _shape = c3d.BlendShape.Conic;
    get shape() { return this._shape }
    set shape(shape: c3d.BlendShape) {
        this._shape = shape;
        this.updateFactories();
    }

    protected _edges!: { views: visual.CurveEdge[]; models: c3d.Edge[] };
    get edges() { return this._edges.views }
    set edges(edges: visual.CurveEdge[]) {
        for (const [, factory] of this.factories) {
            factory.cancel();
        }

        if (edges.length === 0) return;

        const parent2edges = groupBy('parentItem', edges);

        for (const [shell, edges] of parent2edges) {
            const factory = new FilletSolidFactory(this.db, this.materials, this.signals);
            factory.shell = shell;
            factory.edges = edges;
            this.factories.set(shell, factory);
        }

        const models = edges.map(e => this.db.lookupTopologyItem(e));
        this._edges = { views: edges, models };

        this.updateFactories();
    }

    private updateFactories() {
        for (const factory of this.factories.values()) {
            factory.distance1 = this.distance1;
            factory.distance2 = this.distance2;
            factory.prolong = this.prolong;
            factory.shape = this.shape;
            factory.filletMode = this.filletMode;
        }
    }

    ///

    addVariationPoint(to: visual.CurveEdge, position: THREE.Vector3): c3d.EdgeBlendVariationPoint {
        const factory = this.factories.get(to.parentItem);
        if (factory === undefined) throw new Error("invalid edge");
        return factory.addVariationPoint(to, position);
    }

    addLimitPoint(edge: visual.CurveEdge, position: THREE.Vector3, direction: THREE.Vector3): c3d.EdgeBlendLimitPoint {
        const factory = this.factories.get(edge.parentItem);
        if (factory === undefined) throw new Error("invalid edge");
        return factory.addLimitPoint(edge, position, direction);
    }

    addEndpoints(): { point: c3d.EdgeBlendVariationPoint; edge: c3d.Edge; t: number; }[] {
        const result: { point: c3d.EdgeBlendVariationPoint; edge: c3d.Edge; t: number; }[] = [];
        for (const factory of this.factories.values()) {
            result.push(...factory.addEndpoints());
        }
        return result;
    }

    ///

    get extendedEdges() {
        const result = [];
        for (const factory of this.factories.values()) {
            result.push(...factory.extendedEdges);
        }
        return result;
    }

    get mode(): FilletMode {
        return this.distance1 < 0 ? FilletMode.ChamferSolid : FilletMode.FilletSolid;
    }

    copyFaceRadius(face: visual.Face) {
        const model = this.db.lookupTopologyItem(face);
        const radius = model.GetBlendRadius();
        if (radius < 0) throw new Error("invalid precondition");
        this.distance = radius;
    }

    private _filletMode: VariableFilletMode = 'constant';
    get filletMode(): VariableFilletMode { return this._filletMode }
    set filletMode(mode: VariableFilletMode) {
        this._filletMode = mode;
        this.updateFactories();
    }

    async calculate(partition: c3d.Partition = this.partition) {
        const { factories } = this;
        const result = [];
        for (const [, factory] of factories) {
            result.push(await factory.calculate(partition));
        }
        return result.flat();
    }

    async calculatePhantoms(partition: c3d.Partition): Promise<PhantomInfo[]> {
        const { factories } = this;
        const result = [];
        for (const [, factory] of factories) {
            result.push(await factory.calculatePhantoms(partition));
        }
        return result.flat();
    }

    get originalItems() {
        const result = [];
        for (const factory of this.factories.values()) {
            result.push(...factory.originalItems);
        }
        return result;
    }
}

const tolerance = Math.PI / 36;