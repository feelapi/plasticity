import * as THREE from "three";
import { Line2 } from "three/examples/jsm/lines/Line2";
import { AbstractGizmo, EditorLike, Intersector, Mode, MovementInfo } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { AbstractAxialScaleGizmo, AbstractAxisGizmo, AngleGizmo, AxisHelper, CompositeHelper, lineGeometry, MagnitudeStateMachine, NumberHelper, sphereGeometry } from "../../command/MiniGizmos";
import { groupBy } from "../../command/MultiFactory";
import * as c3d from '../../kernel/kernel';
import { CancellablePromise } from "../../util/CancellablePromise";
import { Y } from "../../util/Constants";
import { point2point, vec2vec } from "../../util/Conversion";
import { Helper } from "../../util/Helpers";
import * as visual from "../../visual_model/VisualModel";
import { FilletMode, FilletParams } from './FilletSolidFactory';

export class FilletSolidGizmo extends CompositeGizmo<FilletParams> {
    private readonly main = new FilletMagnitudeGizmo("fillet-solid:distance", this.editor);
    private readonly stretchFillet = new FilletStretchGizmo("fillet-solid:fillet", this.editor);
    private readonly stretchChamfer = new ChamferStretchGizmo("fillet-solid:chamfer", this.editor);
    private readonly angle = new FilletAngleGizmo("fillet-solid:angle", this.editor, this.editor.gizmos.white);
    private readonly variables: FilletMagnitudeGizmo[] = [];
    private readonly limits: FilletLimitGizmo[] = [];

    private mode: FilletMode = FilletMode.FilletSolid;

    constructor(params: FilletParams, editor: EditorLike, private readonly hint?: THREE.Vector3) {
        super(params, editor);
    }

    prepare() {
        const { main, angle, stretchFillet: stretchFillet, stretchChamfer } = this;
        const { point, normal } = this.placement(this.hint);

        main.quaternion.setFromUnitVectors(Y, normal);
        main.position.copy(point);
        stretchFillet.position.copy(point);
        stretchChamfer.position.copy(point);

        main.relativeScale.setScalar(0.8);
        angle.relativeScale.setScalar(0.5);

        this.add(main, stretchFillet, stretchChamfer);
        main.tip.add(angle);

        this.toggle(this.mode);
    }

    execute(cb: (params: FilletParams) => void): CancellablePromise<void> {
        const { main, angle, stretchFillet, stretchChamfer, params } = this;

        angle.value = Math.PI / 4;

        this.addGizmo(main, length => {
            if (this.mode === FilletMode.ChamferSolid) {
                const { distance1, distance2 } = computeDistancesFromLengthAndAngle(length, angle.value);
                params.distance1 = distance1;
                params.distance2 = distance2;
                stretchFillet.value = -length;
                stretchChamfer.value = length;
            } else {
                params.distance = length;
                stretchFillet.value = length;
                stretchChamfer.value = -length;
            }
            angle.stateMachine!.isEnabled = this.shouldShowAngle;
        });

        this.addGizmo(angle, angle => {
            params.distance2 = params.distance1 * Math.tan(angle);
        }, false);

        this.addGizmo(stretchFillet, length => {
            params.distance = length;
            main.value = length;
            stretchChamfer.value = -length;
            angle.stateMachine!.isEnabled = this.shouldShowAngle;
        });

        this.addGizmo(stretchChamfer, length => {
            const { distance1, distance2 } = computeDistancesFromLengthAndAngle(length, angle.value);
            params.distance1 = distance1;
            params.distance2 = distance2;
            main.value = length;
            stretchFillet.value = -length;
            angle.stateMachine!.isEnabled = this.shouldShowAngle;
        });

        return super.execute(cb, Mode.Persistent);
    }

    toggle(mode: FilletMode) {
        const { variables } = this;
        this.mode = mode;
        if (mode === FilletMode.ChamferSolid) {
            for (const variable of variables) {
                variable.visible = false;
                variable.stateMachine!.isEnabled = false;
            }
        } else if (mode === FilletMode.FilletSolid) {
            for (const variable of variables) {
                variable.visible = true;
                variable.stateMachine!.isEnabled = true;
            }
        }
    }

    get shouldShowAngle(): boolean {
        return Math.abs(this.params.distance1) + Math.abs(this.params.distance2) > 0
    }

    private placement(hint?: THREE.Vector3): { point: THREE.Vector3, normal: THREE.Vector3 } {
        const { params: { edges }, editor: { db } } = this;
        const models = edges.map(view => db.lookupTopologyItem(view));
        const curveEdge = models[models.length - 1];

        if (hint !== undefined) {
            const { t, exact } = curveEdge.FindPointNear(point2point(hint));
            const { normal } = curveEdge.EvalBasis(t);
            return { point: point2point(exact), normal: vec2vec(normal, 1) };
        } else {
            const { normal } = curveEdge.EvalBasis(0.5);
            hint = point2point(curveEdge.GetPoint(0.5));
            return { point: hint, normal: vec2vec(normal) };
        }
    }

    render(length: number) {
        this.main.render(length);
    }

    addVariable(at: c3d.EdgeBlendVariationPoint, edge: c3d.Edge, t: number): FilletMagnitudeGizmo {
        const { normal } = edge.EvalBasis(t);
        const gizmo = new FilletMagnitudeGizmo(`fillet:distance:${this.variables.length}`, this.editor);
        gizmo.relativeScale.setScalar(0.5);
        gizmo.value = at.PrimarySize;
        gizmo.position.copy(point2point(at.Position));
        gizmo.quaternion.setFromUnitVectors(Y, vec2vec(normal, 1));
        this.variables.push(gizmo);

        this.updateState();
        return gizmo;
    }

    override enable() {
        super.enable();
        this.updateState();
    }

    private updateState() {
        if (this.variables.length > 0) {
            this.angle.stateMachine!.isEnabled = false;
            this.stretchFillet.stateMachine!.isEnabled = false;
            this.stretchChamfer.stateMachine!.isEnabled = false;
            this.main.stateMachine!.isEnabled = false;
        } else {
            this.angle.stateMachine!.isEnabled = true;
            this.stretchFillet.stateMachine!.isEnabled = true;
            this.stretchChamfer.stateMachine!.isEnabled = true;
            this.main.stateMachine!.isEnabled = true;
        }
    }

    addLimit(at: c3d.EdgeBlendLimitPoint, edge: c3d.Edge, t: number): FilletLimitGizmo {
        const { normal } = edge.EvalBasis(t);
        const gizmo = new FilletLimitGizmo(`fillet:limit:${this.variables.length}`, this.editor);
        gizmo.relativeScale.setScalar(0.5);
        gizmo.position.copy(point2point(at.Position));
        gizmo.quaternion.setFromUnitVectors(Y, vec2vec(normal, 1));
        this.limits.push(gizmo);

        return gizmo;
    }

    private edges: THREE.Object3D[] = [];
    showEdges() {
        for (const edge of this.edges) edge.removeFromParent();

        const map = groupBy('parentItem', this.params.extendedEdges);
        const views = [];
        for (const [solid, edges] of map.entries()) {
            const selected: visual.CurveEdge[] = [];
            const group = solid.high;
            const ids = new Set(edges.map(e => e.simpleName));
            for (const e of group.edges) {
                if (ids.has(e.simpleName)) {
                    selected.push(e);
                }
            }
            const view = solid.edges.slice(selected.map(s => s.group));
            view.material = this.editor.materials.lineDashed();
            view.computeLineDistances();
            this.add(view);
            views.push(view);
        }
        this.edges = views;
    }

    get shouldRescaleOnZoom() { return false }
}

export class FilletMagnitudeGizmo extends AbstractAxisGizmo {
    readonly state = new MagnitudeStateMachine(0);
    protected material = this.editor.gizmos.default;
    readonly helper = new CompositeHelper([new AxisHelper(this.material.line), new NumberHelper()]);
    readonly tip = new THREE.Mesh(sphereGeometry, this.material.mesh);
    protected readonly shaft = new THREE.Mesh();
    protected readonly knob = new THREE.Mesh(new THREE.SphereGeometry(0.2), this.editor.gizmos.invisible);
    private readonly line = new Line2(lineGeometry, this.material.line2);

    constructor(name: string, editor: EditorLike) {
        super(name, editor);
        this.setup();
        this.add(this.helper);
        this.tip.add(this.line);
        this.line.position.set(0, - 0.5, 0);
    }

    onInterrupt(cb: (radius: number) => void) {
        this.state.push();
    }

    render(length: number) {
        const approxDist = length * Math.sin(Math.PI / 4);
        this.tip.position.set(0, approxDist, 0);
        this.knob.position.copy(this.tip.position);
    }

    protected accumulate(original: number, sign: number, dist: number): number {
        return original + dist
    }

    protected override scaleIndependentOfZoom(camera: THREE.Camera) {
        // Rather than scaling the parent, we scale the children, so that the position (set in render)
        // is in world space
        this.tip.scale.copy(this.relativeScale);
        this.knob.scale.copy(this.relativeScale);
        this.helper.scale.copy(this.relativeScale);
        Helper.scaleIndependentOfZoom(this.tip, camera, this.worldPosition);
        Helper.scaleIndependentOfZoom(this.knob, camera, this.worldPosition);
        Helper.scaleIndependentOfZoom(this.helper, camera, this.worldPosition);
    }

    onEnabled() { this.visible = true }
    onDisabled() { this.visible = false }
}

class FilletLimitGizmo extends AbstractGizmo<boolean> {
    private state = false;
    protected offMaterial = this.editor.gizmos.cyan;
    protected onMaterial = this.editor.gizmos.magenta;
    readonly tip = new THREE.Mesh(sphereGeometry, this.offMaterial.mesh);
    protected readonly knob = new THREE.Mesh(new THREE.SphereGeometry(0.2), this.editor.gizmos.invisible);

    constructor(name: string, editor: EditorLike) {
        super(name, editor);
        this.setup();
    }

    protected setup() {
        this.handle.add(this.tip);
        this.picker.add(this.knob);
    }

    onPointerEnter(intersect: Intersector) {
        this.tip.material = this.state ? this.onMaterial.hover.mesh : this.offMaterial.hover.mesh;
    }

    onPointerLeave(intersect: Intersector) {
        this.tip.material = this.state ? this.onMaterial.hover.mesh : this.offMaterial.mesh;
    }

    onPointerMove(cb: (i: boolean) => void, intersector: Intersector, info: MovementInfo): boolean | undefined {
        return this.state;
    }

    onPointerDown(cb: (i: boolean) => void, intersect: Intersector, info: MovementInfo): void {
        this.state = !this.state;
        cb(this.state);
    }

    onPointerUp(cb: (i: boolean) => void, intersect: Intersector, info: MovementInfo): void {
    }

    onInterrupt(cb: (i: boolean) => void): void { }
}

class FilletAngleGizmo extends AngleGizmo {
    onInterrupt(cb: (radius: number) => void) {
        this.state.push();
    }

    get shouldRescaleOnZoom() { return false }

    onEnabled() { this.visible = true }
    onDisabled() { this.visible = false }
}

export class FilletStretchGizmo extends AbstractAxialScaleGizmo {
    readonly state = new MagnitudeStateMachine(0);
    readonly tip = new THREE.Mesh();
    protected readonly shaft = new THREE.Mesh();
    protected readonly knob = new THREE.Mesh();

    constructor(name: string, editor: EditorLike) {
        super(name, editor, editor.gizmos.default);
        this.setup();
    }

    onInterrupt(cb: (radius: number) => void) {
        this.state.push();
    }

    protected accumulate(original: number, dist: number, denom: number, _: number = 1): number {
        if (original === 0) return Math.max(0, dist - denom);
        else return (original + ((dist - denom) * original) / denom);
    }

    override get shouldRescaleOnZoom(): boolean {
        return true;
    }
}

class ChamferStretchGizmo extends FilletStretchGizmo {
    protected accumulate(original: number, dist: number, denom: number, sign: number = 1): number {
        return -Math.abs(super.accumulate(original, dist, denom, sign));
    }

    override get shouldRescaleOnZoom(): boolean {
        return true;
    }
}

function computeDistancesFromLengthAndAngle(length: number, angle: number) {
    const avoidNumericalPrecisionIssue = angle === Math.PI / 4 ? length : length * Math.tan(angle);
    return { distance1: length, distance2: avoidNumericalPrecisionIssue };
}