import { render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { Agent } from '../../editor/DatabaseLike';
import { EditorSignals } from "../../editor/EditorSignals";
import FilletSolidFactory, { FilletMode, FilletParams } from "./FilletSolidFactory";
import beginningLength from './img/begLength.png';
import conic1 from './img/conic1.jpg';
import conic2 from './img/conic2.jpg';
import prolong_ from './img/prolong.png';
import * as c3d from '../../kernel/kernel';

export class FilletDialog extends AbstractDialog<FilletParams> {
    name = "Fillet";

    private mode: FilletMode = FilletMode.FilletSolid;

    constructor(protected readonly params: FilletParams, private readonly agent: Agent, signals: EditorSignals) {
        super(signals);
    }

    toggle(mode: FilletMode) {
        this.mode = mode;
        this.render();
    }

    render() {
        const { agent } = this;
        const { prolong, shape } = this.params;
        let { distance1, distance2 } = this.params;

        render(
            <>
                {agent === 'user' &&
                    <ol>
                        <plasticity-prompt name="Select edges" description="to fillet or chamfer"></plasticity-prompt>
                    </ol>
                }

                <ul>
                    <li>
                        <label for="distance1">Distance</label>
                        <div class="fields">
                            <plasticity-number-scrubber name="distance1" value={distance1} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber name="distance2" value={distance2} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li>
                    {/* <li class={this.mode === FilletMode.ChamferSolid ? 'disabled' : ''}>
                        <label for="conic">Conic
                            <plasticity-tooltip><img src={conic1} /><img src={conic2} /></plasticity-tooltip>
                        </label>
                        <div class="fields">
                            <plasticity-number-scrubber disabled={0} min={0.05} max={0.95} default={0.5} name="conic" value={conic} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li> */}
                    <li class={this.mode === FilletMode.ChamferSolid ? 'disabled' : ''}>
                        <label for="shape">Shape</label>
                        <div class="fields">
                            <input type="radio" hidden name="shape" id="parallel" value={c3d.BlendShape.Conic} checked={shape === c3d.BlendShape.Conic} onClick={this.onChange}></input>
                            <label for="parallel">Conic</label>

                            <input type="radio" hidden name="shape" id="normal" value={c3d.BlendShape.G2} checked={shape === c3d.BlendShape.G2} onClick={this.onChange}></input>
                            <label for="normal">G2</label>
                        </div>
                    </li>
                    {/* <li>
                        <label for="begLength">Length
                            <plasticity-tooltip><img src={beginningLength} /></plasticity-tooltip>
                        </label>
                        <div class="fields">
                            <plasticity-number-scrubber disabled={FilletSolidFactory.LengthSentinel} min={0} default={0} name="begLength" value={begLength} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                            <plasticity-number-scrubber disabled={FilletSolidFactory.LengthSentinel} min={0} default={0} name="endLength" value={endLength} onchange={this.onChange} onscrub={this.onChange} onfinish={this.onChange}></plasticity-number-scrubber>
                        </div>
                    </li> */}

                    <li>
                        <label for="prolong">Selection
                            <plasticity-tooltip><img src={prolong_} /></plasticity-tooltip>
                        </label>
                        <div class="fields">
                            <input type="checkbox" hidden id="prolong" name="prolong" checked={prolong} onClick={this.onChange}></input>
                            <label for="prolong">Add tangent edges</label>
                        </div>
                    </li>

                </ul></>, this);
    }
}
customElements.define('plasticity-fillet-dialog', FilletDialog);
