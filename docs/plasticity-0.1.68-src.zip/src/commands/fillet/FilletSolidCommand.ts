import * as THREE from "three";
import { Mode } from "../../command/AbstractGizmo";
import Command from "../../command/Command";
import { ObjectPicker } from "../../command/ObjectPicker";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { Quasimode } from "../../command/Quasimode";
import { HasSelection } from "../../selection/SelectionDatabase";
import { SelectionMode } from "../../selection/SelectionModeSet";
import { CancellablePromise } from "../../util/CancellablePromise";
import { vec2vec } from '../../util/Conversion';
import * as visual from '../../visual_model/VisualModel';
import { CopyFilletRadiusPicker } from "./CopyFilletRadiusPicker";
import { FilletDialog } from "./FilletDialog";
import { FilletSolidGizmo } from './FilletGizmo';
import { ChamferAndFilletKeyboardGizmo } from "./FilletKeyboardGizmo";
import { FilletSolidFactoryLike, MultiFilletSolidFactory } from "./FilletSolidFactory";


export class FilletSolidCommand extends Command {
    point?: THREE.Vector3;

    async execute(): Promise<void> {
        const fillet = new MultiFilletSolidFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);

        const keyboard = new ChamferAndFilletKeyboardGizmo(this.editor);
        const dialog = new FilletDialog(fillet, this.agent, this.editor.signals);
        let gizmo = new FilletSolidGizmo(fillet, this.editor, this.point);

        const objectPicker = new ObjectPicker(this.editor);
        objectPicker.copy(this.editor.selection);

        dialog.execute(async (params) => {
            gizmo.toggle(fillet.mode);
            keyboard.toggle(fillet.mode);
            gizmo.render(params.distance1);
            await fillet.update();
        }).resource(this).then(() => this.finish(), () => this.cancel());

        let g: CancellablePromise<void> | undefined;
        let p: CancellablePromise<HasSelection> | undefined;
        let r: CancellablePromise<HasSelection> | undefined;
        let q: CancellablePromise<void> | undefined;

        const stopPicker = () => { p?.finish(); p = undefined; };
        const stopGizmo = () => { g?.finish(); g = undefined; };
        const stopQuasimode = () => { q?.finish(); q = undefined; };
        const stopRadius = () => { r?.finish(); r = undefined; };

        const startGizmo = () => {
            if (g !== undefined) {
                gizmo.showEdges();
                return;
            }
            gizmo = new FilletSolidGizmo(fillet, this.editor, this.point);
            g = gizmo.execute(async (params) => {
                keyboard.toggle(fillet.mode);
                gizmo.toggle(fillet.mode);
                dialog.toggle(fillet.mode);
                dialog.render();
                if (Math.abs(params.distance1) > 0) {
                    stopPicker();
                    startQuasimode();
                    startRadius();
                }
                await fillet.update();
            }).resource(this);
            gizmo.showEdges();
        };

        const startQuasimode = async () => {
            if (q !== undefined) return;
            const quasiPicker = new ObjectPicker(this.editor, objectPicker.selection, 'viewport-selector[quasimode]');
            const quasimode = new Quasimode("modify-selection", this.editor, fillet);
            q = quasimode.execute(() => {
                stopRadius();
                return quasiPicker.execute(delta => {
                    fillet.edges = [...quasiPicker.selection.selected.edges];
                    gizmo.showEdges();
                }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.CurveEdge)
                    .after(startRadius).resource(this);
            }).resource(this);
        };

        const startPicker = () => {
            if (p !== undefined) return;
            p = objectPicker.execute(async delta => {
                fillet.edges = [...objectPicker.selection.selected.edges];
                startGizmo();
                fillet.update();
            }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.CurveEdge).resource(this);
        };

        const startRadius = () => {
            if (r !== undefined) return;
            const objectPicker = new CopyFilletRadiusPicker(this.editor);
            r = objectPicker.execute(async selection  => {
                const face = selection.faces.first;
                fillet.copyFaceRadius(face);
                fillet.update();
                objectPicker.selection.selected.removeAll();
            }, 1, Number.MAX_SAFE_INTEGER, SelectionMode.Face).resource(this);
        };

        fillet.edges = [...this.editor.selection.selected.edges];
        if (fillet.edges.length > 0) startGizmo();

        if (this.agent == 'user') {
            dialog.prompt("Select edges", () => {
                stopQuasimode();
                stopRadius();
                startPicker();
                return p!;
            }, () => {
                stopGizmo();
                stopQuasimode();
                stopRadius();
                objectPicker.selection.selected.removeAll();
                fillet.edges = [];
                fillet.distance1 = fillet.distance2 = 0;
                dialog.render();
                fillet.update();
            })();
        }

        keyboard.execute(async (s) => {
            switch (s) {
                case 'add-variation-point':
                    if (fillet.filletMode === 'constant') {
                        await this.addVariableFilletEndpoints(fillet, gizmo);
                        fillet.filletMode = 'variable';
                    } else {
                        await this.addAdditionalVariableFilletPoint(fillet, gizmo);
                    }
                    break;
                case 'add-limit-point':
                    await this.addAdditionalLimitPoint(fillet, gizmo);
            }
        }).resource(this);

        await this.finished;

        const results = await fillet.commit();
        this.editor.selection.selected.add(results);
    }

    private async addAdditionalVariableFilletPoint(fillet: FilletSolidFactoryLike, gizmo: FilletSolidGizmo) {
        const resume = fillet.pause(false);
        const variable = new PointPicker(this.editor);
        const edges = variable.restrictToEdges(fillet.extendedEdges);
        variable.raycasterParams.Line2.threshold = 50;

        gizmo.disable();
        const { point, info: { restriction } } = await variable.execute().resource(this);
        const match = edges.find(restriction);
        const { view } = match;
        const model = this.editor.db.lookupTopologyItem(view);
        const { t } = match.t(point);
        const fn = fillet.addVariationPoint(view, point);
        const added = gizmo.addVariable(fn, model, t);
        resume.dispose();
        gizmo.enable();

        added.execute(delta => {
            fn.PrimarySize = delta;
            fn.SecondarySize = delta;
            fillet.update();
        }, Mode.Persistent).resource(this);
    }

    private limitPoints = 0;
    private async addAdditionalLimitPoint(fillet: FilletSolidFactoryLike, gizmo: FilletSolidGizmo) {
        const resume = fillet.pause(false);
        const variable = new PointPicker(this.editor);
        const edges = variable.restrictToEdges(fillet.extendedEdges);
        variable.raycasterParams.Line2.threshold = 50;

        gizmo.disable();
        const { point, info: { restriction } } = await variable.execute().resource(this);
        const match = edges.find(restriction);
        const { view } = match;
        const model = this.editor.db.lookupTopologyItem(view);
        const { t } = match.t(point);
        const { tangent } = model.EvalBasis(t);
        const fn = fillet.addLimitPoint(view, point, vec2vec(tangent, this.limitPoints++ % 2 == 0 ? 1 : -1));
        const added = gizmo.addLimit(fn, model, t);
        resume.dispose();
        gizmo.enable();

        added.execute(delta => {
            fn.Direction.MultiplyScalar(-1);
            fillet.update();
        }, Mode.Persistent).resource(this);

        await fillet.update();
    }

    private async addVariableFilletEndpoints(fillet: FilletSolidFactoryLike, gizmo: FilletSolidGizmo) {
        const resume = fillet.pause(false);
        gizmo.disable();

        const variations = fillet.addEndpoints();
        if (variations.length === 0) {
            const addLimitPoint = async () => {
                const variable = new PointPicker(this.editor);
                const edges = variable.restrictToEdges(fillet.extendedEdges);
                variable.raycasterParams.Line2.threshold = 50;

                const { point, info: { restriction } } = await variable.execute().resource(this);
                const match = edges.find(restriction);
                const { view } = match;
                const model = this.editor.db.lookupTopologyItem(view);
                const { t } = match.t(point);
                const fn = fillet.addVariationPoint(view, point);
                variations.push({ point: fn, edge: model, t });
            }
            await addLimitPoint();
            await addLimitPoint();
        }

        const gizmoids = [];
        for (const variation of variations) {
            const gizmoid = gizmo.addVariable(variation.point, variation.edge, variation.t);
            gizmoids.push(gizmoid);
        }

        resume.dispose();
        await fillet.update();
        gizmo.enable();

        for (let i = 0; i < gizmoids.length; i++) {
            const gizmoid = gizmoids[i];
            const variation = variations[i];
            gizmoid.execute(delta => {
                variation.point.PrimarySize = delta;
                variation.point.SecondarySize = delta;
                fillet.update();
            }, Mode.Persistent).resource(this);
        }
    }
}
