import * as THREE from "three";
import { Line2 } from "three/examples/jsm/lines/Line2";
import { EditorLike, Mode } from "../../command/AbstractGizmo";
import { CompositeGizmo } from "../../command/CompositeGizmo";
import { AbstractAxialScaleGizmo, lineGeometry, MagnitudeStateMachine, sphereGeometry } from "../../command/MiniGizmos";
import { CancellablePromise } from "../../util/CancellablePromise";
import { FilletStretchGizmo } from "./FilletGizmo";
import { FilletVertexParams } from "./FilletVertexFactory";

export class FilletVertexGizmo extends CompositeGizmo<FilletVertexParams> {
    private readonly main = new FilletStretchGizmo("fillet-vertex:fillet", this.editor);

    constructor(params: FilletVertexParams, editor: EditorLike) {
        super(params, editor);
    }

    prepare() {
        const { main } = this;
        this.add(main);
    }

    execute(cb: (params: FilletVertexParams) => void, mode: Mode = Mode.Persistent): CancellablePromise<void> {
        const { main, params } = this;

        this.addGizmo(main, d => {
            params.radius = d;
        });

        return super.execute(cb, mode);
    }

    get shouldRescaleOnZoom() {
        return false;
    }
}

export class MagnitudeGizmo extends AbstractAxialScaleGizmo {
    handleLength = 0;
    readonly state = new MagnitudeStateMachine(0);
    readonly tip: THREE.Mesh<any, any> = new THREE.Mesh(sphereGeometry, this.material.mesh);
    protected readonly shaft = new Line2(lineGeometry, this.material.line2);
    protected readonly knob = new THREE.Mesh(new THREE.SphereGeometry(0.2), this.editor.gizmos.invisible);

    constructor(name: string, editor: EditorLike) {
        super(name, editor, editor.gizmos.default);
        this.setup();
        this.shaft.visible = false;
    }

    get shouldRescaleOnZoom() { return true }
}