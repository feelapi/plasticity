import { Mode } from "../../command/AbstractGizmo";
import Command from "../../command/Command";
import { FilletFacesFactory } from "./FilletFacesFactory";
import { FilletSolidCommand } from "./FilletSolidCommand";
import { MultiFilletCurveFactory, MultiFilletVertexFactory } from "./FilletVertexFactory";
import { FilletVertexGizmo } from "./FilletVertexGizmo";

export class FilletCommand extends Command {
    async execute(): Promise<void> {
        const { selection: { selected } } = this.editor;
        if (selected.edges.size > 0) {
            const command = new FilletSolidCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.faces.size > 1) {
            const command = new FilletFaceCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.vertices.size > 0) {
            const command = new FilletVertexCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        } else if (selected.curves.size > 0) {
            const command = new FilletCurveCommand(this.editor);
            command.agent = this.agent;
            this.editor.exec(command);
        }
    }
}

export class FilletFaceCommand extends Command {
    async execute(): Promise<void> {
        const { db, materials, signals, selection: { selected } } = this.editor;
        const fillet = new FilletFacesFactory(db, materials, signals).resource(this);
        fillet.faces = [...selected.faces];
        const result = await fillet.commit();
        this.editor.selection.selected.add(result);
        for (const face of fillet.faces) {
            this.editor.selection.selected.remove(face);
        }
    }
}

export class FilletVertexCommand extends Command {
    async execute(): Promise<void> {
        const { editor } = this;
        const points = [...editor.selection.selected.vertices];
        const fillet = new MultiFilletVertexFactory(editor.db, editor.materials, editor.signals).resource(this);
        fillet.vertices = points;

        const gizmo = new FilletVertexGizmo(fillet, this.editor);
        gizmo.position.copy(fillet.centroid);

        gizmo.execute(s => {
            fillet.update();
        }, Mode.None).resource(this);
        gizmo.start('gizmo:fillet-vertex:fillet');

        await this.finished;

        const result = await fillet.commit();
        editor.selection.selected.add(result);
    }
}

export class FilletCurveCommand extends Command {
    async execute(): Promise<void> {
        const { editor } = this;
        const curves = [...editor.selection.selected.curves];
        const fillet = new MultiFilletCurveFactory(editor.db, editor.materials, editor.signals).resource(this);
        fillet.curves = [...curves];

        const gizmo = new FilletVertexGizmo(fillet, this.editor);
        gizmo.position.copy(fillet.centroid);

        gizmo.execute(s => {
            fillet.update();
        }, Mode.None).resource(this);
        gizmo.start('gizmo:fillet-vertex:fillet');

        await this.finished;

        const result = await fillet.commit();
        editor.selection.selected.add(result);
    }
}
