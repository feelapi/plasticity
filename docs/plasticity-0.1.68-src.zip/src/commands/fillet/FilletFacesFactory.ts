import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import { groupBy } from '../../command/MultiFactory';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';

export class FilletFacesFactory extends GeometryFactory<c3d.Sheet, visual.Sheet, []> {
    protected _faces!: { views: visual.Face[]; models: c3d.Face[]; };
    @derive([visual.Face]) get faces(): visual.Face[] { throw ''; }
    set faces(faces: visual.Face[] | c3d.Face[]) { }

    async calculate() {
        const { _faces: { models, views } } = this;
        const map = groupBy('parentItem', views);
        const facess = [];
        for (const [key, value] of map) {
            const faces = value.map(v => this.db.lookupTopologyItem(v));
            facess.push(faces);
        }
        const options = new c3d.FaceBlendOptions();
        return c3d.Sheet.MakeFaceBlend_async(facess[0], facess[1], false, false, options);
    }
}