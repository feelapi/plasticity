import { EditorLike, ObjectPicker, ObjectPickerViewportSelector } from "../../command/ObjectPicker";
import { Viewport } from "../../components/viewport/Viewport";
import { RaycasterParameters } from "../../components/viewport/ViewportControl";
import { EditorSignals } from "../../editor/EditorSignals";
import LayerManager from "../../editor/LayerManager";
import { HasSelectedAndHovered, Selectable, SelectionDatabase } from "../../selection/SelectionDatabase";
import { AbstractViewportSelector } from "../../selection/ViewportSelector";
import * as visual from '../../visual_model/VisualModel';

export class CopyFilletRadiusPicker extends ObjectPicker {
    constructor(editor: EditorLike) {
        super(editor, new SelectionDatabase(editor.db, editor.scene, editor.materials, new EditorSignals()));
    }

    protected makeSelector(viewport: Viewport, editor: EditorLike, selection: HasSelectedAndHovered, raycasterParams: RaycasterParameters, layers: LayerManager, prohibitions: ReadonlySet<Selectable>, keymapSelector?: string): AbstractViewportSelector {
        return new CopyFilletRadiusViewportSelector(viewport, editor, selection, raycasterParams, layers, prohibitions, keymapSelector);
    }
}

class CopyFilletRadiusViewportSelector extends ObjectPickerViewportSelector {
    protected override filter(item: Selectable): boolean {
        if (item instanceof visual.Shell) return true;
        if (!(item instanceof visual.Face)) return false;
        const face = this.db.lookupTopologyItem(item);
        return face.IsBlend();
    }
}
