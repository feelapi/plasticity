import { CommandKeyboardInput, EditorLike } from "../../command/CommandKeyboardInput";
import { CancellablePromise } from "../../util/CancellablePromise";
import { FilletMode } from "./FilletSolidFactory";

export class ChamferAndFilletKeyboardGizmo {
    private mode?: FilletMode;
    private active?: CancellablePromise<void>;
    private cb!: (e: string) => void;

    constructor(private readonly editor: EditorLike) { }

    execute(cb: (e: string) => void) {
        this.cb = cb;
        return new CancellablePromise<void>((resolve, reject) => {
            const dispose = () => this.active?.dispose();
            return { dispose, finish: resolve };
        });
    }

    toggle(mode: FilletMode) {
        if (this.mode === mode) return;
        if (mode === FilletMode.ChamferSolid) {
            this.active?.finish();
            this.active = undefined;
            this.active = new ChamferKeyboardGizmo(this.editor).execute(this.cb);
        } else if (mode === FilletMode.FilletSolid) {
            this.active?.finish();
            this.active = undefined;
            this.active = new FilletKeyboardGizmo(this.editor).execute(this.cb);
        }
        this.mode = mode;
    }
}

export class FilletKeyboardGizmo extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super("fillet", editor,
            ['gizmo:fillet-solid:add-variation-point', 'gizmo:fillet-solid:add-limit-point']);
    }
}

export class ChamferKeyboardGizmo extends CommandKeyboardInput {
    constructor(editor: EditorLike) {
        super("fillet", editor, ['gizmo:fillet-solid:add-limit-point']);
    }
}