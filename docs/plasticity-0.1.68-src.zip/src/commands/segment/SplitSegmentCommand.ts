import Command from "../../command/Command";
import { ValidationError } from "../../command/GeometryFactory";
import { PointPicker } from "../../command/point-picker/PointPicker";
import { AxisCurveCrossPointSnap, CrossPointSnap, CurveEndPointSnap, CurveMidpointSnap, CurveSegmentSnap } from "../../editor/snaps/Snaps";
import { SplitSegmentFactory } from "./SplitSegmentFactory";
import * as visual from '../../visual_model/VisualModel';

export class SplitSegmentCommand extends Command {
    async execute(): Promise<void> {
        const { editor: { selection: { selected } } } = this;
        const pointPicker = new PointPicker(this.editor);
        pointPicker.restrictToSegments();
        const { point, info: { all } } = await pointPicker.execute().resource(this);

        const splits: { segment: visual.CurveSegment, t: number }[] = [];
        for (const snap of all) {
            if (
                snap instanceof CurveSegmentSnap ||
                snap instanceof CurveMidpointSnap ||
                snap instanceof CurveEndPointSnap ||
                snap instanceof AxisCurveCrossPointSnap
            ) {
                splits.push({ segment: snap.view, t: snap.t(point) });
            } else if (snap instanceof CrossPointSnap) {
                const m1 = snap.curve1.model, m2 = snap.curve2.model;
                const t1 = snap.cross.on1.t, t2 = snap.cross.on2.t;
                const t1_ = m1.Normalize(t1), t2_ = m2.Normalize(t2);
                if (selected.curves.has(snap.curve1.view.parentItem))
                    splits.push({ segment: snap.curve1.view, t: t1_ });
                else if (selected.curves.has(snap.curve2.view.parentItem))
                    splits.push({ segment: snap.curve2.view, t: t2_ });
                else {
                    splits.push({ segment: snap.curve1.view, t: t1_ });
                    splits.push({ segment: snap.curve2.view, t: t2_ });
                }
            } else throw new ValidationError('Invalid snap type: ' + snap.constructor.name);
        }
        for (const { segment, t } of splits) {
            if (t === 0 || t === 1) continue;
            const split = new SplitSegmentFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
            split.segment = segment;
            split.curve = segment.parentItem;
            split.param = t;
            await split.commit();
        }
    }
}
