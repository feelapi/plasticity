import { derive } from '../../command/FactoryBuilder';
import { GeometryFactory } from '../../command/GeometryFactory';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';

export class SplitSegmentFactory extends GeometryFactory<c3d.Wire, visual.SpaceInstance> {
    protected _curve!: { view: visual.SpaceInstance, model: c3d.Wire };
    @derive(visual.SpaceInstance) get curve(): visual.SpaceInstance { throw '' }
    set curve(curve: visual.SpaceInstance | c3d.Wire) { }

    protected _segment!: { view: visual.CurveSegment; model: c3d.Edge };
    @derive(visual.CurveSegment) get segment(): visual.CurveSegment { throw ''; }
    set segment(segment: visual.CurveSegment | c3d.Edge) { }

    param!: number;

    async calculate() {
        const { _curve: { model: curve }, _segment: { model: segment }, param } = this;
        segment.SplitAt(param);
        return curve;
    }

    get originalItem() { return this.curve }
}
