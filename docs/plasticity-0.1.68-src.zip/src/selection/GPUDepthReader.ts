import * as THREE from "three";
import { Pass } from "three/examples/jsm/postprocessing/Pass";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass";
import { ProxyCamera } from "../components/viewport/ProxyCamera";
import { readRenderTargetPixelsAsync } from "./gpu/GPUWaitAsync";

const tileSize = 256;

export class GPUDepthReader implements Pass {
    readonly depthTarget = new THREE.WebGLRenderTarget(1, 1);
    private readonly depthScene = new THREE.Scene();
    private readonly depthCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    depthBuffer: Readonly<Uint8Array> = new Uint8Array(4);
    depthMaterial = new THREE.ShaderMaterial({
        vertexShader: `
        varying vec2 vUv;
        void main() {
            vUv = uv;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
        `,
        fragmentShader: `
        #include <packing>

        varying vec2 vUv;
        uniform sampler2D tDepth;
        uniform float cameraNear;
        uniform float cameraFar;

        void main() {
            float fragCoordZ = texture2D( tDepth, vUv ).x;
            gl_FragColor = packDepthToRGBA(fragCoordZ); // for higher precision, spread float onto 4 bytes
        }
        `,
        uniforms: {
            cameraNear: { value: null },
            cameraFar: { value: null },
            tDepth: { value: null }
        }
    });
    private readonly depthQuad = new THREE.Mesh(depthPlane, this.depthMaterial);

    constructor(private readonly texture: THREE.DepthTexture, private readonly camera: ProxyCamera, private readonly renderer: THREE.WebGLRenderer) {
        this.depthScene.add(this.depthQuad);
    }

    enabled = true;
    needsSwap = false;
    clear = false;
    renderToScreen = false;

    readonly renderPass = new RenderPass(this.depthScene, this.depthCamera);

    setSize(width: number, height: number) {
        this.depthTarget.setSize(width, height);
    }

    show() {
        const debug = new DebugRenderTarget(this.depthTarget, this.renderer);
        debug.render();
    }

    private needsRender = true;
    setNeedsRender() { this.needsRender = true }

    render(renderer: THREE.WebGLRenderer) {
        if (!this.needsRender) return;
        this.needsRender = false;

        const { camera, depthMaterial, depthTarget, depthCamera, depthScene, texture } = this;
        depthMaterial.uniforms.cameraNear.value = camera.near;
        depthMaterial.uniforms.cameraFar.value = camera.far;
        depthMaterial.uniforms.tDepth.value = texture;
        const before = renderer.getRenderTarget();
        renderer.setRenderTarget(depthTarget);
        try {
            renderer.render(depthScene, depthCamera);
        } finally {
            renderer.setRenderTarget(before);
        }
        this.flush();
    }

    readSync(denormalizedScreenPoint: THREE.Vector2, normalizedScreenPoint: THREE.Vector2): THREE.Vector3 | undefined {
        const { camera, depthTarget } = this;
        denormalizedScreenPoint.multiplyScalar(this.dpr);
        denormalizedScreenPoint.roundToZero();
        const { x, y } = denormalizedScreenPoint;
        const depthBuffer = new Uint8Array(4);
        this.renderer.readRenderTargetPixels(this.depthTarget, x, y, 1, 1, depthBuffer);
        return GPUDepthReader.depth2position(depthBuffer, normalizedScreenPoint, camera);
    }

    read(denormalizedScreenPoint: THREE.Vector2, normalizedScreenPoint: THREE.Vector2): THREE.Vector3 | undefined {
        const { camera, loaded, depthTarget: { width } } = this;

        denormalizedScreenPoint.multiplyScalar(this.dpr);
        denormalizedScreenPoint.roundToZero();
        const { x, y } = denormalizedScreenPoint;
        const page = this.pages[this.pageFor(x, y)];
        if (page !== undefined) {
            const x0 = Math.floor(x / tileSize) * tileSize, y0 = Math.floor(y / tileSize) * tileSize;
            const dx = x - x0, dy = y - y0;
            const offset = (dy * tileSize + dx) * 4;
            const view = new Uint8Array(page.buffer, page.byteOffset + offset, 4);

            return GPUDepthReader.depth2position(view, normalizedScreenPoint, camera);
        } else {
            if (loaded[this.pageFor(x, y)]) return undefined;
            this.loadPage(x, y);
            return undefined;
        }
    }

    private clock = 0;
    private flush() {
        const { pool, pages, loaded } = this;
        loaded.fill(false);
        this.clock++;
        while (pages.length > 0) {
            const page = pages.pop()!;
            pool.push(page);
        }
    }

    private readonly pool: Uint8Array[] = [];
    private readonly pages: Uint8Array[] = [];
    private readonly loaded: boolean[] = [];
    private async loadPage(x: number, y: number) {
        const { pool, renderer, depthTarget, clock, loaded } = this;
        const pageNumber = this.pageFor(x, y);
        const x0 = Math.floor(x / tileSize) * tileSize, y0 = Math.floor(y / tileSize) * tileSize;
        const page = pool.pop() ?? new Uint8Array((tileSize * tileSize) * 4);
        const rand = Math.random();
        loaded[pageNumber] = true;
        console.time("readRenderTargetPixelsAsync: " + rand);
        readRenderTargetPixelsAsync(renderer, depthTarget, x0, y0, tileSize, tileSize, page).then(() => {
            console.timeEnd("readRenderTargetPixelsAsync: " + rand);
            if (this.clock !== clock) return;
            this.pages[pageNumber] = page;
        })
    }

    private pageFor(x: number, y: number): number {
        const { depthTarget: { width } } = this;
        return Math.floor(x / tileSize) + Math.floor(y / tileSize) * Math.floor(width / tileSize);
    }

    static depth2position(array: ArrayLike<number>, normalizedScreenPoint: THREE.Vector2, camera: ProxyCamera): THREE.Vector3 {
        unpackDepth.fromArray(array);
        unpackDepth.divideScalar(255);
        const ndc_z = unpackDepth.dot(UnpackFactors) * 2 - 1;

        // unproject in homogeneous coordinates, cf https://stackoverflow.com/questions/11277501/how-to-recover-view-space-position-given-view-space-depth-value-and-ndc-xy/46118945#46118945
        camera.updateProjectionMatrix(); // ensure up-to-date
        positionh.set(normalizedScreenPoint.x, normalizedScreenPoint.y, ndc_z, 1);
        positionh.applyMatrix4(camera.projectionMatrixInverse).applyMatrix4(camera.matrixWorld);

        // for perspective, unhomogenize
        const position = new THREE.Vector3(positionh.x, positionh.y, positionh.z).divideScalar(positionh.w);
        return position;
    }

    static depth2distance(array: ArrayLike<number>, camera: ProxyCamera): number {
        unpackDepth.fromArray(array);
        unpackDepth.divideScalar(255);
        const ndc_z = -unpackDepth.dot(UnpackFactors);
        const distance = ndc_z * (camera.near - camera.far) - camera.near;
        return distance;
    }

    private readonly dpr = this.renderer.getPixelRatio();
}

const unpackDepth = new THREE.Vector4()
const positionh = new THREE.Vector4();

const UnpackDownscale = 255. / 256.; // 0..1 -> fraction (excluding 1)
const PackFactors = new THREE.Vector3(256. * 256. * 256., 256. * 256., 256.);
const UnpackFactors = new THREE.Vector4(1 / PackFactors.x, 1 / PackFactors.y, 1 / PackFactors.z, 1)
UnpackFactors.multiplyScalar(UnpackDownscale);

export class DebugRenderTarget {
    private readonly scene = new THREE.Scene();
    private readonly camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    material = new THREE.ShaderMaterial({
        vertexShader: `
        varying vec2 vUv;
        void main() {
            vUv = uv;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
        `,
        fragmentShader: `
        uniform sampler2D tDiffuse;
        varying vec2 vUv;
        void main() {
            gl_FragColor = texture2D( tDiffuse, vUv );
        }
        `,
        uniforms: {
            tDiffuse: { value: null }
        }
    });
    private readonly depthQuad = new THREE.Mesh(depthPlane, this.material);

    constructor(private readonly target: THREE.WebGLRenderTarget, private readonly renderer: THREE.WebGLRenderer) {
        this.scene.add(this.depthQuad);
    }

    render() {
        const { renderer, material, camera, scene } = this;
        material.uniforms.tDiffuse.value = this.target.texture;
        renderer.setRenderTarget(null);
        renderer.render(scene, camera);
    }
}

const depthPlane = new THREE.PlaneGeometry(2, 2);

// https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/WebGL_best_practices
export function clientWaitAsync(gl: WebGL2RenderingContext, sync: WebGLSync, flags: GLbitfield, interval_ms: number) {
    return new Promise<void>((resolve, reject) => {
        function test() {
            const res = gl.clientWaitSync(sync, flags, 0);
            if (res == gl.WAIT_FAILED) {
                reject();
                return;
            }
            if (res == gl.TIMEOUT_EXPIRED) {
                setTimeout(test, interval_ms);
                return;
            }
            resolve();
        }
        test();
    });
}