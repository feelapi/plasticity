import * as cmd from "../command/Command";
import { ReadonlyGeometryDatabase } from "../editor/DatabaseLike";
import * as visual from '../visual_model/VisualModel';
import { ChangeSelectionModifier } from './ChangeSelectionExecutor';
import { HasSelectedAndHovered, ModifiesSelection } from './SelectionDatabase';
import { SelectionMode } from './SelectionModeSet';

export class SelectionConversionStrategy {
    constructor(
        private readonly selection: HasSelectedAndHovered,
        private readonly db: ReadonlyGeometryDatabase
    ) { }

    convert(to: SelectionMode, modifier: ChangeSelectionModifier) {
        const { selection: { selected } } = this;
        switch (to) {
            case SelectionMode.CurveEdge:
                this.faces2edges(selected);
                for (const view of selected.solids) {
                    this.shell2edge(view);
                }
                for (const view of selected.shells) {
                    this.shell2edge(view);
                }
                break;
            case SelectionMode.Face:
                for (const view of selected.edges) {
                    this.edge2face(view);
                }
                for (const view of selected.solids) {
                    this.shell2face(view);
                }
                for (const view of selected.sheets) {
                    this.shell2face(view);
                }
                break;
            case SelectionMode.Solid:
                for (const view of selected.edges) {
                    this.edge2solid(view);
                }
                for (const view of selected.faces) {
                    this.face2shell(view);
                }
        }
    }

    private faces2edges(selected: ModifiesSelection) {
        const { db } = this;
        const map = new Map<visual.EdgeId, number>();
        for (const view of selected.faces) {
            const parentId = view.parentItem.simpleName;
            const model = db.lookupTopologyItem(view);

            const outerLoop = model.GetOuterLoop();
            const edges = outerLoop !== undefined ? outerLoop.GetEdges() : model.GetEdges();
            for (const edgeId of edges.GetIds()) {
                const id = visual.CurveEdge.simpleName(parentId, edgeId);
                if (!map.has(id)) map.set(id, 0);
                map.set(id, map.get(id)! + 1);
            }

            const innerLoops = model.GetInnerLoops();
            for (const loop of innerLoops) {
                for (const edgeId of loop.GetEdges().GetIds()) {
                    const id = visual.CurveEdge.simpleName(parentId, edgeId);
                    const definitelyAddEdge = 1;
                    map.set(id, definitelyAddEdge);
                }
            }

            selected.removeFace(view);
        }
        for (const [edgeId, count] of map) {
            if (count === 1) {
                const info = db.lookupTopologyItemById(edgeId);
                const edgeView = info.view as visual.CurveEdge;
                selected.addEdge(edgeView);
            }
        }
    }

    face2shell(view: visual.Face) {
        const { selection: { selected }, db } = this;
        selected.add(view.parentItem);
        selected.removeFace(view);
    }

    edge2solid(view: visual.CurveEdge) {
        const { selection: { selected }, db } = this;
        selected.add(view.parentItem);
        selected.removeEdge(view);
    }

    shell2face(view: visual.Shell) {
        const { selection: { selected }, db } = this;
        for (const faceView of view.faces) {
            selected.addFace(faceView);
        }
        selected.remove(view);
    }

    edge2face(view: visual.CurveEdge) {
        const { selection: { selected }, db } = this;
        const faces = edge2faces(view, db);
        for (const faceView of faces) {
            selected.addFace(faceView);
        }
        selected.removeEdge(view);
    }

    private shell2edge(view: visual.Shell) {
        const { selection: { selected }, db } = this;
        for (const edgeView of view.edges) {
            selected.addEdge(edgeView);
        }
        selected.remove(view);
    }
}

export class ConvertCommand extends cmd.CommandLike {
    constructor(
        editor: cmd.EditorLike,
        private readonly mode: SelectionMode
    ) {
        super(editor);
    }

    async execute(): Promise<void> {
        const { mode } = this;
        this.editor.changeSelection.onConvert(mode, ChangeSelectionModifier.Replace);
    }
}

export function edge2faces(view: visual.CurveEdge, db: ReadonlyGeometryDatabase) {
    const parentId = view.parentItem.simpleName;
    const model = db.lookupTopologyItem(view);
    const result = [];
    for (const face of model.GetFaces().GetIds()) {
        const faceId = visual.Face.simpleName(parentId, face);
        const info = db.lookupTopologyItemById(faceId);
        const faceView = info.view as visual.Face;
        result.push(faceView);
    }
    return result;
}