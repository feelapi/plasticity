// TODO:
// - Remove signals from this class and move signals to ChangeSelectionExecutor
//  - Ensure commands do not work with this class directly
import { CompositeDisposable, Disposable } from 'event-kit';
import { ReadonlyGeometryDatabase } from "../editor/DatabaseLike";
import { EditorSignals } from '../editor/EditorSignals';
import { Empty, EmptyId } from '../editor/Empties';
import { Group, GroupId } from '../editor/Groups';
import { MementoOriginator, SelectionMemento } from '../editor/History';
import MaterialDatabase from '../editor/MaterialDatabase';
import { Scene } from '../editor/Scene';
import * as signals from '../util/Signals';
import { assertUnreachable, Redisposable, RefCounter } from '../util/Util';
import * as visual from '../visual_model/VisualModel';
import { ParentItem } from './ChangeSelectionExecutor';
import { SelectionCache } from './SelectionCache';
import { SelectionMode, SelectionModeDefault, SelectionModeSet } from './SelectionModeSet';
import { CVSelection, EdgeSelection, EmptySelection, FaceSelection, GroupSelection, ItemSelection, RegionSelection, SegmentSelection, VertexSelection } from './TypedSelection';

export type Selectable =
    visual.Solid |
    visual.Sheet |
    visual.SpaceInstance |
    visual.Region |
    visual.Face |
    visual.CurveEdge |
    visual.CurveSegment |
    visual.Vertex |
    visual.CV |
    Group |
    Empty;

export interface HasSelection {
    readonly solids: ItemSelection<visual.Solid>;
    readonly items: ItemSelection<visual.Item>;
    readonly sheets: ItemSelection<visual.Sheet>;
    readonly shells: ItemSelection<visual.Shell>;
    readonly edges: EdgeSelection;
    readonly segments: SegmentSelection;
    readonly faces: FaceSelection;
    readonly regions: RegionSelection;
    readonly curves: ItemSelection<visual.SpaceInstance>;
    readonly vertices: VertexSelection;
    readonly cvs: CVSelection;
    readonly groups: GroupSelection;
    readonly empties: EmptySelection;
    has(item: Selectable): boolean;
    hasSelectedChildren(solid: visual.Solid | visual.Sheet | visual.SpaceInstance | visual.ItemId): boolean;

    cache(): SelectionCache;
    get parentWithSelectedChildrenIds(): ReadonlySet<visual.ItemId>;
    get itemIds(): ReadonlySet<visual.SolidId | visual.SheetId | visual.SpaceInstanceId>;
    get solidIds(): ReadonlySet<visual.SolidId>;
    get edgeIds(): ReadonlySet<visual.EdgeId>;
    get segmentIds(): ReadonlySet<visual.EdgeId>;
    get faceIds(): ReadonlySet<visual.FaceId>;
    get regionIds(): ReadonlySet<visual.RegionId>;
    get curveIds(): ReadonlySet<visual.SpaceInstanceId>;
    get vertexIds(): ReadonlySet<visual.VertexId>;
    get cvIds(): ReadonlySet<visual.CVId>;

    saveToMemento(): SelectionMemento;
}

export interface ModifiesSelection extends HasSelection {
    addById(mode: SelectionMode, parentId: visual.ItemId, simpleName: visual.TopologyId): void;
    addById(mode: SelectionMode, parentId: visual.ItemId, simpleName?: visual.TopologyId): void;
    addById(mode: SelectionMode, id: visual.ItemId): void;

    removeById(mode: SelectionMode, parentId: visual.ItemId, simpleName: visual.TopologyId): void;
    removeById(mode: SelectionMode, parentId: visual.ItemId, simpleName?: visual.TopologyId): void;
    removeById(mode: SelectionMode, id: visual.ItemId): void;

    add(items: Selectable | Selectable[]): void;
    remove(selectables: Selectable | Selectable[]): void;

    removeFace(object: visual.Face): void;
    addFace(object: visual.Face): void;

    removeRegion(object: visual.Region): void;
    addRegion(object: visual.Region): void;

    removeEdge(object: visual.CurveEdge): void;
    addEdge(object: visual.CurveEdge): void;

    removeSegment(object: visual.CurveSegment): void;
    addSegment(object: visual.CurveSegment): void;

    removeSolid(solid: visual.Solid): void;
    addSolid(solid: visual.Solid): void;

    removeSheet(sheet: visual.Sheet): void;
    addSheet(sheet: visual.Sheet): void;

    removeCurve(curve: visual.SpaceInstance): void;
    addCurve(curve: visual.SpaceInstance): void;

    removeVertex(index: visual.Vertex): void;
    addVertex(index: visual.Vertex): void;

    removeCV(index: visual.CV): void;
    addCV(index: visual.CV): void;

    removeGroup(group: Group): void;
    addGroup(group: Group): void;

    removeEmpty(empty: Empty): void;
    addEmpty(empty: Empty): void;

    deselectChildren(item: visual.Solid | visual.Sheet | visual.SpaceInstance): void;

    removeAll(): void;
    clearSilently(): void;
}

export interface SignalLike {
    selectionChanged: signals.Signal;
}

export class Selection implements HasSelection, ModifiesSelection, MementoOriginator<SelectionMemento> {
    readonly ids = new Set<SelectionKey>();

    private filter(...modes: SelectionMode[]): ReadonlySet<Id> {
        const filter = new Set(modes);
        const result: Set<Id> = new Set();
        for (const key of this.ids) {
            const [mode, id] = decodeId(key)
            if (!filter.has(mode)) continue;
            result.add(id);
        }
        return result;
    }

    cache(): SelectionCache { return new SelectionCache(this.ids, this.geo, this.scene) }
    get solidIds(): ReadonlySet<visual.SolidId> { return this.filter(SelectionMode.Solid) }
    get sheetIds(): ReadonlySet<visual.SheetId> { return this.filter(SelectionMode.Sheet) }
    get shellIds(): ReadonlySet<visual.SheetId | visual.SolidId> { return this.filter(SelectionMode.Sheet, SelectionMode.Solid) }
    get faceIds(): ReadonlySet<visual.FaceId> { return this.filter(SelectionMode.Face) }
    get regionIds(): ReadonlySet<visual.RegionId> { return this.filter(SelectionMode.Region) }
    get edgeIds(): ReadonlySet<visual.EdgeId> { return this.filter(SelectionMode.CurveEdge) }
    get segmentIds(): ReadonlySet<visual.EdgeId> { return this.filter(SelectionMode.CurveSegment) }
    get curveIds(): ReadonlySet<visual.SpaceInstanceId> { return this.filter(SelectionMode.Curve) }
    get vertexIds(): ReadonlySet<visual.VertexId> { return this.filter(SelectionMode.Vertex) }
    get cvIds(): ReadonlySet<visual.CVId> { return this.filter(SelectionMode.CV) }
    get groupIds(): ReadonlySet<GroupId> { return this.filter(SelectionMode.Group) }
    get emptyIds(): ReadonlySet<EmptyId> { return this.filter(SelectionMode.Empty) }
    get itemIds(): ReadonlySet<visual.SolidId | visual.SheetId | visual.SpaceInstanceId> { return this.filter(SelectionMode.Solid, SelectionMode.Sheet, SelectionMode.Curve) }
    get parentWithSelectedChildrenIds(): ReadonlySet<visual.ItemId> { return new Set(this.parentsWithSelectedChildren.keys()) }

    // selectedChildren is the set of solids that have actively selected topological items;
    // It's used in selection logic -- you can't select a solid if its face is already selected, for instance;
    // Further, when you delete a solid, if it has any selected faces, you need to unselect those faces as well.
    private readonly parentsWithSelectedChildren = new RefCounter<visual.ItemId>();

    constructor(
        readonly geo: ReadonlyGeometryDatabase,
        readonly scene: Scene,
        readonly signals: SignalLike
    ) { }

    get items() { return new ItemSelection<visual.Item>(this.geo, this.scene, this.itemIds) }
    get solids() { return new ItemSelection<visual.Solid>(this.geo, this.scene, this.solidIds) }
    get sheets() { return new ItemSelection<visual.Sheet>(this.geo, this.scene, this.sheetIds) }
    get shells() { return new ItemSelection<visual.Shell>(this.geo, this.scene, this.shellIds) }
    get edges() { return new EdgeSelection(this.geo, this.scene, this.edgeIds) }
    get segments() { return new SegmentSelection(this.geo, this.scene, this.segmentIds) }
    get faces() { return new FaceSelection(this.geo, this.scene, this.faceIds) }
    get regions() { return new RegionSelection(this.geo, this.scene, this.regionIds) }
    get curves() { return new ItemSelection<visual.SpaceInstance>(this.geo, this.scene, this.curveIds) }
    get vertices() { return new VertexSelection(this.geo, this.scene, this.vertexIds) }
    get cvs() { return new CVSelection(this.geo, this.scene, this.cvIds) }
    get groups() { return new GroupSelection(this.geo, this.scene, this.groupIds) }
    get empties() { return new EmptySelection(this.geo, this.scene, this.emptyIds) }

    hasSelectedChildren(item: visual.Solid | visual.Sheet | visual.SpaceInstance | visual.SketchIsland | visual.ItemId) {
        if (item instanceof visual.Item) {
            return this.parentsWithSelectedChildren.has(item.simpleName);
        } else {
            return this.parentsWithSelectedChildren.has(item);
        }
    }

    deselectChildren(item: visual.Solid | visual.Sheet | visual.SpaceInstance | visual.SketchIsland) {
        this.parentsWithSelectedChildren.delete(item.simpleName);
    }

    has(item: Selectable) {
        if (item instanceof visual.Solid) {
            return this.solids.has(item);
        } else if (item instanceof visual.Sheet) {
            return this.sheets.has(item);
        } else if (item instanceof visual.SpaceInstance) {
            return this.curves.has(item);
        } else if (item instanceof visual.Region) {
            return this.regions.has(item);
        } else if (item instanceof visual.Face) {
            return this.faces.has(item);
        } else if (item instanceof visual.CurveEdge) {
            return this.edges.has(item);
        } else if (item instanceof visual.CurveSegment) {
            return this.segments.has(item);
        } else if (item instanceof visual.Vertex) {
            return this.vertices.has(item);
        } else if (item instanceof visual.CV) {
            return this.cvs.has(item);
        } else if (item instanceof Group) {
            return this.groups.has(item);
        } else if (item instanceof Empty) {
            return this.empties.has(item);
        } else assertUnreachable(item);
    }

    addById(mode: SelectionMode, parentId: visual.ItemId, simpleName?: visual.TopologyId) {
        if (simpleName === undefined) {
            const encoded = encodeId(mode, parentId);
            this.ids.add(encoded);
        } else {
            const encoded = encodeId(mode, simpleName);
            this.ids.add(encoded);
            this.parentsWithSelectedChildren.incr(parentId, new Redisposable(() => this.ids.delete(encoded)));
        }
    }

    removeById(mode: SelectionMode, parentId: visual.ItemId, simpleName?: visual.TopologyId) {
        if (simpleName === undefined) {
            const encoded = encodeId(mode, parentId);
            this.ids.delete(encoded)
        } else {
            const encoded = encodeId(mode, simpleName);
            this.ids.delete(encoded);
            this.parentsWithSelectedChildren.decr(parentId);
        }
    }

    add(items: Selectable | Selectable[]) {
        if (!Array.isArray(items)) items = [items];
        for (const item of items) {
            if (item instanceof visual.Solid) {
                this.addSolid(item);
            } else if (item instanceof visual.Sheet) {
                this.addSheet(item);
            } else if (item instanceof visual.SpaceInstance) {
                this.addCurve(item);
            } else if (item instanceof visual.Region) {
                this.addRegion(item);
            } else if (item instanceof visual.Face) {
                this.addFace(item);
            } else if (item instanceof visual.CurveEdge) {
                this.addEdge(item);
            } else if (item instanceof visual.CurveSegment) {
                this.addSegment(item);
            } else if (item instanceof visual.Vertex) {
                this.addVertex(item);
            } else if (item instanceof visual.CV) {
                this.addCV(item);
            } else if (item instanceof Group) {
                this.addGroup(item);
            } else if (item instanceof Empty) {
                this.addEmpty(item);
            } else assertUnreachable(item);
        }
    }

    remove(selectables: Selectable | Selectable[]) {
        if (!(selectables instanceof Array)) selectables = [selectables];

        for (const selectable of selectables) {
            if (selectable instanceof visual.Solid) {
                this.removeSolid(selectable);
            } else if (selectable instanceof visual.Sheet) {
                this.removeSheet(selectable);
            } else if (selectable instanceof visual.SpaceInstance) {
                this.removeCurve(selectable);
            } else if (selectable instanceof visual.Region) {
                this.removeRegion(selectable);
            } else if (selectable instanceof visual.Face) {
                this.removeFace(selectable);
            } else if (selectable instanceof visual.CurveEdge) {
                this.removeEdge(selectable);
            } else if (selectable instanceof visual.CurveSegment) {
                this.removeSegment(selectable);
            } else if (selectable instanceof visual.Vertex) {
                this.removeVertex(selectable);
            } else if (selectable instanceof visual.CV) {
                this.removeCV(selectable);
            } else if (selectable instanceof Group) {
                this.removeGroup(selectable);
            } else if (selectable instanceof Empty) {
                this.removeEmpty(selectable);
            } else assertUnreachable(selectable);
        }
    }

    objectDeleted(item: visual.Solid | visual.Sheet | visual.SpaceInstance | visual.SketchIsland | Group | Empty) {
        if (item instanceof visual.Solid) {
            this.removeSolid(item);
            this.deselectChildren(item);
        } else if (item instanceof visual.Sheet) {
            this.removeSheet(item);
            this.deselectChildren(item);
        } else if (item instanceof visual.SpaceInstance) {
            this.removeCurve(item);
            this.deselectChildren(item);
        } else if (item instanceof visual.SketchIsland) {
            this.deselectChildren(item);
        } else if (item instanceof Group) {
            this.removeGroup(item);
        } else if (item instanceof Empty) {
            this.removeEmpty(item);
        } else assertUnreachable(item);
    }

    removeFace(face: visual.Face) {
        const id = encodeId(SelectionMode.Face, face.simpleName);
        if (!this.ids.has(id)) return;
        const parentItem = face.parentItem;

        this.ids.delete(id);
        this.parentsWithSelectedChildren.decr(parentItem.simpleName);
        this.signals.selectionChanged.dispatch();
    }

    addFace(face: visual.Face) {
        const id = encodeId(SelectionMode.Face, face.simpleName);
        if (this.ids.has(id)) return;
        const parentItem = face.parentItem;

        this.ids.add(id);
        this.parentsWithSelectedChildren.incr(parentItem.simpleName,
            new Redisposable(() => this.ids.delete(id)));
        this.signals.selectionChanged.dispatch();
    }

    removeRegion(region: visual.Region) {
        const id = encodeId(SelectionMode.Region, region.simpleName);
        if (!this.ids.has(id)) return;

        this.ids.delete(id);
        this.parentsWithSelectedChildren.decr(region.parentItem.simpleName);
        this.signals.selectionChanged.dispatch();
    }

    addRegion(region: visual.Region) {
        const id = encodeId(SelectionMode.Region, region.simpleName);
        if (this.ids.has(id)) return;
        const parentItem = region.parentItem;

        this.ids.add(id);
        this.parentsWithSelectedChildren.incr(parentItem.simpleName,
            new Redisposable(() => this.ids.delete(id)));
        this.signals.selectionChanged.dispatch();
    }

    removeEdge(edge: visual.CurveEdge) {
        const id = encodeId(SelectionMode.CurveEdge, edge.simpleName);
        if (!this.ids.has(id)) return;
        const parentItem = edge.parentItem;

        this.ids.delete(id);
        this.parentsWithSelectedChildren.decr(parentItem.simpleName);
        this.signals.selectionChanged.dispatch();
    }

    addEdge(edge: visual.CurveEdge) {
        const id = encodeId(SelectionMode.CurveEdge, edge.simpleName);
        if (this.ids.has(id)) return;
        const parentItem = edge.parentItem;

        this.ids.add(id);
        this.parentsWithSelectedChildren.incr(parentItem.simpleName,
            new Redisposable(() => this.ids.delete(id))
        );
        this.signals.selectionChanged.dispatch();
    }

    removeSegment(segment: visual.CurveSegment) {
        const id = encodeId(SelectionMode.CurveSegment, segment.simpleName);
        if (!this.ids.has(id)) return;
        const parentItem = segment.parentItem;

        this.ids.delete(id);
        this.parentsWithSelectedChildren.decr(parentItem.simpleName);
        this.signals.selectionChanged.dispatch();
    }

    addSegment(segment: visual.CurveSegment) {
        const id = encodeId(SelectionMode.CurveSegment, segment.simpleName);
        if (this.ids.has(id)) return;
        const parentItem = segment.parentItem;

        this.ids.add(id);
        this.parentsWithSelectedChildren.incr(parentItem.simpleName,
            new Redisposable(() => this.ids.delete(id))
        );
        this.signals.selectionChanged.dispatch();
    }

    removeSolid(solid: visual.Solid) {
        const id = encodeId(SelectionMode.Solid, solid.simpleName);
        if (!this.ids.has(id)) return;

        this.ids.delete(id);
        this.signals.selectionChanged.dispatch();
    }

    addSolid(solid: visual.Solid) {
        const id = encodeId(SelectionMode.Solid, solid.simpleName);
        if (this.ids.has(id)) return;

        this.ids.add(id);
        this.signals.selectionChanged.dispatch();
    }

    removeSheet(sheet: visual.Sheet) {
        const id = encodeId(SelectionMode.Sheet, sheet.simpleName);
        if (!this.ids.has(id)) return;

        this.ids.delete(id);
        this.signals.selectionChanged.dispatch();
    }

    addSheet(sheet: visual.Sheet) {
        const id = encodeId(SelectionMode.Sheet, sheet.simpleName);
        if (this.ids.has(id)) return;

        this.ids.add(id);
        this.signals.selectionChanged.dispatch();
    }

    removeCurve(curve: visual.SpaceInstance) {
        const id = encodeId(SelectionMode.Curve, curve.simpleName);
        if (!this.ids.has(id)) return;

        this.ids.delete(id);
        this.signals.selectionChanged.dispatch();
    }

    addCurve(curve: visual.SpaceInstance) {
        const id = encodeId(SelectionMode.Curve, curve.simpleName);
        if (this.ids.has(id)) return;

        this.ids.add(id);
        this.signals.selectionChanged.dispatch();
    }

    addVertex(vertex: visual.Vertex) {
        const id = encodeId(SelectionMode.Vertex, vertex.simpleName);
        if (this.ids.has(id)) return;
        const parentItem = vertex.parentItem;

        this.ids.add(id);
        this.parentsWithSelectedChildren.incr(parentItem.simpleName,
            new Redisposable(() => this.ids.delete(id)));
        this.signals.selectionChanged.dispatch();
    }

    removeVertex(vertex: visual.Vertex) {
        const id = encodeId(SelectionMode.Vertex, vertex.simpleName);
        if (!this.ids.has(id)) return;
        const parentItem = vertex.parentItem;

        this.ids.delete(id);
        this.parentsWithSelectedChildren.decr(parentItem.simpleName);
        this.signals.selectionChanged.dispatch();
    }

    addCV(cv: visual.CV) {
        const id = encodeId(SelectionMode.CV, cv.simpleName);
        if (this.ids.has(id)) return;
        const parentItem = cv.parentItem;

        this.ids.add(id);
        this.parentsWithSelectedChildren.incr(parentItem.simpleName,
            new Redisposable(() => this.ids.delete(id)));
        this.signals.selectionChanged.dispatch();
    }

    removeCV(cv: visual.CV) {
        const id = encodeId(SelectionMode.CV, cv.simpleName);
        if (!this.ids.has(id)) return;
        const parentItem = cv.parentItem;

        this.ids.delete(id);
        this.parentsWithSelectedChildren.decr(parentItem.simpleName);
        this.signals.selectionChanged.dispatch();
    }

    removeGroup(group: Group) {
        const id = encodeId(SelectionMode.Group, group.simpleName);
        if (!this.ids.has(id)) return;

        this.ids.delete(id);
        this.signals.selectionChanged.dispatch();
    }

    addGroup(group: Group) {
        const id = encodeId(SelectionMode.Group, group.simpleName);
        if (this.ids.has(id)) return;

        this.ids.add(id);
        this.signals.selectionChanged.dispatch();
    }

    removeEmpty(empty: Empty) {
        const id = encodeId(SelectionMode.Empty, empty.simpleName);
        if (!this.ids.has(id)) return;

        this.ids.delete(id);
        this.signals.selectionChanged.dispatch();
    }

    addEmpty(empty: Empty) {
        const id = encodeId(SelectionMode.Empty, empty.simpleName);
        if (this.ids.has(id)) return;

        this.ids.add(id);
        this.signals.selectionChanged.dispatch();
    }

    removeAll(): void {
        const old = new Set(this.ids);
        this.parentsWithSelectedChildren.clear();
        this.ids.clear();
        if (old.size > 0) this.signals.selectionChanged.dispatch();
    }

    clearSilently() {
        this.ids.clear();
        this.parentsWithSelectedChildren.clear();
    }

    copy(that: HasSelection, ...modes: SelectionMode[]): this {
        const memento = that.saveToMemento();
        this.restoreFromMemento(memento);
        if (modes.length > 0) {
            const filter = new Set(modes);
            const oldIds = [...this.ids];
            this.ids.clear();
            for (const key of oldIds) {
                const [mode, id] = decodeId(key)
                if (!filter.has(mode)) continue;
                this.ids.add(key);
            }
            // FIXME: this clearly leaves parentsWithSelectedChildren in an incoherent state
        }
        return this;
    }

    saveToMemento() {
        return new SelectionMemento(
            new Set(this.ids),
            new RefCounter(this.parentsWithSelectedChildren),
        );
    }

    restoreFromMemento(m: SelectionMemento) {
        (this.ids as Selection['ids']) = new Set(m.ids);
        (this.parentsWithSelectedChildren as Selection['parentsWithSelectedChildren']) = new RefCounter(m.parentsWithSelectedChildren);

        this.signals.selectionChanged.dispatch();
    }

    clear() {
        this.ids.clear();
        this.parentsWithSelectedChildren.clear();
    }

    validate() {
        for (const id of this.solidIds) {
            console.assert(this.geo.lookupItemById(id) !== undefined, "solid is in database", id);
        }
        for (const id of this.sheetIds) {
            console.assert(this.geo.lookupItemById(id) !== undefined, "sheet is in database", id);
        }
        for (const id of this.edgeIds) {
            console.assert(this.geo.lookupTopologyItemById(id) !== undefined);
        }
        for (const id of this.segmentIds) {
            console.assert(this.geo.lookupTopologyItemById(id) !== undefined);
        }
        for (const id of this.faceIds) {
            console.assert(this.geo.lookupTopologyItemById(id) !== undefined);
        }
        for (const id of this.curveIds) {
            console.assert(this.geo.lookupItemById(id) !== undefined, "curve is in database", id);
        }
        for (const id of this.regionIds) {
            console.assert(this.geo.lookupTopologyItemById(id) !== undefined, "region is in database", id);
        }
        for (const id of this.vertexIds) {
            console.assert(this.geo.lookupTopologyItemById(id) !== undefined, "vertex is in database", id);
        }
        for (const id of this.groupIds) {
            console.assert(this.groups.lookupById(id) !== undefined, "group is in database", id);
        }
        for (const id of this.emptyIds) {
            console.assert(this.empties.lookupById(id) !== undefined, "empty is in database", id);
        }
        for (const id of this.parentsWithSelectedChildren.keys()) {
            console.assert(this.geo.lookupItemById(id) !== undefined, "parent is in database", id);
        }
    }

    debug() {
        console.group("SelectionDatabase");
        console.group("solidIds");
        console.table([...this.solidIds]);
        console.groupEnd();
        console.group("sheetIds");
        console.table([...this.sheetIds]);
        console.groupEnd();
        console.group("edgeIds");
        console.table([...this.edgeIds]);
        console.groupEnd();
        console.group("segmentIds");
        console.table([...this.segmentIds]);
        console.groupEnd();
        console.group("faceIds");
        console.table([...this.faceIds]);
        console.groupEnd();
        console.group("curveIds");
        console.table([...this.curveIds]);
        console.groupEnd();
        console.group("regionIds");
        console.table([...this.regionIds]);
        console.groupEnd();
        console.group("vertexIds");
        console.table([...this.vertexIds]);
        console.groupEnd();
        console.group("cvIds");
        console.table([...this.cvIds]);
        console.groupEnd();
        console.group("groupIds");
        console.table([...this.groupIds]);
        console.groupEnd();
        console.group("emptyIds");
        console.table([...this.emptyIds]);
        console.groupEnd();
        console.groupEnd();
    }
}

export interface HasSelectedAndHovered {
    readonly mode: SelectionModeSet;
    readonly selected: ModifiesSelection;
    readonly hovered: ModifiesSelection;
    makeTemporary(): SelectionDatabase;
    copy(that: HasSelectedAndHovered, ...modes: SelectionMode[]): this;
    delta(that: HasSelectedAndHovered): { hoveredAdded: Set<ParentItem>, hoveredRemoved: Set<ParentItem>, selectedAdded: Set<ParentItem>, selectedRemoved: Set<ParentItem> };
    signals: EditorSignals;
}

export class SelectionDatabase implements HasSelectedAndHovered {
    private readonly disposable = new CompositeDisposable();
    dispose() { this.disposable.dispose() }

    private readonly selectedSignals: SignalLike = {
        selectionChanged: this.signals.selectionChanged
    }
    private readonly hoveredSignals: SignalLike = {
        selectionChanged: this.signals.hoverChanged
    }
    readonly selected = new Selection(this.geo, this.scene, this.selectedSignals);
    readonly hovered = new Selection(this.geo, this.scene, this.hoveredSignals);

    constructor(
        private readonly geo: ReadonlyGeometryDatabase,
        private readonly scene: Scene,
        private readonly materials: MaterialDatabase,
        readonly signals: EditorSignals,
        readonly mode = new SelectionModeSet(SelectionModeDefault, signals),
    ) {
        const historyChanged = signals.historyChanged.add(this.clearHovered);
        const commandStarted = signals.commandStarted.add(this.clearHovered);
        const backupLoaded = signals.backupLoaded.add(this.clearHovered);
        this.disposable.add(new Disposable(() => {
            historyChanged.detach();
            commandStarted.detach();
            backupLoaded.detach();
        }));
    }

    // Hover state is not preserved in undo history. So when the user performs undo/redo
    // the data could potentially be invalid. Hover state is volatile. Just clear it without
    // any notifications.
    private clearHovered = () => { this.hovered.clearSilently() }

    makeTemporary(): SelectionDatabase {
        const signals = new EditorSignals();
        return new SelectionDatabase(this.geo, this.scene, this.materials, signals, new SelectionModeSet([], signals))
    }

    copy(that: HasSelectedAndHovered, ...modes: SelectionMode[]) {
        this.selected.copy(that.selected, ...modes);
        this.hovered.copy(that.hovered, ...modes);
        return this;
    }

    delta(before: SelectionDatabase): { hoveredAdded: Set<ParentItem>; hoveredRemoved: Set<ParentItem>; selectedAdded: Set<ParentItem>; selectedRemoved: Set<ParentItem>; } {
        const beforeSelectedIds = before.selected.ids;
        const beforeHoveredIds = before.hovered.ids;
        const afterSelectedIds = this.selected.ids;
        const afterHoveredIds = this.hovered.ids;

        const selectedAddedIds = new Set<SelectionKey>();
        const selectedRemovedIds = new Set<SelectionKey>();
        const hoveredAddedIds = new Set<SelectionKey>();
        const hoveredRemovedIds = new Set<SelectionKey>();

        for (const id of beforeSelectedIds) {
            if (!afterSelectedIds.has(id)) {
                selectedRemovedIds.add(id);
            }
        }
        for (const id of afterSelectedIds) {
            if (!beforeSelectedIds.has(id)) {
                selectedAddedIds.add(id);
            }
        }
        for (const id of beforeHoveredIds) {
            if (!afterHoveredIds.has(id)) {
                hoveredRemovedIds.add(id);
            }
        }
        for (const id of afterHoveredIds) {
            if (!beforeHoveredIds.has(id)) {
                hoveredAddedIds.add(id);
            }
        }

        const selectedAdded = new Set<ParentItem>();
        const selectedRemoved = new Set<ParentItem>();
        const hoveredAdded = new Set<ParentItem>();
        const hoveredRemoved = new Set<ParentItem>();

        for (const id of selectedAddedIds) {
            selectedAdded.add(this.loadParent(id));
        }
        for (const id of selectedRemovedIds) {
            selectedRemoved.add(this.loadParent(id));
        }
        for (const id of hoveredAddedIds) {
            hoveredAdded.add(this.loadParent(id));
        }
        for (const id of hoveredRemovedIds) {
            hoveredRemoved.add(this.loadParent(id));
        }

        return { hoveredAdded, hoveredRemoved, selectedAdded, selectedRemoved };
    }

    private loadParent(key: SelectionKey): ParentItem {
        const { geo, scene } = this;
        const [mode, simpleName] = decodeId(key);

        let parentId: visual.ItemId;
        switch (mode) {
            case SelectionMode.Solid: return geo.lookupItemById(simpleName as visual.SolidId).view as visual.Solid;
            case SelectionMode.Sheet: return geo.lookupItemById(simpleName as visual.SheetId).view as visual.Sheet;
            case SelectionMode.Curve: return geo.lookupItemById(simpleName as visual.SpaceInstanceId).view as visual.SpaceInstance;
            case SelectionMode.Group: return scene.lookupGroupById(simpleName as GroupId);
            case SelectionMode.Empty: return scene.lookupEmptyById(simpleName as EmptyId);

            case SelectionMode.Region:
                parentId = visual.Region.parentId(simpleName);
                return geo.lookupItemById(parentId).view as visual.SketchIsland;
            case SelectionMode.Face:
                parentId = visual.Face.parentId(simpleName);
                return geo.lookupItemById(parentId).view as visual.Solid;
            case SelectionMode.CurveEdge:
                parentId = visual.CurveEdge.parentId(simpleName);
                return geo.lookupItemById(parentId).view as visual.Solid | visual.Sheet;
            case SelectionMode.CurveSegment:
                parentId = visual.CurveSegment.parentId(simpleName);
                return geo.lookupItemById(parentId).view as visual.SpaceInstance;
            case SelectionMode.Vertex:
                parentId = visual.Vertex.parentId(simpleName);
                return geo.lookupItemById(parentId).view as visual.SpaceInstance;
            case SelectionMode.CV:
                parentId = visual.CV.parentId(simpleName);
                return geo.lookupItemById(parentId).view as visual.SpaceInstance;
            case SelectionMode.Shell: throw new Error('Invalid mode: Shell');
            default: assertUnreachable(mode);
        }
    }
}

// type Key = bigint;
// type Id = number;

// function encodeId(type: SelectionMode, id: Id): Key {
//     return BigInt(type) << BigInt(53) | BigInt(id);
// }

// function decodeId(encoded: Key): [SelectionMode, Id] {
//     const type = Number(encoded >> BigInt(53));
//     const id = Number(encoded & BigInt(0x1fffffffffffff));
//     return [type, id];
// }

export type SelectionKey = string;
type Id = any;

function encodeId(type: SelectionMode, id: Id): SelectionKey {
    return `${type}:${id}`;
}

export function decodeId(encoded: SelectionKey): [SelectionMode, Id] {
    const [typeString, idString] = encoded.split(":");
    const type = parseInt(typeString) as SelectionMode;
    switch (type) {
        case SelectionMode.Solid:
        case SelectionMode.Sheet:
        case SelectionMode.Curve:
        case SelectionMode.Empty:
        case SelectionMode.Group:
            return [type, parseInt(idString)];
        case SelectionMode.Region:
        case SelectionMode.CurveEdge:
        case SelectionMode.CurveSegment:
        case SelectionMode.Face:
        case SelectionMode.Vertex:
        case SelectionMode.CV:
            return [type, idString];
        case SelectionMode.Shell:
            throw new Error("Shell is not a valid selection mode");
        default: assertUnreachable(type);
    }
}
