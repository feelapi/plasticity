import { Empty, EmptyId } from '../editor/Empties';
import { Group, GroupId } from '../editor/Groups';
import { assertUnreachable } from '../util/Util';
import * as visual from '../visual_model/VisualModel';
import { Selectable } from './SelectionDatabase';


export class SelectionAccumulator {
    readonly solidIds = new Set<visual.SolidId>();
    readonly sheetIds = new Set<visual.SheetId>();
    readonly edgeIds = new Set<visual.EdgeId>();
    readonly segmentIds = new Set<visual.EdgeId>();
    readonly faceIds = new Set<visual.FaceId>();
    readonly curveIds = new Set<visual.SpaceInstanceId>();
    readonly regionIds = new Set<visual.RegionId>();
    readonly vertexIds = new Set<visual.VertexId>();
    readonly cvIds = new Set<visual.CVId>();
    readonly groupIds = new Set<GroupId>();
    readonly emptyIds = new Set<EmptyId>();

    constructor(items: Iterable<Selectable> = []) {
        for (const item of items) {
            if (item instanceof visual.Solid) {
                this.solidIds.add(item.simpleName);
            } else if (item instanceof visual.Sheet) {
                this.sheetIds.add(item.simpleName);
            } else if (item instanceof visual.SpaceInstance) {
                this.curveIds.add(item.simpleName);
            } else if (item instanceof visual.Region) {
                this.regionIds.add(item.simpleName);
            } else if (item instanceof visual.Face) {
                this.faceIds.add(item.simpleName);
            } else if (item instanceof visual.CurveEdge) {
                this.edgeIds.add(item.simpleName);
            } else if (item instanceof visual.CurveSegment) {
                this.segmentIds.add(item.simpleName);
            } else if (item instanceof visual.Vertex) {
                this.vertexIds.add(item.simpleName);
            } else if (item instanceof visual.CV) {
                this.cvIds.add(item.simpleName);
            } else if (item instanceof Group) {
                this.groupIds.add(item.simpleName);
            } else if (item instanceof Empty) {
                this.emptyIds.add(item.simpleName);
            } else assertUnreachable(item);
        }
    }

    get size() {
        return this.solidIds.size + this.sheetIds.size + this.edgeIds.size + this.segmentIds.size + this.faceIds.size + this.curveIds.size + this.regionIds.size + this.vertexIds.size + this.cvIds.size + this.groupIds.size + this.emptyIds.size;
    }
}
