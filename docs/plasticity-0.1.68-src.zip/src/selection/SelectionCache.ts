import { ReadonlyGeometryDatabase } from "../editor/DatabaseLike";
import { Empty, EmptyId } from '../editor/Empties';
import { Group, GroupId } from '../editor/Groups';
import { SelectionMemento } from '../editor/History';
import { Scene } from '../editor/Scene';
import { assertUnreachable } from '../util/Util';
import * as visual from '../visual_model/VisualModel';
import { decodeId, HasSelection, Selectable, SelectionKey } from './SelectionDatabase';
import { SelectionMode } from './SelectionModeSet';
import { CVSelection, EdgeSelection, EmptySelection, FaceSelection, GroupSelection, ItemSelection, RegionSelection, SegmentSelection, VertexSelection } from './TypedSelection';
import * as c3d from '../kernel/kernel';

export class SelectionCache implements HasSelection {
    private readonly _solidIds: Set<visual.SolidId> = new Set();
    private readonly _sheetIds: Set<visual.SheetId> = new Set();
    private readonly _edgeIds: Set<visual.EdgeId> = new Set();
    private readonly _segmentIds: Set<visual.EdgeId> = new Set();
    private readonly _faceIds: Set<visual.FaceId> = new Set();
    private readonly _curveIds: Set<visual.SpaceInstanceId> = new Set();
    private readonly _regionIds: Set<visual.RegionId> = new Set();
    private readonly _vertexIds: Set<visual.VertexId> = new Set();
    private readonly _cvIds: Set<visual.CVId> = new Set();
    private readonly _groupIds: Set<GroupId> = new Set();
    private readonly _emptyIds: Set<EmptyId> = new Set();

    private readonly _facesForShell: Map<visual.SolidId, c3d.FaceId[]> = new Map();
    private readonly _edgesForShell: Map<visual.SolidId, c3d.EdgeId[]> = new Map();
    private readonly _regionsForIsland: Map<visual.SketchIslandId, c3d.FaceId[]> = new Map();
    private readonly _segmentsForCurve: Map<visual.SpaceInstanceId, c3d.EdgeId[]> = new Map();

    cache(): SelectionCache { return this }

    constructor(keys: Set<SelectionKey>, private readonly db: ReadonlyGeometryDatabase, private readonly scene: Scene) {
        for (const key of keys) {
            const [mode, id] = decodeId(key);
            switch (mode) {
                case SelectionMode.Solid: this._solidIds.add(id); break;
                case SelectionMode.Sheet: this._sheetIds.add(id); break;
                case SelectionMode.Curve: this._curveIds.add(id); break;
                case SelectionMode.CurveSegment: {
                    this._segmentIds.add(id);
                    const [_, parentId, entityId] = visual.CurveSegment.decompose(id);
                    let segments = this._segmentsForCurve.get(parentId);
                    if (segments === undefined) this._segmentsForCurve.set(parentId, segments = []);
                    segments.push(entityId);
                    break;
                }
                case SelectionMode.CurveEdge: {
                    this._edgeIds.add(id);
                    const [_, parentId, entityId] = visual.CurveEdge.decompose(id);
                    let edges = this._edgesForShell.get(parentId);
                    if (edges === undefined) this._edgesForShell.set(parentId, edges = []);
                    edges.push(entityId);
                    break;
                }
                case SelectionMode.Face: {
                    this._faceIds.add(id);
                    const [_, parentId, entityId] = visual.Face.decompose(id);
                    let faces = this._facesForShell.get(parentId);
                    if (faces === undefined) this._facesForShell.set(parentId, faces = []);
                    faces.push(entityId);
                    break;
                }
                case SelectionMode.Region: {
                    this._regionIds.add(id);
                    const [_, parentId, entityId] = visual.Region.decompose(id);
                    let regions = this._regionsForIsland.get(parentId);
                    if (regions === undefined) this._regionsForIsland.set(parentId, regions = []);
                    regions.push(entityId);
                    break;
                }
                case SelectionMode.Vertex: {
                    this._vertexIds.add(id);
                    break;
                }
                case SelectionMode.CV: {
                    this._cvIds.add(id);
                    break;
                }
                case SelectionMode.Group: this._groupIds.add(id); break;
                case SelectionMode.Empty: this._emptyIds.add(id); break;
                case SelectionMode.Shell: throw new Error("Shell is not a valid selection mode");
                default: assertUnreachable(mode);
            }
        }
    }

    get solidIds(): ReadonlySet<visual.SolidId> { return this._solidIds; }
    get sheetIds(): ReadonlySet<visual.SheetId> { return this._sheetIds; }
    get edgeIds(): ReadonlySet<visual.EdgeId> { return this._edgeIds; }
    get segmentIds(): ReadonlySet<visual.EdgeId> { return this._segmentIds; }
    get faceIds(): ReadonlySet<visual.FaceId> { return this._faceIds; }
    get curveIds(): ReadonlySet<visual.SpaceInstanceId> { return this._curveIds; }
    get regionIds(): ReadonlySet<visual.RegionId> { return this._regionIds; }
    get vertexIds(): ReadonlySet<visual.VertexId> { return this._vertexIds; }
    get cvIds(): ReadonlySet<visual.CVId> { return this._cvIds; }
    get groupIds(): ReadonlySet<GroupId> { return this._groupIds; }
    get emptyIds(): ReadonlySet<EmptyId> { return this._emptyIds; }

    get itemIds(): ReadonlySet<visual.ItemId> { return new Set([...this.solidIds, ...this.sheetIds, ...this.curveIds]); }
    get shellIds(): ReadonlySet<visual.ShellId> { return new Set([...this.solidIds, ...this.sheetIds]); }

    get items() { return new ItemSelection<visual.Item>(this.db, this.scene, this.itemIds); }
    get solids() { return new ItemSelection<visual.Solid>(this.db, this.scene, this.solidIds); }
    get sheets() { return new ItemSelection<visual.Sheet>(this.db, this.scene, this.sheetIds); }
    get shells() { return new ItemSelection<visual.Shell>(this.db, this.scene, this.shellIds); }
    get edges() { return new EdgeSelection(this.db, this.scene, this.edgeIds); }
    get segments() { return new SegmentSelection(this.db, this.scene, this.segmentIds); }
    get faces() { return new FaceSelection(this.db, this.scene, this.faceIds); }
    get regions() { return new RegionSelection(this.db, this.scene, this.regionIds); }
    get curves() { return new ItemSelection<visual.SpaceInstance>(this.db, this.scene, this.curveIds); }
    get vertices() { return new VertexSelection(this.db, this.scene, this.vertexIds); }
    get cvs() { return new CVSelection(this.db, this.scene, this.cvIds); }
    get groups() { return new GroupSelection(this.db, this.scene, this.groupIds); }
    get empties() { return new EmptySelection(this.db, this.scene, this.emptyIds); }

    has(item: Selectable): boolean {
        if (item instanceof visual.Solid)
            return this._solidIds.has(item.simpleName);
        if (item instanceof visual.Sheet)
            return this._sheetIds.has(item.simpleName);
        if (item instanceof visual.SpaceInstance)
            return this._curveIds.has(item.simpleName);
        if (item instanceof visual.Region)
            return this._regionIds.has(item.simpleName);
        if (item instanceof visual.Edge)
            return this._edgeIds.has(item.simpleName);
        if (item instanceof visual.Face)
            return this._faceIds.has(item.simpleName);
        if (item instanceof visual.Vertex)
            return this._vertexIds.has(item.simpleName);
        if (item instanceof visual.CV)
            return this._cvIds.has(item.simpleName);
        if (item instanceof Group)
            return this._groupIds.has(item.simpleName);
        if (item instanceof Empty)
            return this._emptyIds.has(item.simpleName);

        assertUnreachable(item);
    }

    facesForShell(shell: visual.Shell): c3d.FaceId[] {
        return this._facesForShell.get(shell.simpleName) || [];
    }

    edgesForShell(shell: visual.Shell): c3d.EdgeId[] {
        return this._edgesForShell.get(shell.simpleName) || [];
    }

    regionsForIsland(island: visual.SketchIsland): c3d.FaceId[] {
        return this._regionsForIsland.get(island.simpleName) || [];
    }

    segmentsForCurve(curve: visual.SpaceInstance): c3d.EdgeId[] {
        return this._segmentsForCurve.get(curve.simpleName) || [];
    }

    hasSelectedChildren(solid: visual.SpaceInstance | visual.Solid | visual.Sheet): boolean {
        throw new Error('Method not implemented.');
    }
    get parentWithSelectedChildrenIds(): ReadonlySet<visual.ItemId> {
        throw new Error('Method not implemented.');
    }
    saveToMemento(): SelectionMemento {
        throw new Error('Method not implemented.');
    }
}
