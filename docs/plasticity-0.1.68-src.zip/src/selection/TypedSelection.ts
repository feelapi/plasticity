import { ReadonlyGeometryDatabase } from "../editor/DatabaseLike";
import { Empty, EmptyId } from '../editor/Empties';
import { Group, GroupId } from '../editor/Groups';
import { Scene } from '../editor/Scene';
import * as c3d from '../kernel/kernel';
import { GConstructor } from '../util/Util';
import * as visual from '../visual_model/VisualModel';
import { Selectable } from './SelectionDatabase';

export abstract class TypedSelection<T extends Selectable, S> {
    size: number;

    constructor(
        protected readonly geo: ReadonlyGeometryDatabase,
        protected readonly scene: Scene,
        readonly ids: ReadonlySet<S>
    ) {
        this.size = ids.size;
    }

    *[Symbol.iterator]() {
        for (const id of this.ids) {
            yield this.lookupById(id) as T;
        }
    }

    // FIXME: : T | undefined
    get first() { return this[Symbol.iterator]().next().value as T }
    get last(): T | undefined {
        if (this.ids.size < 1) return;
        const lastId = [...this.ids][this.ids.size - 1];
        return this.lookupById(lastId);
    }

    has(s: T) { return this.ids.has(s.simpleName as unknown as any) }
    hasId(id: S) { return this.ids.has(id) }

    abstract lookupById(id: S): T;

    concat(that: this): this {
        return new (this.constructor as GConstructor<this>)(this.geo, new Set([...this.ids, ...that.ids]));
    }

    clone() {
        return new (this.constructor as GConstructor<this>)(this.geo, new Set([...this.ids]));
    }
}

export class ItemSelection<T extends visual.Item> extends TypedSelection<T, visual.ItemId> {
    lookupById(id: visual.ItemId) {
        return this.geo.lookupItemById(id).view as T;
    }

    get models() {
        const result = [];
        for (const id of this.ids) {
            result.push(this.geo.lookupItemById(id).model);
        }
        return result;
    }
}

abstract class TopologyItemSelection<
    T extends visual.Face | visual.Region | visual.CurveEdge | visual.CurveSegment | visual.Vertex,
    C extends c3d.VertexCollection | c3d.FaceCollection | c3d.EdgeCollection,
    > extends TypedSelection<T, visual.TopologyId>
{
    lookupById(id: visual.TopologyId) {
        return this.geo.lookupTopologyItemById(id).view as T;
    }

    abstract get collection(): C;
}

export class FaceSelection extends TopologyItemSelection<visual.Face, c3d.FaceCollection> {
    get collection() {
        const result = [];
        for (const id of this.ids) {
            result.push(this.geo.lookupTopologyItemById(id).model);
        }
        return new c3d.FaceCollection(result.map(m => m.Id()));
    }
}

export class RegionSelection extends TopologyItemSelection<visual.Region, c3d.FaceCollection> {
    get collection() {
        const result = [];
        for (const id of this.ids) {
            result.push(this.geo.lookupTopologyItemById(id).model);
        }
        return new c3d.FaceCollection(result.map(m => m.Id()));
    }
}

export class EdgeSelection extends TopologyItemSelection<visual.CurveEdge, c3d.EdgeCollection> {
    get collection() {
        const result = [];
        for (const id of this.ids) {
            result.push(this.geo.lookupTopologyItemById(id).model);
        }
        return new c3d.EdgeCollection(result.map(m => m.Id()));
    }
}

export class SegmentSelection extends TopologyItemSelection<visual.CurveSegment, c3d.EdgeCollection> {
    get collection() {
        const result = [];
        for (const id of this.ids) {
            result.push(this.geo.lookupTopologyItemById(id).model);
        }
        return new c3d.EdgeCollection(result.map(m => m.Id()));
    }
}


export class VertexSelection extends TopologyItemSelection<visual.Vertex, c3d.VertexCollection> {
    get collection() {
        const result = [];
        for (const id of this.ids) {
            result.push(this.geo.lookupTopologyItemById(id).model);
        }
        return new c3d.VertexCollection(result.map(m => m.Id()));
    }
}

export class CVSelection extends TypedSelection<visual.CV, visual.CVId> {
    lookupById(id: visual.CVId) {
        return this.geo.lookupCVById(id).view;
    }
}

export class GroupSelection extends TypedSelection<Group, GroupId> {
    lookupById(id: GroupId) {
        return this.scene.lookupGroupById(id);
    }
}

export class EmptySelection extends TypedSelection<Empty, EmptyId> {
    lookupById(id: EmptyId) {
        return this.scene.lookupEmptyById(id);
    }
}

export type SolidSelection = ItemSelection<visual.Solid>;
export type SheetSelection = ItemSelection<visual.Sheet>;
export type ShellSelection = ItemSelection<visual.Shell>;
export type CurveSelection = ItemSelection<visual.SpaceInstance>;
