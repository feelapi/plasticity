// TODO:
// - [ ] Move all signals from SelectionDatabase into here, and ensure that commands use this rather than modifying the selction directly.
import { ReadonlyPlanarCurveDatabase } from '../editor/curves/PlanarCurveDatabase';
import { ReadonlySketchManager } from '../editor/curves/SketchManager';
import { ReadonlyGeometryDatabase } from '../editor/DatabaseLike';
import { EditorSignals } from '../editor/EditorSignals';
import { Empty } from "../editor/Empties";
import { Group } from "../editor/Groups";
import { RealNodeItem } from "../editor/Nodes";
import { Scene } from "../editor/Scene";
import { assertUnreachable } from "../util/Util";
import { Intersectable, Intersection } from "../visual_model/Intersectable";
import { CurveEdge, CurveSegment, CV, Face, Region, Sheet, Shell, SketchIsland, Solid, SpaceInstance, Vertex } from '../visual_model/VisualModel';
import { ClickStrategy, HoverStrategy } from './Click';
import { SelectionAccumulator } from './SelectionAccumulator';
import { SelectionConversionStrategy } from "./SelectionConversionStrategy";
import { HasSelectedAndHovered, Selectable, Selection } from './SelectionDatabase';
import { SelectionMode } from "./SelectionModeSet";

export enum ChangeSelectionModifier {
    Replace, Add, Remove, Toggle
}

export enum ChangeSelectionOption {
    None = 0,
    IgnoreMode = 1 << 0,
    Extend = 1 << 1,
    ExtendAlt = 1 << 2,
}

const includeEverything = (_: Selectable): true => true;

export class ChangeSelectionExecutor {
    private readonly conversionStrategy = new SelectionConversionStrategy(this.selection, this.geo);

    constructor(
        private readonly selection: HasSelectedAndHovered,
        private readonly geo: ReadonlyGeometryDatabase,
        sketches: ReadonlySketchManager,
        curves: ReadonlyPlanarCurveDatabase,
        scene: Scene,
        private readonly signals: EditorSignals,
        private readonly filter: (s: Selectable) => boolean = includeEverything,
        private readonly clickStrategy = new ClickStrategy(geo, sketches, curves, scene, selection.mode, selection.selected, selection.hovered, selection.selected),
        private readonly hoverStrategy = new HoverStrategy(geo, sketches, curves, scene, selection.mode, selection.selected, selection.hovered, selection.hovered)
    ) {
        this.onClick = this.observeChanges(this.onClick);
        this.onHover = this.observeChanges(this.onHover);
        this.onConvert = this.observeChanges(this.onConvert);

        this.onBoxHover = this.observeChanges(this.onBoxHover);
        this.onBoxSelect = this.observeChanges(this.onBoxSelect);
        this.onOutlinerHover = this.observeChanges(this.onOutlinerHover);
        this.onOutlinerSelect = this.observeChanges(this.onOutlinerSelect);
    }

    private onIntersection(intersections: Intersection[], strategy: ClickStrategy, modifier: ChangeSelectionModifier, option: ChangeSelectionOption): Intersection | undefined {
        const { filter } = this;

        if (intersections.length == 0) {
            strategy.emptyIntersection(modifier, option);
            return;
        }

        const objects = new Set(intersections.map(i => i.object));
        for (const intersection of intersections) {
            const object = intersection.object;
            const prohibitable = object instanceof Empty ? object : object.parentItem;
            if (!filter(prohibitable)) continue;

            if (object instanceof Face || object instanceof CurveEdge) {
                if (!filter(object)) continue;

                if (strategy.shell(object, modifier, option)) return intersection;
                if (strategy.topologicalItem(object, objects, modifier, option)) return intersection;
            } else if (object instanceof CurveSegment) {
                if (strategy.curve3D(object.parentItem, modifier, option)) return intersection;
                if (strategy.topologicalItem(object, objects, modifier, option)) return intersection;
            } else if (object instanceof Region) {
                if (strategy.region(object, modifier, option)) return intersection;
            } else if (object instanceof Vertex) {
                if (!filter(object)) continue;

                if (strategy.vertex(object, modifier, option)) return intersection;
            } else if (object instanceof Empty) {
                if (strategy.empty(object, modifier, option)) return intersection;
            } else if (object instanceof CV) {
                if (strategy.cv(object, modifier, option)) return intersection;
            } else assertUnreachable(object);
        }

        strategy.emptyIntersection(modifier, option);
        return;
    }

    onClick(intersections: Intersection[], modifier: ChangeSelectionModifier, option: ChangeSelectionOption): Intersection | undefined {
        return this.onIntersection(intersections, this.clickStrategy, modifier, option);
    }

    onDblClick(intersections: Intersection[], modifier: ChangeSelectionModifier): Intersection | undefined {
        if (intersections.length === 0) return;
        const first = intersections[0];
        if (this.clickStrategy.dblClick(first.object, modifier)) return first;
    }

    onHover(intersections: Intersection[], modifier: ChangeSelectionModifier, option: ChangeSelectionOption) {
        this.onIntersection(intersections, this.hoverStrategy, modifier, option);
    }

    onBoxHover(hover: SelectionAccumulator, modifier: ChangeSelectionModifier) {
        this.hoverStrategy.box(this.filterProhibited(hover), modifier, ChangeSelectionOption.None);
    }

    onBoxSelect(select: SelectionAccumulator, modifier: ChangeSelectionModifier) {
        this.clickStrategy.box(this.filterProhibited(select), modifier, ChangeSelectionOption.None);
    }

    onOutlinerHover(items: Iterable<RealNodeItem>, modifier: ChangeSelectionModifier, option: ChangeSelectionOption) {
        const intersectables = this.getIntersectables(items);
        this.hoverStrategy.box(new SelectionAccumulator(intersectables), modifier, ChangeSelectionOption.IgnoreMode | option);
    }

    onOutlinerSelect(items: Iterable<RealNodeItem>, modifier: ChangeSelectionModifier, option: ChangeSelectionOption) {
        const intersectables = this.getIntersectables(items);
        this.clickStrategy.box(new SelectionAccumulator(intersectables), modifier, ChangeSelectionOption.IgnoreMode | option);
    }

    private getIntersectables(items: Iterable<RealNodeItem>) {
        const intersectables = [];
        for (const item of items) {
            let intersectable: Intersectable | Shell | Group | Empty;
            if (item instanceof Shell)
                intersectable = item;
            else if (item instanceof SpaceInstance || item instanceof SketchIsland)
                intersectable = item;
            else if (item instanceof Group)
                intersectable = item;
            else if (item instanceof Empty)
                intersectable = item;
            else assertUnreachable(item);
            intersectables.push(intersectable);
        }
        return intersectables;
    }

    onConvert(mode: SelectionMode, modifier: ChangeSelectionModifier) {
        this.conversionStrategy.convert(mode, modifier);
    }

    private filterProhibited(select: SelectionAccumulator): SelectionAccumulator {
        const { filter, geo } = this;
        if (filter === includeEverything) return select;

        for (const faceId of select.faceIds) {
            const face = geo.lookupTopologyItemById(faceId).view;
            if (filter(face.parentItem) && filter(face)) continue;
            select.faceIds.delete(faceId);
        }
        for (const edgeId of select.edgeIds) {
            const edge = geo.lookupTopologyItemById(edgeId).view;
            if (filter(edge.parentItem) && filter(edge)) continue;
            select.edgeIds.delete(edgeId);
        }
        for (const solidId of select.solidIds) {
            const solid = geo.lookupItemById(solidId).view;
            if (filter(solid)) continue;
            select.solidIds.delete(solidId);
        }
        for (const sheetId of select.sheetIds) {
            const sheet = geo.lookupItemById(sheetId).view;
            if (filter(sheet)) continue;
            select.sheetIds.delete(sheetId);
        }
        for (const curveId of select.curveIds) {
            const curve = geo.lookupItemById(curveId).view;
            if (filter(curve)) continue;
            select.curveIds.delete(curveId);
        }

        return select;
    }

    private aggregate<R>(f: () => R): R {
        const { selection } = this;

        const oldSelection = selection.makeTemporary();
        oldSelection.copy(selection);

        const result = f();

        const { hoveredAdded, hoveredRemoved, selectedAdded, selectedRemoved } = selection.delta(oldSelection);

        if (hoveredAdded.size > 0 || hoveredRemoved.size > 0) this.signals.hoverDelta.dispatch({ added: hoveredAdded, removed: hoveredRemoved });
        if (selectedAdded.size > 0 || selectedRemoved.size > 0) this.signals.selectionDelta.dispatch({ added: selectedAdded, removed: selectedRemoved });

        if (hoveredAdded.size > 0 || hoveredRemoved.size > 0 || selectedAdded.size > 0 || selectedRemoved.size > 0) this.signals.selectionChanged.dispatch();

        return result;
    }

    private observeChanges<A extends any[], R>(f: (...args: A) => R): (...args: A) => R {
        return (...args: A): R => this.aggregate(() => f.call(this, ...args));
    }
}

export type ParentItem = Solid | Sheet | Group | Empty | SpaceInstance | SketchIsland;

export type SelectionDelta = {
    added: Set<ParentItem>;
    removed: Set<ParentItem>;
};
