import { ReadonlyPlanarCurveDatabase } from "../editor/curves/PlanarCurveDatabase";
import { ReadonlySketchManager } from "../editor/curves/SketchManager";
import { ReadonlyGeometryDatabase } from "../editor/DatabaseLike";
import { Empty } from "../editor/Empties";
import { Group } from "../editor/Groups";
import { Scene } from "../editor/Scene";
import { assertUnreachable } from "../util/Util";
import { Intersectable } from "../visual_model/Intersectable";
import { CurveEdge, CurveSegment, CV, Face, ItemId, Region, Sheet, Solid, SpaceInstance, TopologyId, TopologyItem, Vertex } from "../visual_model/VisualModel";
import { ChangeSelectionModifier, ChangeSelectionOption } from "./ChangeSelectionExecutor";
import { SelectionAccumulator } from "./SelectionAccumulator";
import { ModifiesSelection } from "./SelectionDatabase";
import { SelectionExtensionStrategy } from "./SelectionExtensionStrategy";
import { SelectionMode, SelectionModeSet } from "./SelectionModeSet";

export type BoxSelectable = Intersectable | Solid | Sheet | Group | Empty | SpaceInstance;

export class ClickStrategy {
    private readonly extend = new SelectionExtensionStrategy(this.db, this.sketches, this.curves);

    constructor(
        protected readonly db: ReadonlyGeometryDatabase,
        protected readonly sketches: ReadonlySketchManager,
        protected readonly curves: ReadonlyPlanarCurveDatabase,
        protected readonly scene: Scene,
        protected readonly mode: SelectionModeSet,
        protected readonly selected: ModifiesSelection,
        protected readonly hovered: ModifiesSelection,
        protected readonly writeable: ModifiesSelection
    ) { }

    emptyIntersection(modifier: ChangeSelectionModifier, option: ChangeSelectionOption): void {
        if (modifier !== ChangeSelectionModifier.Replace) return;
        this.writeable.removeAll();
        this.hovered.removeAll();
    }

    curve3D(object: SpaceInstance, modifier: ChangeSelectionModifier, option: ChangeSelectionOption): boolean {
        if (!this.mode.has(SelectionMode.Curve)) return false;
        if (this.selected.hasSelectedChildren(object)) return false;

        const add = () => {
            if (ChangeSelectionOption.Extend & option) {
                const extended = this.extend.extendCurve(object);
                this.writeable.add(extended);
            } else {
                this.writeable.addCurve(object);
            }
            return true;
        };
        return this.modify(modifier,
            add,
            () => {
                this.writeable.removeCurve(object);
                return true;
            },
            () => {
                if (this.writeable.has(object)) this.writeable.removeCurve(object);
                else add();
                return true;
            });
    }

    vertex(object: Vertex, modifier: ChangeSelectionModifier, option: ChangeSelectionOption): boolean {
        if (!this.mode.has(SelectionMode.Vertex)) return false;

        const add = () => {
            const parentItem = object.parentItem;
            if (this.selected.curves.has(parentItem)) {
                this.writeable.removeCurve(parentItem);
            }
            this.writeable.addVertex(object);
            return true;
        };
        return this.modify(modifier,
            add,
            () => {
                this.writeable.removeVertex(object);
                return true;
            },
            () => {
                if (this.writeable.has(object)) this.writeable.removeVertex(object);
                else add();
                return true;
            }
        );
    }

    cv(object: CV, modifier: ChangeSelectionModifier, option: ChangeSelectionOption): boolean {
        if (!this.mode.has(SelectionMode.CV)) return false;

        const add = () => {
            const parentItem = object.parentItem;
            if (this.selected.curves.has(parentItem)) {
                this.writeable.removeCurve(parentItem);
            }
            this.writeable.addCV(object);
            return true;
        };
        return this.modify(modifier,
            add,
            () => {
                this.writeable.removeCV(object);
                return true;
            },
            () => {
                if (this.writeable.has(object)) this.writeable.removeCV(object);
                else add();
                return true;
            }
        );
    }

    empty(object: Empty, modifier: ChangeSelectionModifier, option: ChangeSelectionOption): boolean {
        if (!this.mode.has(SelectionMode.Empty)) return false;

        return this.modify(modifier,
            () => {
                this.writeable.addEmpty(object);
                return true;
            },
            () => {
                this.writeable.removeEmpty(object);
                return true;
            },
            () => {
                if (this.writeable.has(object)) this.writeable.removeEmpty(object);
                else this.writeable.addEmpty(object);
                return true;
            }
        );
    }

    shell(object: CurveEdge | Face, modifier: ChangeSelectionModifier, option: ChangeSelectionOption): boolean {
        if (!(this.mode.has(SelectionMode.Solid) || this.mode.has(SelectionMode.Sheet)) || (ChangeSelectionOption.IgnoreMode & option)) return false;
        const parentItem = object.parentItem;
        const parentGroup = this.scene.parent(parentItem);

        if (parentGroup !== undefined && option & ChangeSelectionOption.Extend && !parentGroup.isRoot) {
            return this.selectGroup(parentGroup, modifier, option);
        } else {
            if (this.selected.has(parentItem)) {
                return this.modify(modifier,
                    () => false,
                    () => {
                        this.writeable.remove(parentItem);
                        return true;
                    },
                    () => {
                        this.writeable.remove(parentItem);
                        return true;
                    });
            } else if (!this.selected.hasSelectedChildren(parentItem) || (this.mode.is(SelectionMode.Solid) || this.mode.is(SelectionMode.Sheet))) {
                const add = () => {
                    this.writeable.deselectChildren(parentItem);
                    this.writeable.add(parentItem);
                    return true;
                };
                return this.modify(modifier,
                    add,
                    () => true,
                    () => {
                        this.writeable.add(parentItem);
                        return true;
                    }
                );
            }
        }
        return false;
    }

    private selectGroup(parentGroup: Group, modifier: ChangeSelectionModifier, option: ChangeSelectionOption) {
        const add = () => {
            for (const listing of this.scene.walk(parentGroup)) {
                switch (listing.tag) {
                    case 'Item':
                        const item = listing.item;
                        if (item instanceof Solid || item instanceof Sheet) {
                            if (!this.mode.has(SelectionMode.Solid) || (ChangeSelectionOption.IgnoreMode & option)) continue;
                            this.writeable.deselectChildren(item);
                            this.writeable.add(item);
                        } else if (item instanceof SpaceInstance) {
                            if (!this.mode.has(SelectionMode.Curve)) continue;
                            this.writeable.deselectChildren(item);
                            this.writeable.addCurve(item);
                        }
                }
            }
            return true;
        }
        const remove = () => {
            for (const listing of this.scene.walk(parentGroup)) {
                switch (listing.tag) {
                    case 'Item':
                        const item = listing.item;
                        if (item instanceof Solid) {
                            if (!this.mode.has(SelectionMode.Solid) || (ChangeSelectionOption.IgnoreMode & option)) continue;
                            this.writeable.removeSolid(item);
                        } else if (item instanceof SpaceInstance) {
                            if (!this.mode.has(SelectionMode.Curve)) continue;
                            this.writeable.removeCurve(item);
                        }
                }
            }
            return true;
        }
        return this.modify(modifier,
            add,
            remove,
            () => {
                for (const listing of this.scene.walk(parentGroup)) {
                    switch (listing.tag) {
                        case 'Item':
                            const item = listing.item;
                            if (item instanceof Solid) {
                                if (!this.mode.has(SelectionMode.Solid) || (ChangeSelectionOption.IgnoreMode & option)) continue;
                                if (this.writeable.has(item)) this.writeable.removeSolid(item);
                                else this.writeable.addSolid(item);
                            } else if (item instanceof SpaceInstance) {
                                if (!this.mode.has(SelectionMode.Curve)) continue;
                                if (this.writeable.has(item)) this.writeable.removeCurve(item);
                                else this.writeable.addCurve(item);
                            }
                    }
                }
                return true;
            })
    }

    topologicalItem(object: TopologyItem, intersections: ReadonlySet<Intersectable>, modifier: ChangeSelectionModifier, option: ChangeSelectionOption): boolean {
        if (object instanceof Face && (this.mode.has(SelectionMode.Face) || (ChangeSelectionOption.IgnoreMode & option))) {
            const add = () => {
                if (ChangeSelectionOption.Extend & option) {
                    const extended = this.extend.extendFace(object, intersections);
                    this.writeable.add(extended);
                } else {
                    this.writeable.addFace(object);
                }
                this.writeable.remove(object.parentItem);
            }
            this.modify(modifier,
                add,
                () => this.writeable.removeFace(object),
                () => {
                    if (this.writeable.has(object)) this.writeable.removeFace(object);
                    else add();
                });
            return true;
        } else if (object instanceof CurveEdge && (this.mode.has(SelectionMode.CurveEdge) || (ChangeSelectionOption.IgnoreMode & option))) {
            const add = () => {
                if (ChangeSelectionOption.Extend & option) {
                    const extended = this.extend.extendEdge(object, intersections);
                    this.writeable.add(extended);
                } else if (ChangeSelectionOption.ExtendAlt & option) {
                    const extended = this.extend.extendEdgeAlt(object, intersections);
                    this.writeable.add(extended);
                } else {
                    this.writeable.addEdge(object);
                }
                this.writeable.remove(object.parentItem);
            };
            this.modify(modifier,
                add,
                () => this.writeable.removeEdge(object),
                () => {
                    if (this.writeable.has(object)) this.writeable.removeEdge(object);
                    else add();
                });
            return true;
        } else if (object instanceof CurveSegment && (this.mode.has(SelectionMode.CurveSegment) || (ChangeSelectionOption.IgnoreMode & option))) {
            const add = () => {
                this.writeable.addSegment(object);
                this.writeable.remove(object.parentItem);
            };
            this.modify(modifier,
                add,
                () => this.writeable.removeSegment(object),
                () => {
                    if (this.writeable.has(object)) this.writeable.removeSegment(object);
                    else add();
                });
            return true;
        }
        return false;
    }

    protected modify<T>(modifier: ChangeSelectionModifier, add: () => T, remove: () => T, toggle: () => T): T {
        switch (modifier) {
            case ChangeSelectionModifier.Remove:
                return remove();
            case ChangeSelectionModifier.Add:
                return add();
            case ChangeSelectionModifier.Toggle:
                return toggle();
            case ChangeSelectionModifier.Replace:
                this.writeable.removeAll();
                return add();
            default: assertUnreachable(modifier);
        }
    }

    region(object: Region, modifier: ChangeSelectionModifier, option: ChangeSelectionOption): boolean {
        if (!this.mode.has(SelectionMode.Region)) return false;
        const parentItem = object.parentItem;

        const add = () => {
            if (ChangeSelectionOption.Extend & option) {
                const extended = this.extend.extendRegion(object);
                this.writeable.add(extended);
            } else if (ChangeSelectionOption.ExtendAlt & option) {
                const extended = this.extend.extendRegionAlt(object);
                this.writeable.add(extended);
            } else {
                this.writeable.addRegion(object);
            }
            return true;
        }
        return this.modify(modifier,
            add,
            () => {
                this.writeable.removeRegion(object);
                return true;
            },
            () => {
                if (this.writeable.has(object)) this.writeable.removeRegion(object);
                else add();
                return true;
            });
    }

    box(set: SelectionAccumulator, modifier: ChangeSelectionModifier, option: ChangeSelectionOption) {
        const { selected, writeable, mode } = this;
        const parentsVisited = new Set<ItemId>();

        const cache = selected.cache();

        if (modifier === ChangeSelectionModifier.Replace) {
            writeable.clearSilently();
        }

        if (mode.has(SelectionMode.Solid) || (ChangeSelectionOption.IgnoreMode & option)) {
            for (const solidId of set.solidIds) {
                if (selected.hasSelectedChildren(solidId)) continue;

                parentsVisited.add(solidId);
                if (modifier === ChangeSelectionModifier.Replace) this.addById(SelectionMode.Solid, solidId);
                if (modifier === ChangeSelectionModifier.Add && !cache.solidIds.has(solidId)) this.addById(SelectionMode.Solid, solidId);
                if (modifier === ChangeSelectionModifier.Remove && cache.solidIds.has(solidId)) this.removeById(SelectionMode.Solid, solidId);
                if (modifier === ChangeSelectionModifier.Toggle && !cache.solidIds.has(solidId)) this.addById(SelectionMode.Solid, solidId);
                if (modifier === ChangeSelectionModifier.Toggle && cache.solidIds.has(solidId)) this.removeById(SelectionMode.Solid, solidId);
            }
        }
        if (mode.has(SelectionMode.Sheet) || (ChangeSelectionOption.IgnoreMode & option)) {
            for (const sheetId of set.sheetIds) {
                if (selected.hasSelectedChildren(sheetId)) continue;
                if (modifier === ChangeSelectionModifier.Add && cache.sheetIds.has(sheetId)) continue;
                if (modifier === ChangeSelectionModifier.Remove && !cache.sheetIds.has(sheetId)) continue;

                parentsVisited.add(sheetId);
                if (modifier === ChangeSelectionModifier.Replace) this.addById(SelectionMode.Sheet, sheetId);
                if (modifier === ChangeSelectionModifier.Add && !cache.sheetIds.has(sheetId)) this.addById(SelectionMode.Sheet, sheetId);
                if (modifier === ChangeSelectionModifier.Remove && cache.sheetIds.has(sheetId)) this.removeById(SelectionMode.Sheet, sheetId);
                if (modifier === ChangeSelectionModifier.Toggle && !cache.sheetIds.has(sheetId)) this.addById(SelectionMode.Sheet, sheetId);
                if (modifier === ChangeSelectionModifier.Toggle && cache.sheetIds.has(sheetId)) this.removeById(SelectionMode.Sheet, sheetId);
            }
        }
        if (mode.has(SelectionMode.Face) || (ChangeSelectionOption.IgnoreMode & option)) {
            for (const faceId of set.faceIds) {
                const parentId = Face.parentId(faceId);
                if (parentsVisited.has(parentId)) continue;

                const isParentAlreadySelected = cache.solidIds.has(parentId) || cache.sheetIds.has(parentId) || selected.hasSelectedChildren(parentId);
                if ((mode.has(SelectionMode.Solid) || mode.has(SelectionMode.Sheet)) && !isParentAlreadySelected) continue;

                this.writeable.removeById(SelectionMode.Solid, parentId);
                this.writeable.removeById(SelectionMode.Sheet, parentId);

                if (modifier === ChangeSelectionModifier.Replace) this.addById(SelectionMode.Face, parentId, faceId);
                if (modifier === ChangeSelectionModifier.Add && !cache.faceIds.has(faceId)) this.addById(SelectionMode.Face, parentId, faceId);
                if (modifier === ChangeSelectionModifier.Remove && cache.faceIds.has(faceId)) this.removeById(SelectionMode.Face, parentId, faceId);
                if (modifier === ChangeSelectionModifier.Toggle && !cache.faceIds.has(faceId)) this.addById(SelectionMode.Face, parentId, faceId);
                if (modifier === ChangeSelectionModifier.Toggle && cache.faceIds.has(faceId)) this.removeById(SelectionMode.Face, parentId, faceId);
            }
        }
        if (mode.has(SelectionMode.CurveEdge) || (ChangeSelectionOption.IgnoreMode & option)) {
            for (const edgeId of set.edgeIds) {
                const parentId = CurveEdge.parentId(edgeId);
                if (parentsVisited.has(parentId)) continue;

                const isParentAlreadySelected = cache.solidIds.has(parentId) || cache.sheetIds.has(parentId) || selected.hasSelectedChildren(parentId);
                if ((mode.has(SelectionMode.Solid) || mode.has(SelectionMode.Sheet)) && !isParentAlreadySelected) continue;

                this.writeable.removeById(SelectionMode.Solid, parentId);
                this.writeable.removeById(SelectionMode.Sheet, parentId);

                if (modifier === ChangeSelectionModifier.Replace) this.addById(SelectionMode.CurveEdge, parentId, edgeId);
                if (modifier === ChangeSelectionModifier.Add && !cache.edgeIds.has(edgeId)) this.addById(SelectionMode.CurveEdge, parentId, edgeId);
                if (modifier === ChangeSelectionModifier.Remove && cache.edgeIds.has(edgeId)) this.removeById(SelectionMode.CurveEdge, parentId, edgeId);
                if (modifier === ChangeSelectionModifier.Toggle && !cache.edgeIds.has(edgeId)) this.addById(SelectionMode.CurveEdge, parentId, edgeId);
                if (modifier === ChangeSelectionModifier.Toggle && cache.edgeIds.has(edgeId)) this.removeById(SelectionMode.CurveEdge, parentId, edgeId);
            }
        }
        if (mode.has(SelectionMode.Curve) || (ChangeSelectionOption.IgnoreMode & option)) {
            for (const curveId of set.curveIds) {
                parentsVisited.add(curveId);

                if (modifier === ChangeSelectionModifier.Replace) this.addById(SelectionMode.Curve, curveId);
                if (modifier === ChangeSelectionModifier.Add && !cache.curveIds.has(curveId)) this.addById(SelectionMode.Curve, curveId);
                if (modifier === ChangeSelectionModifier.Remove && cache.curveIds.has(curveId)) this.removeById(SelectionMode.Curve, curveId);
                if (modifier === ChangeSelectionModifier.Toggle && !cache.curveIds.has(curveId)) this.addById(SelectionMode.Curve, curveId);
                if (modifier === ChangeSelectionModifier.Toggle && cache.curveIds.has(curveId)) this.removeById(SelectionMode.Curve, curveId);
            }
        }
        if (mode.has(SelectionMode.CurveSegment) || (ChangeSelectionOption.IgnoreMode & option)) {
            for (const segmentId of set.segmentIds) {
                const parentId = CurveSegment.parentId(segmentId);
                if (parentsVisited.has(parentId)) continue;

                if (mode.has(SelectionMode.Curve) && !cache.curveIds.has(parentId) && !selected.hasSelectedChildren(parentId)) continue;

                this.writeable.removeById(SelectionMode.Curve, parentId);

                if (modifier === ChangeSelectionModifier.Replace) this.addById(SelectionMode.CurveSegment, parentId, segmentId);
                if (modifier === ChangeSelectionModifier.Add && !cache.segmentIds.has(segmentId)) this.addById(SelectionMode.CurveSegment, parentId, segmentId);
                if (modifier === ChangeSelectionModifier.Remove && cache.segmentIds.has(segmentId)) this.removeById(SelectionMode.CurveSegment, parentId, segmentId);
                if (modifier === ChangeSelectionModifier.Toggle && !cache.segmentIds.has(segmentId)) this.addById(SelectionMode.CurveSegment, parentId, segmentId);
                if (modifier === ChangeSelectionModifier.Toggle && cache.segmentIds.has(segmentId)) this.removeById(SelectionMode.CurveSegment, parentId, segmentId);
            }
        }
        if (mode.has(SelectionMode.Vertex) || (ChangeSelectionOption.IgnoreMode & option)) {
            for (const vertexId of set.vertexIds) {
                const parentId = Vertex.parentId(vertexId);
                if (parentsVisited.has(parentId)) continue;

                this.writeable.removeById(SelectionMode.Curve, parentId);

                if (modifier === ChangeSelectionModifier.Replace) this.addById(SelectionMode.Vertex, parentId, vertexId);
                if (modifier === ChangeSelectionModifier.Add && !cache.vertexIds.has(vertexId)) this.addById(SelectionMode.Vertex, parentId, vertexId);
                if (modifier === ChangeSelectionModifier.Remove && cache.vertexIds.has(vertexId)) this.removeById(SelectionMode.Vertex, parentId, vertexId);
                if (modifier === ChangeSelectionModifier.Toggle && !cache.vertexIds.has(vertexId)) this.addById(SelectionMode.Vertex, parentId, vertexId);
                if (modifier === ChangeSelectionModifier.Toggle && cache.vertexIds.has(vertexId)) this.removeById(SelectionMode.Vertex, parentId, vertexId);
            }
        }
        if (mode.has(SelectionMode.CV) || (ChangeSelectionOption.IgnoreMode & option)) {
            for (const cvId of set.cvIds) {
                const parentId = CV.parentId(cvId);
                if (parentsVisited.has(parentId)) continue;

                this.writeable.removeById(SelectionMode.Curve, parentId);

                if (modifier === ChangeSelectionModifier.Replace) this.addById(SelectionMode.CV, parentId, cvId);
                if (modifier === ChangeSelectionModifier.Add && !cache.cvIds.has(cvId)) this.addById(SelectionMode.CV, parentId, cvId);
                if (modifier === ChangeSelectionModifier.Remove && cache.cvIds.has(cvId)) this.removeById(SelectionMode.CV, parentId, cvId);
                if (modifier === ChangeSelectionModifier.Toggle && !cache.cvIds.has(cvId)) this.addById(SelectionMode.CV, parentId, cvId);
                if (modifier === ChangeSelectionModifier.Toggle && cache.cvIds.has(cvId)) this.removeById(SelectionMode.CV, parentId, cvId);
            }
        }
        if (mode.has(SelectionMode.Region) || (ChangeSelectionOption.IgnoreMode & option)) {
            for (const regionId of set.regionIds) {
                const parentId = Region.parentId(regionId);

                if (modifier === ChangeSelectionModifier.Replace) this.addById(SelectionMode.Region, parentId, regionId);
                if (modifier === ChangeSelectionModifier.Add && !cache.regionIds.has(regionId)) this.addById(SelectionMode.Region, parentId, regionId);
                if (modifier === ChangeSelectionModifier.Remove && cache.regionIds.has(regionId)) this.removeById(SelectionMode.Region, parentId, regionId);
                if (modifier === ChangeSelectionModifier.Toggle && !cache.regionIds.has(regionId)) this.addById(SelectionMode.Region, parentId, regionId);
                if (modifier === ChangeSelectionModifier.Toggle && cache.regionIds.has(regionId)) this.removeById(SelectionMode.Region, parentId, regionId);
            }
        }
        // if (mode.has(SelectionMode.Group)) {
        for (const groupId of set.groupIds) {
            if (modifier === ChangeSelectionModifier.Replace) this.addById(SelectionMode.Group, groupId);
            if (modifier === ChangeSelectionModifier.Add && !cache.groupIds.has(groupId)) this.addById(SelectionMode.Group, groupId);
            if (modifier === ChangeSelectionModifier.Remove && cache.groupIds.has(groupId)) this.removeById(SelectionMode.Group, groupId);
            if (modifier === ChangeSelectionModifier.Toggle && !cache.groupIds.has(groupId)) this.addById(SelectionMode.Group, groupId);
            if (modifier === ChangeSelectionModifier.Toggle && cache.groupIds.has(groupId)) this.removeById(SelectionMode.Group, groupId);
        }
        // }
        if (mode.has(SelectionMode.Empty) || (ChangeSelectionOption.IgnoreMode & option)) {
            for (const emptyId of set.emptyIds) {
                if (modifier === ChangeSelectionModifier.Replace) this.addById(SelectionMode.Empty, emptyId);
                if (modifier === ChangeSelectionModifier.Add && !cache.emptyIds.has(emptyId)) this.addById(SelectionMode.Empty, emptyId);
                if (modifier === ChangeSelectionModifier.Remove && cache.emptyIds.has(emptyId)) this.removeById(SelectionMode.Empty, emptyId);
                if (modifier === ChangeSelectionModifier.Toggle && !cache.emptyIds.has(emptyId)) this.addById(SelectionMode.Empty, emptyId);
                if (modifier === ChangeSelectionModifier.Toggle && cache.emptyIds.has(emptyId)) this.removeById(SelectionMode.Empty, emptyId);
            }
        }
    }

    protected addById(mode: SelectionMode, parentId: ItemId, simpleName?: TopologyId) {
        this.writeable.addById(mode, parentId, simpleName);
    }

    protected removeById(mode: SelectionMode, parentId: ItemId, simpleName?: TopologyId) {
        this.writeable.removeById(mode, parentId, simpleName);
    }

    dblClick(intersection: Intersectable, modifier: ChangeSelectionModifier): boolean {
        if (intersection instanceof CurveEdge || intersection instanceof Face) {
            const add = () => {
                this.selected.deselectChildren(intersection.parentItem);
                this.writeable.add(intersection.parentItem);
                return true;
            };
            return this.modify(modifier,
                add,
                () => {
                    this.writeable.remove(intersection.parentItem);
                    return true;
                },
                () => {
                    if (this.writeable.has(intersection.parentItem)) this.writeable.remove(intersection.parentItem);
                    else add();
                    return true;
                });
        }
        return false;
    }
}


export class NonemptyClickStrategy extends ClickStrategy {
    override emptyIntersection(modifier: ChangeSelectionModifier, option: ChangeSelectionOption): void { }
}

export class HoverStrategy extends ClickStrategy {
    emptyIntersection(modifier: ChangeSelectionModifier, option: ChangeSelectionOption): void {
        this.writeable.removeAll();
        this.hovered.removeAll();
    }

    protected override modify<T>(modifier: ChangeSelectionModifier, add: () => T, remove: () => T): T {
        this.hovered.removeAll();
        if (modifier === ChangeSelectionModifier.Remove) {
            return add();
        } else if (modifier === ChangeSelectionModifier.Add) {
            return add();
        } else {
            this.writeable.removeAll();
            return add();
        }
    }

    protected override addById(mode: SelectionMode, parentId: ItemId, simpleName?: TopologyId) {
        this.writeable.addById(mode, parentId, simpleName);
    }

    protected override removeById(mode: SelectionMode, parentId: ItemId, simpleName?: TopologyId) {
        this.writeable.addById(mode, parentId, simpleName);
    }
}
