import { ReadonlyPlanarCurveDatabase } from '../editor/curves/PlanarCurveDatabase';
import { ReadonlySketchManager } from '../editor/curves/SketchManager';
import { ReadonlyGeometryDatabase } from '../editor/DatabaseLike';
import * as c3d from '../kernel/kernel';
import { Intersectable } from "../visual_model/Intersectable";
import * as visual from '../visual_model/VisualModel';

export class SelectionExtensionStrategy {
    constructor(protected readonly db: ReadonlyGeometryDatabase,
        private readonly sketches: ReadonlySketchManager,
        private readonly curves: ReadonlyPlanarCurveDatabase
    ) { }

    extendFace(face: visual.Face, hint: ReadonlySet<Intersectable>): visual.Face[] {
        const model = this.db.lookupTopologyItem(face);
        const parentItem = face.parentItem;
        const parentName = parentItem.simpleName;
        const shell = this.db.lookup(parentItem);
        if (model.IsBlend()) {
            const result = shell.IdentifyBlends([model], c3d.BlendIdentifyType.MaxChain, new c3d.FaceIdentifyBlendsOptions());
            const all = c3d.FaceCollection.Union(result);
            return this.faceCollection2views(parentName, all);
        } else {
            const { surface } = model.GetSurface();
            const all = surface.GetFaces();
            return this.faceCollection2views(parentName, all);
        }
    }

    extendRegionAlt(region: visual.Region): visual.Region[] {
        const sketch = region.parentItem;
        const regions = [...sketch.regions]
        return regions;
    }

    extendRegion(region: visual.Region): visual.Region[] {
        const sketch = region.parentItem;
        const islands = this.sketches.getArchipelago(sketch);
        const result = [];
        for (const island of islands)
            result.push(...island.regions);
        return result;
    }

    extendCurve(object: visual.SpaceInstance): visual.SpaceInstance[] {
        return this.curves.getCoplanarCurves(object);
    }

    extendEdgeAlt(edge: visual.CurveEdge, hint: ReadonlySet<Intersectable>): visual.CurveEdge[] {
        const model = this.db.lookupTopologyItem(edge);
        const parentItem = edge.parentItem;
        const parentName = parentItem.simpleName;

        const endLoops = model.GetEndLoops();
        if (endLoops.length === 0) {
            return this.edgeCollection2views(parentName, new c3d.EdgeCollection([]));
        }

        const endEdgeIds = new Set<c3d.EdgeId>();
        for (const loop of endLoops) {
            const ids = loop.GetEndEdges().GetIds();
            for (const id of ids)
                endEdgeIds.add(id);
            break;
        }

        return this.edgeCollection2views(parentName, new c3d.EdgeCollection([...endEdgeIds]));
    }

    extendEdge(edge: visual.CurveEdge, hint: ReadonlySet<Intersectable>): visual.CurveEdge[] {
        const model = this.db.lookupTopologyItem(edge);
        const parentItem = edge.parentItem;
        const parentName = parentItem.simpleName;
        if (model.IsLaminar()) {
            const laminar = model.FindConnectedLaminar();
            return this.edgeCollection2views(parentName, laminar);
        } else {
            const loops = model.GetLoops();
            if (loops.length === 0) {
                return this.edgeCollection2views(parentName, new c3d.EdgeCollection([]));
            }

            for (const loop of loops) {
                const face = loop.GetFace();
                const faceName = visual.Face.simpleName(parentName, face.Id());
                const view = this.db.lookupTopologyItemById(faceName).view;
                if (hint.has(view))
                    return this.edgeCollection2views(parentName, loop.GetEdges());
            }

            return this.edgeCollection2views(parentName, loops[0].GetEdges());
        }
    }

    private edgeCollection2views(simpleName: visual.SpaceInstanceId, edges: c3d.EdgeCollection): visual.CurveEdge[] {
        const result = [];
        for (const edgeId of edges.GetIds()) {
            const id = visual.CurveEdge.simpleName(simpleName, edgeId);
            if (this.db.hasTopologyItem(id)) {
                const view = this.db.lookupTopologyItemById(id).view as visual.CurveEdge;
                result.push(view);
            }
        }
        return result;
    }

    private faceCollection2views(simpleName: visual.SpaceInstanceId, faces: c3d.FaceCollection): visual.Face[] {
        const result = [];
        for (const faceId of faces.GetIds()) {
            const id = visual.Face.simpleName(simpleName, faceId);
            if (this.db.hasTopologyItem(id)) {
                const view = this.db.lookupTopologyItemById(id).view as visual.Face;
                result.push(view);
            }
        }
        return result;
    }
}
