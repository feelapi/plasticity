import { EditorSignals } from '../editor/EditorSignals';

export enum SelectionMode {
    CurveEdge, CurveSegment, Face, Region, Solid, Sheet, Empty, Curve, Vertex, CV, Group,
    Shell // NOTE: shell is the union of Sheet and Solid; it's a virtual selection mode used in the ObjectPicker primarily
}

export const SelectionModeAll = [SelectionMode.CurveEdge, SelectionMode.Face, SelectionMode.Region, SelectionMode.Solid, SelectionMode.Sheet, SelectionMode.Curve, SelectionMode.Vertex, SelectionMode.CV, SelectionMode.Empty, SelectionMode.Group];
export const SelectionModeDefault = [SelectionMode.CurveEdge, SelectionMode.Face, SelectionMode.Region, SelectionMode.Solid, SelectionMode.Sheet, SelectionMode.Curve, SelectionMode.Empty];


export class SelectionModeSet extends Set<SelectionMode> {
    constructor(values: SelectionMode[], private readonly signals: EditorSignals) {
        super(values);
    }

    toggle(...elements: SelectionMode[]) {
        for (const element of elements) {
            if (this.has(element))
                this.delete(element);
            else
                this.add(element);
        }
        this.signals.selectionModeChanged.dispatch(this);
    }

    set(...elements: SelectionMode[]) {
        this.clear();
        for (const element of elements) {
            if (element === SelectionMode.Shell) {
                this.add(SelectionMode.Solid);
                this.add(SelectionMode.Sheet);
            } else {
                this.add(element);
            }
        }
        this.signals.selectionModeChanged.dispatch(this);
    }

    is(...elements: SelectionMode[]) {
        if (this.size !== elements.length)
            return false;
        for (const element of elements) {
            if (!this.has(element))
                return false;
        }
        return true;
    }
}
