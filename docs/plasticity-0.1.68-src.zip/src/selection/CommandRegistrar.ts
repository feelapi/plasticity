import { CompositeDisposable } from 'event-kit';
import * as cmd from '../command/Command';
import CommandRegistry from '../components/atom/CommandRegistry';
import { SnapManager } from '../editor/snaps/SnapManager';
import { ConvertCommand } from './SelectionConversionStrategy';
import { SelectionMode, SelectionModeAll } from './SelectionModeSet';

interface EditorLike extends cmd.EditorLike {
    snaps: SnapManager;
}

export class SelectionCommandRegistrar {
    private readonly disposable = new CompositeDisposable();
    dispose() { this.disposable.dispose() }

    constructor(
        private readonly editor: EditorLike
    ) { }

    register(registry: CommandRegistry) {
        const { selection } = this.editor;

        return registry.add(document.body, {
            'selection:mode:set:control-point': () => selection.mode.set(SelectionMode.Vertex, SelectionMode.CV),
            'selection:mode:set:edge': () => selection.mode.set(SelectionMode.CurveEdge, SelectionMode.Curve),
            'selection:mode:set:face': () => selection.mode.set(SelectionMode.Face, SelectionMode.Region),
            'selection:mode:set:solid': () => selection.mode.set(SelectionMode.Solid, SelectionMode.Sheet, SelectionMode.Empty),
            'selection:mode:set:all': () => selection.mode.set(...SelectionModeAll),

            'selection:mode:toggle:control-point': () => selection.mode.toggle(SelectionMode.Vertex, SelectionMode.CV),
            'selection:mode:toggle:edge': () => selection.mode.toggle(SelectionMode.CurveEdge, SelectionMode.Curve),
            'selection:mode:toggle:face': () => selection.mode.toggle(SelectionMode.Face, SelectionMode.Region),
            'selection:mode:toggle:solid': () => selection.mode.toggle(SelectionMode.Solid, SelectionMode.Sheet),

            'selection:convert:edge': () => this.editor.exec(new ConvertCommand(this.editor, SelectionMode.CurveEdge)),
            'selection:convert:face': () => this.editor.exec(new ConvertCommand(this.editor, SelectionMode.Face)),
            'selection:convert:solid': () => this.editor.exec(new ConvertCommand(this.editor, SelectionMode.Solid)),

            'snaps:temporarily-enable': () => this.editor.snaps.xor = false,
            'snaps:temporarily-disable': () => this.editor.snaps.xor = true,
        })
    }
}

