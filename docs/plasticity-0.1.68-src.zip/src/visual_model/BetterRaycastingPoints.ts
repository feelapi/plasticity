import * as THREE from "three";
import { Unprojectable } from "./GeometryPicker";


export class BetterRaycastingPoints extends THREE.Points {
    raycast(raycaster: THREE.Raycaster, intersects: (THREE.Intersection & Unprojectable)[]) {
        const { geometry, matrixWorld } = this;
        const camera = raycaster.camera as THREE.PerspectiveCamera | THREE.OrthographicCamera;
        const threshold = raycaster.params.Points?.threshold ?? 0;

        const size = 1; // px
        const ssMaxWidth = size + threshold;
        const material = this.material as BetterRaycastingPointsMaterial;
        const resolution = material.resolution;

        BoundingSphere: {
            if (geometry.boundingSphere === null)
                geometry.computeBoundingSphere();
            _sphere.copy(geometry.boundingSphere!).applyMatrix4(matrixWorld);
            const distanceToSphere = Math.max(camera.near, _sphere.distanceToPoint(_ray.origin)); // increase the sphere bounds by the worst case line screen space width
            const sphereMargin = getWorldSpaceHalfWidth(camera, distanceToSphere + _sphere.radius, ssMaxWidth, resolution);

            _sphere.radius += sphereMargin;
            if (!raycaster.ray.intersectsSphere(_sphere))
                return;
        }

        BoundingBox: {
            if (geometry.boundingBox === null)
                geometry.computeBoundingBox();
            _box.copy(geometry.boundingBox!).applyMatrix4(matrixWorld);
            const distanceToBox = Math.max(camera.near, _box.distanceToPoint(_ray.origin));
            const boxMargin = getWorldSpaceHalfWidth(camera, distanceToBox, ssMaxWidth, resolution);
            _box.max.x += boxMargin;
            _box.max.y += boxMargin;
            _box.max.z += boxMargin;
            _box.min.x -= boxMargin;
            _box.min.y -= boxMargin;
            _box.min.z -= boxMargin;
            if (!raycaster.ray.intersectsBox(_box))
                return;
        }

        _inverseMatrix.copy(matrixWorld).invert();
        _ray.copy(raycaster.ray).applyMatrix4(_inverseMatrix);

        const { attributes: { position: positionAttribute }, drawRange } = geometry;

        const start = Math.max(0, drawRange.start);
        const end = Math.min(positionAttribute.count, (drawRange.start + drawRange.count));

        for (let i = start, l = end; i < l; i++) {
            _position.fromBufferAttribute(positionAttribute, i);
            const dist = Math.max(camera.near, _position.distanceTo(_ray.origin));
            const half = getWorldSpaceHalfWidth(camera, dist, ssMaxWidth, resolution);
            const halfSq = half * half;
            const rayPointDistanceSq = _ray.distanceSqToPoint(_position);

            if (rayPointDistanceSq < halfSq) {
                const intersectPoint = new THREE.Vector3();
                _ray.closestPointToPoint(_position, intersectPoint);
                intersectPoint.applyMatrix4(matrixWorld);
                const distance = raycaster.ray.origin.distanceTo(intersectPoint);
                if (distance < raycaster.near || distance > raycaster.far)
                    return;

                _ssOrigin.copy(_position).applyMatrix4(camera.projectionMatrix);
                _ssOrigin.x *= resolution.x / 2; _ssOrigin.y *= resolution.y / 2;
                _ssOrigin.z = 0;
                _ssIntersect.copy(intersectPoint).applyMatrix4(camera.projectionMatrix);
                _ssIntersect.x *= resolution.x / 2; _ssIntersect.y *= resolution.y / 2;
                _ssIntersect.z = 0;
                const distance2d = _ssOrigin.distanceTo(_ssIntersect);

                intersects.push({
                    distance,
                    distance2d,
                    distanceToRay: Math.sqrt(rayPointDistanceSq),
                    point: intersectPoint,
                    index: i,
                    object: this,
                });
            }
        }
    }
}

export class BetterRaycastingPointsMaterial extends THREE.PointsMaterial {
    readonly resolution = new THREE.Vector2;
}

export function getWorldSpaceHalfWidth(camera: THREE.Camera, distance: number, lineWidth: number, resolution: THREE.Vector2) {
    // transform into clip space, adjust the x and y values by the pixel width offset, then
    // transform back into world space to get world offset. Note clip space is [-1, 1] so full
    // width does not need to be halved.
    _clipToWorldVector.set(0, 0, -distance, 1.0).applyMatrix4(camera.projectionMatrix);
    _clipToWorldVector.multiplyScalar(1.0 / _clipToWorldVector.w);
    _clipToWorldVector.x = lineWidth / resolution.width;
    _clipToWorldVector.y = lineWidth / resolution.height;
    _clipToWorldVector.applyMatrix4(camera.projectionMatrixInverse);
    _clipToWorldVector.multiplyScalar(1.0 / _clipToWorldVector.w);
    return Math.abs(Math.max(_clipToWorldVector.x, _clipToWorldVector.y));
}

const _inverseMatrix = new THREE.Matrix4();
const _ray = new THREE.Ray();
const _sphere = new THREE.Sphere();
const _clipToWorldVector = new THREE.Vector4();
const _box = new THREE.Box3();
const _position = new THREE.Vector3();
const _ssOrigin = new THREE.Vector3();
const _ssIntersect = new THREE.Vector3();
