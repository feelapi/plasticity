import * as THREE from "three";
import { Shell } from "./VisualModel";

/**
 * Raycasting against faces is most expensive, as it has a lot of geometry.
 * When backface culling is off, we only need the closest intersections. So it doesn't
 * make sense to consider a Shell's faces if we already have a closer intersection.
 * 
 * At the moment, because there is some post-processing of the intersections using the SelectionMode,
 * It may only be safe to do this optimization with Shells. But not 100% sure.
 */

export class StopEarlyRaycaster extends THREE.Raycaster {
    intersectObjects<TIntersected extends THREE.Object3D>(
        objects: THREE.Object3D[],
        recursive = true,
        intersects: Array<THREE.Intersection<TIntersected>> = []
    ): THREE.Intersection<TIntersected>[] {
        const { params, ray } = this;
        if (params.Mesh?.backfaceCulling === false) return super.intersectObjects(objects, recursive, intersects);

        const distances = objects.map(o => {
            if (!(o instanceof Shell)) return -Infinity;
            _box.copy(o.getBoundingBox());
            const i = ray.intersectBox(_box, _v);
            return i ? ray.origin.distanceTo(i) : -Infinity;
        });
        const objectsAndDistances = objects.map((o, i) => ({ object: o, distance: distances[i] }));
        objectsAndDistances.sort((a, b) => a.distance! - b.distance!);

        let minDistance = Infinity;
        for (const { object, distance } of objectsAndDistances) {
            if (!object.layers.test(this.layers)) continue;
            if (distance > minDistance) break;

            const is: THREE.Intersection<TIntersected>[] = [];
            object.raycast(this, is);
            for (const i of is) {
                minDistance = Math.min(minDistance, i.distance);
                intersects.push(i);
            }
        }

        intersects.sort(ascSort);
        return intersects;
    }
}

function ascSort(a: THREE.Intersection, b: THREE.Intersection): number {
    return a.distance - b.distance;
}

const _v = new THREE.Vector3();
const _box = new THREE.Box3();
