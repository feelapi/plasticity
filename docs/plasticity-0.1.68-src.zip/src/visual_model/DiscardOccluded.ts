import * as THREE from "three";
import { Viewport } from "../components/viewport/Viewport";
import { IntersectableWithTopologyItem, Unprojectable, UnprojectableIntersection } from "./GeometryPicker";
import { StopEarlyRaycaster } from "./StopEarlyRaycaster";

export function discardOccluded<T extends Unprojectable>(intersections: T[], raycast: RaycastOcclusionDiscarder): T[] {
    if (intersections.length === 0) return [];
    const result: T[] = [];

    // Nearest without large distance2d, which means intersected without margin
    // (i.e,. nearest object directly under the cursor pixel)
    for (const intersection of intersections) {
        if ((intersection.distance2d ?? 0) > 1) continue;
        // TODO: If not a face, we can return early
        result.push(intersection);
        break;
    }

    // Nothing directly under the cursor. Consider all intersections. This may include some occluded objects within margin, which has pros and cons.
    if (result.length === 0) return intersections;

    let notUnderCursorButWithinMargin = [];
    for (const intersection of intersections) {
        if ((intersection.distance2d ?? 0) <= 1) continue;
        notUnderCursorButWithinMargin.push(intersection);
    }
    notUnderCursorButWithinMargin.sort((i1, i2) => i1.distance2d! - i2.distance2d!);
    notUnderCursorButWithinMargin = notUnderCursorButWithinMargin;

    const start = performance.now();
    for (const intersection of notUnderCursorButWithinMargin) {
        if (performance.now() - start > deadlineMs) break; // Must enforce a limit

        // pointOnLine is the point on the line that is closest to the cursor.
        // if it doesn't exist, the intersection could be a point, so use the intersection point.
        const point = intersection.pointOnLine ?? intersection.point;
        raycast.test(intersection, point, result);
    }

    return result;
}

interface OcclusionDiscarder {
    test(intersection: Unprojectable, point: THREE.Vector3, result: Unprojectable[]): boolean;
}

export class RaycastOcclusionDiscarder implements OcclusionDiscarder {
    private readonly occlusionRaycaster = new StopEarlyRaycaster();

    constructor(private readonly raycaster: THREE.Raycaster, private readonly viewport: Viewport, private objects: THREE.Object3D[]) {
    }

    test(intersection: Unprojectable, point: THREE.Vector3, result: Unprojectable[]) {
        const { raycaster, occlusionRaycaster, objects, viewport: { camera } } = this;

        _direction.copy(point).sub(raycaster.ray.origin)
        const d = _direction.length();
        _direction.divideScalar(d);
        occlusionRaycaster.ray.set(raycaster.ray.origin, _direction);
        occlusionRaycaster.camera = camera;
        occlusionRaycaster.far = d + 1e-2;
        occlusionRaycaster.params = { Mesh: { backfaceCulling: true }, Line2: { threshold: 0, offsetDistance: false } } as THREE.RaycasterParameters;
        occlusionRaycaster.layers.mask = raycaster.layers.mask;
        const is = occlusionRaycaster.intersectObjects(objects, false) as IntersectableWithTopologyItem[];
        if (is.length === 0) {
            result.push(intersection);
            return true;
        } else {
            const i = is[0];
            if (d - i.distance <= 1e-3) {
                result.push(intersection);
                return true;
            }
        }
        return true;
    }
}

export class DepthBufferOcclusionDiscarder implements OcclusionDiscarder {
    constructor(private readonly viewport: Viewport, private readonly raycaster: THREE.Raycaster) {
    }

    test(intersection: UnprojectableIntersection, point: THREE.Vector3, result: UnprojectableIntersection[]) {
        tmp.copy(point);
        const distanceToIntersection = intersection.distance;
        tmp.project(this.viewport.camera);

        normalizedScreenPoint.set(tmp.x, tmp.y);
        denormalizedScreenPoint.set(tmp.x, -tmp.y);
        this.viewport.denormalizeScreenPosition(denormalizedScreenPoint);

        const pos = this.viewport.depth.read(denormalizedScreenPoint, normalizedScreenPoint);
        if (pos === undefined) return false;
        const distanceToOccluder = this.raycaster.ray.origin.distanceTo(pos);
        if (distanceToIntersection <= distanceToOccluder + 1e-3) {
            result.push(intersection);
            return true;
        }
        return true;
    }

}

const tmp = new THREE.Vector3();
const normalizedScreenPoint = new THREE.Vector2();
const denormalizedScreenPoint = new THREE.Vector2();
const deadlineMs = 5;
const _direction = new THREE.Vector3();
