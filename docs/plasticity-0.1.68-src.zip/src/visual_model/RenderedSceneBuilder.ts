import { CompositeDisposable, Disposable } from "event-kit";
import * as THREE from "three";
import { LineMaterial } from "three/examples/jsm/lines/LineMaterial";
import { CrossPointDatabase } from "../editor/curves/CrossPointDatabase";
import { MaterialOverride } from "../editor/DatabaseLike";
import { EditorSignals } from "../editor/EditorSignals";
import { Empty, ImageEmpty, isOutlinableEmpty, ObjectEmpty, OutlinableEmpty } from "../editor/Empties";
import { Group } from "../editor/Groups";
import { Scene } from "../editor/Scene";
import { TextureLoader } from "../editor/TextureLoader";
import ceramicDark from '../img/matcap/ceramic_dark.exr';
import { ParentItem, SelectionDelta } from "../selection/ChangeSelectionExecutor";
import { SelectionCache } from "../selection/SelectionCache";
import { HasSelectedAndHovered } from "../selection/SelectionDatabase";
import { Theme } from "../startup/ConfigFiles";
import * as signals from '../util/Signals';
import * as visual from '../visual_model/VisualModel';

export type MaterialWithColor = THREE.Material & { color: THREE.Color };

type State = { tag: 'none' } | { tag: 'scratch', selection: HasSelectedAndHovered }
type UniformMaterials = { solid: MaterialWithColor; sheet: MaterialWithColor };
type Mode = { tag: 'uniform', materials: UniformMaterials, isTinted: boolean } | { tag: 'per-object', prev: { materials: UniformMaterials, isTinted: boolean } };

type FaceMaterials = {
    face_hovered: THREE.Material;
    face_highlighted: THREE.Material;
    face_hovered_phantom: THREE.Material;
    face_highlighted_phantom: THREE.Material;
    mode_material: THREE.Material;
};

export class RenderedSceneBuilder {
    private readonly disposable = new CompositeDisposable();
    dispose() { this.disposable.dispose() }

    private state: State = { tag: 'none' };

    private _mode: Mode = { tag: 'uniform', materials: { solid: face_unhighlighted_matcap, sheet: surface_unhighlighted_matcap }, isTinted: false };
    get mode(): Readonly<Mode> { return this._mode }
    set mode(mode: Mode) {
        if (this._mode === mode) return;
        this._mode = mode;
        this.highlight();
    }

    constructor(
        private readonly scene: Scene,
        private readonly textures: TextureLoader,
        private readonly editorSelection: HasSelectedAndHovered,
        private readonly crosses: CrossPointDatabase,
        theme: Theme,
        private readonly signals: EditorSignals,
    ) {
        const bindings: signals.SignalBinding<any>[] = [];
        bindings.push(signals.renderPrepared.add(({ resolution }) => this.setResolution(resolution)));
        bindings.push(signals.commandEnded.add(this.highlight));
        bindings.push(signals.backupLoaded.add(this.highlight));
        bindings.push(signals.historyChanged.add(this.highlight));
        bindings.push(signals.quasimodeChanged.add(this.highlight));
        bindings.push(signals.hoverDelta.add(({ added, removed }) => {
            this.hover(added, removed);
        }));
        this.disposable.add(new Disposable(() => {
            for (const binding of bindings) binding.detach();
        }));

        this.setTheme(theme);
        this.setMatcap(ceramicDark, false);
    }

    private hover(added: Iterable<ParentItem>, removed: Iterable<ParentItem>) {
        const hoverChanged = new Set<ParentItem>();
        for (const item of added) hoverChanged.add(item);
        for (const item of removed) hoverChanged.add(item);
        const expensive = this.expensiveData;
        for (const changed of hoverChanged) {
            if (changed instanceof Group) continue;
            this.highlightItem(changed, undefined, expensive, undefined);
        }
    }

    highlightTemporary(view: visual.Item, ancestor?: visual.Item, override?: MaterialOverride) {
        this.highlightItem(view, ancestor, this.expensiveData, override);
    }

    private get selection() {
        switch (this.state.tag) {
            case 'none': return this.editorSelection;
            case 'scratch': return this.state.selection;
        }
    }

    highlight = () => {
        performance.mark('begin-highlight');
        const expensive = this.expensiveData;
        for (const item of this.scene.visibleObjects) {
            this.highlightItem(item, undefined, expensive, undefined);
        }
        performance.mark('end-highlight');
        performance.measure('highlight', 'begin-highlight', 'end-highlight');
    }

    get expensiveData(): CachedData {
        const selected = this.selection.selected.cache();
        const hovered = this.selection.hovered.cache();
        return { selected, hovered }
    }

    private highlightItem(item: visual.SpaceItem, ancestor: visual.Item | undefined, expensive: CachedData, materialOverride: MaterialOverride | undefined) {
        if (item instanceof visual.Solid) {
            this.highlightSolid(item, ancestor as visual.Solid | undefined, expensive, materialOverride);
        } else if (item instanceof visual.Sheet) {
            this.highlightSheet(item, ancestor as visual.Sheet | undefined, expensive, materialOverride);
        } else if (item instanceof visual.SpaceInstance) {
            this.highlightSpaceInstance(item, expensive);
        } else if (item instanceof visual.SketchIsland) {
            this.highlightSketch(item, expensive);
        } else if (item instanceof Empty) {
            this.highlightEmpty(item, expensive);
        } else {
            throw new Error("invalid type: " + item.constructor.name);
        }
        item.updateMatrixWorld();
    }

    private highlightSolid(solid: visual.Solid, ancestor: visual.Solid | undefined, expensive: CachedData, override: MaterialOverride | undefined) {
        this.highlightSolidFaces(solid, ancestor, expensive, override?.mesh);
        this.highlightEdges(solid, expensive);
    }

    private highlightSheet(sheet: visual.Sheet, ancestor: visual.Sheet | undefined, expensive: CachedData, override: MaterialOverride | undefined) {
        this.highlightSheetFaces(sheet, ancestor, expensive, override?.mesh);
        this.highlightEdges(sheet, expensive);
    }

    private highlightEmpty(empty: Empty, expensive: CachedData) {
        const transform = this.scene.getTransform(empty, true);
        empty.position.copy(transform.position);
        empty.quaternion.copy(transform.quaternion);
        empty.scale.copy(transform.scale);
        if (empty instanceof ImageEmpty) {
            const particularMaterial = this.scene.getMaterial(empty, true);
            if (particularMaterial !== undefined) {
                const material = empty.plane.material as THREE.MeshBasicMaterial;
                material.opacity = particularMaterial.opacity;
                material.transparent = particularMaterial.opacity < 1;
                material.depthWrite = particularMaterial!.depthFunc !== THREE.NeverDepth;
                material.depthFunc = particularMaterial!.depthFunc;
            }
        } else if (empty instanceof ObjectEmpty) {
            empty.traverse(child => {
                if (child instanceof THREE.Mesh) {
                    child.material = face_unhighlighted_matcap;
                }
            });
        }
    }

    private highlightSketch(item: visual.SketchIsland, expensive: CachedData) {
        const regiongroup = item.regions;
        const hoveredEntityIds = expensive.hovered.regionsForIsland(item);
        const selectedEntityIds = expensive.selected.regionsForIsland(item);
        const hovered = regiongroup.groupsForIds(hoveredEntityIds);
        const selected = regiongroup.groupsForIds(selectedEntityIds);
        const unselected = regiongroup.allGroups;
        const hovered_phantom = hovered.map(u => ({ ...u }));
        hovered.forEach(s => s.materialIndex = 0);
        selected.forEach(s => s.materialIndex = 1);
        unselected.forEach(s => s.materialIndex = 2);
        hovered_phantom.forEach(s => s.materialIndex = 3);
        regiongroup.mesh.material = [region_hovered, region_highlighted, region_unhighlighted, face_hovered_phantom];

        regiongroup.mesh.geometry.groups = [...hovered, ...selected, ...unselected, ...hovered_phantom];
    }

    private highlightSpaceInstance(item: visual.SpaceInstance, expensive: CachedData) {
        const isSelected = expensive.selected.curveIds.has(item.simpleName);
        const isHovered = expensive.hovered.curveIds.has(item.simpleName);
        item.line.material = isSelected ? line_selected : isHovered ? line_hovered : line_unselected;
        this.highlightVertices(item, expensive);
        this.highlightCVs(item, expensive);
        this.highlightSegments(item, expensive);
    }

    // TODO: Investigate whether these methods would benefit from using expensive.selected.verticesForCurve
    // Copy default colors from a prepopulated immutable array.
    private highlightVertices(item: visual.SpaceInstance, expensive: CachedData) {
        const crossInfo = this.crosses.lookup(item);
        const vertices = item.vertices;
        const geometry = vertices.geometry;
        const colors = geometry.attributes.color;
        if (colors === undefined) return;
        const colorsArray = colors.array as unknown as Uint8Array;
        for (let i = 0; i < colorsArray.length / 3; i++) {
            const id = vertices.getId(i);
            const simpleName = visual.Vertex.simpleName(item.simpleName, id);
            const unselected = crossInfo !== undefined && crossInfo.vertices.has(id) ? controlPoint_intersected : controlPoint_unselected;
            const isSelected = expensive.selected.vertexIds.has(simpleName);
            const isHovered = expensive.hovered.vertexIds.has(simpleName);
            const color = isSelected ? controlPoint_selected : isHovered ? controlPoint_hovered : unselected;
            colorsArray[i * 3 + 0] = color.r * 255;
            colorsArray[i * 3 + 1] = color.g * 255;
            colorsArray[i * 3 + 2] = color.b * 255;
        }
        colors.needsUpdate = true;
    }

    private highlightCVs(item: visual.SpaceInstance, expensive: CachedData) {
        const cvs = item.cvs;
        const geometry = cvs.geometry;
        const colors = geometry.attributes.color;
        if (colors === undefined) return;
        const colorsArray = colors.array as unknown as Uint8Array;
        for (let i = 0; i < colorsArray.length / 3; i++) {
            const id = visual.CV.simpleName(item.simpleName, cvs.getId(i));
            const isSelected = expensive.selected.cvIds.has(id);
            const isHovered = expensive.hovered.cvIds.has(id);
            const color = isSelected ? controlPoint_selected : isHovered ? controlPoint_hovered : controlPoint_unselected;
            colorsArray[i * 3 + 0] = color.r * 255;
            colorsArray[i * 3 + 1] = color.g * 255;
            colorsArray[i * 3 + 2] = color.b * 255;
        }
        colors.needsUpdate = true;
    }

    private highlightEdges(solid: visual.Solid | visual.Sheet, expensive: CachedData) {
        const lod = solid.high;
        const edgegroup = lod.edges;
        let hoveredEntityIds = expensive.hovered.edgesForShell(solid);
        let selectedEntityIds = expensive.selected.edgesForShell(solid);
        let hovered = edgegroup.groupsForIds(hoveredEntityIds);
        let selected = edgegroup.groupsForIds(selectedEntityIds);

        edgegroup.temp.clear();
        if (selected.length > 0) {
            const sliced1 = edgegroup.slice(selected);
            sliced1.material = line_selected;
            edgegroup.temp.add(sliced1);
        }

        if (hovered.length > 0) {
            const sliced2 = edgegroup.slice(hovered);
            sliced2.material = line_hovered;
            edgegroup.temp.add(sliced2);
        }
    }

    private highlightSegments(wire: visual.SpaceInstance, expensive: CachedData) {
        const segmentgroup = wire.segments;
        let hoveredEntityIds = expensive.hovered.segmentsForCurve(wire);
        let selectedEntityIds = expensive.selected.segmentsForCurve(wire);
        let hovered = segmentgroup.groupsForIds(hoveredEntityIds);
        let selected = segmentgroup.groupsForIds(selectedEntityIds);

        segmentgroup.temp.clear();
        if (selected.length > 0) {
            const sliced1 = segmentgroup.slice(selected);
            sliced1.material = line_selected;
            segmentgroup.temp.add(sliced1);
        }

        if (hovered.length > 0) {
            const sliced2 = segmentgroup.slice(hovered);
            sliced2.material = line_hovered;
            segmentgroup.temp.add(sliced2);
        }
    }

    private highlightFaces(solid: visual.Solid | visual.Sheet, expensive: CachedData, defaults: FaceMaterials) {
        const lod = solid.high;
        const facegroup = lod.faces;
        const hoveredEntityIds = expensive.hovered.facesForShell(solid);
        const selectedEntityIds = expensive.selected.facesForShell(solid);
        const hovered = facegroup.groupsForIds(hoveredEntityIds);
        const selected = facegroup.groupsForIds(selectedEntityIds);
        const unselected = facegroup.allGroups;
        const hovered_phantom = hovered.map(u => ({ ...u }));
        const selected_phantom = selected.map(u => ({ ...u }));
        hovered.forEach(s => s.materialIndex = 0);
        selected.forEach(s => s.materialIndex = 1);
        unselected.forEach(s => s.materialIndex = 2);
        hovered_phantom.forEach(s => s.materialIndex = 3);
        selected_phantom.forEach(s => s.materialIndex = 4);
        facegroup.mesh.material = [defaults.face_hovered, defaults.face_highlighted, defaults.mode_material, defaults.face_hovered_phantom, defaults.face_highlighted_phantom];
        facegroup.mesh.geometry.groups = [...hovered, ...selected, ...unselected, ...hovered_phantom, ...selected_phantom];
    }

    private highlightShellFaces(key: 'solid' | 'sheet', shell: visual.Solid | visual.Sheet, ancestor: visual.Solid | visual.Sheet | undefined, expensive: CachedData, override: MaterialWithColor | undefined) {
        const ancestorMaterial = ancestor !== undefined ? this.scene.getMaterial(ancestor, true) : undefined;
        const thisMaterial = !shell.isTemporary ? this.scene.getMaterial(shell, true) : undefined;
        const particularMaterial = thisMaterial ?? ancestorMaterial;

        let mode_material;
        if (override !== undefined) mode_material = override;
        else {
            switch (this.mode.tag) {
                case 'uniform':
                    mode_material = this.mode.materials[key];
                    if (this.mode.isTinted && particularMaterial !== undefined) {
                        const colored = mode_material.clone() as MaterialWithColor;
                        colored.color.set(particularMaterial.color);
                        mode_material = colored;
                    }
                    break;
                case 'per-object':
                    const perObjectMaterial = particularMaterial ?? (key === 'solid' ? default_physical_material_solid : default_physical_material_sheet);
                    mode_material = perObjectMaterial;
            }
        }
        const defaults: FaceMaterials = {
            face_hovered,
            face_highlighted,
            face_hovered_phantom,
            face_highlighted_phantom,
            mode_material
        };
        this.highlightFaces(shell, expensive, defaults);
    }

    private highlightSolidFaces(solid: visual.Solid, ancestor: visual.Solid | undefined, expensive: CachedData, override: MaterialWithColor | undefined) {
        this.highlightShellFaces('solid', solid, ancestor, expensive, override);
    }

    private highlightSheetFaces(sheet: visual.Sheet, ancestor: visual.Sheet | undefined, expensive: CachedData, override: MaterialWithColor | undefined) {
        this.highlightShellFaces('sheet', sheet, ancestor, expensive, override);
    }

    setResolution(size: THREE.Vector2) {
        for (const material of needsResolution) {
            material.resolution.copy(size);
        }
    }

    get outlineSelection(): Iterable<visual.Outlineable> {
        const cache = this.selection.selected.cache();
        const solids = cache.solids
        const sheets = cache.sheets;
        const empties = [...cache.empties].filter(e => isOutlinableEmpty(e)) as OutlinableEmpty[];
        return [...solids, ...sheets, ...empties];
    }

    get outlineHover(): Iterable<visual.Outlineable> {
        const cache = this.selection.hovered.cache();
        const solids = cache.solids;
        const sheets = cache.sheets;
        const empties = [...cache.empties].filter(e => isOutlinableEmpty(e)) as OutlinableEmpty[];
        return [...solids, ...sheets, ...empties];
    }

    useTemporary(selection: HasSelectedAndHovered) {
        switch (this.state.tag) {
            case 'none': this.state = { tag: 'scratch', selection }; break;
            case 'scratch': throw new Error("already in scratch state");
        }
        this.signals.selectionChanged.dispatch();
        const bindings: signals.SignalBinding<SelectionDelta>[] = [];
        bindings.push(selection.signals.selectionDelta.add(() => this.highlight()));
        bindings.push(selection.signals.hoverDelta.add(({ added, removed }) => {
            this.hover(added, removed);
            this.signals.hoverDelta.dispatch({ added, removed });
        }));
        return new Disposable(() => {
            bindings.forEach(x => x.detach());
            this.state = { tag: 'none' };
            this.highlight();
            this.signals.selectionChanged.dispatch();
        })
    }

    private setTheme(theme: Theme) {
        face_unhighlighted_matcap.color.setStyle(theme.colors.matcap).convertSRGBToLinear();
        face_highlighted.color.setStyle(theme.colors.yellow[200]).convertSRGBToLinear();
        face_hovered.color.setStyle(theme.colors.yellow[500]).convertSRGBToLinear();

        line_unselected.color.setStyle(theme.colors.blue[400]).convertSRGBToLinear();

        region_hovered.color.setStyle(theme.colors.blue[200]).convertSRGBToLinear();
        region_highlighted.color.setStyle(theme.colors.blue[300]).convertSRGBToLinear();
        region_unhighlighted.color.setStyle(theme.colors.blue[400]).convertSRGBToLinear();

        controlPoint_selected.setStyle(theme.colors.accent[200]).convertSRGBToLinear();
        controlPoint_hovered.setStyle(theme.colors.accent[300]).convertSRGBToLinear();
        controlPoint_unselected.setStyle(theme.colors.accent[600]).convertSRGBToLinear();
    }

    async setMatcap(name: string, isTinted: boolean): Promise<THREE.Texture> {
        const { texture, loaded } = this.textures.get(name);
        face_unhighlighted_matcap.matcap = texture;
        surface_unhighlighted_matcap.matcap = texture;
        const old = this.mode;
        this.mode = { tag: 'uniform', materials: { solid: face_unhighlighted_matcap, sheet: surface_unhighlighted_matcap }, isTinted };
        if (old.tag !== 'uniform' || old.isTinted !== isTinted || old.materials.solid !== face_unhighlighted_matcap || old.materials.sheet !== surface_unhighlighted_matcap)
            this.highlight();
        return loaded;
    }

    setUniformMaterial(material: MaterialWithColor, isTinted: boolean) {
        const doublesided = material.clone();
        doublesided.side = THREE.DoubleSide;
        this.mode = { tag: 'uniform', materials: { solid: material, sheet: doublesided }, isTinted };
        this.highlight();
    }

    togglePerObjectMode() {
        const mode = this.mode;
        const isPerObjectMode = mode.tag === 'per-object';
        if (isPerObjectMode) {
            this.mode = { tag: 'uniform', ...mode.prev };
        } else {
            this.mode = { tag: 'per-object', prev: { ...mode } };
        }
    }
}

const line_unselected = new LineMaterial({ linewidth: 1.5 });
line_unselected.polygonOffset = true;
line_unselected.polygonOffsetFactor = -2;
line_unselected.polygonOffsetUnits = -2;

const line_selected = new LineMaterial({ color: 0xffff00, linewidth: 2, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, transparent: true, opacity: 0.9 });
line_selected.depthFunc = THREE.AlwaysDepth;

const line_hovered = new LineMaterial({ color: 0xffffff, linewidth: 2, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, transparent: true, opacity: 0.8 });
line_hovered.depthFunc = THREE.AlwaysDepth;

export const line_helper = new LineMaterial({ color: 0xffffff, linewidth: 2, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
line_helper.depthFunc = THREE.AlwaysDepth;

export const face_unhighlighted_matcap = new THREE.MeshMatcapMaterial();
face_unhighlighted_matcap.fog = false;
face_unhighlighted_matcap.polygonOffset = true;
face_unhighlighted_matcap.polygonOffsetFactor = 1;
face_unhighlighted_matcap.polygonOffsetUnits = 2;

export const face_unhighlighted_black_silhouette = new THREE.MeshBasicMaterial();
face_unhighlighted_black_silhouette.color = new THREE.Color(0x0);
face_unhighlighted_black_silhouette.polygonOffset = true;
face_unhighlighted_black_silhouette.polygonOffsetFactor = 1;
face_unhighlighted_black_silhouette.polygonOffsetUnits = 2;

export const face_unhighlighted_colored_silhouette = new THREE.MeshBasicMaterial();
face_unhighlighted_colored_silhouette.color = new THREE.Color(0xffffff);
face_unhighlighted_colored_silhouette.polygonOffset = true;
face_unhighlighted_colored_silhouette.polygonOffsetFactor = 1;
face_unhighlighted_colored_silhouette.polygonOffsetUnits = 2;

export const face_unhighlighted_colored_matcap = new THREE.MeshMatcapMaterial();
face_unhighlighted_matcap.fog = false;
face_unhighlighted_matcap.polygonOffset = true;
face_unhighlighted_matcap.polygonOffsetFactor = 1;
face_unhighlighted_matcap.polygonOffsetUnits = 2;

const face_highlighted = new THREE.MeshBasicMaterial();
face_highlighted.fog = false;
face_highlighted.opacity = 0.2;
face_highlighted.transparent = true;
face_highlighted.polygonOffset = true;
face_highlighted.polygonOffsetFactor = 1;
face_highlighted.polygonOffsetUnits = 1;

// This is the face visible obscured behind objects
const face_highlighted_phantom = face_highlighted.clone();
face_highlighted_phantom.depthFunc = THREE.AlwaysDepth;
face_highlighted_phantom.transparent = true;
face_highlighted_phantom.opacity = 0.1;
face_highlighted_phantom.side = THREE.DoubleSide;

const face_hovered = new THREE.MeshBasicMaterial();
face_hovered.fog = false;
face_hovered.transparent = true;
face_hovered.opacity = 0.04;
face_hovered.polygonOffset = true;
face_hovered.polygonOffsetFactor = 1;
face_hovered.polygonOffsetUnits = 1;

// This is the face visible obscured behind objects
const face_hovered_phantom = face_hovered.clone();
face_hovered_phantom.depthFunc = THREE.AlwaysDepth;
face_hovered_phantom.transparent = true;
face_hovered_phantom.opacity = 0.04;
face_hovered_phantom.side = THREE.DoubleSide;

const region_hovered = new THREE.MeshBasicMaterial();
region_hovered.fog = false;
region_hovered.opacity = 0.3;
region_hovered.transparent = true;
region_hovered.side = THREE.DoubleSide;
region_hovered.polygonOffset = true;
region_hovered.polygonOffsetFactor = -10;
region_hovered.polygonOffsetUnits = -1;
region_hovered.depthFunc = THREE.AlwaysDepth;

const region_highlighted = new THREE.MeshBasicMaterial();
region_highlighted.fog = false;
region_highlighted.opacity = 0.7;
region_highlighted.transparent = true;
region_highlighted.side = THREE.DoubleSide;
region_highlighted.polygonOffset = true;
region_highlighted.polygonOffsetFactor = -10;
region_highlighted.polygonOffsetUnits = -1;

const region_highlighted_phantom = region_highlighted.clone();
region_highlighted_phantom.depthFunc = THREE.AlwaysDepth;
region_highlighted_phantom.transparent = true;
region_highlighted_phantom.opacity = 0.0;

export const region_unhighlighted = new THREE.MeshBasicMaterial();
region_unhighlighted.fog = false;
region_unhighlighted.opacity = 0.1;
region_unhighlighted.transparent = true;
region_unhighlighted.side = THREE.DoubleSide;
region_unhighlighted.polygonOffset = true;
region_unhighlighted.polygonOffsetFactor = -10;
region_unhighlighted.polygonOffsetUnits = -1;

export const surface_unhighlighted_matcap = face_unhighlighted_matcap.clone();
surface_unhighlighted_matcap.side = THREE.DoubleSide;

const controlPoint_intersected = new THREE.Color(0x000aaa);
const controlPoint_hovered = new THREE.Color(0xffff88);
const controlPoint_selected = new THREE.Color(0xffff00);
export const controlPoint_unselected = new THREE.Color(0xa000aa);

export const default_physical_material_solid = new THREE.MeshPhysicalMaterial({
    metalness: 1,
    roughness: 0.1,
    ior: 1.5,
    specularColor: new THREE.Color(0xffffff),
    color: new THREE.Color(0xffffff),
    envMapIntensity: 1,
    polygonOffset: true,
    polygonOffsetFactor: 1,
    polygonOffsetUnits: 2,
});
export const default_physical_material_sheet = default_physical_material_solid.clone();
default_physical_material_sheet.side = THREE.DoubleSide;

export const needsResolution = [line_unselected, line_selected, line_hovered, line_helper];

interface CachedData {
    selected: SelectionCache;
    hovered: SelectionCache;
}
