import * as THREE from "three";
import { LineMaterial } from "three/examples/jsm/lines/LineMaterial";
import { LineSegmentsGeometry } from "three/examples/jsm/lines/LineSegmentsGeometry";
import { ImageEmpty, ObjectEmpty } from "../editor/Empties";
import { RaycasterParams } from "../editor/snaps/SnapPicker";
import { mat2mat, ray2ray } from "../util/Conversion";
import { getWorldSpaceHalfWidth } from "./BetterRaycastingPoints";
import { RaycastableTopologyItem } from "./Intersectable";
import { LineSegments2 } from "./LineSegments2";
import { AbstractFaceGroup, ControlPointGroup, CurveEdge, CurveGroup, CurveSegment, CV, Face, FaceGroup, Layers, Region, RegionGroup, Sheet, Shell, SketchIsland, Solid, SpaceInstance, Vertex } from './VisualModel';

declare module './VisualModel' {
    interface TopologyItem {
        raycast(raycaster: THREE.Raycaster, intersects: THREE.Intersection[]): void;
    }

    interface Shell {
        getBoundingBox(): THREE.Box3;
    }

    interface AbstractFaceGroup<T extends Face | Region> {
        computeBoundingBox(): THREE.Box3;
    }

    interface FaceGroup {
        get backfaceCulling(): true;
    }

    interface RegionGroup {
        get backfaceCulling(): false;
    }

    interface Vertex {
        getBoundingBox(): THREE.Box3;
    }

    interface CV {
        getBoundingBox(): THREE.Box3;
    }

    interface CurveEdge {
    }

    interface CurveSegment {
        raycast(raycaster: THREE.Raycaster, intersects: THREE.Intersection[]): void;
    }
}

Shell: {
    Shell.prototype.getBoundingBox = function () {
        const geometry = this.faces.mesh.geometry;
        if (geometry.boundingBox === null) return this.faces.computeBoundingBox();
        else return geometry.boundingBox;
    }

    AbstractFaceGroup.prototype.computeBoundingBox = function () {
        const box = new THREE.Box3();
        for (const face of this) {
            box.union(face.getBoundingBox());
        }
        this.mesh.geometry.boundingBox = box;
        return box;
    }
}

Solids: {
    Solid.prototype.raycast = function (raycaster: THREE.Raycaster, intersects: THREE.Intersection[]) {
        _v1.setFromMatrixPosition(this.matrixWorld);
        const level = this.high;
        const edges = level.children[0];
        const faces = level.children[1];

        raycaster.intersectObject(faces, false, intersects);
        raycaster.intersectObject(edges, false, intersects);
    }

    Object.defineProperty(FaceGroup.prototype, 'backfaceCulling', {
        configurable: true,
        get() {
            const backfaceCulling: boolean = this.parentItem instanceof Solid;
            Object.defineProperty(this, 'backfaceCulling', { configurable: false, value: backfaceCulling });
            return backfaceCulling;
        }
    });

    FaceGroup.prototype.raycast = function (raycaster: THREE.Raycaster, intersects: THREE.Intersection[]) {
        const { matrixWorld, geometry } = this.mesh;
        const camera = raycaster.camera as THREE.PerspectiveCamera | THREE.OrthographicCamera;
        if (!raycaster.layers.isEnabled(Layers.Face)) return;

        if (geometry.boundingSphere === null) geometry.computeBoundingSphere();
        _sphere.copy(geometry.boundingSphere!);
        _sphere.applyMatrix4(matrixWorld);
        if (!raycaster.ray.intersectsSphere(_sphere)) return;

        _inverseMatrix.copy(matrixWorld).invert();
        _ray.copy(raycaster.ray).applyMatrix4(_inverseMatrix);

        if (geometry.boundingBox === null) this.computeBoundingBox();
        if (!_ray.intersectsBox(geometry.boundingBox!)) return;

        let work = this.faceOrder;
        if (this.accelerator !== undefined) {
            const result = this.accelerator.RaycastFaces(ray2ray(raycaster.ray), camera.near, mat2mat(matrixWorld));
            work = result;
        }

        // If backfaceCulling is on, we can sort the faces by distance and only check the closest ones
        // NOTE: backfaceCulling=false is sometimes used by picker when user wants all faces under the pointer
        const distances = work.map(idx => {
            this.getBoundingBox(idx, _box);
            const i = raycaster.ray.intersectBox(_box, _v2);
            return i ? raycaster.ray.origin.distanceTo(i) : Infinity;
        });
        const objectsAndDistances = [];
        for (let i = 0; i < work.length; i++) {
            objectsAndDistances.push({ object: work[i], distance: distances[i] });
        }
        objectsAndDistances.sort((a, b) => a.distance! - b.distance!);

        let minDistance = Infinity;
        for (const { object, distance } of objectsAndDistances) {
            if (distance === Infinity) continue;

            // See note in Face.raycast
            const backfaceCulling = raycaster.params.Mesh?.backfaceCulling === false ? false : this.backfaceCulling;
            if (backfaceCulling && (distance > minDistance)) break;

            raycastableTopologyItem.topologyItem = this.get(object);
            const is: THREE.Intersection[] = [];
            raycastableTopologyItem.raycast(raycaster, is);
            for (const i of is) {
                minDistance = Math.min(minDistance, i.distance);
                intersects.push(i);
            }
        }

        intersects.sort(ascSort);
    }

    RaycastableTopologyItem.prototype.raycast = function (raycaster: THREE.Raycaster, intersects: THREE.Intersection[]) {
        this['_topologyItem'].raycast(raycaster, intersects);
    }

    Face.prototype.raycast = function (raycaster: THREE.Raycaster, intersects: THREE.Intersection[]) {
        const parent = this.parent as FaceGroup;
        const { matrixWorld, geometry } = parent.mesh;
        const boundingBox = this.getBoundingBox(_box);

        _inverseMatrix.copy(matrixWorld).invert();
        _ray.copy(raycaster.ray).applyMatrix4(_inverseMatrix);

        if (!_ray.intersectsBox(boundingBox)) return;

        const group = this.group;
        const start = group.start;
        const end = group.start + group.count;
        const index = geometry.index!.array;
        const position = geometry.attributes.position!.array;

        // Normally, raycast sheets without backface culling, and solids with; however, if the
        // the raycaster explicitly disables backface culling, that takes priority.
        const backfaceCulling = raycaster.params.Mesh?.backfaceCulling === false ? false : parent.backfaceCulling;

        let minDistanceSq = Number.MAX_VALUE;
        for (let i = start; i < end; i += 3) {
            const a = index[i];
            const b = index[i + 1];
            const c = index[i + 2];

            _vA.set(position[a * 3], position[a * 3 + 1], position[a * 3 + 2]);
            _vB.set(position[b * 3], position[b * 3 + 1], position[b * 3 + 2]);
            _vC.set(position[c * 3], position[c * 3 + 1], position[c * 3 + 2]);

            if (_vA.distanceToSquared(_ray.origin) > minDistanceSq && _vB.distanceToSquared(_ray.origin) > minDistanceSq && _vC.distanceToSquared(_ray.origin) > minDistanceSq) continue;

            const intersect = _ray.intersectTriangle(_vA, _vB, _vC, backfaceCulling, _intersectionPoint);
            if (intersect === null) continue;

            _intersectionPointWorld.copy(_intersectionPoint);
            _intersectionPointWorld.applyMatrix4(matrixWorld);

            const distanceSq = raycaster.ray.origin.distanceToSquared(_intersectionPoint);
            const distance = Math.sqrt(distanceSq);
            minDistanceSq = Math.min(minDistanceSq, distanceSq);
            intersects.push({
                object: raycastableTopologyItem,
                distance,
                point: _intersectionPointWorld.clone(),
                // @ts-expect-error
                topologyItem: this,
            });
        }
    }

    CurveGroup.prototype.raycast = function (raycaster: THREE.Raycaster & { params: { Line2?: { threshold: number, offsetDistance?: boolean } } }, intersects: THREE.Intersection[]) {
        const { line } = this;
        const camera = raycaster.camera as THREE.PerspectiveCamera | THREE.OrthographicCamera;
        const { geometry, matrixWorld } = line;
        const { resolution } = line.material as LineMaterial;

        let { linewidth } = line.material;
        const raycasterParams = raycaster.params as RaycasterParams;
        const threshold = ('Line2' in raycasterParams) ? raycasterParams.Line2.threshold || 0 : 0;
        linewidth += threshold;

        BoundingSphere: {
            if (geometry.boundingSphere === null) geometry.computeBoundingSphere();
            _sphere.copy(geometry.boundingSphere!);
            _sphere.applyMatrix4(matrixWorld);

            const distanceToSphere = Math.max(camera.near, _sphere.distanceToPoint(raycaster.ray.origin)); // increase the sphere bounds by the worst case line screen space width
            _clipToWorldVector.set(0, 0, - distanceToSphere, 1.0).applyMatrix4(camera.projectionMatrix);
            _clipToWorldVector.multiplyScalar(1.0 / _clipToWorldVector.w);
            _clipToWorldVector.applyMatrix4(camera.projectionMatrixInverse); // increase the sphere bounds by the worst case line screen space width
            const sphereMargin = getWorldSpaceHalfWidth(camera, distanceToSphere, linewidth, resolution);
            _sphere.radius += sphereMargin;
            if (!raycaster.ray.intersectsSphere(_sphere)) return;
        }

        BoundingBox: {
            if (geometry.boundingBox === null) geometry.computeBoundingBox();
            _box.copy(geometry.boundingBox!);
            _box.applyMatrix4(matrixWorld);

            const distanceToBox = Math.max(camera.near, _box.distanceToPoint(raycaster.ray.origin)); // increase the box bounds by the worst case line screen space width
            const boxMargin = getWorldSpaceHalfWidth(camera, distanceToBox, linewidth, resolution);
            _box.max.x += boxMargin;
            _box.max.y += boxMargin;
            _box.max.z += boxMargin;
            _box.min.x -= boxMargin;
            _box.min.y -= boxMargin;
            _box.min.z -= boxMargin;
            if (!raycaster.ray.intersectsBox(_box)) return;
        }
        if (this.accelerator !== undefined) {
            const threshold = (raycaster.params.Line2 !== undefined) ? raycaster.params.Line2.threshold ?? 0 : 0;
            const material = this.line.material as THREE.Material & { linewidth: number, resolution: THREE.Vector2 };
            const lineWidth = material.linewidth + threshold;

            const result = this.accelerator.RaycastEdges(ray2ray(raycaster.ray), camera.near, mat2mat(camera.projectionMatrix), mat2mat(camera.projectionMatrixInverse), mat2mat(matrixWorld), lineWidth, material.resolution.x, material.resolution.y);
            if (result.length === 0) return;
            const filtered = [];
            for (const i of result) filtered.push(this.get(i));
            raycaster.intersectObjects(filtered, false, intersects);
        } else {
            raycaster.intersectObjects([...this], false, intersects);
        }
    }

    CurveEdge.prototype.raycast = function (raycaster: THREE.Raycaster, intersects: THREE.Intersection[]) {
        const parent = this.parent as CurveGroup<CurveEdge>;
        const line = parent.line;
        const boundingBox = this.getBoundingBox(_box);

        BuildSlice: {
            const allPoints = line.geometry.attributes.instanceStart.array as Float32Array;
            const group = this.group;
            const slice = new Float32Array(allPoints.buffer, group.start * 4, group.count);
            _instanceBuffer.array = slice;
            _instanceBuffer.count = slice.length / _instanceBuffer.stride;
        }

        _lineSegmentsGeometry.boundingBox!.copy(boundingBox);

        // NOTE: the precomputed bounding box is used by _lineSegments.raycast
        _lineSegments.material = line.material;
        _lineSegments.geometry = _lineSegmentsGeometry;
        _lineSegments.matrixWorld.copy(line.matrixWorld);
        const is: THREE.Intersection[] = [];
        raycaster.intersectObject(_lineSegments, false, is);

        for (const i of is) {
            intersects.push({
                ...i,
                object: raycastableTopologyItem,
                // @ts-expect-error
                topologyItem: this
            })
        }
    }
}

Sheets: {
    Sheet.prototype.raycast = Solid.prototype.raycast;
}

Curves: {
    SpaceInstance.prototype.raycast = function (raycaster: THREE.Raycaster, intersects: THREE.Intersection[]) {
        raycaster.intersectObject(this.segments, false, intersects);
        raycaster.intersectObject(this.vertices, false, intersects);
        raycaster.intersectObject(this.cvs, false, intersects);
    }

    CurveSegment.prototype.raycast = CurveEdge.prototype.raycast;

    ControlPointGroup.prototype.raycast = function (raycaster: THREE.Raycaster, intersects: THREE.Intersection[]) {
        const is: THREE.Intersection[] = [];
        raycaster.intersectObject(this.points, false, is);
        for (const i of is) {
            const topologyItem = this.get(i.index!);
            intersects.push({
                ...i,
                object: raycastableTopologyItem,
                // @ts-expect-error
                topologyItem
            });
        }
    }

    Vertex.prototype.getBoundingBox = function () {
        return new THREE.Box3(this.position, this.position);
    }

    CV.prototype.getBoundingBox = function () {
        return new THREE.Box3(this.position, this.position);
    }
}

Regions: {
    SketchIsland.prototype.raycast = function (raycaster: THREE.Raycaster, intersects: THREE.Intersection[]) {
        raycaster.intersectObject(this.regions, false, intersects);
    }

    RegionGroup.prototype.raycast = FaceGroup.prototype.raycast;

    // @ts-expect-error
    RegionGroup.prototype.backfaceCulling = false;
    Region.prototype.raycast = Face.prototype.raycast;
}

Empties: {
    ImageEmpty.prototype.raycast = function (raycaster: THREE.Raycaster, intersects: THREE.Intersection[]) {
        const child: THREE.Intersection[] = [];
        raycaster.intersectObject(this.plane, false, child);
        if (child.length > 0) {
            const intersection = child[0];
            intersection.object = this;
            intersects.push(intersection);
        }
    }

    ObjectEmpty.prototype.raycast = function (raycaster: THREE.Raycaster, intersects: THREE.Intersection[]) {
        const child: THREE.Intersection[] = [];
        raycaster.intersectObject(this.object, true, child);
        if (child.length > 0) {
            const intersection = child[0];
            intersection.object = this;
            intersects.push(intersection);
        }
    }
}

const _inverseMatrix = new THREE.Matrix4();
const _ray = new THREE.Ray();
const _sphere = new THREE.Sphere();
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _clipToWorldVector = new THREE.Vector4();
const _box = new THREE.Box3();
const _lineSegments = new LineSegments2();
const _instanceBuffer = new THREE.InstancedInterleavedBuffer([], 6, 1); // xyz, xyz
const _lineSegmentsGeometry = new LineSegmentsGeometry();
_lineSegmentsGeometry.setAttribute('instanceStart', new THREE.InterleavedBufferAttribute(_instanceBuffer, 3, 0)); // xyz
_lineSegmentsGeometry.setAttribute('instanceEnd', new THREE.InterleavedBufferAttribute(_instanceBuffer, 3, 3)); // xyz
_lineSegmentsGeometry.boundingBox = new THREE.Box3();
const raycastableTopologyItem = new RaycastableTopologyItem();
const _vA = new THREE.Vector3();
const _vB = new THREE.Vector3();
const _vC = new THREE.Vector3();
const _intersectionPoint = new THREE.Vector3();
const _intersectionPointWorld = new THREE.Vector3();

function ascSort(a: { distance: number }, b: { distance: number }) {
    return a.distance - b.distance;
}

export { };
