import {
    Box3, BufferAttribute, InstancedInterleavedBuffer,
    InterleavedBufferAttribute, Intersection, Line3,
    MathUtils,
    Matrix4,
    Mesh, OrthographicCamera,
    PerspectiveCamera, Ray, Vector2,
    Vector3,
    Vector4
} from 'three';
import { LineMaterial } from 'three/examples/jsm/lines/LineMaterial';
import { LineSegmentsGeometry } from "three/examples/jsm/lines/LineSegmentsGeometry";

const _start = new Vector3();
const _end = new Vector3();

const _start4 = new Vector4();
const _end4 = new Vector4();

const _ssOrigin = new Vector4();
const _ssOrigin3 = new Vector3();
const _mvMatrix = new Matrix4();
const _line = new Line3();
const _closestPoint = new Vector3();

const _box = new Box3();
const _clipToWorldVector = new Vector4();

let _ray: Ray, _instanceStart: BufferAttribute, _instanceEnd: BufferAttribute, _lineWidth: number;

// Returns the margin required to expand by in world space given the distance from the camera,
// line width, resolution, and camera projection
function getWorldSpaceHalfWidth(camera: OrthographicCamera | PerspectiveCamera, distance: number, resolution: Vector2) {

    // transform into clip space, adjust the x and y values by the pixel width offset, then
    // transform back into world space to get world offset. Note clip space is [-1, 1] so full
    // width does not need to be halved.
    _clipToWorldVector.set(0, 0, - distance, 1.0).applyMatrix4(camera.projectionMatrix);
    _clipToWorldVector.multiplyScalar(1.0 / _clipToWorldVector.w);
    _clipToWorldVector.x = _lineWidth / resolution.width;
    _clipToWorldVector.y = _lineWidth / resolution.height;
    _clipToWorldVector.applyMatrix4(camera.projectionMatrixInverse);
    _clipToWorldVector.multiplyScalar(1.0 / _clipToWorldVector.w);

    return Math.abs(Math.max(_clipToWorldVector.x, _clipToWorldVector.y));

}


function raycastScreenSpace(lineSegments: LineSegments2, camera: OrthographicCamera | PerspectiveCamera, intersects: (Intersection & { distance2d: number })[], offsetDistance: boolean) {

    const projectionMatrix = camera.projectionMatrix;
    const material = lineSegments.material as THREE.Material & { resolution: Vector2 };
    const resolution = material.resolution;
    const matrixWorld = lineSegments.matrixWorld;

    const geometry = lineSegments.geometry;
    const instanceStart = geometry.attributes.instanceStart as BufferAttribute;
    const instanceEnd = geometry.attributes.instanceEnd as BufferAttribute;
    const array = instanceStart.array as Float32Array;

    const near = - camera.near;

    //

    // pick a point 1 unit out along the ray to avoid the ray origin
    // sitting at the camera origin which will cause "w" to be 0 when
    // applying the projection matrix.
    _ray.at(1, _ssOrigin as unknown as THREE.Vector3);

    // ndc space [ - 1.0, 1.0 ]
    _ssOrigin.w = 1;
    _ssOrigin.applyMatrix4(camera.matrixWorldInverse);
    _ssOrigin.applyMatrix4(projectionMatrix);
    _ssOrigin.multiplyScalar(1 / _ssOrigin.w);

    // screen space
    _ssOrigin.x *= resolution.x / 2;
    _ssOrigin.y *= resolution.y / 2;
    _ssOrigin.z = 0;

    _ssOrigin3.copy(_ssOrigin as unknown as THREE.Vector3);

    _mvMatrix.multiplyMatrices(camera.matrixWorldInverse, matrixWorld);

    for (let i = 0, l = instanceStart.count; i < l; i++) {

        _start4.set(array[i * 3 * 2 + 0], array[i * 3 * 2 + 1], array[i * 3 * 2 + 2], 1);
        _end4.set(array[i * 3 * 2 + 3], array[i * 3 * 2 + 4], array[i * 3 * 2 + 5], 1);

        // camera space
        _start4.applyMatrix4(_mvMatrix);
        _end4.applyMatrix4(_mvMatrix);

        // skip the segment if it's entirely behind the camera
        const isBehindCameraNear = _start4.z > near && _end4.z > near;
        if (isBehindCameraNear) {

            continue;

        }

        // trim the segment if it extends behind camera near
        if (_start4.z > near) {

            const deltaDist = _start4.z - _end4.z;
            const t = (_start4.z - near) / deltaDist;
            _start4.lerp(_end4, t);

        } else if (_end4.z > near) {

            const deltaDist = _end4.z - _start4.z;
            const t = (_end4.z - near) / deltaDist;
            _end4.lerp(_start4, t);

        }

        // clip space
        _start4.applyMatrix4(projectionMatrix);
        _end4.applyMatrix4(projectionMatrix);

        // ndc space [ - 1.0, 1.0 ]
        _start4.multiplyScalar(1 / _start4.w);
        _end4.multiplyScalar(1 / _end4.w);

        // screen space
        _start4.x *= resolution.x / 2;
        _start4.y *= resolution.y / 2;

        _end4.x *= resolution.x / 2;
        _end4.y *= resolution.y / 2;

        // create 2d segment
        _line.start.copy(_start4 as unknown as THREE.Vector3);
        _line.start.z = 0;

        _line.end.copy(_end4 as unknown as THREE.Vector3);
        _line.end.z = 0;

        // get closest point on ray to segment
        const param = _line.closestPointToPointParameter(_ssOrigin3, true);
        _line.at(param, _closestPoint);

        // check if the intersection point is within clip space
        const zPos = MathUtils.lerp(_start4.z, _end4.z, param);
        const isInClipSpace = zPos >= - 1 && zPos <= 1;

        const distance2d = _ssOrigin3.distanceTo(_closestPoint);
        const isInside = distance2d < _lineWidth * 0.5;

        if (isInClipSpace && isInside) {

            _line.start.fromBufferAttribute(instanceStart, i);
            _line.end.fromBufferAttribute(instanceEnd, i);

            _line.start.applyMatrix4(matrixWorld);
            _line.end.applyMatrix4(matrixWorld);

            const pointOnLine = new Vector3();
            const point = new Vector3();

            _ray.distanceSqToSegment(_line.start, _line.end, point, pointOnLine);

            const distanceToPointOnLine = _ray.origin.distanceTo(pointOnLine);
            intersects.push({
                point: point,
                // @ts-ignore
                pointOnLine: pointOnLine,
                distance: distanceToPointOnLine,
                distance2d: distance2d,
                object: lineSegments,
                faceIndex: i,
            });

        }

    }

}

class LineSegments2 extends Mesh {
    isLineSegments2: boolean = true;
    material!: LineMaterial;

    constructor(geometry = new LineSegmentsGeometry(), material = new LineMaterial({ color: Math.random() * 0xffffff })) {

        super(geometry, material);

        this.type = 'LineSegments2';

    }

    // for backwards-compatibility, but could be a method of LineSegmentsGeometry...

    computeLineDistances() {

        const geometry = this.geometry;

        const instanceStart = geometry.attributes.instanceStart;
        const instanceEnd = geometry.attributes.instanceEnd;
        const lineDistances = new Float32Array(2 * instanceStart.count);

        for (let i = 0, j = 0, l = instanceStart.count; i < l; i++, j += 2) {

            _start.fromBufferAttribute(instanceStart, i);
            _end.fromBufferAttribute(instanceEnd, i);

            lineDistances[j] = (j === 0) ? 0 : lineDistances[j - 1];
            lineDistances[j + 1] = lineDistances[j] + _start.distanceTo(_end);

        }

        const instanceDistanceBuffer = new InstancedInterleavedBuffer(lineDistances, 2, 1); // d0, d1

        geometry.setAttribute('instanceDistanceStart', new InterleavedBufferAttribute(instanceDistanceBuffer, 1, 0)); // d0
        geometry.setAttribute('instanceDistanceEnd', new InterleavedBufferAttribute(instanceDistanceBuffer, 1, 1)); // d1

        return this;

    }

    raycast(raycaster: THREE.Raycaster & { params: { Line2?: { threshold: number, offsetDistance?: boolean } } }, intersects: (Intersection & { distance2d: number })[]) {
        const camera = raycaster.camera as THREE.PerspectiveCamera | THREE.OrthographicCamera;

        const threshold = (raycaster.params.Line2 !== undefined) ? raycaster.params.Line2.threshold ?? 0 : 0;
        const offsetDistance = (raycaster.params.Line2?.offsetDistance !== undefined) ? raycaster.params.Line2.offsetDistance : true;

        _ray = raycaster.ray;

        const matrixWorld = this.matrixWorld;
        const geometry = this.geometry;
        const material = this.material as THREE.Material & { linewidth: number, resolution: Vector2 };

        _lineWidth = material.linewidth + threshold;

        _instanceStart = geometry.attributes.instanceStart as BufferAttribute;
        _instanceEnd = geometry.attributes.instanceEnd as BufferAttribute;

        _box.copy(geometry.boundingBox!).applyMatrix4(matrixWorld);

        // increase the box bounds by the worst case line width
        let boxMargin;

        const distanceToBox = Math.max(camera.near, _box.distanceToPoint(_ray.origin));
        boxMargin = getWorldSpaceHalfWidth(camera, distanceToBox, material.resolution);

        _box.expandByScalar(boxMargin);

        if (_ray.intersectsBox(_box) === false) return;
        
        raycastScreenSpace(this, camera, intersects, offsetDistance);

    }

}

export { LineSegments2 };
