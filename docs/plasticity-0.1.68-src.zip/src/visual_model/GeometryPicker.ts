import * as THREE from "three";
import { Viewport } from "../components/viewport/Viewport";
import * as visual from '../visual_model/VisualModel';
import { discardOccluded, RaycastOcclusionDiscarder } from "./DiscardOccluded";
import * as intersectable from "./Intersectable";
import { StopEarlyRaycaster } from "./StopEarlyRaycaster";
import { CurveEdge, CurveSegment, CV, Face, Region, Vertex } from "./VisualModel";

export type IntersectableWithTopologyItem = THREE.Intersection<intersectable.Raycastable> & {
    topologyItem?: visual.TopologyItem;
};

export type Unprojectable = {
    distance: number;
    distance2d?: number;
    pointOnLine?: THREE.Vector3;
    point: THREE.Vector3;
}

export type UnprojectableIntersection = THREE.Intersection<intersectable.Raycastable> & Unprojectable

type Unprojected = { distance2d: number };

export class GeometryPicker {
    private readonly raycaster = new StopEarlyRaycaster();
    layers = new THREE.Layers();
    raycasterParams: Readonly<THREE.RaycasterParameters> = {};

    constructor() {
        this.raycaster.near = 0;
        this.raycaster.far = Infinity;
    }

    intersect(objects: THREE.Object3D[], isXRay = this.viewport.isXRay, isBackfaceCulling = true): intersectable.Intersection[] {
        const { raycaster, raycasterParams, layers, viewport } = this;

        raycaster.layers.mask = layers.mask;
        raycaster.params = { ...raycasterParams, Mesh: { ...raycasterParams.Mesh, backfaceCulling: isBackfaceCulling } };
        let intersections = raycaster.intersectObjects(objects, false) as UnprojectableIntersection[];
        if (!isXRay) {
            const raycast = new RaycastOcclusionDiscarder(raycaster, viewport, objects);
            intersections = discardOccluded(intersections, raycast);
        }
        const unprojected = this.unproject(intersections);
        const sorted = unprojected.sort(sort);
        return raycastable2intersectable(sorted);
    }

    private unproject<T extends UnprojectableIntersection>(intersections: T[]): (T & Unprojected)[] {
        const camera = this.raycaster.camera;
        for (const intersection of intersections) {
            let projected;
            if (intersection.distance2d !== undefined) {
                continue; // Already has a value, which our custom LineSegments2 currently sets.
            } else {
                const point = intersection.point;
                projected = point.clone().project(camera);
            }
            const distance2d = this.normalizedScreenPoint.distanceTo(projected as unknown as THREE.Vector2);
            (intersection as any).distance2d = distance2d;
        }
        return intersections as (T & Unprojected)[];
    }

    private viewport!: Viewport;
    private readonly normalizedScreenPoint = new THREE.Vector2();
    setFromViewport(normalizedScreenPoint: THREE.Vector2, viewport: Viewport) {
        viewport.camera.updateProjectionMatrix(); // ensure up-to-date; necessary for reading depthTexture
        this.raycaster.setFromCamera(normalizedScreenPoint, viewport.camera);
        this.normalizedScreenPoint.copy(normalizedScreenPoint);
        this.viewport = viewport;
    }
}

function sort(i1: IntersectableWithTopologyItem & Unprojected, i2: IntersectableWithTopologyItem & Unprojected): number {
    const o1 = i1.object, o2 = i2.object;
    const t1 = o1 instanceof intersectable.RaycastableTopologyItem ? i1.topologyItem! : o1;
    const t2 = o2 instanceof intersectable.RaycastableTopologyItem ? i2.topologyItem! : o2;
    const p1 = t1.priority, p2 = t2.priority;
    if (Math.trunc(p1) === Math.trunc(p2)) {
        if ((t1 instanceof CurveEdge && t2 instanceof CurveEdge) || (t1 instanceof CurveSegment && t2 instanceof CurveSegment)) {
            return i1.distance2d - i2.distance2d;
        } else {
            const delta = i1.distance - i2.distance;
            if (Math.abs(delta) < 10e-5) {
                if (p1 != p2) return p1 - p2;
                else return delta;
            } else return delta;
        }
    } else return p1 - p2;
}

declare module './VisualModel' {
    interface Vertex { priority: number }
    interface CV { priority: number }
    interface TopologyItem { priority: number }
    interface SpaceItem { priority: number }
}

Vertex.prototype.priority = 1;
CV.prototype.priority = 1.1;
CurveSegment.prototype.priority = 2;
CurveEdge.prototype.priority = 3;
Region.prototype.priority = 4;
Face.prototype.priority = 4.1;

function raycastable2intersectable(sorted: THREE.Intersection<intersectable.Raycastable>[]): intersectable.Intersection[] {
    const result = [];
    for (const intersection of sorted) {
        const object = intersection.object;
        const i = object instanceof intersectable.RaycastableTopologyItem
            // @ts-expect-error
            ? intersection.topologyItem
            : object;
        result.push({ ...intersection, object: i });
    }
    return result;
}

