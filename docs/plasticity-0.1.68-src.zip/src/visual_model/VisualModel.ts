import { Disposable } from "event-kit";
import * as THREE from "three";
import { LineSegmentsGeometry } from "three/examples/jsm/lines/LineSegmentsGeometry";
import { MaterialOverride } from "../editor/DatabaseLike";
import * as c3d from '../kernel/kernel';
import { indexOfIndexed, indexOfSorted } from "../util/Util";
import { BetterRaycastingPoints } from "./BetterRaycastingPoints";
import { LineSegments2 } from "./LineSegments2";

/**
 * A note about geometry disposal: Buffers need to be disposed from the GPU when no longer needed. 
 * Because of undo/redo, we don't want to dispose of geometry when it is deleted by the user; rather
 * we use a finalization registry to trigger the threejs disposal on garbage collection.
 * 
 * The geometry stored on the CPU is backed by buffers created by MeshCreator. In effect, the threejs
 * buffer is merely a slice of the MeshCreator buffer. The MeshCreator buffer is disposed when gc'd,
 * and it is kept alive using the keepAlive field; see MeshCreator and VisualModelBuilder to see how
 * this is done.
 * 
 * There is, however, one more "dispose()" concept in this code. The MeshCreator has a map of facet
 * results it uses for incremental faceting. This should be cleared when the user deletes a body, and
 * that is the Disposable callback that these objects have.
 * 
 */

export abstract class SpaceItem extends THREE.Object3D {
    #nominal: undefined;
    abstract dispose(): void;

    private readonly identity = new THREE.Matrix4();
    get isTemporaryOptimization() {
        return !this.matrixWorld.equals(this.identity);
    }
}

export type ItemId = SolidId | SheetId | SpaceInstanceId;

export abstract class Item extends SpaceItem {
    #nominal: undefined;
    get simpleName(): ItemId { return this.userData.simpleName }
    toString() { return this.simpleName.toString(); }
    get isTemporary() { return this.simpleName < 0 }
}


export class SolidLevel extends THREE.Group {
    #nominal: undefined;

    constructor(readonly edges: CurveGroup<CurveEdge>, readonly faces: AbstractFaceGroup<Face>, private readonly disposable: Disposable) {
        super();
        this.add(edges);
        this.add(faces);
    }

    clone(recursive?: boolean): this {
        return new THREE.Object3D().copy(this, recursive) as this;
    }

    dispose() { this.disposable.dispose() }
}

export interface Outlineable {
    get outline(): THREE.Object3D | undefined
}

export type ShellId = SolidId | SheetId;

const __ALLOC_ONLY__ = '__ALLOC_ONLY__';
export abstract class Shell extends Item implements Outlineable {
    #nominal: undefined;

    constructor(bypass?: string) {
        super();
        if (bypass === __ALLOC_ONLY__) return;
    }

    private readonly lods: SolidLevel[] = [];
    addLevel(level: SolidLevel, distance: number) {
        if (this.lods.length > 1) throw new Error('Only two levels allowed for now');
        this.lods.push(level);
        this.children.length = 0;
        this.add(level);
    }

    get high() { return this.lods[this.lods.length - 1] }
    get low() { return this.lods[0] }

    get edges() { return this.high.edges }
    get faces() { return this.high.faces }

    private _outline?: THREE.Object3D;
    get outline(): THREE.Object3D | undefined {
        if (!this.visible) return;
        if (this._outline === undefined) this._outline = this.computeOutline();
        this._outline.matrix.copy(this.matrix);
        this._outline.matrixAutoUpdate = false;
        return this._outline;
    }

    get bbox() {
        const geo = this.high.faces.mesh.geometry;
        if (geo.boundingBox === null) geo.computeBoundingBox();
        return geo.boundingBox!;
    }

    private computeOutline() {
        const mesh = this.faces.mesh;
        const faces = mesh.clone();
        if (Array.isArray(faces.material)) {
            faces.material = faces.material[0];
        }

        FastGeometryClone: {
            const source = faces.geometry as THREE.BufferGeometry;
            const target = new THREE.BufferGeometry();
            // To save memory, we don't clone the index array or the attributes
            target.setIndex(source.index);
            const attributes = source.attributes;
            for (const name in attributes) {
                const attribute = attributes[name];
                target.setAttribute(name, attribute);
            }
            if (source.boundingBox !== null) target.boundingBox = source.boundingBox.clone();
            if (source.boundingSphere !== null) target.boundingSphere = source.boundingSphere.clone();
            target.drawRange.start = source.drawRange.start;
            target.drawRange.count = source.drawRange.count;
            target.userData = source.userData;
            faces.geometry = target;
        }

        // We parent this ONLY so we can apply Solid-level transformations
        const parentShim = new THREE.Object3D();
        parentShim.add(faces);
        return parentShim;
    }

    dispose() {
        for (const level of this.lods) level.dispose();
    }

    abstract clone(recursive?: boolean): this;

    makePhantom(material: MaterialOverride): this {
        const clone = this.clone();
        const level = clone.children[0];
        const faces = level.children[1], edges = level.children[0];
        const mesh = faces.children[0];
        if (!(mesh instanceof THREE.Mesh)) throw new Error('Expected Mesh');
        mesh.material = material.mesh ?? mesh.material;
        const line = edges.children[0];
        const occluded = edges.children[1];
        if (!(line instanceof LineSegments2)) throw new Error('Expected Line2');
        if (!(occluded instanceof LineSegments2)) throw new Error('Expected Line2');
        line.material = material.line ?? line.material;
        occluded.material = material.lineDashed ?? occluded.material;
        return clone;
    }
}

export type SolidId = number;

export class Solid extends Shell {
    #nominal: undefined;

    constructor(bypass?: string) {
        super(bypass);
        if (bypass === __ALLOC_ONLY__) return;
        this.layers.set(Layers.Solid);
    }

    clone(recursive?: boolean): this {
        return new Solid(__ALLOC_ONLY__).copy(this, recursive) as this;
    }
}

export type SheetId = number;

export class Sheet extends Shell {
    #nominal: undefined;

    constructor(bypass?: string) {
        super(bypass);
        if (bypass === __ALLOC_ONLY__) return;
        this.layers.set(Layers.Sheet);
    }

    clone(recursive?: boolean): this {
        return new Sheet(__ALLOC_ONLY__).copy(this, recursive) as this;
    }
}

export type SpaceInstanceId = number;

export class SpaceInstance extends Item {
    #nominal: undefined;

    constructor(readonly segments: CurveGroup<CurveSegment>, private _vertices: VertexGroup, private _cvs: CVGroup, private readonly disposable: Disposable) {
        super();
        this.add(segments, _vertices, _cvs);
        this.layers.set(Layers.Curve);
    }

    get cvs() { return this._cvs }
    get vertices() { return this._vertices }
    get line() { return this.segments.line }
    get occludedLine() { return this.segments.occluded }

    get fragmentInfo(): FragmentInfo | undefined {
        if (!this.isFragment) return undefined;
        return this.userData as FragmentInfo;
    }

    befragment(edgeId: c3d.EdgeId, start: number, stop: number, ancestor: SpaceInstance) {
        this.userData.edgeId = edgeId;
        this.userData.start = start;
        this.userData.stop = stop;
        this.userData.untrimmedAncestor = ancestor;
        this._cvs.dispose();
        this._cvs.removeFromParent();
        this._cvs = emptyCVGroup;
        this._vertices.dispose();
        this._vertices.removeFromParent();
        this._vertices = emptyVertexGroup;
        this.layers.set(Layers.CurveFragment);
        this._vertices.layers.set(Layers.CurveFragment);
        this._cvs.layers.set(Layers.CurveFragment);
        this.segments.befragment();
        this.add(this._vertices, this._cvs);
    }

    get isFragment(): boolean {
        return !!this.userData.untrimmedAncestor;
    }

    dispose() {
        this.disposable.dispose();
        this._vertices.dispose();
        this._cvs.dispose();
    }

    clone(recursive?: boolean): this {
        const segments = this.segments.clone();
        const vertices = new VertexGroup(new Int32Array(), new BetterRaycastingPoints(), new BetterRaycastingPoints());
        const cvs = new CVGroup(new Int32Array(), new BetterRaycastingPoints(), new BetterRaycastingPoints(), new THREE.LineSegments());
        const inst = new SpaceInstance(segments, vertices, cvs, new Disposable()) as this;
        return inst;
    }
}

export class SketchIsland extends Item {
    #nominal: undefined;

    constructor(readonly regions: RegionGroup, private readonly disposable: Disposable) {
        super();
        this.add(regions);
    }

    dispose() { this.disposable.dispose() }
}

export type SketchIslandId = number;

export type FragmentInfo = { edgeId: c3d.EntityId, start: number, stop: number, untrimmedAncestor: SpaceInstance };

const emptyGeometry = new THREE.BufferGeometry();
emptyGeometry.setAttribute('position', new THREE.Float32BufferAttribute([], 3));
const emptyPoints = new THREE.Points(emptyGeometry);
const emptyHull = new THREE.LineSegments();
const emptyIds = new Int32Array();

export type TopologyId = EdgeId | FaceId | VertexId;
export type TopologyClass = 'e' | 's' | 'f' | 'v' | 'r';

export abstract class TopologyItem {
    #nominal: undefined;

    static decompose(id: TopologyId): [TopologyClass, ItemId, c3d.TopologyId] {
        const [_, parentId, topologyClass, entityId] = id.match(/^(\d+)(e|s|f|v|r)(\d+)$/)!;
        return [topologyClass as TopologyClass, parseInt(parentId, 10), parseInt(entityId, 10)];
    }

    static parentId(id: TopologyId): ItemId {
        const [_, parentId] = id.match(/^(\d+)/)!;
        return parseInt(parentId, 10);
    }

    layers = new THREE.Layers();

    constructor(readonly simpleName: TopologyId, readonly entityId: c3d.TopologyId) { }
}

export type VertexId = string;

export class Vertex extends TopologyItem {
    #nominal: undefined;
    readonly position = new THREE.Vector3();

    static simpleName(parentId: ItemId, id: c3d.VertexId): VertexId {
        return `${parentId}v${id}`;
    }

    constructor(
        readonly parentItem: SpaceInstance,
        readonly points: THREE.Points,
        readonly id: c3d.VertexId,
        readonly index: number,
    ) {
        super(Vertex.simpleName(parentItem.simpleName, id), id,);
    }

    get geometry() { return this.points.geometry }
    dispose() { }
}

const availableBitsForCVid = 53 - 32;
const maxCVid = 2 ** availableBitsForCVid - 1;

export type CVId = string;

export class CV {
    #nominal: undefined;
    layers = new THREE.Layers();

    readonly position = new THREE.Vector3();

    static decompose(id: CVId): [ItemId, c3d.CVId] {
        const [parentId, cvId] = id.split('c')
        return [parseInt(parentId), parseInt(cvId)];
    }

    static parentId(id: CVId): ItemId {
        const [parentId] = id.split('c')
        return parseInt(parentId);
    }

    static simpleName(parentId: SpaceInstanceId, id: c3d.CVId): CVId {
        if (id < 0) throw new Error("Invalid precondition");
        if (id > maxCVid) throw new Error("Invalid precondition");
        // const shift = Bitwise.lshift(parentId, availableBitsForCVid);
        // const or = Bitwise.or(shift, id);
        // return or;
        return `${parentId}c${id}`;
    }

    get uuid() { return this.simpleName }

    readonly simpleName = CV.simpleName(this.parentItem.simpleName, this.id);

    constructor(
        readonly parentItem: SpaceInstance,
        readonly points: THREE.Points,
        readonly id: number,
        readonly index: number,
    ) { }

    get geometry() { return this.points.geometry }
    dispose() { }
}

export type EdgeId = string;
export type SegmentId = string;

export abstract class Edge extends TopologyItem {

}

export class CurveSegment extends Edge {
    #nominal: undefined;

    static simpleName(parentId: ItemId, edgeId: c3d.EdgeId): SegmentId {
        return `${parentId}s${edgeId}`;
    }

    parent!: CurveSegmentGroup;
    get parentItem(): SpaceInstance { return this.parent.parentItem }

    constructor(readonly group: Readonly<GeometryGroup>, simpleName: EdgeId, entityId: c3d.EdgeId, private readonly index: number) {
        super(simpleName, entityId);
        this.layers.set(Layers.CurveSegment);
    }

    getBoundingBox(box = new THREE.Box3): THREE.Box3 {
        this.parent.getBoundingBox(this.index, box);
        return box;
    }

    set(group: Readonly<GeometryGroup>, parentId: ItemId, entityId: c3d.EdgeId, index: number) {
        (this['group'] as CurveSegment['group']) = group;
        (this['simpleName'] as CurveSegment['simpleName']) = CurveSegment.simpleName(parentId, entityId);
        (this['entityId'] as CurveSegment['entityId']) = entityId;
        (this['index'] as CurveSegment['index']) = index;
    }
}

export class CurveEdge extends Edge {
    #nominal: undefined;

    static simpleName(parentId: ItemId, edgeId: c3d.EdgeId): EdgeId {
        return `${parentId}e${edgeId}`;
    }

    parent!: CurveEdgeGroup;
    get parentItem() { return this.parent.parentItem }

    constructor(readonly group: Readonly<GeometryGroup>, simpleName: EdgeId, entityId: c3d.EdgeId, private readonly index: number) {
        super(simpleName, entityId);
        this.layers.set(Layers.Edge);
    }

    slice(): LineSegments2 { return this.parent.slice([this.group]); }

    getBoundingBox(box = new THREE.Box3): THREE.Box3 {
        this.parent.getBoundingBox(this.index, box);
        return box;
    }

    set(group: Readonly<GeometryGroup>, parentId: ItemId, entityId: c3d.EdgeId, index: number) {
        (this['group'] as CurveEdge['group']) = group;
        (this['simpleName'] as CurveEdge['simpleName']) = CurveEdge.simpleName(parentId, entityId);
        (this['entityId'] as CurveEdge['entityId']) = entityId;
        (this['index'] as CurveEdge['index']) = index;
    }
}

export type GeometryGroup = { start: number; count: number; materialIndex?: number | undefined };

export class GeometryGroupUtils {
    static compact(groups: Readonly<GeometryGroup>[]): GeometryGroup[] {
        const first = groups.shift();
        if (first === undefined) return [];
        if (groups.length === 0) return [first];

        let start = first.start;
        let count = first.count;
        let position = start + count;

        const result = [];
        for (const group of groups) {
            if (group.start === position) {
                count += group.count;
                position += group.count;
            } else {
                result.push({ start, count });
                start = group.start;
                count = group.count;
                position = start + count;
            }
        }
        result.push({ start, count });
        return result;
    }
}

export type FaceId = string;

export class Face extends TopologyItem {
    #nominal: undefined;

    parent!: FaceGroup;
    get parentItem() { return this.parent.parentItem }

    static simpleName(parentId: ShellId, faceId: c3d.FaceId): FaceId {
        return `${parentId}f${faceId}`;
    }

    constructor(readonly group: Readonly<GeometryGroup>, simpleName: FaceId, entityId: c3d.FaceId, private readonly index: number) {
        super(simpleName, entityId);
        this.layers.set(Layers.Face);
    }

    getBoundingBox(box = new THREE.Box3): THREE.Box3 {
        this.parent.getBoundingBox(this.index, box);
        return box;
    }

    set(group: Readonly<GeometryGroup>, parentId: ItemId, entityId: c3d.FaceId, index: number) {
        (this['group'] as Face['group']) = group;
        (this['simpleName'] as Face['simpleName']) = Face.simpleName(parentId, entityId);
        (this['entityId'] as Face['entityId']) = entityId;
        (this['index'] as Face['index']) = index;
    }
}

export type RegionId = string;

export class Region extends TopologyItem {
    #nominal: undefined;

    parent!: RegionGroup;
    get parentItem() { return this.parent.parentItem }

    static simpleName(parentId: SketchIslandId, id: c3d.FaceId): RegionId {
        return `${parentId}r${id}`;
    }

    constructor(readonly group: Readonly<GeometryGroup>, simpleName: FaceId, entityId: c3d.FaceId, private readonly index: number) {
        super(simpleName, entityId);
        this.layers.set(Layers.Region);
    }

    getBoundingBox(box = new THREE.Box3): THREE.Box3 {
        this.parent.getBoundingBox(this.index, box);
        return box;
    }

    set(group: Readonly<GeometryGroup>, parentId: ItemId, entityId: c3d.FaceId, index: number) {
        (this['group'] as Region['group']) = group;
        (this['simpleName'] as Region['simpleName']) = Region.simpleName(parentId, entityId);
        (this['entityId'] as Region['entityId']) = entityId;
        (this['index'] as Region['index']) = index;
    }
}

export abstract class CurveGroup<T extends CurveEdge | CurveSegment> extends THREE.Group {
    #nominal: undefined;

    readonly temp = new THREE.Group();
    constructor(readonly line: LineSegments2, readonly occluded: LineSegments2, readonly parentId: ItemId, readonly edgeIds: Int32Array, readonly bboxes: Float32Array, readonly groups: Int32Array) {
        super();
        const { layer, xray } = this.getLayer();
        this.layers.set(layer);
        line.layers.set(layer);
        occluded.layers.set(xray);
        this.add(line, occluded);
        this.add(this.temp);
        registry.register(this, line.geometry);
        registry.register(this, occluded.geometry);
    }

    get accelerator() {
        return this.line.geometry.userData.accelerator as c3d.FacetFacesAndEdgesResult | undefined
    }

    befragment() {
        this.layers.set(Layers.CurveFragment);
        this.line.layers.set(Layers.CurveFragment);
        this.occluded.layers.set(Layers.CurveFragment_XRay);
    }

    *[Symbol.iterator]() {
        for (let i = 0; i < this.edgeIds.length; i++) yield this.get(i);
    }

    get(i: number): T {
        const { parentId, edgeIds, groups } = this;
        const edgeId = edgeIds[i];
        const start = groups[i * 2 + 0], count = groups[i * 2 + 1];
        const group = { start, count };
        const edge = this.makeItem(group, parentId, edgeId, i) as T;
        edge.parent = this as unknown as CurveEdgeGroup | CurveSegmentGroup;
        if (this.layers.isEnabled(Layers.CurveFragment)) edge.layers.set(Layers.CurveFragment);
        return edge;
    }

    getBoundingBox(i: number, into: THREE.Box3) {
        const { bboxes } = this;
        into.min.set(bboxes[i * 6 + 0], bboxes[i * 6 + 1], bboxes[i * 6 + 2]);
        into.max.set(bboxes[i * 6 + 3], bboxes[i * 6 + 4], bboxes[i * 6 + 5]);
    }

    lookup(edgeId: c3d.EdgeId): T {
        const index = indexOfSorted(this.edgeIds, edgeId);
        return this.get(index);
    }

    hydrate(edge: T, i: number) {
        const { parentId, edgeIds, groups } = this;

        const edgeId = edgeIds[i];

        const start = groups[i * 2 + 0], count = groups[i * 2 + 1];
        const group = { start, count };
        edge.parent = this as unknown as CurveEdgeGroup | CurveSegmentGroup;
        edge.set(group, parentId, edgeId, i);
    }

    groupsForIds(ids: c3d.EdgeId[]): GeometryGroup[] {
        const groups = [];
        for (const id of ids) {
            const index = indexOfSorted(this.edgeIds, id);
            const start = this.groups[index * 2 + 0], count = this.groups[index * 2 + 1];
            groups.push({ start, count });
        }
        return GeometryGroupUtils.compact(groups);
    }

    slice(groups: GeometryGroup[]): LineSegments2 {
        const instanceStart = this.line.geometry.attributes.instanceStart as THREE.InterleavedBufferAttribute;
        const inArray = instanceStart.data.array as Float32Array;
        const inBuffer = Buffer.from(inArray.buffer);

        let size = 0;
        for (const group of groups) size += group.count;
        const outBuffer = Buffer.alloc(size * 4);
        let offset = 0;
        for (const group of groups) {
            const next = (group.start + group.count) * 4;
            inBuffer.copy(outBuffer, offset, group.start * 4, next);
            offset += group.count * 4;
        }
        const points = new Float32Array(outBuffer.buffer);
        const geometry = new LineSegmentsGeometry();
        geometry.setPositions(points);
        // Fast clone: this code is brittle but has been measured to offer a significant boost
        const line = new LineSegments2(geometry, this.line.material);
        line.scale.copy(this.line.scale);
        line.matrixWorld.copy(this.line.matrixWorld);
        line.renderOrder = this.line.renderOrder;
        return line;
    }

    get simpleName(): string { return this.userData.simpleName }
    get index(): number { return this.userData.index }
    abstract get parentItem(): Item;

    clone(recursive?: boolean): this {
        return new THREE.Object3D().copy(this) as this;
    }

    protected abstract getLayer(): { layer: Layers, xray: Layers };
    protected abstract makeItem(group: Readonly<GeometryGroup>, parentId: ItemId, edgeId: c3d.EdgeId, index: number): T;
}

export class CurveEdgeGroup extends CurveGroup<CurveEdge> {
    #nominal: undefined;

    protected getLayer() { return { layer: Layers.Edge, xray: Layers.CurveEdge_XRay } };

    get parentItem(): Solid | Sheet {
        const result = this.parent?.parent;
        if (!(result instanceof Solid) && !(result instanceof Sheet)) {
            console.error(this);
            throw new Error("Invalid precondition");
        }
        return result as Solid | Sheet;
    }

    makeItem(group: Readonly<GeometryGroup>, parentId: ItemId, edgeId: c3d.EdgeId, index: number) {
        return new CurveEdge(group, CurveEdge.simpleName(parentId, edgeId), edgeId, index);
    }

    get simpleNames() {
        const result = [];
        for (const id of this.edgeIds) {
            result.push(CurveEdge.simpleName(this.parentId, id));
        }
        return result;
    }
}

export class CurveSegmentGroup extends CurveGroup<CurveSegment> {
    #nominal: undefined;

    protected getLayer() { return { layer: Layers.CurveSegment, xray: Layers.CurveSegment_XRay } };

    get parentItem(): SpaceInstance {
        const result = this.parent;
        if (!(result instanceof SpaceInstance)) {
            console.error(this);
            throw new Error("Invalid precondition");
        }
        return result as SpaceInstance;
    }

    makeItem(group: Readonly<GeometryGroup>, parentId: ItemId, edgeId: c3d.EdgeId, index: number) {
        return new CurveSegment(group, CurveSegment.simpleName(parentId, edgeId), edgeId, index);
    }

    get simpleNames() {
        const result = [];
        for (const id of this.edgeIds) {
            result.push(CurveSegment.simpleName(this.parentId, id));
        }
        return result;
    }
}

export abstract class AbstractFaceGroup<T extends Face | Region> extends THREE.Group {
    #nominal: undefined;

    constructor(readonly mesh: THREE.Mesh, readonly parentId: ItemId, readonly faceIds: Int32Array, readonly bboxes: Float32Array, readonly groups: Int32Array, readonly faceOrder: Int32Array) {
        super();
        mesh.layers.set(Layers.Face);
        this.add(mesh);
        registry.register(this, this.mesh.geometry);
    }

    *[Symbol.iterator]() {
        for (let i = 0; i < this.faceIds.length; i++) yield this.get(i);
    }

    get accelerator() {
        return this.mesh.geometry.userData.accelerator as c3d.FacetFacesAndEdgesResult | undefined
    }

    get(i: number): T {
        const { parentId, faceIds, groups } = this;

        const faceId = faceIds[i];

        const start = groups[i * 2 + 0], count = groups[i * 2 + 1];
        const group = { start, count };

        const face = this.makeItem(group, parentId, faceId, i);
        face.parent = this as unknown as FaceGroup | RegionGroup;
        return face;
    }

    hydrate(face: T, i: number) {
        const { parentId, faceIds, groups } = this;

        const faceId = faceIds[i];

        const start = groups[i * 2 + 0], count = groups[i * 2 + 1];
        const group = { start, count };
        face.parent = this as unknown as FaceGroup | RegionGroup;
        face.set(group, parentId, faceId, i);
    }

    getBoundingBox(i: number, into: THREE.Box3) {
        const { bboxes } = this;
        into.min.set(bboxes[i * 6 + 0], bboxes[i * 6 + 1], bboxes[i * 6 + 2]);
        into.max.set(bboxes[i * 6 + 3], bboxes[i * 6 + 4], bboxes[i * 6 + 5]);
    }

    lookup(faceId: c3d.FaceId): T {
        const index = indexOfIndexed(this.faceIds, this.faceOrder, faceId);
        return this.get(index);
    }

    private _allGroups?: GeometryGroup[];
    get allGroups(): GeometryGroup[] {
        const { _allGroups } = this;
        if (_allGroups !== undefined) return _allGroups;

        const { groups } = this;
        const result: GeometryGroup[] = [];
        for (let i = 0; i < groups.length; i += 2) {
            result.push({ start: groups[i + 0], count: groups[i + 1] });
        }
        return this._allGroups = GeometryGroupUtils.compact(result);
    }

    groupsForIds(ids: c3d.FaceId[]): GeometryGroup[] {
        const result: GeometryGroup[] = [];
        for (const id of ids) {
            const index = indexOfIndexed(this.faceIds, this.faceOrder, id);
            const start = this.groups[index * 2 + 0], count = this.groups[index * 2 + 1];
            result.push({ start, count });
        }
        return GeometryGroupUtils.compact(result);
    }

    get length() { return this.faceIds.length }

    clone(recursive?: boolean): this {
        return new THREE.Object3D().copy(this) as this;
    }

    abstract get parentItem(): Item;

    protected abstract makeItem(group: Readonly<GeometryGroup>, parentId: ItemId, entityId: c3d.FaceId, index: number): T;
}

export class FaceGroup extends AbstractFaceGroup<Face> {
    #nominal: undefined;

    get simpleNames() {
        const result = [];
        for (const id of this.faceIds) {
            result.push(Face.simpleName(this.parentId, id));
        }
        return result;
    }

    get parentItem(): Solid | Sheet {
        const result = this.parent?.parent;
        if (!(result instanceof Solid) && !(result instanceof Sheet)) {
            console.error(this);
            throw new Error("Invalid precondition");
        }
        return result as Solid | Sheet;
    }

    protected makeItem(group: Readonly<GeometryGroup>, parentId: ItemId, entityId: c3d.FaceId, index: number) {
        return new Face(group, Face.simpleName(parentId, entityId), entityId, index);
    }
}

export class RegionGroup extends AbstractFaceGroup<Region> {
    #nominal: undefined;

    get simpleNames() {
        const result = [];
        for (const id of this.faceIds) {
            result.push(Region.simpleName(this.parentId, id));
        }
        return result;
    }

    get parentItem(): SketchIsland {
        const result = this.parent;
        if (!(result instanceof SketchIsland)) {
            console.error(this);
            throw new Error("Invalid precondition");
        }
        return result as SketchIsland;
    }

    protected makeItem(group: Readonly<GeometryGroup>, parentId: ItemId, entityId: c3d.FaceId, index: number) {
        return new Region(group, Region.simpleName(parentId, entityId), entityId, index);
    }
}

export abstract class ControlPointGroup<T extends Vertex | CV> extends THREE.Object3D {
    #nominal: undefined;

    constructor(protected readonly ids: Int32Array, readonly points: BetterRaycastingPoints, readonly occluded: BetterRaycastingPoints) {
        super();
        registry.register(this, points.geometry);
        registry.register(this, occluded.geometry);
    }

    get parentItem(): SpaceInstance {
        const result = this.parent;
        if (!(result instanceof SpaceInstance)) throw new Error("Invalid precondition");
        return result;
    }

    *[Symbol.iterator]() {
        for (let i = 0; i < this.length; i++) {
            yield this.get(i);
        }
    }

    getId(i: number): number {
        return this.ids[i];
    }

    get geometry() { return this.points.geometry }
    abstract get length(): number;
    abstract get(i: number): T;

    dispose() { }
}

export class VertexGroup extends ControlPointGroup<Vertex> {
    #nominal: undefined;

    readonly length: number;

    constructor(ids: Int32Array, points: BetterRaycastingPoints, occluded: BetterRaycastingPoints) {
        super(ids, points, occluded);
        this.length = ids.length;
        points.layers.set(Layers.Vertex);
        occluded.layers.set(Layers.Vertex_XRay);
        this.add(points, occluded);
        this.layers.set(Layers.Vertex);
    }

    get(i: number): Vertex {
        if (i < 0 || i >= this.length) throw new Error("Invalid index");
        const point = new Vertex(this.parentItem, this.points, this.ids[i], i);
        point.position.fromBufferAttribute(this.points.geometry.attributes.position, i);
        return point;
    }

    lookup(id: c3d.VertexId): Vertex {
        const index = indexOfSorted(this.ids, id);
        return this.get(index);
    }
}

export class CVGroup extends ControlPointGroup<CV> {
    #nominal: undefined;

    readonly length: number;

    constructor(ids: Int32Array, points: BetterRaycastingPoints, occluded: BetterRaycastingPoints, hulls: THREE.LineSegments) {
        super(ids, points, occluded);
        this.length = ids.length;
        points.layers.set(Layers.CV);
        occluded.layers.set(Layers.CV_XRay);
        hulls.layers.set(Layers.CV);
        this.add(points, occluded, hulls);
        this.layers.set(Layers.CV);
    }

    get(i: number): CV {
        if (i < 0 || i >= this.length) throw new Error("Invalid index");
        const point = new CV(this.parentItem, this.points, this.ids[i], i);
        point.position.fromBufferAttribute(this.points.geometry.attributes.position, i);
        return point;
    }
}

export const RenderOrder = {
    Overlay: 40,
    Vertex: 35,
    CV: 30,
    CurveEdge: 20,
    Face: 10,
    CurveSegment: 20,
    ImageEmpty: 0,
    ObjectEmpty: 0,
}

export enum Layers {
    Default,

    Overlay,

    Edge,
    CurveEdge_XRay,

    CurveSegment,
    CurveSegment_XRay,

    CurveFragment,
    CurveFragment_XRay,

    Solid,
    Sheet,
    Curve,
    Empty,

    Region,
    Face,

    Vertex,
    Vertex_XRay,
    CV,
    CV_XRay,
}

import("./VisualModelRaycasting");
import("./VisualModelBuilder");
import("./VisualModelBoxcasting");

const registry = new FinalizationRegistry((geo: THREE.BufferGeometry) => {
    geo.dispose();
});

const emptyCVGroup = new CVGroup(emptyIds, emptyPoints, emptyPoints, emptyHull);
const emptyVertexGroup = new VertexGroup(emptyIds, emptyPoints, emptyPoints);
