import { Disposable } from "event-kit";
import * as THREE from "three";
import { PointsMaterial } from "three";
import { LineMaterial } from 'three/examples/jsm/lines/LineMaterial.js';
import { LineSegmentsGeometry } from "three/examples/jsm/lines/LineSegmentsGeometry";
import { FaceBuffers, FacetEdgesResults } from "../editor/MeshCreator";
import * as c3d from '../kernel/kernel';
import { deunit } from "../util/Conversion";
import { BetterRaycastingPoints } from "./BetterRaycastingPoints";
import { LineSegments2 } from "./LineSegments2";
import { controlPoint_unselected } from "./RenderedSceneBuilder";
import { AbstractFaceGroup, CurveEdge, CurveEdgeGroup, CurveGroup, CurveSegment, CurveSegmentGroup, CVGroup, Face, FaceGroup, ItemId, Region, RegionGroup, RenderOrder, Sheet, Shell, ShellId, SketchIsland, Solid, SolidLevel, SpaceInstance, SpaceInstanceId, VertexGroup } from "./VisualModel";

export interface Builder<T> {
    build(simpleName: ItemId): T
}

abstract class ShellBuilder<T extends Shell> implements Builder<T> {
    private readonly levels: [CurveEdgeGroupBuilder, FaceGroupBuilder, number, Disposable][] = [];

    add(edges: CurveEdgeGroupBuilder, faces: FaceGroupBuilder, distance: number, disposable: Disposable) {
        this.levels.push([edges, faces, distance, disposable]);
    }

    build(simpleName: ItemId): T {
        const sheet = this.makeItem();
        this.levels.sort((a, b) => {
            const distance1 = a[2];
            const distance2 = b[2];
            return distance2 - distance1;
        });
        for (let i = 0; i < this.levels.length; i++) {
            const [edges, faces, distance, disposable] = this.levels[i];
            const builtEdges = edges.build();
            const builtFaces = faces.build();
            const level = new SolidLevel(builtEdges, builtFaces, disposable);
            sheet.addLevel(level, distance);
        }
        sheet.userData.simpleName = simpleName
        return sheet;
    }

    protected abstract makeItem(): T;
}


export class SolidBuilder extends ShellBuilder<Solid> {
    protected makeItem() {
        return new Solid();
    }
}

export class SheetBuilder extends ShellBuilder<Sheet> {
    protected makeItem() {
        return new Sheet();
    }
}

export class WireBodyBuilder implements Builder<SpaceInstance> {
    private curves!: CurveSegmentGroupBuilder;
    private vertices!: VertexGroup;
    private cvs!: CVGroup;
    private disposable!: Disposable;

    add(curves: CurveSegmentGroupBuilder, vertices: VertexGroup, cvs: CVGroup, distance: number, disposable: Disposable) {
        this.curves = curves;
        this.vertices = vertices;
        this.cvs = cvs;
        this.disposable = disposable;
    }

    build(simpleName: ItemId): SpaceInstance {
        const segments = this.curves.build();
        const instance = new SpaceInstance(segments, this.vertices, this.cvs, this.disposable);
        instance.userData.simpleName = simpleName; // NOTE: this is necessary because point.simpleName relies on the parent having been set.
        return instance;
    }
}

export class PlaneInstanceBuilder implements Builder<SketchIsland> {
    private regions!: RegionGroupBuilder;
    private disposable!: Disposable;

    add(regions: RegionGroupBuilder, disposable: Disposable) {
        this.regions = regions;
        this.disposable = disposable;
    }

    build(simpleName: ItemId) {
        const { regions } = this;
        const instance = new SketchIsland(regions.build() as RegionGroup, this.disposable);

        return instance;
    }
}

abstract class AbstractFaceGroupBuilder<T extends Face | Region> {
    private grid!: FaceBuffers;
    private material!: THREE.Material;
    private parentId!: ShellId;

    add(grid: FaceBuffers, parentId: ShellId, material: THREE.Material) {
        this.grid = grid;
        this.parentId = parentId;
        this.material = material;
    }

    build(): AbstractFaceGroup<T> {
        const { grid, material, parentId } = this;
        const geometry = new THREE.BufferGeometry();
        geometry.setIndex(new THREE.BufferAttribute(grid.index, 1));
        geometry.attributes.position = new THREE.BufferAttribute(grid.position, 3);
        geometry.attributes.normal = new THREE.BufferAttribute(grid.normal, 3);
        geometry.userData.keepAlive = grid.keepAlive; // NOTE: see note in MeshCreator
        geometry.userData.accelerator = grid.accelerator;
        const mesh = new THREE.Mesh(geometry, material);

        mesh.scale.setScalar(deunit(1));
        mesh.renderOrder = RenderOrder.Face;

        const group = this.makeGroup(mesh, parentId, grid.face, grid.bbox, grid.group, grid.order);

        return group;
    }

    protected abstract makeGroup(mesh: THREE.Mesh, parentId: ItemId, faceIds: Int32Array, bboxes: Float32Array, groups: Int32Array, order: Int32Array): AbstractFaceGroup<T>;
}

export class FaceGroupBuilder extends AbstractFaceGroupBuilder<Face> {
    protected makeGroup(mesh: THREE.Mesh, parentId: ItemId, faceIds: Int32Array, bboxes: Float32Array, groups: Int32Array, order: Int32Array) {
        return new FaceGroup(mesh, parentId, faceIds, bboxes, groups, order);
    }
}

export class RegionGroupBuilder extends AbstractFaceGroupBuilder<Region> {
    protected makeGroup(mesh: THREE.Mesh, parentId: ItemId, faceIds: Int32Array, bboxes: Float32Array, groups: Int32Array, order: Int32Array) {
        return new RegionGroup(mesh, parentId, faceIds, bboxes, groups, order);
    }
}

const emptyLineSegmentsGeometry = new LineSegmentsGeometry();
const emptyLineMaterial = new LineMaterial();
const emptyEdgeIds = new Int32Array();
const emptyEdgeGroups = new Int32Array();
const emptyBboxes = new Float32Array();

abstract class CurveGroupBuilder<T extends CurveEdge | CurveSegment> {
    private lines!: FacetEdgesResults;
    private material!: LineMaterial;
    private occludedMaterial!: LineMaterial;
    private parentId!: SpaceInstanceId;

    add(lines: FacetEdgesResults, parentId: SpaceInstanceId, material: LineMaterial, occludedMaterial: LineMaterial) {
        this.lines = lines;
        this.parentId = parentId;
        this.material = material;
        this.occludedMaterial = occludedMaterial;
    }

    build(): CurveGroup<T> {
        let { lines, parentId, material, occludedMaterial } = this;

        const groups = [];
        for (let i = 0; i < lines.group.length / 2; i++) {
            const start = lines.group[i * 2 + 0], count = lines.group[i * 2 + 1];
            groups.push({ start, count, materialIndex: i });
        }

        if (groups.length === 0) {
            const line = new LineSegments2(emptyLineSegmentsGeometry, emptyLineMaterial);
            const occluded = new LineSegments2(emptyLineSegmentsGeometry, emptyLineMaterial);
            return this.makeGroup(line, occluded, parentId, emptyEdgeIds, emptyBboxes, emptyEdgeGroups);
        }

        const geometry = new LineSegmentsGeometry();
        geometry.setPositions(lines.position);
        geometry.userData.keepAlive = lines.keepAlive; // NOTE: see note in MeshCreator
        geometry.userData.accelerator = lines.accelerator;

        const line = new LineSegments2(geometry, material);
        line.scale.setScalar(deunit(1));

        const occluded = new LineSegments2(geometry, occludedMaterial);
        occluded.renderOrder = line.renderOrder = RenderOrder.CurveEdge;
        occluded.scale.copy(line.scale);
        occluded.computeLineDistances();


        const group = this.makeGroup(line, occluded, parentId, lines.edge, lines.bbox, lines.group);

        return group;
    }

    protected abstract makeGroup(line: LineSegments2, occluded: LineSegments2, parentId: ItemId, edgeIds: Int32Array, bboxes: Float32Array, groups: Int32Array): CurveGroup<T>;
}

export class CurveEdgeGroupBuilder extends CurveGroupBuilder<CurveEdge> {
    makeGroup(line: LineSegments2, occluded: LineSegments2, parentId: ItemId, edgeIds: Int32Array, bboxes: Float32Array, groups: Int32Array) {
        return new CurveEdgeGroup(line, occluded, parentId, edgeIds, bboxes, groups);
    }
}

export class CurveSegmentGroupBuilder extends CurveGroupBuilder<CurveSegment> {
    makeGroup(line: LineSegments2, occluded: LineSegments2, parentId: ItemId, edgeIds: Int32Array, bboxes: Float32Array, groups: Int32Array) {
        return new CurveSegmentGroup(line, occluded, parentId, edgeIds, bboxes, groups);
    }
}

export class VertexGroupBuilder {
    static build(
        item: c3d.Wire,
        parentId: ItemId,
        material: PointsMaterial,
        occludedMaterial: PointsMaterial
    ): VertexGroup {
        const vertices = item.GetVertices();
        vertices.Sort();
        const points = vertices.GetPoints();
        const length = points.Size();
        const buffer = points.GetBuffer();
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.Float32BufferAttribute(buffer, 3));
        const colors = new Uint8Array(length * 3);
        geometry.setAttribute('color', new THREE.Uint8BufferAttribute(colors, 3, true));
        geometry.setAttribute('color', new THREE.Uint8BufferAttribute(colors, 3, true))
        for (let i = 0; i < length; i++) {
            colors[i * 3 + 0] = controlPoint_unselected.r * 255;
            colors[i * 3 + 1] = controlPoint_unselected.g * 255;
            colors[i * 3 + 2] = controlPoint_unselected.b * 255;
        }
        const better = new BetterRaycastingPoints(geometry, material);
        const occluded = new BetterRaycastingPoints(geometry, occludedMaterial);
        occluded.renderOrder = better.renderOrder = RenderOrder.Vertex;
        return new VertexGroup(vertices.GetIds(), better, occluded);
    }
}

export class CVGroupBuilder {
    static build(
        item: c3d.Wire,
        material: PointsMaterial,
        occludedMaterial: PointsMaterial,
        hullMaterial: THREE.LineBasicMaterial
    ): CVGroup {
        const cvs = item.FindOrderedEdges().GetCVs();
        const ids = cvs.GetIds();
        const length = cvs.Size();
        const buffer = cvs.GetBuffer();
        const hullBuffer = cvs.GetHullSegments();
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.Float32BufferAttribute(buffer, 3));
        const colors = new Uint8Array(length * 3);
        geometry.setAttribute('color', new THREE.Uint8BufferAttribute(colors, 3, true))
        for (let i = 0; i < length; i++) {
            colors[i * 3 + 0] = controlPoint_unselected.r * 255;
            colors[i * 3 + 1] = controlPoint_unselected.g * 255;
            colors[i * 3 + 2] = controlPoint_unselected.b * 255;
        }
        const better = new BetterRaycastingPoints(geometry, material);
        const occluded = new BetterRaycastingPoints(geometry, occludedMaterial);
        occluded.renderOrder = better.renderOrder = RenderOrder.CV;
        const hullGeometry = new THREE.BufferGeometry();
        hullGeometry.setAttribute('position', new THREE.Float32BufferAttribute(hullBuffer, 3));
        const hulls = new THREE.LineSegments(hullGeometry, hullMaterial);
        return new CVGroup(ids, better, occluded, hulls);
    }
}

