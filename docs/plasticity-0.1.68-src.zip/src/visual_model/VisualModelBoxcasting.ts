import * as THREE from "three";
import { ImageEmpty } from "../editor/Empties";
import { Boxcastable, Boxcaster, IntersectionType } from "../selection/Boxcaster";
import { SelectionAccumulator } from "../selection/SelectionAccumulator";
import { ControlPointGroup, CurveEdge, CurveEdgeGroup, CurveGroup, CurveSegment, CurveSegmentGroup, CVGroup, Face, FaceGroup, Region, RegionGroup, Sheet, Shell, SketchIsland, Solid, SpaceInstance, VertexGroup } from './VisualModel';

declare module './VisualModel' {
    interface Item extends Boxcastable { }
    interface AbstractFaceGroup<T> extends Boxcastable { }
    interface RegionGroup extends Boxcastable { }
    interface CurveGroup<T> extends Boxcastable { }
    interface CurveEdge extends Boxcastable { }
    interface Face extends Boxcastable { }
    interface CurveSegment extends Boxcastable { }
    interface Region extends Boxcastable { }
    interface ControlPointGroup<T> extends Boxcastable { }
    interface Vertex extends Boxcastable { }
    interface CV extends Boxcastable { }
    interface ImageEmpty extends Boxcastable { }
    interface SpaceItem extends Boxcastable { }
}

Shells: {
    Solid.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        if (type === 'contained') {
            selects.solidIds.add(this.simpleName);
        } else if (type === 'intersected' && boxcaster.selectGeometry(this)) {
            selects.solidIds.add(this.simpleName);
        }
        const low = this.low;
        const edges = low.edges;
        const faces = low.faces
        faces.boxcast(type, boxcaster, selects);
        edges.boxcast(type, boxcaster, selects);
        return selects;
    }

    Sheet.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        if (type === 'contained') {
            selects.sheetIds.add(this.simpleName);
        } else if (type === 'intersected' && boxcaster.selectGeometry(this)) {
            selects.sheetIds.add(this.simpleName);
        }
        const low = this.low;
        const edges = low.edges;
        const faces = low.faces
        faces.boxcast(type, boxcaster, selects);
        edges.boxcast(type, boxcaster, selects);
        return selects;
    }

    Shell.prototype.intersectsBounds = function (boxcaster: Boxcaster) {
        const low = this.low;
        const faces = low.faces;
        return faces.intersectsBounds(boxcaster);
    }

    Shell.prototype.containsGeometry = function (boxcaster: Boxcaster) {
        const low = this.low;
        const faces = low.faces;
        return faces.containsGeometry(boxcaster);
    }

    Shell.prototype.intersectsGeometry = function (boxcaster: Boxcaster) {
        const low = this.low;
        const faces = low.faces;
        return faces.intersectsGeometry(boxcaster);
    }

    FaceGroup.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        if (type === 'contained') {
            const faceIds = selects.faceIds;
            for (const simpleName of this.simpleNames) faceIds.add(simpleName);
        } else if (type === 'intersected') {
            for (const idx of this.faceOrder) {
                this.hydrate(_face, idx);
                boxcaster.selectObject(_face, selects);
            }
        }
    }

    FaceGroup.prototype.intersectsBounds = function (boxcaster: Boxcaster) {
        const { matrixWorld, geometry } = this.mesh;

        if (geometry.boundingBox === null) geometry.computeBoundingBox();
        _box.copy(geometry.boundingBox!);
        _box.applyMatrix4(matrixWorld);
        _frustum.copy(boxcaster.frustum);

        if (_frustum.containsBox(_box)) {
            return 'contained';
        } else if (_frustum.intersectsBox(_box)) {
            return 'intersected';
        } else {
            return 'not-intersected';
        }
    }

    FaceGroup.prototype.containsGeometry = function (boxcaster: Boxcaster) {
        const { matrixWorld, geometry } = this.mesh;
        const { drawRange, index } = geometry;
        const start = drawRange.start;
        const end = Math.min(index!.count, drawRange.start + drawRange.count);
        return containsGeometry(boxcaster, geometry, matrixWorld, start, end);
    }

    FaceGroup.prototype.intersectsGeometry = function (boxcaster: Boxcaster) {
        const { matrixWorld, geometry } = this.mesh;
        const { drawRange, index } = geometry;
        const start = drawRange.start;
        const end = Math.min(index!.count, drawRange.start + drawRange.count);
        return intersectsGeometry(boxcaster, geometry, matrixWorld, start, end);
    }

    Face.prototype.intersectsBounds = function (boxcaster: Boxcaster) {
        const parent = this.parent as FaceGroup;
        const { matrixWorld } = parent.mesh;
        _box.copy(this.getBoundingBox());
        _box.applyMatrix4(matrixWorld);
        _frustum.copy(boxcaster.frustum);

        if (_frustum.containsBox(_box)) {
            return 'contained';
        } else if (_frustum.intersectsBox(_box)) {
            return 'intersected';
        } else {
            return 'not-intersected';
        }
    }

    Face.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        if (type === 'contained') {
            selects.faceIds.add(this.simpleName);
        } else if (type === 'intersected' && boxcaster.selectGeometry(this)) {
            selects.faceIds.add(this.simpleName);
        }
    }

    Face.prototype.containsGeometry = function (boxcaster: Boxcaster) {
        const parent = this.parent as FaceGroup;
        const { matrixWorld, geometry } = parent.mesh;
        const { group } = this;
        const { drawRange, index } = geometry;
        const start = Math.max(group.start, drawRange.start);
        const end = Math.min(index!.count, Math.min((group.start + group.count), (drawRange.start + drawRange.count)));
        return containsGeometry(boxcaster, geometry, matrixWorld, start, end);
    }

    Face.prototype.intersectsGeometry = function (boxcaster: Boxcaster) {
        const parent = this.parent as FaceGroup;
        const { matrixWorld, geometry } = parent.mesh;
        const { group } = this;
        const { drawRange, index } = geometry;
        const start = Math.max(group.start, drawRange.start);
        const end = Math.min(index!.count, Math.min((group.start + group.count), (drawRange.start + drawRange.count)));
        return intersectsGeometry(boxcaster, geometry, matrixWorld, start, end);
    }

    CurveGroup.prototype.intersectsBounds = function (boxcaster: Boxcaster) {
        const { line: { geometry, matrixWorld } } = this;

        if (geometry.boundingBox === null) geometry.computeBoundingBox();
        _box.copy(geometry.boundingBox!);
        _box.applyMatrix4(matrixWorld);
        _frustum.copy(boxcaster.frustum);

        if (_frustum.containsBox(_box)) {
            return 'contained';
        } else if (_frustum.intersectsBox(_box)) {
            return 'intersected';
        } else {
            return 'not-intersected';
        }
    }

    CurveEdgeGroup.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        const edgeIds = selects.edgeIds;
        if (type === 'contained') {
            for (const simpleName of this.simpleNames) edgeIds.add(simpleName);
        } else if (type === 'intersected') {
            for (let i = 0; i < this.edgeIds.length; i++) {
                this.hydrate(_edge, i);
                boxcaster.selectObject(_edge, selects);
            }
        }
    }

    CurveEdge.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        if (type === 'contained') {
            selects.edgeIds.add(this.simpleName);
        } else if (type === 'intersected' && boxcaster.selectGeometry(this)) {
            selects.edgeIds.add(this.simpleName);
        }
    }

    CurveEdge.prototype.intersectsBounds = function (boxcaster: Boxcaster) {
        const parent = this.parent as CurveGroup<CurveEdge>;
        const { line: { matrixWorld } } = parent;
        this.getBoundingBox(_box);
        _box.applyMatrix4(matrixWorld);

        if (boxcaster.frustum.containsPoint(_box.min) && boxcaster.frustum.containsPoint(_box.max)) {
            return 'contained';
        } else if (boxcaster.frustum.intersectsBox(_box)) {
            return 'intersected';
        } else {
            return 'not-intersected';
        }
    }

    CurveEdge.prototype.containsGeometry = function (boxcaster: Boxcaster) {
        const parent = this.parent as CurveGroup<CurveEdge>;
        const { line: { geometry, matrixWorld } } = parent;
        const { group } = this;

        const instanceStart = geometry.attributes.instanceStart as THREE.InterleavedBufferAttribute;
        const array = instanceStart.data.array as Float32Array;

        _frustum.copy(boxcaster.frustum);
        _inverseMatrix.copy(matrixWorld).invert();
        _frustum.applyMatrix4(_inverseMatrix);

        const start = group.start / 3;
        const end = (group.start + group.count) / 3;

        for (let i = start; i <= end; i++) {
            _v.set(array[3 * i + 0], array[3 * i + 1], array[3 * i + 2]);
            if (!_frustum.containsPoint(_v)) return false;
        }
        return true;
    }

    CurveEdge.prototype.intersectsGeometry = function (boxcaster: Boxcaster) {
        const parent = this.parent as CurveGroup<any>;
        const { line: { geometry, matrixWorld } } = parent;
        const { group } = this;

        const instanceStart = geometry.attributes.instanceStart as THREE.InterleavedBufferAttribute;
        const instanceEnd = geometry.attributes.instanceEnd; // camera forward is negative

        _frustum.copy(boxcaster.frustum);
        _inverseMatrix.copy(matrixWorld).invert();
        _frustum.applyMatrix4(_inverseMatrix);

        const start = group.start / 3 / 2;
        const end = (group.start + group.count) / 3 / 2;

        for (let i = start; i < end; i++) {
            _line.start.fromBufferAttribute(instanceStart, i);
            _line.end.fromBufferAttribute(instanceEnd, i);

            if (_frustum.containsPoint(_line.start)) return true;
            if (_frustum.containsPoint(_line.end)) return true;
            if (_frustum.intersectsLine(_line)) return true;
        }
        return false;
    }
}

Curves: {
    SpaceInstance.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        if (type === 'contained') {
            selects.curveIds.add(this.simpleName);
        } else if (type === 'intersected' && boxcaster.selectGeometry(this)) {
            selects.curveIds.add(this.simpleName);
        }
        boxcaster.selectObject(this.vertices, selects);
        boxcaster.selectObject(this.cvs, selects);
    }

    SpaceInstance.prototype.intersectsBounds = function (boxcaster: Boxcaster) {
        return minIntersection([
            this.segments.intersectsBounds(boxcaster),
            this.vertices.intersectsBounds(boxcaster),
            this.cvs.intersectsBounds(boxcaster)
        ]);
    }

    SpaceInstance.prototype.containsGeometry = function (boxcaster: Boxcaster) {
        for (const segment of this.segments) {
            const i = segment.intersectsBounds(boxcaster);
            if (i === 'not-intersected') return false;
            if (i === 'contained') continue;
            if (!segment.containsGeometry(boxcaster)) return false;
        }
        return true;
    }

    SpaceInstance.prototype.intersectsGeometry = function (boxcaster: Boxcaster) {
        for (const segment of this.segments) {
            const i = segment.intersectsBounds(boxcaster);
            if (i === 'not-intersected') continue;
            if (i === 'contained') return true;
            if (segment.intersectsGeometry(boxcaster)) return true;
        }
        return false;
    }

    CurveSegmentGroup.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        if (type === 'contained') {
            const segmentIds = selects.segmentIds;
            for (const simpleName of this.simpleNames) {
                segmentIds.add(simpleName);
            }
        } else if (type === 'intersected') {
            for (let i = 0; i < this.edgeIds.length; i++) {
                this.hydrate(_segment, i);
                boxcaster.selectObject(_segment, selects);
            }
        }
    }

    CurveSegment.prototype.intersectsBounds = function (boxcaster: Boxcaster) {
        const parent = this.parent as CurveGroup<CurveSegment>;
        const { line: { matrixWorld } } = parent;
        this.getBoundingBox(_box);
        _box.applyMatrix4(matrixWorld);

        if (boxcaster.frustum.containsPoint(_box.min) && boxcaster.frustum.containsPoint(_box.max)) {
            return 'contained';
        } else if (boxcaster.frustum.intersectsBox(_box)) {
            return 'intersected';
        } else {
            return 'not-intersected';
        }
    }

    CurveSegment.prototype.containsGeometry = function (boxcaster: Boxcaster) {
        const parent = this.parent as CurveGroup<CurveSegment>;
        const { line: { geometry, matrixWorld } } = parent;
        const { group } = this;

        const instanceStart = geometry.attributes.instanceStart as THREE.InterleavedBufferAttribute;
        const array = instanceStart.data.array as Float32Array;

        _frustum.copy(boxcaster.frustum);
        _inverseMatrix.copy(matrixWorld).invert();
        _frustum.applyMatrix4(_inverseMatrix);

        const start = group.start / 3;
        const end = (group.start + group.count) / 3;

        for (let i = start; i <= end; i++) {
            _v.set(array[3 * i + 0], array[3 * i + 1], array[3 * i + 2]);
            if (!_frustum.containsPoint(_v)) return false;
        }
        return true;
    }

    if (CurveEdge.prototype.intersectsGeometry === undefined) throw new Error("invalid precondition");
    CurveSegment.prototype.intersectsGeometry = CurveEdge.prototype.intersectsGeometry;

    ControlPointGroup.prototype.intersectsBounds = function (boxcaster: Boxcaster) {
        const { geometry, matrixWorld } = this;
        if (this.length === 0) return 'not-intersected';
        if (geometry.boundingBox === null) geometry.computeBoundingBox();
        _box.copy(geometry.boundingBox!);
        _box.applyMatrix4(matrixWorld);

        if (boxcaster.frustum.containsPoint(_box.min) && boxcaster.frustum.containsPoint(_box.max)) {
            return 'contained';
        } else if (boxcaster.frustum.intersectsBox(_box)) {
            return 'intersected';
        } else {
            return 'not-intersected';
        }
    }

    VertexGroup.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        if (type === 'contained') {
            for (const point of this) selects.vertexIds.add(point.simpleName);
        } else if (type === 'intersected') {
            const { geometry, matrixWorld } = this;
            const { attributes: { position: positionAttribute }, drawRange } = geometry;

            _frustum.copy(boxcaster.frustum);
            _inverseMatrix.copy(matrixWorld).invert();
            _frustum.applyMatrix4(_inverseMatrix);

            const start = Math.max(0, drawRange.start);
            const end = Math.min(positionAttribute.count, (drawRange.start + drawRange.count));

            for (let i = start, l = end; i < l; i++) {
                _v.fromBufferAttribute(positionAttribute, i);
                if (_frustum.containsPoint(_v)) selects.vertexIds.add(this.get(i).simpleName);
            }
        }
    }

    CVGroup.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        if (type === 'contained') {
            for (const point of this) selects.cvIds.add(point.simpleName);
        } else if (type === 'intersected') {
            const { geometry, matrixWorld } = this;
            const { attributes: { position: positionAttribute }, drawRange } = geometry;

            _frustum.copy(boxcaster.frustum);
            _inverseMatrix.copy(matrixWorld).invert();
            _frustum.applyMatrix4(_inverseMatrix);

            const start = Math.max(0, drawRange.start);
            const end = Math.min(positionAttribute.count, (drawRange.start + drawRange.count));

            for (let i = start, l = end; i < l; i++) {
                _v.fromBufferAttribute(positionAttribute, i);
                if (_frustum.containsPoint(_v)) selects.cvIds.add(this.get(i).simpleName);
            }
        }
    }
}

Regions: {
    SketchIsland.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        return boxcaster.selectObject(this.regions, selects);
    }

    SketchIsland.prototype.intersectsBounds = function (boxcaster: Boxcaster) {
        return this.regions.intersectsBounds(boxcaster);
    }


    RegionGroup.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        if (type === 'contained') {
            const regionIds = selects.regionIds;
            for (const simpleName of this.simpleNames) regionIds.add(simpleName);
        } else if (type === 'intersected') {
            for (const idx of this.faceOrder) {
                this.hydrate(_region, idx);
                boxcaster.selectObject(_region, selects);
            }
        }
    }
    RegionGroup.prototype.intersectsBounds = FaceGroup.prototype.intersectsBounds;
    RegionGroup.prototype.containsGeometry = FaceGroup.prototype.containsGeometry;
    RegionGroup.prototype.intersectsGeometry = FaceGroup.prototype.intersectsGeometry;

    Region.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        if (type === 'contained') {
            selects.regionIds.add(this.simpleName);
        } else if (type === 'intersected' && boxcaster.selectGeometry(this)) {
            selects.regionIds.add(this.simpleName);
        }
    }
    Region.prototype.intersectsBounds = Face.prototype.intersectsBounds;
    Region.prototype.containsGeometry = Face.prototype.containsGeometry;
    Region.prototype.intersectsGeometry = Face.prototype.intersectsGeometry;
}

Empties: {
    ImageEmpty.prototype.boxcast = function (type: 'intersected' | 'contained', boxcaster: Boxcaster, selects: SelectionAccumulator) {
        if (type === 'contained') {
            selects.emptyIds.add(this.simpleName);
        } else if (type === 'intersected' && boxcaster.selectGeometry(this)) {
            selects.emptyIds.add(this.simpleName);
        }
    }

    ImageEmpty.prototype.intersectsBounds = function (boxcaster: Boxcaster) {
        const { matrixWorld, geometry } = this.plane;

        if (geometry.boundingBox === null) geometry.computeBoundingBox();
        _box.copy(geometry.boundingBox!);
        _box.applyMatrix4(matrixWorld);
        _frustum.copy(boxcaster.frustum);

        if (_frustum.containsBox(_box)) {
            return 'contained';
        } else if (_frustum.intersectsBox(_box)) {
            return 'intersected';
        } else {
            return 'not-intersected';
        }
    }

    ImageEmpty.prototype.containsGeometry = function (boxcaster: Boxcaster) {
        const { matrixWorld, geometry } = this.plane;
        const { drawRange, index } = geometry;
        const start = drawRange.start;
        const end = Math.min(index!.count, drawRange.start + drawRange.count);
        return containsGeometry(boxcaster, geometry, matrixWorld, start, end);
    }

    ImageEmpty.prototype.intersectsGeometry = function (boxcaster: Boxcaster) {
        const { matrixWorld, geometry } = this.plane;
        const { drawRange, index } = geometry;
        const start = drawRange.start;
        const end = Math.min(index!.count, drawRange.start + drawRange.count);
        return intersectsGeometry(boxcaster, geometry, matrixWorld, start, end);
    }
}

function intersectsGeometry(boxcaster: Boxcaster, geometry: THREE.BufferGeometry, matrixWorld: THREE.Matrix4, start: number, end: number) {
    const index = geometry.index!;
    const position = geometry.attributes.position;

    _frustum.copy(boxcaster.frustum);
    _inverseMatrix.copy(matrixWorld).invert();
    _frustum.applyMatrix4(_inverseMatrix);


    for (let i = start; i < end; i += 3) {
        const a = index.getX(i + 0);
        const b = index.getX(i + 1);
        const c = index.getX(i + 2);
        _v.fromBufferAttribute(position, a);
        if (_frustum.containsPoint(_v)) return true;
        _v.fromBufferAttribute(position, b);
        if (_frustum.containsPoint(_v)) return true;
        _v.fromBufferAttribute(position, c);
        if (_frustum.containsPoint(_v)) return true;

        _line.start.fromBufferAttribute(position, a);
        _line.end.fromBufferAttribute(position, b);
        if (_frustum.intersectsLine(_line)) return true;

        _line.start.fromBufferAttribute(position, a);
        _line.end.fromBufferAttribute(position, c);
        if (_frustum.intersectsLine(_line)) return true;

        _line.start.fromBufferAttribute(position, b);
        _line.end.fromBufferAttribute(position, c);
        if (_frustum.intersectsLine(_line)) return true;
    }
    return false;
}

function containsGeometry(boxcaster: Boxcaster, geometry: THREE.BufferGeometry, matrixWorld: THREE.Matrix4, start: number, end: number) {
    const index = geometry.index!;

    const position = geometry.attributes.position;

    _frustum.copy(boxcaster.frustum);
    _inverseMatrix.copy(matrixWorld).invert();
    _frustum.applyMatrix4(_inverseMatrix);

    for (let i = start; i < end; i++) {
        const j = index.getX(i);
        _v.fromBufferAttribute(position, j);
        if (!_frustum.containsPoint(_v)) return false;
    }
    return true;
}

export class FastFrustum extends THREE.Frustum {
    applyMatrix4(matrix: THREE.Matrix4) {
        for (const plane of this.planes) {
            plane.applyMatrix4(matrix);
        }
        return this;
    }

    intersectsLine(line: THREE.Line3): boolean {
        for (const plane of this.planes) {
            const p1 = plane.distanceToPoint(line.start);
            const p2 = plane.distanceToPoint(line.end);
            const inside = p1 >= 0 && p2 >= 0;
            if (inside) continue;
            const entering = p1 < 0 && p2 >= 0;
            const leaving = p1 >= 0 && p2 < 0;
            plane.intersectLine(line, _i);
            if (entering) line.start.copy(_i);
            else if (leaving) line.end.copy(_i);
        }
        return this.containsPoint(line.start) || this.containsPoint(line.end);
    }

    containsPoint(point: THREE.Vector3) {
        const planes = this.planes;
        for (let i = 0; i < 6; i++) {
            if (planes[i].distanceToPoint(point) < -1e-6) {
                return false;
            }
        }
        return true;
    }

    containsBox(box: THREE.Box3): boolean {
        _points[0].set(box.min.x, box.min.y, box.min.z);
        _points[1].set(box.min.x, box.min.y, box.max.z);
        _points[2].set(box.min.x, box.max.y, box.min.z);
        _points[3].set(box.min.x, box.max.y, box.max.z);
        _points[4].set(box.max.x, box.min.y, box.min.z);
        _points[5].set(box.max.x, box.min.y, box.max.z);
        _points[6].set(box.max.x, box.max.y, box.min.z);
        _points[7].set(box.max.x, box.max.y, box.max.z);
        for (const point of _points) {
            if (!this.containsPoint(point)) return false;
        }
        return true;
    }
}

function minIntersection(intersections: IntersectionType[]) {
    let notIntersected = 0, intersected = 0, contained = 0;
    for (const intersection of intersections) {
        if (intersection === 'not-intersected') notIntersected++;
        else if (intersection === 'intersected') intersected++;
        else if (intersection === 'contained') contained++;
    }
    const total = intersections.length;
    if (contained === total) return 'contained';
    else if (intersected > 0 || contained > 0) return 'intersected';
    else return 'not-intersected';
}

const _frustum = new FastFrustum();
const _v = new THREE.Vector3();
const _i = new THREE.Vector3();
const _inverseMatrix = new THREE.Matrix4();
const _box = new THREE.Box3();
const _line = new THREE.Line3();
const _face = new Face({ start: 0, count: 0 }, '', 0, 0);
const _region = new Region({ start: 0, count: 0 }, '', 0, 0);
const _edge = new CurveEdge({ start: 0, count: 0 }, '', 0, 0);
const _segment = new CurveSegment({ start: 0, count: 0 }, '', 0, 0);

const _points = [
    new THREE.Vector3(),
    new THREE.Vector3(),
    new THREE.Vector3(),
    new THREE.Vector3(),
    new THREE.Vector3(),
    new THREE.Vector3(),
    new THREE.Vector3(),
    new THREE.Vector3()
];
export { };
