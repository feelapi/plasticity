import classNames from 'classnames';
import { createRef } from 'preact';
import { useState } from 'preact/hooks';
import * as THREE from 'three';
import * as cmd from "../../command/Command";
import { TransactionBuilder } from '../../editor/db/DatabaseTransaction';
import { Editor } from '../../editor/Editor';
import { Empty } from '../../editor/Empties';
import { Group, VirtualGroup } from '../../editor/Groups';
import { NodeItem, NodeKey, RealNodeItem } from '../../editor/Nodes';
import * as visual from '../../visual_model/VisualModel';

export const indentSize = 12;

export default (editor: Editor) => {
    type OutlinerItemProps = {
        onExpand: (e: MouseEvent, group: Group) => void,
        onSelect: (e: MouseEvent, item: RealNodeItem, position: number) => void,
        onHover: (e: MouseEvent, item?: RealNodeItem) => void,
        nodeKey: NodeKey,
        position: number,
        isExpanded: boolean,
        isFirstSelected: boolean,
        isLastSelected: boolean,
        klass: string,
        name: string,
        indent: number,
        isVisible: boolean,
        isHidden: boolean,
        isSelectable: boolean,
        isDisplayed: boolean,
        isSelected: boolean,
        material: THREE.Material | undefined,
    };

    function OutlinerItem({ nodeKey, isExpanded, klass, isVisible, isHidden, isSelectable, isSelected, isDisplayed, name, indent, material, isFirstSelected, isLastSelected, onExpand, onSelect, onHover, position }: OutlinerItemProps) {
        const { scene } = editor;
        const item = scene.key2item(nodeKey);
        if (!(item instanceof visual.Item || item instanceof Group || item instanceof Empty)) throw new Error("invalid item: " + item.constructor.name);
        const inputRef = createRef<HTMLInputElement>();
        const itemRef = createRef<HTMLDivElement>();
        const [isEditable, setEditable] = useState(false);
        const color = getColor(material);

        const handleEnter = (e: KeyboardEvent) => {
            if (e.code === "Enter") {
                setName();
                inputRef.current!.blur();
            }
            e.stopPropagation();
        }

        const handleBlur = (e: FocusEvent) => {
            setName();
            e.stopPropagation();
        }

        const setName = () => {
            setEditable(false);
            const input = inputRef.current!;
            if (input.value === name) return;

            const command = new SetNameCommand(editor, item, input.value);
            editor.exec(command);
        }

        const expand = (e: MouseEvent) => {
            if (!(item instanceof Group)) throw new Error("invalid item: " + item.constructor.name);
            e.stopPropagation();
            e.preventDefault();
            onExpand(e, item);
        }

        const select = (e: MouseEvent) => {
            e.stopPropagation();
            e.preventDefault();
            onSelect(e, item, position);
        }

        const hover = (e: MouseEvent) => {
            onHover(e, item);
        }

        const unhover = (e: MouseEvent) => {
            onHover(e, undefined);
        }

        const editName = (e: MouseEvent) => {
            setEditable(true);
            const input = inputRef.current!;
            input.select();
            input.focus();
        }

        const setVisibility = (e: MouseEvent, value: boolean) => {
            const command = new ToggleVisibilityCommand(editor, item, value);
            editor.exec(command);
            e.stopPropagation();
        }

        const setHidden = (e: MouseEvent, value: boolean) => {
            const command = new ToggleHiddenCommand(editor, item, value);
            editor.exec(command);
            e.stopPropagation();
        }

        const setSelectable = (e: MouseEvent, value: boolean) => {
            const command = new ToggleSelectableCommand(editor, item, value);
            editor.exec(command);
            e.stopPropagation();
        }

        const allowDrop = (e: DragEvent) => {
            // if (item instanceof Group && !isExpanded) expand(e);
            e.preventDefault();
        }

        const onDragEnter = (e: DragEvent) => {
            itemRef.current?.classList.add("ring-2");
        }

        const onDragLeave = (e: DragEvent) => {
            itemRef.current?.classList.remove("ring-2");
        }

        const onDragStart = (e: DragEvent) => {
            e.dataTransfer!.setData("plasticity/item-id", String(item.simpleName));
            e.dataTransfer!.setData("plasticity/command", "set-parent");
            e.dataTransfer!.effectAllowed = "move";
            e.stopPropagation();
        }

        const onDragStartMaterial = (e: DragEvent) => {
            e.dataTransfer!.setData("plasticity/item-id", String(item.simpleName));
            e.dataTransfer!.setData("plasticity/command", "use-material");
            e.stopPropagation();
        }

        const onDrop = (e: DragEvent) => {
            itemRef.current?.classList.remove("ring-2");
            const itemId = e.dataTransfer!.getData("plasticity/item-id");
            const command = e.dataTransfer!.getData("plasticity/command");
            const droppedItem = editor.db.lookupItemById(Number(itemId)).view;
            if (command === "set-parent") {
                const parent = item instanceof Group ? item : editor.scene.parent(item) ?? editor.scene.root;
                const command = new MoveToGroupCommand(editor, droppedItem, parent);
                editor.exec(command);
            } else if (command === "use-material") {
                const command = new UseMaterialCommand(editor, item, droppedItem);
                editor.exec(command);
            } else throw new Error("invalid command: " + command);
            e.preventDefault();
            e.stopPropagation();
        }

        indent = item instanceof Group ? indent - 1 : indent;
        const input = !isEditable
            ? <input
                type="text"
                class={classNames(
                    "w-full text-xs h-6 py-1 bg-transparent rounded pointer-events-none overflow-hidden overflow-ellipsis whitespace-nowrap",
                    isSelected
                        ? 'text-accent-100 hover:text-accent-50'
                        : 'text-neutral-300 group-hover:text-neutral-100'
                )}
                ref={inputRef}
                autoComplete='no' autocorrect='off' spellCheck={false}
                placeholder={klass} value={name}
            ></input>
            : <input
                type="text"
                class="w-full h-6 py-1 overflow-hidden text-xs bg-transparent rounded select-text overflow-ellipsis whitespace-nowrap"
                ref={inputRef}
                autoComplete='no' autocorrect='off' spellCheck={false}
                placeholder={klass} value={name}
                onBlur={handleBlur}
                onKeyDown={handleEnter}
                onSelect={e => e.stopPropagation()}
            ></input>;
        const anySettingsForThisSpecificItem = isHidden || !isVisible || !isSelectable;
        return (
            <div
                ref={itemRef}
                class={classNames("flex gap-1 overflow-hidden items-center group pr-1",
                    !isDisplayed && 'opacity-50',
                    isSelected ? 'bg-accent-600 hover:bg-accent-500' : 'hover:bg-neutral-600 hover:rounded',
                    isFirstSelected && 'rounded-t',
                    isLastSelected && 'rounded-b',
                )}
                style={`padding-left: ${indentSize * indent}px`}
                onPointerUp={select}
                onPointerEnter={hover}
                onPointerLeave={unhover}
                onDragOver={allowDrop}
                onDragEnter={onDragEnter}
                onDragLeave={onDragLeave}
                onDragStart={onDragStart}
                onDrop={onDrop}
                draggable={true}
            >
                {item instanceof Group
                    ? (
                        <button class="w-4 h-4" onClick={expand}>
                            <plasticity-icon key={isExpanded ? "nav-arrow-down" : "nav-arrow-right"} name={isExpanded ? "nav-arrow-down" : "nav-arrow-right"} class="text-neutral-500 hover:text-neutral-300"></plasticity-icon>
                        </button>)
                    : <div class="w-4 h-4"></div>
                }
                <plasticity-icon
                    key={klass}
                    name={klass.toLowerCase()}
                    class={isSelected ? 'text-accent-100 hover:text-accent-50' : 'text-accent-500 hover:text-neutral-50'}
                ></plasticity-icon>
                <div
                    class="py-0.5 flex-1"
                    onDblClick={e => { if (!isEditable) editName(e) }}
                >
                    {input}
                </div>
                {!isEditable && <>
                    <button
                        class={classNames(
                            "px-1 rounded group",
                            isSelected ? 'text-accent-300 hover:text-accent-100' : "text-neutral-300 hover:text-neutral-100",
                            isHidden ? '' : anySettingsForThisSpecificItem ? "group-hover:visible invisible" : "group-hover:block hidden"
                        )}
                        onClick={e => setHidden(e, !isHidden)}
                    >
                        <plasticity-tooltip placement="top" command="command:hide-selected">Hide in viewport</plasticity-tooltip>
                        <plasticity-icon key={!isHidden} name={!isHidden ? 'eye' : 'eye-off'}></plasticity-icon>
                    </button>
                    <button
                        class={classNames(
                            "px-1 rounded group",
                            isSelected ? 'text-accent-300 hover:text-accent-100' : "text-neutral-300 hover:text-neutral-100",
                            !isVisible ? '' : anySettingsForThisSpecificItem ? "group-hover:visible invisible" : "group-hover:block hidden"
                        )}
                        onClick={e => setVisibility(e, !isVisible)}
                    >
                        <plasticity-tooltip placement="top">Disable in viewport</plasticity-tooltip>
                        <plasticity-icon key={isVisible} name={isVisible ? 'light-bulb-on' : 'light-bulb-off'}></plasticity-icon>
                    </button>
                    <button
                        class={classNames(
                            "px-1 rounded group",
                            isSelected ? 'text-accent-300 hover:text-accent-100' : "text-neutral-300 hover:text-neutral-100",
                            !isSelectable ? '' : anySettingsForThisSpecificItem ? "group-hover:visible invisible" : "group-hover:block hidden"
                        )}
                        onClick={e => setSelectable(e, !isSelectable)}
                    >
                        <plasticity-tooltip placement="top">Disable selection in viewport</plasticity-tooltip>
                        <plasticity-icon key={isSelectable} name={isSelectable ? 'no-lock' : 'lock'}></plasticity-icon>
                    </button>
                    <button
                        onDragStart={onDragStartMaterial}
                        draggable={true}
                        style={color === undefined ? "" : `background-color: #${color}`}
                        class={classNames(
                            "w-2 h-2 px-1 rounded-full group",
                            isSelected ? 'text-accent-300 hover:text-accent-100' : "text-neutral-300 hover:text-neutral-100",
                            color === undefined ? '' : "ring-1"
                        )}
                    >
                    </button>
                </>
                }
            </div>);
    }

    type OutlinerSectionProps = {
        onClick: (e: MouseEvent) => void,
        virtualGroup: VirtualGroup,
        name: string,
        isDisplayed: boolean,
        isVisible: boolean,
        indent: number,
    }

    function OutlinerSection({ virtualGroup, name, isDisplayed, isVisible, indent }: OutlinerSectionProps) {
        const setVisibility = (e: MouseEvent, virtual: VirtualGroup, value: boolean) => {
            const command = new ToggleVisibilityCommand(editor, virtual, value);
            editor.exec(command);
            e.stopPropagation();
        }

        return <div
            class={classNames(
                "flex gap-1 pl-0.5 pr-3 overflow-hidden items-center rounded-md group",
                isDisplayed ? '' : 'opacity-50',
            )}
            style={`padding-left: ${indentSize * indent}px`}
        >
            <div class="w-4 h-4"></div>
            <div class="pt-0.5 flex-1">
                <div class="w-full uppercase text-neutral-400 font-medium text-xxs group-hover:text-neutral-200 h-5 p-0.5 bg-transparent rounded pointer-events-none overflow-hidden overflow-ellipsis whitespace-nowrap">{name}</div>
            </div>
            <button
                class="py-0.5 rounded group text-neutral-300 group-hover:visible invisible hover:text-neutral-100"
                onClick={e => setVisibility(e, virtualGroup, !isVisible)}
            >
                <plasticity-tooltip placement="top">Disable in viewport</plasticity-tooltip>
                <plasticity-icon key={isVisible} name={isVisible ? 'light-bulb-on' : 'light-bulb-off'}></plasticity-icon>
            </button>
        </div>
    }
    return { OutlinerItem, OutlinerSection };
}

export class ToggleVisibilityCommand extends cmd.CommandLike {
    constructor(editor: cmd.EditorLike, private readonly item: NodeItem, private readonly value: boolean) {
        super(editor);
    }

    async execute(): Promise<void> {
        const db = this.editor.db;
        if (this.value) await db.makeVisible(this.item)
        else await db.makeInvisible(this.item);
    }
}

class ToggleHiddenCommand extends cmd.CommandLike {
    constructor(editor: cmd.EditorLike, private readonly item: RealNodeItem, private readonly value: boolean) {
        super(editor);
    }

    async execute(): Promise<void> {
        const db = this.editor.db;
        if (this.value) await db.hideItem(this.item)
        else await db.unhideItem(this.item);
    }
}

class ToggleSelectableCommand extends cmd.CommandLike {
    constructor(editor: cmd.EditorLike, private readonly item: NodeItem, private readonly value: boolean) {
        super(editor);
    }

    async execute(): Promise<void> {
        const { editor: { db, selection }, item } = this;
        if (this.value) await db.makeSelectable(this.item)
        else await db.makeUnselectable(this.item);
        if (item instanceof visual.Item) selection.selected.remove(item);
    }
}

export class MoveToGroupCommand extends cmd.CommandLike {
    constructor(editor: cmd.EditorLike, private readonly item: RealNodeItem, private readonly group: Group) {
        super(editor);
    }

    async execute(): Promise<void> {
        const { editor: { db, geo, selection: { selected, selected: { items, empties, groups } } }, item, group } = this;
        const all = selected.has(item) ? [...items, ...empties, ...groups] : [item];
        const txn = new TransactionBuilder(geo);
        for (const i of all) txn.move(i, group);
        await db.commit(txn);
    }
}

class UseMaterialCommand extends cmd.CommandLike {
    constructor(editor: cmd.EditorLike, private readonly item: RealNodeItem, private readonly from: RealNodeItem) {
        super(editor);
    }

    async execute(): Promise<void> {
        const { editor: { nodes }, item, from } = this;
        nodes.useMaterial(item, from);
    }
}

class SetNameCommand extends cmd.CommandLike {
    constructor(editor: cmd.EditorLike, private readonly item: RealNodeItem, private readonly value: string) {
        super(editor);
    }

    async execute(): Promise<void> {
        const { editor: { nodes }, item, value } = this;
        nodes.setName(item, value);
    }
}


function getColor(material: THREE.Material | undefined): string | undefined {
    if (material instanceof THREE.MeshStandardMaterial) return material.color.getHexString();
    if (material instanceof THREE.MeshBasicMaterial) return material.color.getHexString();
    if (material instanceof THREE.MeshLambertMaterial) return material.color.getHexString();
    return undefined;
}
