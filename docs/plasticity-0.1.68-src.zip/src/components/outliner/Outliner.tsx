import { CompositeDisposable, Disposable } from 'event-kit';
import { render } from 'preact';
import * as cmd from "../../command/Command";
import { DeselectAllCommand, ExportCommand, GroupSelectedCommand, HideSelectedCommand, HideUnselectedCommand, InvertHiddenCommand, LockSelectedCommand, UngroupSelectedCommand, UnhideAllCommand } from '../../commands/CommandLike';
import { DeleteCommand, RemoveMaterialCommand, SetMaterialCommand } from '../../commands/GeometryCommands';
import { Editor } from '../../editor/Editor';
import { Empty } from '../../editor/Empties';
import { Group, GroupId, VirtualGroup } from '../../editor/Groups';
import { NodeKey, RealNodeItem } from '../../editor/Nodes';
import { ChangeSelectionModifier, ChangeSelectionOption, SelectionDelta } from '../../selection/ChangeSelectionExecutor';
import { SelectionKeypressStrategy } from '../../selection/SelectionKeypressStrategy';
import { assertUnreachable } from '../../util/Util';
import * as visual from '../../visual_model/VisualModel';
import { findContiguousBlocksOfSelectedItems, FlatOutlineElement, flatten } from "./FlattenOutline";
import OutlinerItems, { MoveToGroupCommand, ToggleVisibilityCommand } from './OutlinerItems';

export interface EditorLike extends cmd.EditorLike { }

type OutlinerState = { tag: 'basic', selector: BasicOutlinerSelector } | { tag: 'temporary', selector: OutlinerSelector }

export class Outliner {
    private readonly basic = new BasicOutlinerSelector(this.editor);
    private state: OutlinerState = { tag: 'basic', selector: this.basic };

    constructor(private readonly editor: EditorLike) { }

    select(items: RealNodeItem[], modifier: ChangeSelectionModifier, option: ChangeSelectionOption) {
        this.state.selector.select(items, modifier, option);
    }

    hover(items: RealNodeItem[], modifier: ChangeSelectionModifier, option: ChangeSelectionOption) {
        this.state.selector.hover(items, modifier, option);
    }

    push(selector: OutlinerSelector) {
        if (this.state.tag !== 'basic') throw new Error("invalid state");

        this.state = { tag: 'temporary', selector };
        return new Disposable(() => {
            this.state = { tag: 'basic', selector: this.basic }
        });
    }
}

export default (editor: Editor) => {
    const { OutlinerItem, OutlinerSection } = OutlinerItems(editor);

    const keypress = new SelectionKeypressStrategy(editor.keymaps);

    class OutlinerElement extends HTMLElement {
        readonly model = new Outliner(editor);

        private readonly disposable = new CompositeDisposable();
        private readonly expandedGroups = new Set<GroupId>([editor.scene.root.id]);

        connectedCallback() {
            const { disposable } = this;
            editor.outliners.add(this.model);
            this.render();

            editor.signals.backupLoaded.add(this.render);
            // editor.signals.sceneGraphChanged.add(this.render);
            editor.signals.selectionDelta.add(this.onSelectionDelta);
            editor.signals.commandEnded.add(this.render);
            editor.signals.historyChanged.add(this.render);

            const Commands = [DeleteCommand, LockSelectedCommand, HideSelectedCommand, HideUnselectedCommand, InvertHiddenCommand, UnhideAllCommand, DeselectAllCommand, ExportCommand, GroupSelectedCommand, UngroupSelectedCommand, SetMaterialCommand, RemoveMaterialCommand];
            for (const Command of Commands) {
                disposable.add(editor.registry.addOne(this, `command:${Command.identifier}`, () => {
                    const command = new Command(editor);
                    command.agent = 'user';
                    editor.exec(command)
                }));
            }
        }

        disconnectedCallback() {
            editor.outliners.delete(this.model);
            editor.signals.backupLoaded.remove(this.render);
            // editor.signals.sceneGraphChanged.remove(this.render);
            editor.signals.historyChanged.remove(this.render);
            editor.signals.commandEnded.remove(this.render);
            editor.signals.selectionDelta.remove(this.onSelectionDelta);
            this.disposable.dispose();
        }

        private onSelectionDelta = (delta: SelectionDelta) => {
            const { scene } = editor;
            for (const item of delta.added) {
                if (!(item instanceof Group || item instanceof visual.Item)) continue;
                let parent = scene.parent(item);
                if (parent === undefined) return;
                while (!parent.isRoot) {
                    this.expandedGroups.add(parent.id);
                    parent = scene.parent(parent)!;
                }
            }
            this.lastSelected = undefined;
        }

        static klass(nodeKey: NodeKey): string {
            const item = editor.scene.key2item(nodeKey);
            if (item instanceof visual.Solid) return "Solid";
            else if (item instanceof visual.Sheet) return "Sheet";
            else if (item instanceof visual.SpaceInstance) return "Curve";
            else if (item instanceof Group) return "Group";
            else if (item instanceof Empty) return "Empty";
            // NOTE: these three should never happen
            else if (item instanceof VirtualGroup) return "VirtualGroup";
            else if (item instanceof visual.SketchIsland) return "Sketch";
            else if (item instanceof visual.Shell) return "Shell";
            else assertUnreachable(item);
        }

        private flattened?: FlatOutlineElement[];
        render = () => {
            const { scene, scene: { root }, selection: { selected } } = editor;
            const selectionCache = selected.cache();

            const flattened = flatten(root, scene, scene.visibility, this.expandedGroups);
            this.flattened = flattened;
            const { firstSelected, lastSelected } = findContiguousBlocksOfSelectedItems(flattened, selectionCache);

            const items = flattened.map((item, i) => {
                const { indent, displayed: isDisplayed, tag } = item;
                switch (tag) {
                    case 'Group':
                    case 'Empty':
                    case 'Item':
                        const object = item.object;
                        const nodeKey = scene.item2key(object);
                        const id = object instanceof Group || object instanceof Empty ? object.simpleName : editor.geo.lookupStableId(object.simpleName);
                        const klass = OutlinerElement.klass(nodeKey);
                        const name = scene.getName(object) ?? `${klass} ${id}`;
                        return <OutlinerItem
                            key={nodeKey}
                            position={i}
                            onExpand={this.expand}
                            onSelect={this.select}
                            onHover={this.hover}
                            isFirstSelected={firstSelected.has(i)}
                            isLastSelected={lastSelected.has(i)}
                            isExpanded={this.expandedGroups.has(object.id)}
                            nodeKey={nodeKey}
                            klass={klass}
                            name={name}
                            indent={indent}
                            isVisible={scene.isVisible(object)}
                            isHidden={scene.isHidden(object)}
                            isSelectable={scene.isSelectable(object)}
                            isDisplayed={isDisplayed}
                            isSelected={selectionCache.has(object)}
                            material={scene.getMaterial(object)}
                        />
                    case 'SolidSection':
                    case 'CurveSection':
                    case 'EmptySection': {
                        const group = scene.lookupGroupById(item.parentId);
                        let name: string;
                        let virtualGroup: VirtualGroup;
                        switch (tag) {
                            case 'CurveSection': name = 'Curves'; virtualGroup = group.curves; break;
                            case 'SolidSection': name = 'Solids'; virtualGroup = group.solids; break;
                            case 'EmptySection': name = 'Empties'; virtualGroup = group.empties; break;
                            default: assertUnreachable(tag);
                        }
                        const isVisible = scene.isVisible(virtualGroup);
                        return <OutlinerSection
                            key={editor.nodes.item2key(virtualGroup)}
                            onClick={e => this.setVisibility(e, virtualGroup, !isVisible)}
                            virtualGroup={virtualGroup}
                            name={name}
                            isDisplayed={item.displayed}
                            isVisible={isVisible}
                            indent={indent}
                        />
                    }
                }
            });

            render(<div class="relative">
                <div
                    class="overflow-y-auto overflow-x-clip w-full h-full pt-1"
                    onDrop={this.onDrop}
                    onDragOver={this.allowDrop}
                >
                    <div class="px-3">
                        {items}
                    </div>
                </div>
                <div class="absolute border-t p-2 w-full text-neutral-600">
                    <button
                        class="py-0.5 rounded group text-neutral-300 hover:text-neutral-100"
                        onClick={this.createGroup}
                    >
                        <plasticity-icon name='plus'></plasticity-icon>
                        <plasticity-tooltip placement="top" command="command:group-selected">Create group (of selected items)</plasticity-tooltip>
                    </button>
                </div>
            </div>
                , this);
        }

        expand = (e: MouseEvent, group: Group) => {
            if (this.expandedGroups.has(group.id)) this.expandedGroups.delete(group.id);
            else this.expandedGroups.add(group.id);
            this.render();
        }

        private lastSelected?: number;
        select = (e: MouseEvent, item: RealNodeItem, position: number) => {
            const items: RealNodeItem[] = [];
            if (this.lastSelected !== undefined && e.shiftKey) {
                const { flattened } = this;
                if (flattened === undefined) throw new Error("flattened is undefined");
                const min = Math.min(this.lastSelected, position);
                const max = Math.max(this.lastSelected, position);
                for (let i = min; i <= max; i++) {
                    const item = flattened[i];
                    if (item.tag === 'Group' || item.tag === 'Item' || item.tag === 'Empty') items.push(item.object);
                }
                this.model.select(items, ChangeSelectionModifier.Add, keypress.event2option(e));
            } else {
                this.model.select([item], keypress.event2modifier(e), keypress.event2option(e));
            }
            this.lastSelected = position;
        }

        hover = (e: MouseEvent, item?: RealNodeItem) => {
            if (item === undefined) this.model.hover([], ChangeSelectionModifier.Replace, ChangeSelectionOption.None);
            else this.model.hover([item], keypress.event2modifier(e), keypress.event2option(e));
        }

        setVisibility = async (e: MouseEvent, virtual: VirtualGroup, value: boolean) => {
            const command = new ToggleVisibilityCommand(editor, virtual, value);
            editor.exec(command);
            e.stopPropagation();
        }

        createGroup = (e: MouseEvent) => {
            const command = new GroupSelectedCommand(editor);
            editor.exec(command);
        }

        allowDrop = (e: DragEvent) => {
            e.preventDefault();
        }

        onDrop = (e: DragEvent) => {
            const itemId = e.dataTransfer!.getData("plasticity/item-id");
            const command = e.dataTransfer!.getData("plasticity/command");
            const droppedItem = editor.db.lookupItemById(Number(itemId)).view;
            if (command === "set-parent") {
                const command = new MoveToGroupCommand(editor, droppedItem, editor.scene.root);
                editor.exec(command);
            }
            e.preventDefault();
            e.stopPropagation();
        }
    }
    customElements.define('plasticity-outliner', OutlinerElement);
}

export interface OutlinerSelector {
    select(items: RealNodeItem[], modifier: ChangeSelectionModifier, option: ChangeSelectionOption): void;
    hover(items: RealNodeItem[], modifier: ChangeSelectionModifier, option: ChangeSelectionOption): void;
}

class BasicOutlinerSelector implements OutlinerSelector {
    constructor(private readonly editor: EditorLike) { }

    select(items: RealNodeItem[], modifier: ChangeSelectionModifier, option: ChangeSelectionOption) {
        const { editor } = this;
        const command = new OutlinerChangeSelectionCommand(editor, items, modifier, option);
        editor.exec(command);
    }

    hover(items: RealNodeItem[], modifier: ChangeSelectionModifier, option: ChangeSelectionOption) {
        const { editor } = this;
        editor.changeSelection.onOutlinerHover(items, modifier, option);
    }
}

class OutlinerChangeSelectionCommand extends cmd.CommandLike {
    constructor(
        editor: cmd.EditorLike,
        private readonly items: readonly RealNodeItem[],
        private readonly modifier: ChangeSelectionModifier,
        private readonly option: ChangeSelectionOption
    ) { super(editor) }

    async execute(): Promise<void> {
        const { items } = this;
        this.editor.changeSelection.onOutlinerSelect(items, this.modifier, this.option);
    }
}
