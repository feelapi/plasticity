import { render } from 'preact';
import { Editor } from '../../editor/Editor';

export default (editor: Editor) => {
    class Palette extends HTMLElement {
        connectedCallback() { this.render() }

        render() {
            return render(
                <div class="absolute z-40 flex flex-col right-2 top-1/2 space-y-2 -translate-y-1/2">
                    <section class="flex flex-col space-y-0.5">
                        <plasticity-command name="line" class="shadow-lg first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                        <plasticity-command name="curve" class="shadow-lg first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                        <plasticity-button-group class="shadow-lg first:rounded-t last:rounded-b overflow-clip">
                            <plasticity-command name="center-circle" class="first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                            <plasticity-command name="two-point-circle" class="first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                            <plasticity-command name="center-point-arc" class="first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                            <plasticity-command name="three-point-arc" class="first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                        </plasticity-button-group>
                        <plasticity-command name="polygon" class="first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                        <plasticity-command name="spiral" class="first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                        <plasticity-button-group class="shadow-lg first:rounded-t last:rounded-b overflow-clip">
                            <plasticity-command name="corner-rectangle" class="first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                            <plasticity-command name="center-rectangle" class="first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                            <plasticity-command name="three-point-rectangle" class="first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                        </plasticity-button-group>
                        <plasticity-command name="trim" class="shadow-lg first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                        <plasticity-command name="split-segment" class="shadow-lg first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                        <plasticity-button-group class="shadow-lg first:rounded-t last:rounded-b overflow-clip">
                        </plasticity-button-group>
                        {/* 
                        <plasticity-button-group class="shadow-lg first:rounded-t last:rounded-b overflow-clip">
                            <plasticity-command name="center-ellipse" class="first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                            <plasticity-command name="three-point-ellipse" class="first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                        </plasticity-button-group>
                        <plasticity-command name="bridge-curves" class="shadow-lg first:rounded-t last:rounded-b overflow-clip"></plasticity-command> */}
                    </section>
                    <section class="flex flex-col space-y-0.5">
                        <plasticity-command name="sphere" class="shadow-lg first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                        <plasticity-button-group class="shadow-lg first:rounded-t last:rounded-b overflow-clip">
                            <plasticity-command name="corner-box" class="first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                            <plasticity-command name="center-box"></plasticity-command>
                            <plasticity-command name="three-point-box"></plasticity-command>
                        </plasticity-button-group>
                        <plasticity-command name="cylinder" class="first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                        {/* <plasticity-command name="cylinder" class="shadow-lg first:rounded-t last:rounded-b overflow-clip"></plasticity-command>
                        <plasticity-command name="slot" class="shadow-lg first:rounded-t last:rounded-b overflow-clip"></plasticity-command> */}
                    </section>
                </div>, this);
        }
    }
    customElements.define('plasticity-palette', Palette);
}
