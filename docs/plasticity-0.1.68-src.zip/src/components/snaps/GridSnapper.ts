import * as THREE from 'three';
import { AxisSnap } from '../../editor/snaps/AxisSnap';
import { ConstructionPlane } from '../../editor/snaps/ConstructionPlaneSnap';
import { PlaneSnap } from '../../editor/snaps/PlaneSnap';
import { Snap } from '../../editor/snaps/Snap';
import { GridHelper } from '../viewport/GridHelper';


export class GridSnapper {
    constructor(private readonly helper: GridHelper, private readonly constructionPlane: ConstructionPlane) { }

    snapToGrid(position: THREE.Vector3, compat: Snap) {
        const { constructionPlane, helper: { gridFactor } } = this;
        if (!(constructionPlane instanceof PlaneSnap))
            return position;

        if (compat instanceof PlaneSnap && compat !== constructionPlane)
            return position;
        const { plane } = constructionPlane;
        if (compat instanceof AxisSnap && !compat.isCoplanar(plane))
            return position;

        const { basis, basisInv } = constructionPlane;
        position.applyMatrix4(basisInv);
        position.set(
            Math.round(position.x / gridFactor) * gridFactor,
            Math.round(position.y / gridFactor) * gridFactor,
            0);
        position.applyMatrix4(basis);
        return position;
    }

    truncateToGrid(from: number): number {
        const { helper: { gridFactor } } = this;
        return Math.round(from / gridFactor) * gridFactor;
    }
}
