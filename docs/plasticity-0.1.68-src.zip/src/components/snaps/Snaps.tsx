import { PointPickerModel } from "../../command/point-picker/PointPickerModel";
import { render } from 'preact';
import { Editor } from '../../editor/Editor';
import { Snap } from "../../editor/snaps/Snap";
import { SnapType } from '../../editor/snaps/SnapManager';
import * as visual from '../../visual_model/VisualModel';
import classNames from 'classnames';
import { assertUnreachable } from '../../util/Util';

type State = { tag: 'inactive' } | { tag: 'active', pointPicker: PointPickerModel, snaps: Snap[] };

export default (editor: Editor) => {
    class SnapList extends HTMLElement {
        private state: State = { tag: 'inactive' };

        connectedCallback() {
            editor.signals.snapsAdded.add(this.add);
            editor.signals.snapsCleared.add(this.delete);
            this.render();
        }

        disconnectedCallback() {
            editor.signals.snapsAdded.remove(this.add);
            editor.signals.snapsCleared.remove(this.remove);
        }

        private add = (info: { snaps: Snap[], pointPicker: PointPickerModel }) => {
            switch (this.state.tag) {
                case 'inactive':
                    this.state = { tag: 'active', pointPicker: info.pointPicker, snaps: info.snaps };
                    break;
                case 'active':
                    this.state = { tag: 'active', pointPicker: info.pointPicker, snaps: [...this.state.snaps, ...info.snaps] };
                    break;
                default: assertUnreachable(this.state);
            }
            this.render();
        }

        private delete = (snaps: Snap[]) => {
            switch (this.state.tag) {
                case 'inactive': throw new Error('Invalid state');
                case 'active':
                    this.state = { tag: 'inactive' };
                    break;
                default: assertUnreachable(this.state);
            }

            this.render();
        }

        render() {
            const state = this.state;
            const layers = visual.Layers;
            const result = <div
                class={classNames
                    ("px-4 py-1",
                        state.tag === 'active' ? "opacity-100" : "opacity-80"
                    )}
            >
                <Grid enable={this.toggleGrid} incr={this.incr} decr={this.decr}></Grid>
                <h1 class="flex justify-between items-center py-0.5 px-2 mb-4 space-x-2 text-xs font-bold rounded text-neutral-100 hover:bg-neutral-700 w-20">
                    <div>Snaps</div>
                    <div class="flex">
                        <input
                            type="checkbox"
                            class="w-4 h-4 rounded border-accent-300 text-accent-600 focus:ring-accent-500"
                            onClick={e => this.toggleAllSnaps(e)}
                            checked={editor.snaps.enabled}
                        />
                        <plasticity-tooltip placement="left">Enable or disable all snapping behavior during modeling operations</plasticity-tooltip>
                    </div>
                </h1>
                <ul class="flex flex-col w-24 space-y-1">
                    {state.tag === 'active' &&
                        [...state.snaps].map(snap => {
                            if (snap.name === undefined) return;
                            return <SnapItem
                                key={snap.name}
                                name={snap.name}
                                enabled={state.pointPicker.isEnabled(snap)}
                                onClick={(e: MouseEvent) => this.toggleSnap(e, snap)}
                            ></SnapItem>
                        })}
                    {[layers.Face, layers.Curve, layers.Edge].map(layer => {
                        return <SnapItem
                            key={layers[layer]}
                            name={layers[layer]}
                            enabled={editor.snaps.layers.isEnabled(layer)}
                            onClick={(e: MouseEvent) => this.toggleLayer(e, layer)}
                        ></SnapItem>
                    })}
                    {[SnapType.Basic, SnapType.Crosses].map(snapType => {
                        return <SnapItem
                            key={SnapType[snapType]}
                            name={SnapType[snapType]}
                            enabled={(editor.snaps.options & snapType) === snapType}
                            onClick={(e: MouseEvent) => this.toggleSnapType(e, snapType)}
                        ></SnapItem>
                    })}
                </ul>
            </div>;
            render(result, this);
        }

        toggleLayer = (event: MouseEvent, layer: visual.Layers) => {
            editor.snaps.layers.toggle(layer);
            event.preventDefault();
            this.render();
        }

        toggleSnapType = (event: MouseEvent, snapType: SnapType) => {
            editor.snaps.options ^= snapType;
            event.preventDefault();
            this.render();
        }

        toggleAllSnaps = (event: MouseEvent) => {
            editor.snaps.enabled = !editor.snaps.enabled;
            this.render();
        }

        toggleGrid = (event: MouseEvent) => {
            editor.snaps.snapToGrid = !editor.snaps.snapToGrid;
            event.preventDefault();
            this.render();
        }

        incr = (event: MouseEvent) => {
            for (const v of editor.viewports) v.resizeGrid(1);
            event.preventDefault();
            this.render();
        }

        decr = (event: MouseEvent) => {
            for (const v of editor.viewports) v.resizeGrid(-1);
            event.preventDefault();
            this.render();
        }

        toggleSnap = (event: MouseEvent, snap: Snap) => {
            switch (this.state.tag) {
                case 'inactive': throw new Error('Invalid state');
                case 'active':
                    this.state.pointPicker.toggle(snap);
                    break;
                default: assertUnreachable(this.state);
            }
            event.preventDefault();
            this.render();
        }
    }
    customElements.define('plasticity-snaps', SnapList);

    type SnapItemProps = { name: string, enabled: boolean; onClick: (e: MouseEvent) => void };
    function SnapItem({ name, enabled, onClick }: SnapItemProps) {
        return <li>
            <input type="checkbox" id={name} class="hidden peer" checked={enabled} />
            <label
                for={name}
                onClick={onClick}
                class="
                    block px-2 py-2 text-xs font-medium uppercase 
                    rounded-md cursor-pointer
                    peer-checked:text-accent-200 peer-checked:hover:text-accent-100 peer-checked:bg-accent-600 peer-checked:hover:bg-accent-700
                    text-neutral-200 hover:text-neutral-100 bg-neutral-500 hover:bg-neutral-600"
            >
                <span class="block m-auto text-center">{name}</span>
            </label>
        </li>;
    }

    type GridProps = { enable: (e: MouseEvent) => void; incr: (e: MouseEvent) => void; decr: (e: MouseEvent) => void; };
    function Grid({ enable, incr, decr }: GridProps) {
        return <ul class="flex mb-4">
            <li
                class="relative inline-flex items-center px-1 py-1 text-xs border border-neutral-500 rounded-l-md hover:text-neutral-100 bg-neutral-400 hover:bg-neutral-500"
                onClick={decr}
            >
                <plasticity-tooltip placement="bottom">Make grid less precise</plasticity-tooltip>
                <plasticity-icon name="nav-arrow-left"></plasticity-icon>
            </li>
            <input type="checkbox" id="grid" class="hidden peer" checked={editor.snaps.snapToGrid} />
            <li
                class="
                    relative inline-flex items-center px-1 py-1 text-xs border 
                   border-neutral-500 hover:text-neutral-100 bg-neutral-400 hover:bg-neutral-500
                   peer-checked:text-accent-200 peer-checked:hover:text-accent-100 peer-checked:bg-accent-600 peer-checked:hover:bg-accent-700"
            >
                <plasticity-tooltip placement="bottom">Toggle grid snapping</plasticity-tooltip>
                <label for="grid" onClick={enable} class="w-10">
                    <div class="text-xs text-center">{editor.activeViewport?.grid.gridFactor}</div>
                </label>
            </li>
            <li
                class="relative inline-flex items-center px-1 py-1 text-xs border border-neutral-500 rounded-r-md hover:text-neutral-100 bg-neutral-400 hover:bg-neutral-500"
                onClick={incr}
            >
                <plasticity-tooltip placement="bottom">Make grid more precise</plasticity-tooltip>
                <plasticity-icon name="nav-arrow-right"></plasticity-icon>
            </li>
        </ul>
    }
}

