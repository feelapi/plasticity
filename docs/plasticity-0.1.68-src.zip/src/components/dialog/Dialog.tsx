import { CompositeDisposable, Disposable } from 'event-kit';
import { createRef, render } from 'preact';
import { AbstractDialog } from "../../command/AbstractDialog";
import { Editor } from '../../editor/Editor';

export default (editor: Editor) => {
    class Dialog extends HTMLElement {
        private readonly disposable = new CompositeDisposable();
        disconnectedCallback() { this.disposable.dispose() }

        connectedCallback() {
            editor.signals.dialogAdded.add(this.render);
            editor.signals.dialogRemoved.add(_ => this.render());
            editor.signals.factoryUpdateFailed.add(this.onFailure);
            editor.signals.factoryUpdated.add(this.onSuccess);
            editor.signals.factoryCancelled.add(this.reset);
            editor.signals.factoryCommitted.add(this.reset);
            this.disposable.add(new Disposable(() => {
                editor.signals.dialogAdded.remove(this.render);
                editor.signals.dialogRemoved.remove(_ => this.render());
                editor.signals.factoryUpdateFailed.remove(_ => this.render());
                editor.signals.factoryUpdated.remove(_ => this.render());
                editor.signals.factoryCancelled.remove(this.reset);
                editor.signals.factoryCommitted.remove(this.reset);
            }));
            this.render();
        }

        render = (dialog?: AbstractDialog<any>) => {
            if (dialog !== undefined) {
                const ref = createRef();
                const form = <div class="absolute rounded shadow-lg bottom-2 left-2 w-96 opacity-90 bg-dialog overflow-clip shadow-neutral-900/95">
                    <div class="my-1 border-b border-neutral-900 m">
                        <div class="flex items-center justify-between px-2">
                            <div class="flex items-center m-3 text-xs font-bold space-x-4 text-neutral-100">
                                <div>{dialog.name}</div>
                                <plasticity-icon name="alert" class="text-red-700 alert"></plasticity-icon>
                            </div>

                            <a class="px-3 py-1 text-xs text-center align-middle rounded-full bg-neutral-800 text-neutral-400">Learn more ...</a>
                        </div>
                    </div>
                    <div ref={ref}></div>
                    <div class="flex justify-end px-2 py-1 border space-x-2 bg-neutral-900 border-neutral-900">
                        <button class="px-2 py-1 text-xs rounded text-neutral-200" type="button" onClick={e => dialog.cancel()} tabIndex={-1}>Cancel</button>
                        <button class="px-2 py-1 text-xs rounded shadow-sm bg-accent-900 text-accent-100" type="button" onClick={e => dialog.finish()} tabIndex={-1}>OK</button>
                    </div>
                </div>
                render(form, this);
                ref.current.appendChild(dialog);
            } else {
                render(<></>, this);
            }
        }

        onFailure = (e: any) => {
            this.classList.add('failure');
            this.classList.remove('success');
        }

        onSuccess = () => {
            this.classList.remove('failure');
            this.classList.add('success');
        }

        reset = () => {
            this.classList.remove('failure');
            this.classList.remove('success');
        }
    }
    customElements.define('plasticity-dialog', Dialog);
}