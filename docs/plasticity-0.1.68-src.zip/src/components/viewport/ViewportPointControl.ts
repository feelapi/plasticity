import { Disposable } from "event-kit";
import * as THREE from "three";
import * as gizmo from "../../command/AbstractGizmo";
import { GizmoLike } from "../../command/AbstractGizmo";
import Command, * as cmd from "../../command/Command";
import { DashedLineMagnitudeHelper } from "../../command/MiniGizmos";
import { SnapCollector } from "../../command/point-picker/SnapCollector";
import { SnapPresentation, SnapPresenter } from "../../command/SnapPresenter";
import { ConvertVertexFactory } from "../../commands/modify_curve/ConvertVertexFactory";
import { MoveControlPointFactory } from "../../commands/modify_curve/TransformControlPointFactory";
import { AxisSnap } from "../../editor/snaps/AxisSnap";
import { GizmoSnapPicker } from "../../editor/snaps/GizmoSnapPicker";
import { Snap } from "../../editor/snaps/Snap";
import { SnapResult } from "../../editor/snaps/SnapPicker";
import { CurveSegmentSnap } from "../../editor/snaps/Snaps";
import { SelectionKeypressStrategy } from "../../selection/SelectionKeypressStrategy";
import { ClickChangeSelectionCommand } from "../../selection/ViewportSelector";
import { CancellablePromise } from "../../util/CancellablePromise";
import { point2point, vec2vec } from "../../util/Conversion";
import { Intersection } from "../../visual_model/Intersectable";
import * as visual from '../../visual_model/VisualModel';
import { Viewport } from "./Viewport";
import { ViewportControl } from "./ViewportControl";

/**
 * The PointControl allows dragging and dropping any visible points.
 */

export interface EditorLike extends cmd.EditorLike {
    keymaps: AtomKeymap.KeymapManager;
}

type Mode = { tag: 'none' }
    | { tag: 'start', controlPoint: visual.Vertex | visual.CV }
    | { tag: 'dragging', controlPoint: visual.Vertex | visual.CV, helper: DashedLineMagnitudeHelper, addedSnaps: SnapCollector, disposable: Disposable, best?: SnapResult, lastMoveEvent: (() => void) | undefined, mutualSnaps: Set<Snap>; }
    | { tag: 'executing', controlPoint: visual.Vertex | visual.CV, cb: (delta: THREE.Vector3) => void, cancellable: CancellablePromise<void>, helper: DashedLineMagnitudeHelper, addedSnaps: SnapCollector, disposable: Disposable, best?: SnapResult, lastMoveEvent: (() => void) | undefined, mutualSnaps: Set<Snap>; }
    | { tag: 'committing' };

export class ViewportPointControl extends ViewportControl implements GizmoLike<THREE.Vector3, void> {
    private readonly keypress = new SelectionKeypressStrategy(this.editor.keymaps);

    private readonly delta = new THREE.Vector3();
    private readonly pointStart3d = new THREE.Vector3();
    private readonly pointEnd3d = new THREE.Vector3();
    private readonly center2d = new THREE.Vector2();
    private readonly center3d = new THREE.Vector3();
    readonly _raycaster = new THREE.Raycaster();

    private readonly snapPicker = new GizmoSnapPicker();
    private readonly presenter = new SnapPresenter(this.editor);
    private readonly cameraPlane = new THREE.Mesh(new THREE.PlaneGeometry(100_000, 100_000, 2, 2), new THREE.MeshBasicMaterial());

    constructor(viewport: Viewport, private readonly editor: EditorLike) {
        super(viewport, editor.layers, editor.db, editor.scene, editor.signals);
        this._raycaster.layers.enableAll();
    }

    startHover(intersections: Intersection[]) { }
    continueHover(intersections: Intersection[]): void { }
    endHover(): void { }

    private mode: Mode = { tag: 'none' };

    startClick(intersections: Intersection[], downEvent: MouseEvent): boolean {
        if (intersections.length === 0) return false;
        const first = intersections[0].object;
        if (!(first instanceof visual.Vertex) && !(first instanceof visual.CV)) return false;
        const { domElement } = this.viewport;
        if (domElement.ownerDocument.body.hasAttribute('gizmo')) return false;
        if (downEvent.altKey) return false;

        switch (this.mode.tag) {
            case 'committing': return false;
            case 'none':
                const controlPoint = first;
                const exact = this.getExactPositionForControlPoint(controlPoint);
                this.pointStart3d.copy(exact);
                this.cameraPlane.position.copy(this.pointStart3d);
                this.mode = { tag: 'start', controlPoint };

                break;
            default: throw new Error("invalid state: " + this.mode.tag);
        }
        return true;
    }

    private getExactPositionForControlPoint(controlPoint: visual.Vertex | visual.CV): THREE.Vector3 {
        if (controlPoint instanceof visual.Vertex) {
            const vertex = this.editor.db.lookupTopologyItem(controlPoint);
            return point2point(vertex.GetPoint());
        } else {
            const curve = this.editor.db.lookup(controlPoint.parentItem);
            const cvs = curve.FindOrderedEdges().GetCVs();
            const centroid = cvs.GetCentroid([controlPoint.id]);
            return point2point(centroid);
        }
    }

    endClick(intersections: Intersection[], upEvent: MouseEvent): void {
        switch (this.mode.tag) {
            case 'start':
                const command = new ClickChangeSelectionCommand(this.editor, intersections, this.keypress.event2modifier(upEvent), this.keypress.event2option(upEvent));
                this.editor.exec(command);
                this.mode = { tag: 'none' };
                break;
            default: throw new Error("invalid state: " + this.mode.tag);
        }
    }

    startDrag(downEvent: MouseEvent, normalizedMousePosition: THREE.Vector2): boolean {
        switch (this.mode.tag) {
            case 'none': return false;
            case 'start':
                const { center2d, center3d, pointStart3d, viewport: { camera } } = this;
                center3d.copy(pointStart3d).project(camera);
                center2d.set(center3d.x, center3d.y);

                const command = new MoveControlPointCommand(this.editor);
                command.controlPoint = this.mode.controlPoint;
                command.gizmo = this;
                const helper = new DashedLineMagnitudeHelper();
                helper.onStart(this.viewport, center2d);
                document.addEventListener('keydown', this.onKeyDown);
                document.addEventListener('keyup', this.onKeyUp);
                const disposable = new Disposable(() => {
                    document.removeEventListener('keydown', this.onKeyDown);
                    document.removeEventListener('keyup', this.onKeyUp);
                });
                const addedSnaps = new SnapCollector(this.db, this.editor.crosses, this.editor.snaps);
                this.mode = { tag: 'dragging', controlPoint: this.mode.controlPoint, helper, addedSnaps, disposable, lastMoveEvent: undefined, mutualSnaps: new Set() };
                this.editor.exec(command).then(() => {
                    this.moveCommandFinished();
                });

                return true;
            default: throw new Error('invalid precondition');
        }
    }

    onKeyDown = (e: KeyboardEvent) => {
        switch (this.mode.tag) {
            case 'dragging':
            case 'executing':
                if (e.repeat) return;

                if (e.key === "Shift") {
                    const collector = this.mode.addedSnaps;
                    const best = this.mode.best;
                    collector.choose(best?.snap, best, true);
                }
                break;
            default: throw new Error('invalid precondition');
        }
    }

    onKeyUp = (e: KeyboardEvent) => {
        switch (this.mode.tag) {
            case 'dragging':
            case 'executing':
                if (e.key === "Shift") {
                    const collector = this.mode.addedSnaps;
                    const best = this.mode.best;
                    const oldChoice = collector.choice;
                    collector.choose(undefined);
                    if (best !== undefined || oldChoice !== undefined) {
                        if (this.mode.lastMoveEvent !== undefined) this.mode.lastMoveEvent();
                    }
                }
                break;
            default: throw new Error('invalid precondition');
        }
    }

    private readonly unprojected = new THREE.Vector3();
    continueDrag(moveEvent: MouseEvent, normalizedMousePosition: THREE.Vector2) {
        switch (this.mode.tag) {
            case 'none': break; // If, rarely, the command fails while dragging, we can get here.
            case 'dragging':
            case 'executing':
                const { pointEnd3d, _raycaster: raycaster, delta, viewport: { camera, constructionPlane }, pointStart3d } = this;
                this.presenter.clear();

                if (moveEvent.ctrlKey) {
                    const { unprojected, snapPicker } = this;
                    snapPicker.setFromViewport(moveEvent, this.viewport);
                    const { presentation, intersections } = SnapPresentation.makeForGizmo(
                        this.snapPicker,
                        this.viewport,
                        this.editor.scene,
                        this.editor.snaps.cache,
                        this.mode.addedSnaps.otherAddedSnaps.other,
                        [this.mode.addedSnaps.otherAddedSnaps.cache],
                        this.mode.addedSnaps.choice,
                        this.editor.gizmos);
                    this.presenter.onPointerMove(this.viewport, presentation);
                    this.activateMutualSnaps(intersections.map(s => s.snap));
                    const best = intersections[0];
                    this.mode.best = best;
                    this.mode.lastMoveEvent = () => this.continueDrag(moveEvent, normalizedMousePosition);
                    if (best === undefined) return;

                    const point = best.position.clone();
                    unprojected.copy(point).project(camera);

                    this.mode.helper.onMove(unprojected as any);

                    delta.copy(point).sub(pointStart3d);
                } else {
                    this.mode.helper.onMove(normalizedMousePosition);
                    this.mode.best = undefined;
                    this.mode.lastMoveEvent = undefined;
                    this.presenter.clear();

                    raycaster.setFromCamera(normalizedMousePosition, camera);
                    const moved = constructionPlane.move(pointStart3d);
                    const intersection = raycaster.intersectObject(moved.snapper);
                    if (intersection.length === 0) throw new Error("corrupt intersection query");
                    pointEnd3d.copy(intersection[0].point);

                    const { position } = moved.project(pointEnd3d);
                    delta.copy(position).sub(pointStart3d);
                }
                if (this.mode.tag === 'executing')
                    this.mode.cb(delta.clone());
                break;
            case 'committing': break; // If, rarely, the user moves the mouse while committing, we can get here.
            default: throw new Error('invalid state: ' + this.mode.tag);
        }
    }

    endDrag(normalizedMousePosition: THREE.Vector2): void {
        const mode = this.mode;
        switch (mode.tag) {
            case 'none': break;
            case 'dragging':
                mode.helper.onEnd();
                mode.disposable.dispose();
                this.mode = { tag: 'none' };
                break;
            case 'executing':
                mode.helper.onEnd();
                mode.disposable.dispose();
                mode.cancellable.finish();
                const newState = this.mode.tag;
                if (newState !== 'committing') throw new Error("invalid postcondition: " + newState);
                break;
            default: throw new Error('invalid state: ' + this.mode.tag);
        }
    }

    private moveCommandFinished() {
        switch (this.mode.tag) {
            case 'none': break; // very rarely, the command can abort AND the user can finish dragging before it puts us in the 'execute' state
            case 'dragging': // very rarely, the command can abort before it puts us in the 'execute' state
                this.mode.helper.onEnd();
                this.mode.disposable.dispose();
            case 'committing':
                this.mode = { tag: 'none' };
                break;
            default: throw new Error('invalid state: ' + this.mode.tag);
        }
    }

    dblClick(intersections: Intersection[], dblClickEvent: MouseEvent) {
        switch (this.mode.tag) {
            case 'start':
                const command = new ConvertControlPointCommand(this.editor);
                command.controlPoint = this.mode.controlPoint;
                this.editor.exec(command);
                this.mode = { tag: 'none' };
                break;
            default: throw new Error('invalid state: ' + this.mode.tag);
        }
    }

    activateMutualSnaps(intersected: Iterable<Snap>) {
        const mode = this.mode;
        switch (mode.tag) {
            case 'dragging':
            case 'executing':
                for (const snap of intersected) {
                    if (mode.mutualSnaps.has(snap)) continue;
                    mode.mutualSnaps.add(snap); // idempotent

                    if (snap instanceof CurveSegmentSnap) {
                        const additional = snap.additionalSnapsGivenPreviousSnap(mode.controlPoint.position);
                        mode.addedSnaps.addSnap(...additional);
                    }
                }
                break;
            default: throw new Error('invalid state: ' + this.mode.tag);
        }
    }

    async addAxesAt(point: THREE.Vector3, axes: AxisSnap[]) {
        const mode = this.mode;
        switch (mode.tag) {
            case 'dragging':
            case 'executing':
                const addedSnaps = mode.addedSnaps;
                for (const axis of axes) {
                    await addedSnaps.addAxis(axis);
                    if (this.mode.tag !== 'dragging' && this.mode.tag !== 'executing')
                        return;
                }
                await addedSnaps.addAxesAt(point);
                addedSnaps.update();
                break;
            default: throw new Error('invalid state: ' + this.mode.tag);
        }
    }

    // implement interface GizmoLike:
    execute(cb: (delta: THREE.Vector3) => void, finishFast?: gizmo.Mode): CancellablePromise<void> {
        switch (this.mode.tag) {
            case 'dragging':
                const clearPresenter = this.presenter.execute();
                const result = new CancellablePromise<void>((resolve, reject) => {
                    const dispose = () => {
                        switch (this.mode.tag) {
                            case 'executing':
                                clearPresenter.dispose();
                                this.mode.helper.onEnd();
                                this.mode.disposable.dispose();
                                this.mode = { tag: 'committing' };
                        }
                    }
                    return { dispose, finish: resolve };
                });

                this.mode = { tag: 'executing', controlPoint: this.mode.controlPoint, cancellable: result, cb, helper: this.mode.helper, addedSnaps: this.mode.addedSnaps, disposable: this.mode.disposable, best: this.mode.best, lastMoveEvent: this.mode.lastMoveEvent, mutualSnaps: this.mode.mutualSnaps };
                return result;
            default: throw new Error('invalid state: ' + this.mode.tag);
        }
    }
}

export class MoveControlPointCommand extends cmd.CommandLike {
    controlPoint!: visual.Vertex | visual.CV;
    gizmo!: ViewportPointControl;

    async execute(): Promise<void> {
        const { controlPoint, gizmo, editor: { db } } = this;
        const curve = controlPoint.parentItem;
        const move = this.makeFactory(controlPoint, curve);
        db.disable([curve]);

        await this.addSnaps(move);

        gizmo.execute(delta => {
            move.move.copy(delta);
            move.update();
        }).resource(this);

        await this.finished;

        await move.commit();
    }

    private async addSnaps(move: MoveControlPointFactory) {
        const { controlPoint, gizmo } = this;
        const axes = [];
        if (controlPoint instanceof visual.Vertex) {
            const model = this.editor.db.lookupTopologyItem(controlPoint);
            const dirs = model.EvalBasis().map(v => vec2vec(v, 1));
            for (const dir of dirs) {
                axes.push(new AxisSnap("Hull", dir, controlPoint.position));
            }
        } else {
            const hulls = move.hulls;
            if (hulls.length !== 1)
                throw new Error("invalid precondition");
            const hull = hulls[0];
            const { before, after } = hull;
            if (before !== undefined)
                axes.push(new AxisSnap("Hull", before, controlPoint.position));
            if (after !== undefined)
                axes.push(new AxisSnap("Hull", after, controlPoint.position));
        }
        await gizmo.addAxesAt(controlPoint.position, axes);
    }

    private makeFactory(controlPoint: visual.Vertex | visual.CV, curve: visual.SpaceInstance) {
        const factory = new MoveControlPointFactory(this.editor.db, this.editor.materials, this.editor.signals).resource(this);
        factory.curve = curve;
        if (controlPoint instanceof visual.Vertex) {
            factory.vertices = [controlPoint];
        } else {
            factory.cvs = [controlPoint];
        }
        return factory;
    }
}

export class ConvertControlPointCommand extends cmd.CommandLike {
    controlPoint!: visual.Vertex | visual.CV;

    async execute(): Promise<void> {
        const { controlPoint, editor: { db } } = this;
        const curve = controlPoint.parentItem;
        const convert = new ConvertVertexFactory(db, this.editor.materials, this.editor.signals).resource(this);
        convert.curve = curve;
        if (controlPoint instanceof visual.Vertex) {
            convert.vertices = [controlPoint];
            await convert.commit();
        }
    }
}