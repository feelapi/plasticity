import * as THREE from 'three';
import { LineBasicMaterial } from 'three';
import * as visual from "../../visual_model/VisualModel";
import { ProxyCamera } from './ProxyCamera';

export class OrthoModeGrid extends THREE.Group {
    protected readonly grid1: THREE.GridHelper;
    protected readonly grid2: THREE.GridHelper;
    protected readonly grid3: THREE.GridHelper;

    constructor(private readonly size: number, private readonly divisions: number, private readonly color1: THREE.Color, private readonly color2: THREE.Color, private readonly backgroundColor: THREE.Color) {
        super();

        const grid1 = this.makeGrid(size, divisions, color1);
        this.grid1 = grid1;

        const grid2 = this.makeGrid(size, divisions / 10, color2);
        this.grid2 = grid2;

        const grid3 = this.makeGrid(size * 10, divisions / 10, color2);
        this.grid3 = grid3;

        this.add(grid1, grid2, grid3);
        this.layers.set(visual.Layers.Overlay);
        this.renderOrder = -1;
    }

    protected makeGrid(size: number, divisions: number, color1: THREE.Color) {
        const grid1 = new THREE.GridHelper(size, divisions, color1, color1);
        const material = grid1.material as THREE.LineBasicMaterial;
        material.vertexColors = false;
        material.color.copy(color1);
        material.depthWrite = false;
        grid1.geometry.rotateX(Math.PI / 2);
        return grid1;
    }

    dispose() {
        this.grid1.geometry.dispose();
        const material1 = this.grid1.material as LineBasicMaterial;
        material1.dispose();
        this.grid1.removeFromParent();

        this.grid2.geometry.dispose();
        const material2 = this.grid2.material as LineBasicMaterial;
        material2.dispose();

        this.grid3.geometry.dispose();
        const material3 = this.grid3.material as LineBasicMaterial;
        material3.dispose();
    }

    update(camera: THREE.Camera) {
        let factor;
        if (ProxyCamera.isOrthographic(camera)) {
            factor = (camera.top - camera.bottom) / camera.zoom;
        } else throw new Error("invalid camera type");

        factor *= 10;

        const material1 = this.grid1.material as THREE.LineBasicMaterial;
        const alpha1 = Math.max(0, 1 - factor / this.size);
        material1.color.lerpColors(this.backgroundColor, this.color1, alpha1);
        this.grid1.visible = factor < this.size;

        factor /= 10;
        const material2 = this.grid2.material as THREE.LineBasicMaterial;
        const alpha2 = Math.max(0, 1 - factor / this.size);
        material2.color.lerpColors(this.backgroundColor, this.color2, alpha2);
        this.grid2.visible = factor < this.size;

        this.updateMatrixWorld();
    }
}


export class FloorHelper extends THREE.Group {
    private readonly grid1: THREE.GridHelper;
    private readonly grid2: THREE.GridHelper;

    constructor(private readonly size: number, private readonly divisions: number, private readonly color1: THREE.Color, private readonly color2: THREE.Color) {
        super();

        const grid1 = this.makeGrid(size, divisions, color1);
        this.grid1 = grid1;

        const grid2 = this.makeGrid(size, divisions / 10, color2);
        this.grid2 = grid2;

        this.add(grid1, grid2);
        this.layers.set(visual.Layers.Overlay);
    }

    private makeGrid(size: number, divisions: number, color1: THREE.Color) {
        const grid1 = new THREE.GridHelper(size, divisions);
        const material1 = grid1.material as THREE.LineBasicMaterial;
        material1.transparent = true;
        material1.vertexColors = false;
        material1.color.copy(color1);
        material1.fog = true;
        grid1.renderOrder = visual.RenderOrder.Overlay;
        grid1.geometry.rotateX(Math.PI / 2);
        return grid1;
    }

    dispose() {
        this.grid1.geometry.dispose();
        const material1 = this.grid1.material as LineBasicMaterial;
        material1.dispose();
        this.grid1.removeFromParent();

        this.grid2.geometry.dispose();
        const material2 = this.grid2.material as LineBasicMaterial;
        material2.dispose();
    }

    private readonly grid = new THREE.Vector3(0, 1, 0);
    private readonly eye = new THREE.Vector3(0, 0, 1);
    update(camera: THREE.Camera) {
        const { grid, eye, grid1, grid2 } = this;

        grid.set(0, 0, 1).applyQuaternion(this.quaternion);
        eye.set(0, 0, 1).applyQuaternion(camera.quaternion);
        const dot = grid.dot(eye);
        const material1 = grid1.material as THREE.LineBasicMaterial;
        const material2 = grid2.material as THREE.LineBasicMaterial;
        const dotSq = dot * dot;
        material1.opacity = material2.opacity = dotSq;

        let factor;
        if (ProxyCamera.isOrthographic(camera)) {
            factor = (camera.top - camera.bottom) / camera.zoom;
        } else if (ProxyCamera.isPerspective(camera)) {
            factor = this.position.distanceTo(camera.position) * Math.min(1.9 * Math.tan(Math.PI * camera.fov / 360), 7);
        } else throw new Error("invalid camera type");

        let denom = this.size;
        const ratio = factor / denom;
        material1.opacity *= 1 - Math.min(1, ratio);
        this.grid1.visible = factor < denom;

        this.updateMatrixWorld();
    }
}
