import classNames from 'classnames';
import { render } from 'preact';
import { Editor } from '../../editor/Editor';
import { PlaneDatabase } from '../../editor/PlaneDatabase';
import { ConstructionPlaneSnap } from '../../editor/snaps/ConstructionPlaneSnap';
import basic_side from '../../img/matcap/basic_side.exr';
import black_silhouette_png from '../../img/matcap/black_silhouette.png';
import ceramic_dark from '../../img/matcap/ceramic_dark.exr';
import ceramic_dark_png from '../../img/matcap/ceramic_dark.png';
import ceramic_lightbulb from '../../img/matcap/ceramic_lightbulb.exr';
import ceramic_lightbulb_png from '../../img/matcap/ceramic_lightbulb.png';
import color_matcap_png from '../../img/matcap/color_matcap.png';
import color_silhouette_png from '../../img/matcap/color_silhouette.png';
import metal_carpaint from '../../img/matcap/metal_carpaint.exr';
import metal_carpaint_png from '../../img/matcap/metal_carpaint.png';
import reflection_check_horizontal from '../../img/matcap/reflection_check_horizontal.exr';
import reflection_check_horizontal_png from '../../img/matcap/reflection_check_horizontal.png';
import reflection_check_vertical from '../../img/matcap/reflection_check_vertical.exr';
import reflection_check_vertical_png from '../../img/matcap/reflection_check_vertical.png';
import { ConvertCommand } from '../../selection/SelectionConversionStrategy';
import { SelectionMode } from '../../selection/SelectionModeSet';
import { face_unhighlighted_black_silhouette, face_unhighlighted_colored_silhouette } from '../../visual_model/RenderedSceneBuilder';
import { ViewportElement } from './Viewport';

export default (editor: Editor) => {
    let counter = 0;

    class Header extends HTMLElement {
        private uid = counter++;

        constructor() {
            super();
            this.render = this.render.bind(this);
        }

        connectedCallback() {
            this.render();
            this.viewport.changed.add(this.render);
            editor.signals.selectionModeChanged.add(this.render);
        }

        disconnectedCallback() {
            this.viewport.changed.remove(this.render);
            editor.signals.selectionModeChanged.remove(this.render);
        }

        get viewport() {
            const element = this.parentNode as unknown as ViewportElement;
            return element.model;
        }

        render() {
            const { viewport, uid, viewport: { constructionPlane } } = this;
            const result = (
                <>
                    <div class="absolute z-50 flex justify-between ml-32 mr-32 top-2 right-2 left-2">
                        <ol class="flex flex-row space-x-0.5 no-drag">
                            <li class="group"
                                onClick={e => this.onClick(e, SelectionMode.Vertex, SelectionMode.CV)}
                                onContextMenu={e => this.onClick(e, SelectionMode.Vertex, SelectionMode.CV)}
                            >
                                <input type="checkbox" class="absolute hidden peer" id={`control-point_${uid}`} checked={editor.selection.mode.has(SelectionMode.Vertex)} />
                                <label for={`control-point_${uid}`} class="block p-2 shadow-lg cursor-pointer transform group-first:rounded-l group-last:rounded-r bg-neutral-800 peer-checked:bg-accent-600 peer-checked:hover:bg-accent-700 text-accent-200 hover:text-accent-100 hover:bg-accent-600">
                                    <plasticity-icon name='control-point'></plasticity-icon>
                                    <plasticity-tooltip placement="bottom">
                                        <ul class="text-left">
                                            <li>Selection mode: Control-Point <plasticity-keybinding command="selection:mode:set:control-point"></plasticity-keybinding></li>
                                            <li>Convert selection to Control-Points <plasticity-keybinding command="selection:convert:control-point"></plasticity-keybinding></li>
                                        </ul>
                                    </plasticity-tooltip>
                                </label>
                            </li>

                            <li class="group"
                                onClick={e => this.onClick(e, SelectionMode.CurveEdge, SelectionMode.Curve)}
                                onContextMenu={e => this.onClick(e, SelectionMode.CurveEdge, SelectionMode.Curve)}
                            >
                                <input type="checkbox" class="absolute hidden peer" id={`edge_${uid}`} checked={editor.selection.mode.has(SelectionMode.CurveEdge)} />
                                <label for={`edge_${uid}`} class="block p-2 shadow-lg cursor-pointer transform group-first:rounded-l group-last:rounded-r bg-neutral-800 peer-checked:bg-accent-600 peer-checked:hover:bg-accent-700 text-accent-200 hover:text-accent-100 hover:bg-accent-600">
                                    <plasticity-icon name='edge'></plasticity-icon>
                                    <plasticity-tooltip placement="bottom">
                                        <ul class="text-left">
                                            <li>Selection mode: Edge <plasticity-keybinding command="selection:mode:set:edge"></plasticity-keybinding></li>
                                            <li>Convert selection to Edges <plasticity-keybinding command="selection:convert:edge"></plasticity-keybinding></li>
                                        </ul>
                                    </plasticity-tooltip>
                                </label>
                            </li>

                            <li class="group"
                                onClick={e => this.onClick(e, SelectionMode.Face, SelectionMode.Region)}
                                onContextMenu={e => this.onClick(e, SelectionMode.Face, SelectionMode.Region)}
                            >
                                <input type="checkbox" class="absolute hidden peer" id={`face_${uid}`} checked={editor.selection.mode.has(SelectionMode.Face)} />
                                <label for={`face_${uid}`} class="block p-2 shadow-lg cursor-pointer transform group-first:rounded-l group-last:rounded-r bg-neutral-800 peer-checked:bg-accent-600 peer-checked:hover:bg-accent-700 text-accent-200 hover:text-accent-100 hover:bg-accent-600">
                                    <plasticity-icon name='face'></plasticity-icon>
                                    <plasticity-tooltip placement="bottom">
                                        <ul class="text-left">
                                            <li>Selection mode: Face <plasticity-keybinding command="selection:mode:set:face"></plasticity-keybinding></li>
                                            <li>Convert selection to Faces <plasticity-keybinding command="selection:convert:face"></plasticity-keybinding></li>
                                        </ul>
                                    </plasticity-tooltip>
                                </label>
                            </li>

                            <li class="group"
                                onClick={e => this.onClick(e, SelectionMode.Solid, SelectionMode.Sheet, SelectionMode.Empty)}
                                onContextMenu={e => this.onClick(e, SelectionMode.Solid, SelectionMode.Sheet, SelectionMode.Empty)}
                            >
                                <input type="checkbox" class="absolute hidden peer" id={`solid_${uid}`} checked={editor.selection.mode.has(SelectionMode.Solid)} />
                                <label for={`solid_${uid}`} class="block p-2 shadow-lg cursor-pointer transform group-first:rounded-l group-last:rounded-r bg-neutral-800 peer-checked:bg-accent-600 peer-checked:hover:bg-accent-700 text-accent-200 hover:text-accent-100 hover:bg-accent-600">
                                    <plasticity-icon name='solid'></plasticity-icon>
                                    <plasticity-tooltip placement="bottom">
                                        <ul class="text-left">
                                            <li>Selection mode: Body <plasticity-keybinding command="selection:mode:set:solid"></plasticity-keybinding></li>
                                            <li>Convert selection to Bodies <plasticity-keybinding command="selection:convert:solid"></plasticity-keybinding></li>
                                        </ul>
                                    </plasticity-tooltip>
                                </label>
                            </li>
                        </ol>

                        <ol class="flex flex-row space-x-0.5 no-drag">
                            <li class="group">
                                <input
                                    type="checkbox" class="absolute hidden peer" id={`ortho_${uid}`} checked={viewport.camera.isPerspectiveCamera}
                                    onClick={e => viewport.togglePerspective()}
                                />
                                <label
                                    for={`ortho_${uid}`}
                                    class="block p-2 shadow-lg cursor-pointer transform group-first:rounded-l group-last:rounded-r bg-neutral-800 peer-checked:bg-accent-600 peer-checked:hover:bg-accent-700 text-accent-200 hover:text-accent-100 hover:bg-accent-600"
                                >
                                    <plasticity-icon key={viewport.camera.isOrthographicCamera ? 'orthographic-view' : 'perspective-view'} name={viewport.camera.isOrthographicCamera ? 'orthographic-view' : 'perspective-view'}></plasticity-icon>
                                    <plasticity-tooltip placement="bottom" command="viewport:toggle-orthographic">Perspective/Orthographic</plasticity-tooltip>
                                    <plasticity-menu placement="bottom">
                                        <div class="w-60 border-[0.5px] rounded-lg text-neutral-50 bg-neutral-900 border-neutral-800 shadow-black/20 shadow-md">
                                            <ul>
                                                <li>
                                                    <label for="fov">FOV</label>
                                                    <div class="fields">
                                                        <plasticity-number-scrubber
                                                            name="fov"
                                                            precision={1}
                                                            min={1}
                                                            max={90}
                                                            value={viewport.fov}
                                                            onscrub={e => viewport.fov = e.value}
                                                            onchange={e => viewport.fov = e.value}
                                                            onfinish={() => { }}
                                                        ></plasticity-number-scrubber>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </plasticity-menu>
                                </label>
                            </li>

                            <li class="group">
                                <input type="checkbox" class="absolute hidden peer" id={`overlays_${uid}`} checked={this.viewport.showOverlays}
                                    onClick={e => viewport.toggleOverlays()}
                                />
                                <label for={`overlays_${uid}`} class="block p-2 shadow-lg cursor-pointer transform group-first:rounded-l group-last:rounded-r bg-neutral-800 peer-checked:bg-accent-600 peer-checked:hover:bg-accent-700 text-accent-200 hover:text-accent-100 hover:bg-accent-600">
                                    <plasticity-icon name='overlays'></plasticity-icon>
                                    <plasticity-tooltip placement="bottom" command="viewport:toggle-overlays">Toggle overlays</plasticity-tooltip>
                                </label>
                            </li>

                            <li class="group">
                                <input type="checkbox" class="absolute hidden peer" id={`xray_${uid}`} checked={viewport.isXRay}
                                    onClick={e => viewport.toggleXRay()}
                                />
                                <label for={`xray_${uid}`} class="block p-2 shadow-lg cursor-pointer transform group-first:rounded-l group-last:rounded-r bg-neutral-800 peer-checked:bg-accent-600 peer-checked:hover:bg-accent-700 text-accent-200 hover:text-accent-100 hover:bg-accent-600">
                                    <plasticity-icon name='xray'></plasticity-icon>
                                    <plasticity-tooltip placement="bottom" command="viewport:toggle-x-ray">Toggle X-Ray mode</plasticity-tooltip>
                                </label>
                            </li>

                            <li class="group">
                                <input type="checkbox" class="absolute hidden peer" id={`render-mode_${uid}`} checked={viewport.isRenderMode}
                                    onClick={e => viewport.isRenderMode = !viewport.isRenderMode}
                                />
                                <label for={`render-mode_${uid}`} class="block p-2 shadow-lg cursor-pointer transform group-first:rounded-l group-last:rounded-r bg-neutral-800 peer-checked:bg-accent-600 peer-checked:hover:bg-accent-700 text-accent-200 hover:text-accent-100 hover:bg-accent-600">
                                    <plasticity-icon name='render-mode'></plasticity-icon>
                                    <plasticity-tooltip placement="bottom" command="viewport:toggle-render-mode">Toggle render mode</plasticity-tooltip>
                                    <plasticity-menu placement="bottom">
                                        <div class="min-w-60 border-[0.5px] rounded-lg text-neutral-50 bg-neutral-900 border-neutral-800 shadow-black/20 shadow-md">
                                            <ul>
                                                <li>
                                                    <div class="flex flex-row space-x-1">
                                                        <img src={ceramic_dark_png} class="hover:ring block w-16 rounded" onClick={e => viewport.setMatcap(ceramic_dark, false)} />
                                                        <img src={metal_carpaint_png} class="hover:ring block w-16 rounded" onClick={e => viewport.setMatcap(metal_carpaint, false)} />
                                                        <img src={reflection_check_horizontal_png} class="hover:ring block w-16 rounded" onClick={e => viewport.setMatcap(reflection_check_horizontal, false)} />
                                                        <img src={reflection_check_vertical_png} class="hover:ring block w-16 rounded" onClick={e => viewport.setMatcap(reflection_check_vertical, false)} />
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="flex flex-row space-x-1">
                                                        <img src={ceramic_lightbulb_png} class="hover:ring block w-16 rounded" onClick={e => viewport.setMatcap(ceramic_lightbulb, true)} />
                                                        <img src={color_matcap_png} class="hover:ring block w-16 rounded" onClick={e => viewport.setMatcap(basic_side, true)} />
                                                        <img src={black_silhouette_png} class="hover:ring block w-16 rounded" onClick={e => viewport.setMaterial(face_unhighlighted_black_silhouette, false)} />
                                                        <img src={color_silhouette_png} class="hover:ring block w-16 rounded" onClick={e => viewport.setMaterial(face_unhighlighted_colored_silhouette, true)} />
                                                    </div>
                                                </li>

                                                <li>
                                                    <label for="form" class="hidden">Visibility</label>
                                                    <div class="fields">
                                                        <input type="checkbox" hidden name="form" id="show-edges" checked={viewport.isShowingEdges} onClick={e => viewport.toggleEdges()}></input>
                                                        <label for="show-edges">Show edges</label>
                                                        <input type="checkbox" hidden name="form" id="show-faces" checked={viewport.isShowingFaces} onClick={e => viewport.toggleFaces()}></input>
                                                        <label for="show-faces">Show faces</label>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </plasticity-menu>
                                </label>
                            </li>

                        </ol>
                    </div>
                    {constructionPlane !== PlaneDatabase.XY &&
                        <div class="absolute z-50 top-2 left-1/2 no-drag flex justify-between items-center space-x-1">
                            <button
                                class="p-1 rounded-full group text-neutral-300  bg-neutral-800 hover:bg-accent-700"
                                onClick={() => viewport.constructionPlane = undefined}
                            >
                                <plasticity-tooltip placement="bottom">Reset construction plane to default</plasticity-tooltip>
                                <plasticity-icon name="cancel"></plasticity-icon>
                            </button>
                            <div class={classNames(
                                "flex justify-between items-center py-0.5 px-2 space-x-1 rounded-full shadow-lg bg-neutral-800 hover:bg-accent-700",
                                constructionPlane.isTemp ? 'cursor-pointer' : ''
                            )}
                                onClick={() => editor.planes.add(constructionPlane as ConstructionPlaneSnap)}
                            >
                                {constructionPlane.isTemp &&
                                    <plasticity-tooltip placement="bottom">Save construction plane</plasticity-tooltip>
                                }
                                <div class="p-1 text-xs text-neutral-300 group-hover:text-neutral-100">{constructionPlane.isTemp ? "Temporary" : constructionPlane.name}</div>
                                {constructionPlane.isTemp &&
                                    <button class="p-1 rounded group text-neutral-300">
                                        <plasticity-icon name="save"> </plasticity-icon>
                                    </button>
                                }
                            </div>
                        </div>
                    }
                </>
            );
            render(result, this);
        }

        private onClick = (mouseEvent: MouseEvent, ...modes: SelectionMode[]) => {
            mouseEvent.stopPropagation();
            mouseEvent.preventDefault();
            if (mouseEvent.shiftKey) {
                editor.selection.mode.toggle(...modes);
            } else if (mouseEvent.ctrlKey) {
                editor.exec(new ConvertCommand(editor, modes[0]));
            } else {
                editor.selection.mode.set(...modes);
            }
        }
    }

    customElements.define('plasticity-viewport-header', Header);
}
