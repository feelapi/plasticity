import { CompositeDisposable, Disposable } from "event-kit";
import * as THREE from "three";
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { GammaCorrectionShader } from 'three/examples/jsm/shaders/GammaCorrectionShader.js';
import { Database } from "../../editor/db/Database";
import { Editor } from "../../editor/Editor";
import { EditorSignals } from '../../editor/EditorSignals';
import { ImageEmpty, ObjectEmpty } from "../../editor/Empties";
import { ConstructionPlaneMemento, EditorOriginator, MementoOriginator, ViewportMemento } from "../../editor/History";
import { PlaneDatabase } from "../../editor/PlaneDatabase";
import { Scene } from "../../editor/Scene";
import { ConstructionPlaneSnap, FaceConstructionPlaneSnap } from "../../editor/snaps/ConstructionPlaneSnap";
import { TextureLoader } from "../../editor/TextureLoader";
import studio_small_03 from '../../img/hdri/studio_small_03_1k.exr';
import { GPUDepthReader } from "../../selection/GPUDepthReader";
import * as selector from '../../selection/ViewportSelector';
import { ViewportSelector } from '../../selection/ViewportSelector';
import { Settings, Theme } from "../../startup/ConfigFiles";
import { Helper, Helpers } from "../../util/Helpers";
import * as signals from '../../util/Signals';
import { MaterialWithColor, RenderedSceneBuilder } from "../../visual_model/RenderedSceneBuilder";
import * as visual from '../../visual_model/VisualModel';
import { Pane } from '../pane/Pane';
import { GridHelper } from "./GridHelper";
import { NavigationTargetGenerator } from "./NavigationTargetGenerator";
import { AlignEvent, OrbitControls } from "./OrbitControls";
import { OutlinePass } from "./OutlinePass";
import { CameraMode, ProxyCamera } from "./ProxyCamera";
import { ViewportControlMultiplexer } from "./ViewportControlMultiplexer";
import { NavigationMode, NavigationTarget, ViewportNavigationTargetExecutor } from "./ViewportNavigationTargetExecutor";
import { Orientation, ViewportNavigatorGizmo, ViewportNavigatorPass } from "./ViewportNavigator";
import { ViewportPointControl } from "./ViewportPointControl";

export interface EditorLike extends selector.EditorLike {
    db: Database, // FIXME: should be Readonly
    helpers: Helpers,
    viewports: Iterable<Viewport>,
    signals: EditorSignals,
    originator: EditorOriginator,
    windowLoaded: boolean,
    highlight: RenderedSceneBuilder,
    keymaps: AtomKeymap.KeymapManager,
    styles: Theme,
    settings: Settings,
    planes: PlaneDatabase,
    textures: TextureLoader,
    scene: Scene,
}

export class Viewport implements MementoOriginator<ViewportMemento> {
    private readonly disposable = new CompositeDisposable();
    dispose() { this.disposable.dispose() }

    readonly changed = new signals.Signal();
    readonly navigationEnded = new signals.Signal();

    private readonly colors = this.editor.styles.colors;
    private readonly gridColor1 = new THREE.Color(this.colors.grid1).convertSRGBToLinear();
    private readonly gridColor2 = new THREE.Color(this.colors.grid2).convertSRGBToLinear();
    private readonly backgroundColor = new THREE.Color(this.colors.viewport).convertSRGBToLinear();
    private readonly selectionOutlineColor = new THREE.Color(this.colors.yellow[400]).convertSRGBToLinear();
    private readonly hoverOutlineColor = new THREE.Color(this.colors.yellow[50]).convertSRGBToLinear();

    private readonly composer: EffectComposer;
    readonly outlinePassSelection: OutlinePass;
    readonly outlinePassHover: OutlinePass;
    private readonly phantomsPass: RenderPass;
    private readonly helpersPass: RenderPass;
    readonly depth: GPUDepthReader;

    private readonly points = new ViewportPointControl(this, this.editor);
    readonly selector = new ViewportSelector(this, this.editor);
    readonly gestures = new selector.ViewportGestureSelector(this, this.editor);
    readonly multiplexer = new ViewportControlMultiplexer(this, this.editor.layers, this.editor.db, this.editor.scene, this.editor.signals);

    lastPointerEvent?: MouseEvent;

    private readonly scene = new THREE.Scene();
    private readonly phantomsScene = new THREE.Scene(); // Objects visualizing a geometry computation, like a transparent red boolean difference object.
    private readonly helpersScene = new THREE.Scene(); // Things like gizmos

    readonly additionalHelpers = new Set<THREE.Scene>();
    readonly cplanes = new NavigationTargetGenerator(this.editor.db, this.editor.planes, this.editor.snaps, this.editor.nodes);
    private readonly navigator = new ViewportNavigationTargetExecutor(this.editor, this.orbitControls);
    readonly grid = new GridHelper(this.gridColor1, this.gridColor2, this.backgroundColor);

    constructor(
        private readonly editor: EditorLike,
        readonly renderer: THREE.WebGLRenderer,
        readonly domElement: HTMLElement,
        readonly camera: ProxyCamera,
        constructionPlane: ConstructionPlaneSnap,
        readonly orbitControls: OrbitControls,
    ) {
        this._constructionPlane = constructionPlane;

        renderer.domElement.addEventListener('pointermove', e => {
            this.lastPointerEvent = e;
        });

        renderer.setPixelRatio(window.devicePixelRatio);
        const renderTarget = makeRenderTarget(renderer, this.editor.settings.Viewport.renderer);
        this.depth = new GPUDepthReader(renderTarget.depthTexture, camera, renderer);

        EffectComposer: {
            this.composer = new EffectComposer(renderer, renderTarget);
            this.composer.setPixelRatio(window.devicePixelRatio);

            const renderPass = new RenderPass(this.scene, this.camera);
            this.phantomsPass = new RenderPass(this.phantomsScene, this.camera);
            this.helpersPass = new RenderPass(this.helpersScene, this.camera);

            this.phantomsPass.clear = false;
            this.phantomsPass.clearDepth = true;
            this.helpersPass.clear = false;
            this.helpersPass.clearDepth = true;

            const outlinePassSelection = new OutlinePass(new THREE.Vector2(this.domElement.offsetWidth, this.domElement.offsetHeight), this.camera);
            outlinePassSelection.visibleEdgeColor.copy(this.selectionOutlineColor);
            outlinePassSelection.hiddenEdgeColor.copy(this.selectionOutlineColor);
            this.outlinePassSelection = outlinePassSelection;

            const outlinePassHover = new OutlinePass(new THREE.Vector2(this.domElement.offsetWidth, this.domElement.offsetHeight), this.camera);
            outlinePassHover.visibleEdgeColor.copy(this.hoverOutlineColor);
            outlinePassHover.hiddenEdgeColor.copy(this.hoverOutlineColor);
            this.outlinePassHover = outlinePassHover;

            const navigatorGizmo = new ViewportNavigatorGizmo(this, this.editor.settings.Viewport.navigator.size, this.editor.settings.Viewport.navigator.padding);
            const navigatorPass = new ViewportNavigatorPass(navigatorGizmo, this.camera);
            const gammaCorrection = new ShaderPass(GammaCorrectionShader);

            this.composer.addPass(renderPass);
            this.composer.addPass(this.depth);
            this.composer.addPass(this.outlinePassHover);
            this.composer.addPass(this.outlinePassSelection);
            this.composer.addPass(this.phantomsPass);
            this.composer.addPass(this.helpersPass);
            this.composer.addPass(navigatorPass);
            this.composer.addPass(gammaCorrection);
        }

        this.render = this.render.bind(this);
        this.setNeedsRender = this.setNeedsRender.bind(this);
        this.setRenderListNeedsUpdate = this.setRenderListNeedsUpdate.bind(this);
        this.outlineSelection = this.outlineSelection.bind(this);
        this.outlineHover = this.outlineHover.bind(this);
        this.navigationStart = this.navigationStart.bind(this);
        this.navigationAlign = this.navigationAlign.bind(this);
        this.navigationEnd = this.navigationEnd.bind(this);
        this.navigationChange = this.navigationChange.bind(this);
        this.controlStart = this.controlStart.bind(this);
        this.controlEnd = this.controlEnd.bind(this);

        this.disposable.add(
            this.editor.registry.add(this.domElement, {
                'viewport:navigate:front': () => this.navigateToOrientation(Orientation.negY),
                'viewport:navigate:right': () => this.navigateToOrientation(Orientation.posX),
                'viewport:navigate:top': () => this.navigateToOrientation(Orientation.posZ),
                'viewport:navigate:back': () => this.navigateToOrientation(Orientation.posY),
                'viewport:navigate:left': () => this.navigateToOrientation(Orientation.negX),
                'viewport:navigate:bottom': () => this.navigateToOrientation(Orientation.negZ),
                'viewport:navigate:selection': () => this.navigateToSelection(),
                'viewport:focus': () => this.focus(),
                'viewport:toggle-orthographic': () => this.togglePerspective(),
                'viewport:toggle-edges': () => this.toggleEdges(),
                'viewport:toggle-faces': () => this.toggleFaces(),
                'viewport:toggle-x-ray': () => this.toggleXRay(),
                'viewport:toggle-overlays': () => this.toggleOverlays(),
                'viewport:cplane:selection': () => this.cplaneToSelection(),
                'viewport:grid:incr': () => this.resizeGrid(1),
                'viewport:grid:decr': () => this.resizeGrid(-1),
                'viewport:depth:show': () => this.depth.show(),
            })
        );

        this.disposable.add(new Disposable(() => {
            this.multiplexer.dispose();
            this.selector.dispose();
            this.points.dispose();
            this.orbitControls.dispose();
        }));

        this.scene.background = this.backgroundColor;
        // @ts-expect-error
        this.scene.matrixWorldAutoUpdate = false;
        // @ts-expect-error
        this.helpersScene.matrixWorldAutoUpdate = false;
        this.multiplexer.push(this.points, this.selector, this.gestures);
    }

    private started = false;
    start() {
        if (this.started) return;
        this.started = true;

        this.editor.signals.commandEnded.add(this.outlineSelection);
        this.editor.signals.historyChanged.add(this.outlineSelection);
        this.editor.signals.backupLoaded.add(this.outlineSelection);
        this.editor.signals.factoryUpdated.add(this.outlineSelection);
        this.editor.signals.factoryCancelled.add(this.outlineSelection);
        this.editor.signals.factoryCommitted.add(this.outlineSelection);
        this.editor.signals.historyChanged.add(this.outlineHover);
        this.editor.signals.commandEnded.add(this.outlineHover);
        this.editor.signals.hoverDelta.add(this.outlineHover);
        this.editor.signals.backupLoaded.add(this.outlineHover);

        this.editor.signals.commandEnded.add(this.setNeedsRender);
        this.editor.signals.itemMaterialChanged.add(this.setNeedsRender);
        this.editor.signals.pointPickerChanged.add(this.setNeedsRender);
        this.editor.signals.gizmoChanged.add(this.setNeedsRender);
        this.editor.signals.hoverDelta.add(this.setNeedsRender);

        this.editor.signals.databaseChanged.add(this.setRenderListNeedsUpdate);
        this.editor.signals.factoryUpdated.add(this.setRenderListNeedsUpdate);
        this.editor.signals.factoryCancelled.add(this.setRenderListNeedsUpdate);
        this.editor.signals.quasimodeChanged.add(this.setRenderListNeedsUpdate);
        this.editor.signals.historyChanged.add(this.setRenderListNeedsUpdate);
        this.editor.signals.commandEnded.add(this.setRenderListNeedsUpdate);
        this.editor.signals.moduleReloaded.add(this.setRenderListNeedsUpdate);
        this.editor.signals.visibleLayersChanged.add(this.setRenderListNeedsUpdate);

        this.orbitControls.addEventListener('change', this.setNeedsRender);
        this.orbitControls.addEventListener('start', this.navigationStart);
        this.orbitControls.addEventListener('align', this.navigationAlign);

        this.multiplexer.addEventListener('start', this.controlStart);
        this.multiplexer.addEventListener('end', this.controlEnd);
        this.multiplexer.addEventLiseners();
        this.orbitControls.addEventListeners();

        this.renderer.setAnimationLoop(clock => this.animate(clock));

        this.disposable.add(new Disposable(() => {
            this.editor.signals.selectionChanged.remove(this.outlineSelection);
            this.editor.signals.historyChanged.remove(this.outlineSelection);
            this.editor.signals.backupLoaded.remove(this.outlineSelection);
            this.editor.signals.factoryUpdated.remove(this.outlineSelection);
            this.editor.signals.factoryCancelled.remove(this.outlineSelection);
            this.editor.signals.factoryCommitted.remove(this.outlineSelection);
            this.editor.signals.historyChanged.remove(this.outlineHover);
            this.editor.signals.commandEnded.remove(this.outlineHover);
            this.editor.signals.hoverDelta.remove(this.outlineHover);
            this.editor.signals.backupLoaded.remove(this.outlineHover);

            this.editor.signals.selectionChanged.remove(this.setNeedsRender);
            this.editor.signals.itemMaterialChanged.remove(this.setNeedsRender);
            this.editor.signals.pointPickerChanged.remove(this.setNeedsRender);
            this.editor.signals.gizmoChanged.remove(this.setNeedsRender);
            this.editor.signals.hoverDelta.remove(this.setNeedsRender);

            this.editor.signals.databaseChanged.remove(this.setRenderListNeedsUpdate);
            this.editor.signals.factoryUpdated.remove(this.setRenderListNeedsUpdate);
            this.editor.signals.factoryCancelled.remove(this.setRenderListNeedsUpdate);
            this.editor.signals.quasimodeChanged.remove(this.setRenderListNeedsUpdate);
            this.editor.signals.historyChanged.remove(this.setRenderListNeedsUpdate);
            this.editor.signals.commandEnded.remove(this.setRenderListNeedsUpdate);
            this.editor.signals.moduleReloaded.remove(this.setRenderListNeedsUpdate);
            this.editor.signals.visibleLayersChanged.remove(this.setRenderListNeedsUpdate);

            this.orbitControls.removeEventListener('change', this.setNeedsRender);
            this.orbitControls.removeEventListener('start', this.navigationStart);
            this.multiplexer.removeEventListener('start', this.controlStart);
            this.multiplexer.removeEventListener('end', this.controlEnd);

            this.renderer.setAnimationLoop(null);
            this.started = false;
        }));
    }

    private needsRender = true;
    private setNeedsRender() { this.needsRender = true }

    private renderListNeedsUpdate = true;
    private setRenderListNeedsUpdate() {
        this.renderListNeedsUpdate = true;
        this.setNeedsRender();
        this.depth.setNeedsRender
    }

    private readonly renderListScene = new THREE.Scene();
    private get renderList() {
        if (!this.renderListNeedsUpdate) return this.renderListScene;
        this.renderListNeedsUpdate = false;
        this.renderListScene.children.length = 0;

        const { editor: { scene: editorScene } } = this

        const visibleObjects = editorScene.visibleObjects;
        const layers = this.editor.layers.visible;

        const renderList = this.renderListScene.children;
        for (const item of visibleObjects) {
            if (!item.visible) continue;
            if (item instanceof visual.Solid) {
                renderList.push(item.high.faces.mesh, item.high.edges.line, item.high.edges.temp);
                if (layers.test(item.high.edges.occluded.layers))
                    renderList.push(item.high.edges.occluded);
            } else if (item instanceof visual.Sheet) {
                renderList.push(item.high.faces.mesh, item.high.edges.line, item.high.edges.temp);
                if (layers.test(item.high.edges.occluded.layers))
                    renderList.push(item.high.edges.occluded);
            } else if (item instanceof visual.SpaceInstance) {
                if (layers.test(item.segments.line.layers))
                    renderList.push(item.segments.line);
                if (layers.test(item.segments.occluded.layers))
                    renderList.push(item.segments.occluded);
                if (layers.test(item.vertices.layers))
                    renderList.push(item.vertices);
                if (layers.test(item.cvs.layers))
                    renderList.push(item.cvs);
            } else if (item instanceof visual.SketchIsland) {
                renderList.push(item.regions.mesh);
            } else if (item instanceof ImageEmpty) {
                renderList.push(item.plane);
            } else if (item instanceof ObjectEmpty) {
                renderList.push(item.object);
            } else {
                throw new Error("invalid type: " + item.constructor.name);
            }
        }
        return this.renderListScene;
    }

    private lastFrameNumber = -1; // FIXME: move to editor so that when there are multiple viewports, we don't redo work
    render(frameNumber: number) {
        if (!this.needsRender) return;
        this.needsRender = false;

        const { editor: { db, helpers, signals }, scene, phantomsScene, helpersScene, composer, camera, lastFrameNumber, phantomsPass, helpersPass, domElement, additionalHelpers, depth, renderList } = this
        const additional = [...additionalHelpers];

        try {
            // prepare the scene, once per frame (there may be multiple viewports rendering the same frame):
            if (frameNumber > lastFrameNumber) {
                scene.add(renderList);
                scene.add(db.temporaryObjects);
                this.addOverlays(scene);

                helpersScene.add(helpers.scene);
                phantomsScene.add(db.phantomObjects);

                if (additional.length > 0) {
                    for (const a of additional) {
                        a.traverse(child => {
                            if (child instanceof Helper) {
                                child.update(camera);
                                child.updateMatrixWorld()
                            }
                        })
                    }
                    if (this.isXRay) helpersScene.add(...additional);
                    else scene.add(...additional)
                }

                phantomsPass.enabled = db.phantomObjects.children.length > 0;
                helpersPass.enabled = helpers.scene.children.length > 0;
            }

            const resolution = new THREE.Vector2(domElement.offsetWidth, domElement.offsetHeight);
            signals.renderPrepared.dispatch({ camera, resolution });
            helpersScene.traverse(child => {
                if (child instanceof Helper) {
                    child.update(camera);
                    child.updateMatrixWorld();
                }
            });

            camera.layers = this.editor.layers.visible as THREE.Layers;
            composer.render();

            if (frameNumber > lastFrameNumber) {
                scene.clear();
                helpersScene.clear();
                phantomsScene.clear();
            }
        } finally {
            this.lastFrameNumber = frameNumber;
        }
    }

    private addOverlays(scene: THREE.Scene) {
        if (!this.showOverlays) return;
        const { grid, isOrthoMode, constructionPlane, camera, editor: { helpers } } = this;

        scene.fog = new THREE.Fog(this.backgroundColor, 50, 300)

        const overlay = grid.getOverlay(isOrthoMode, constructionPlane, camera);
        scene.add(overlay);

        helpers.axes.updateMatrixWorld();
        scene.add(helpers.axes);
    }

    private readonly clock = new THREE.Clock();
    private animate(frameNumber: number) {
        const delta = this.clock.getDelta();
        if (this.navigator.update(delta)) this.setNeedsRender();
        this.render(frameNumber);
    }

    private outlineSelection() {
        this.outlinePassSelection.selectedObjects = this.collectOutline(this.editor.highlight.outlineSelection);
    }

    private outlineHover() {
        this.outlinePassHover.selectedObjects = this.collectOutline(this.editor.highlight.outlineHover);
    }

    private collectOutline(selection: Iterable<visual.Outlineable>) {
        const toOutline = [];
        for (const item of selection) {
            const outline = item.outline;
            if (outline !== undefined) toOutline.push(outline);
        }
        return toOutline;
    }

    setSize(offsetWidth: number, offsetHeight: number) {
        const { camera, renderer, composer, depth } = this;
        camera.setSize(offsetWidth, offsetHeight);

        renderer.setSize(offsetWidth, offsetHeight);
        composer.setSize(offsetWidth, offsetHeight);

        this.boundingClientRect = this.domElement.getBoundingClientRect();

        this.setNeedsRender();
    }

    private readonly controls = [this.multiplexer, this.selector, this.points, this.orbitControls];
    disableControls(except?: { enable(e: boolean): Disposable }): Disposable {
        const disposable = new CompositeDisposable();
        for (const control of this.controls) {
            if (control === except) continue;
            disposable.add(control.enable(false));
        }
        return disposable;
    }

    enableControls() {
        for (const control of this.controls) control.enable(true);
    }

    private navigationState: NavigationState = { tag: 'none' }

    private navigationStart() {
        switch (this.navigationState.tag) {
            case 'none':
                this.orbitControls.addEventListener('change', this.navigationChange);
                this.orbitControls.addEventListener('end', this.navigationEnd);
                const restoreControls = this.disableControls(this.orbitControls);
                this.navigationState = { tag: 'navigating', restoreControls, quaternion: this.camera.quaternion.clone() };
                this.editor.signals.viewportActivated.dispatch(this);
                break;
            default: throw new Error("invalid state");
        }
    }

    private navigationAlign(event: AlignEvent) {
        const cplane = this.cplanes.navigationTargetForCardinalDirection(event.direction, this.camera);
        this._navigate(cplane, 'align-camera');
    }

    private navigationChange() {
        switch (this.navigationState.tag) {
            case 'navigating':
                this.transitionFromOrthoModeIfOrbitted(this.navigationState.quaternion);
                break;
            default: throw new Error("invalid state");
        }
    }

    // NOTE: ortho mode is not the same as an ortho camera; in ortho mode you have an ortho camera but there are also special snapping behaviors, etc.
    private orthoState?: { oldCameraMode: CameraMode, oldConstructionPlane: ConstructionPlaneSnap | FaceConstructionPlaneSnap } = undefined;
    get isOrthoMode(): boolean { return this.orthoState !== undefined }
    get preferConstructionPlane(): boolean { return this.orthoState !== undefined || this.constructionPlane !== PlaneDatabase.XY }

    private transitionToOrthoMode(oldConstructionPlane: ConstructionPlaneSnap | FaceConstructionPlaneSnap) {
        if (this.orthoState !== undefined) return;
        const oldCameraMode = this.camera.setOrtho();
        this.orthoState = { oldCameraMode, oldConstructionPlane };
    }

    private transitionFromOrthoModeIfOrbitted(quaternion: THREE.Quaternion) {
        if (this.orthoState === undefined) return;
        const dot = quaternion.dot(this.camera.quaternion);
        if (Math.abs(Math.abs(dot) - 1) > 10e-6) {
            this.transitionFromOrthoMode();
        }
    }

    private transitionFromOrthoMode() {
        if (this.orthoState === undefined) return;
        this.camera.setMode(this.orthoState.oldCameraMode);
        this.constructionPlane = this.orthoState.oldConstructionPlane;
        this.orthoState = undefined;
        this.changed.dispatch();
    }

    private navigationEnd() {
        switch (this.navigationState.tag) {
            case 'navigating':
                this.orbitControls.removeEventListener('change', this.navigationChange);
                this.orbitControls.removeEventListener('end', this.navigationEnd);
                this.navigationState.restoreControls.dispose();
                this.navigationEnded.dispatch();
                this.navigationState = { tag: 'none' };
                this.depth.setNeedsRender();
                break;
            default: throw new Error("invalid state");
        }
    }

    private controlStart() {
        this.editor.signals.viewportActivated.dispatch(this);
    }

    private controlEnd() { }

    togglePerspective() {
        this.camera.toggle();
        this.transitionFromOrthoMode();
        this.orbitControls.update();
        this.changed.dispatch();
        this.setNeedsRender();
    }

    get fov() { return this.camera.fov }
    set fov(fov: number) {
        this.camera.fov = fov;
        this.transitionFromOrthoMode();
        this.orbitControls.update();
        this.changed.dispatch();
        this.setNeedsRender();
    }

    get isXRay() { return this.editor.layers.isXray }
    set isXRay(isXRay: boolean) {
        this.editor.layers.isXray = isXRay;
        this.setNeedsRender();
        this.changed.dispatch();
    }

    toggleXRay() {
        this.editor.layers.toggleXRay();
        this.setNeedsRender();
        this.changed.dispatch();
    }

    get isShowingEdges() { return this.editor.layers.isShowingEdges }
    set isShowingEdges(show: boolean) {
        this.editor.layers.isShowingEdges = show;
    }

    toggleEdges() {
        this.isShowingEdges = !this.isShowingEdges;
    }

    get isShowingFaces() { return this.editor.layers.isShowingFaces }
    set isShowingFaces(show: boolean) {
        this.editor.layers.isShowingFaces = show;
    }

    toggleFaces() {
        this.isShowingFaces = !this.isShowingFaces;
    }

    setMatcap(matcap: string, isTinted: boolean) {
        this.editor.highlight.setMatcap(matcap, isTinted).then(() => {
            this.setNeedsRender();
        });
        this.changed.dispatch();
    }

    setMaterial(material: MaterialWithColor, isTinted: boolean) {
        this.editor.highlight.setUniformMaterial(material, isTinted);
        this.setNeedsRender();
        this.changed.dispatch();
    }

    get isRenderMode() { return this.editor.highlight.mode.tag === 'per-object' }
    set isRenderMode(isRenderMode: boolean) {
        if (this.isRenderMode === isRenderMode) return;
        this.editor.highlight.togglePerObjectMode();
        if (isRenderMode) {
            const { texture, loaded } = this.editor.textures.get(studio_small_03);
            texture.mapping = THREE.EquirectangularReflectionMapping;
            this.scene.environment = texture;
            loaded.then(() => this.setNeedsRender());
        } else {
            this.scene.environment = null;
            this.setNeedsRender();
        }
        this.changed.dispatch();
    }

    private _shouldShowOverlays = true;
    get showOverlays() { return this._shouldShowOverlays }
    toggleOverlays() {
        this._shouldShowOverlays = !this._shouldShowOverlays;
        this.setNeedsRender();
        this.changed.dispatch();
    }

    resizeGrid(factor: -1 | 1) {
        this.grid.resizeGrid(factor);
        this.setNeedsRender();
    }

    navigateToSelection() {
        const target = this.cplanes.navigationTargetForSelection(this.editor.selection.selected, this.camera);
        const backup = this.cplanes.navigationTargetFor(this.constructionPlane, this.camera);
        this._navigate(target ?? backup, 'align-camera');
    }

    navigateToOrientation(orientation: Orientation) {
        const target = this.cplanes.navigationTargetForOrientation(orientation);
        this._navigate(target, 'align-camera');
    }

    navigate(input: visual.Face | visual.Region | ConstructionPlaneSnap) {
        const target = input !== undefined ? this.cplanes.navigationTargetFor(input, this.camera) : undefined;
        const backup = this.cplanes.navigationTargetFor(this.constructionPlane, this.camera);
        this._navigate(target ?? backup, 'align-camera');
    }

    private cplaneToSelection() {
        const target = this.cplanes.navigationTargetForSelection(this.editor.selection.selected, this.camera);
        const backup = this.cplanes.navigationTargetFor(PlaneDatabase.XY, this.camera);
        this._navigate(target ?? backup, 'keep-camera-position');
    }

    set constructionPlane(input: visual.Face | visual.Region | Orientation | ConstructionPlaneSnap | FaceConstructionPlaneSnap | undefined) {
        const target = input !== undefined ? this.cplanes.navigationTargetFor(input, this.camera) : undefined;
        const backup = this.cplanes.navigationTargetFor(PlaneDatabase.XY, this.camera);
        this._navigate(target ?? backup, 'keep-camera-position');
    }

    private _navigate(to: NavigationTarget, mode: NavigationMode) {
        this.navigator.navigate(to, mode);
        const oldConstructionPlane = this.constructionPlane;
        this._constructionPlane = to.cplane;
        if (mode === 'align-camera')
            this.transitionToOrthoMode(oldConstructionPlane);
        else
            this.orthoState = undefined;
        this.setNeedsRender();
        this.changed.dispatch();
    }

    private _constructionPlane!: ConstructionPlaneSnap | FaceConstructionPlaneSnap;
    get constructionPlane(): ConstructionPlaneSnap | FaceConstructionPlaneSnap { return this._constructionPlane }

    focus() {
        const { solids, sheets, curves, regions, vertices, cvs, faces, edges } = this.editor.selection.selected;
        this.orbitControls.focus([...solids, ...sheets, ...curves, ...regions, ...vertices, ...cvs, ...edges, ...faces], this.editor.scene.visibleObjects);
    }

    validate() {
        console.assert(this.selector.enabled, "this.selector.enabled");
    }

    saveToMemento(): ViewportMemento {
        return new ViewportMemento(
            this.camera.saveToMemento(),
            this.orbitControls.target,
            this.isXRay,
            new ConstructionPlaneMemento(this.constructionPlane.n, this.constructionPlane.n));
    }

    restoreFromMemento(m: ViewportMemento) {
        this.camera.restoreFromMemento(m.camera);
        this.orbitControls.target.copy(m.target);
        this.orbitControls.update();
        this.isXRay = m.isXRay;
        this.orthoState = undefined;
        this._constructionPlane = PlaneDatabase.XY;
        this.changed.dispatch();
    }

    clear() { }

    debug() { }

    private boundingClientRect = this.domElement.getBoundingClientRect();

    // top left is 0,0, bottom right is width,height
    private getMousePosition(event: MouseEvent, to = new THREE.Vector2()): THREE.Vector2 {
        const [x, y] = [event.clientX, event.clientY];
        const rect = this.boundingClientRect;
        to.set((x - rect.left), rect.height - (y - rect.top));
        return to;
    }

    // input: top left is 0,0, bottom right is width,height
    // output: bottom left -1,-1, top right 1,1
    private normalizeScreenPosition(position: THREE.Vector2): THREE.Vector2 {
        const rect = this.boundingClientRect;
        position.set(position.x / rect.width, position.y / rect.height);
        position.set((position.x * 2) - 1, (position.y * 2) - 1);
        return position;
    }

    // input: bottom left -1,-1, top right 1,1
    // output: top left is 0,0, botton right is width,height
    denormalizeScreenPosition(position: THREE.Vector2): THREE.Vector2 {
        position.set((1 + position.x) / 2, (1 - position.y) / 2);
        const rect = this.boundingClientRect;
        position.set(position.x * rect.width, position.y * rect.height);
        return position;
    }

    getNormalizedMousePosition(event: MouseEvent, to = new THREE.Vector2()): THREE.Vector2 {
        const result = this.getMousePosition(event, to);
        this.normalizeScreenPosition(result);
        return result;
    }
}

type NavigationState = { tag: 'none' } | { tag: 'navigating', restoreControls: Disposable, quaternion: THREE.Quaternion }

export interface ViewportElement {
    readonly model: Viewport;
}

export default (editor: Editor) => {
    class ViewportElement extends HTMLElement implements ViewportElement {
        readonly model: Viewport;
        private disposable: Disposable;

        constructor() {
            super();

            const renderer = new THREE.WebGLRenderer({ antialias: false, alpha: true });
            this.append(renderer.domElement);
            this.disposable = this.handleContextLoss(renderer);

            const view = this.getAttribute("view");

            let camera: ProxyCamera;
            let constructionPlane: ConstructionPlaneSnap;
            let enableRotate = false;
            switch (view) {
                case "3d":
                    camera = new ProxyCamera();
                    camera.position.set(5, -5, 5);
                    constructionPlane = PlaneDatabase.XY;
                    enableRotate = true;
                    break;
                case "top":
                    camera = new ProxyCamera();
                    camera.position.set(0, 0, 10);
                    constructionPlane = PlaneDatabase.XY;
                    break;
                case "right":
                    camera = new ProxyCamera();
                    camera.position.set(10, 0, 0);
                    constructionPlane = PlaneDatabase.YZ;
                    break;
                case "front":
                default:
                    camera = new ProxyCamera();
                    camera.position.set(0, 10, 0);
                    constructionPlane = PlaneDatabase.XZ;
                    break;
            }

            const orbitControls = new OrbitControls(
                camera,
                renderer.domElement,
                editor.keymaps,
                editor.settings.OrbitControls);
            orbitControls.enableRotate = enableRotate;

            camera.up.set(0, 0, 1);
            camera.lookAt(new THREE.Vector3());
            camera.updateMatrixWorld();

            this.model = new Viewport(
                editor,
                renderer,
                this,
                camera,
                constructionPlane,
                orbitControls,
            );
        }

        private handleContextLoss(renderer: THREE.WebGLRenderer) {
            const onContextRestore = () => {
                console.log(new Date().toString(), "context restored");
            };
            const onContextLoss = () => {
                // NOTE: this is a hack to force the Toolbar to rerender, which triggers a true context restore.
                // sorry.... I don't know what else to do????
                console.log(new Date().toString(), "context lost");
                setTimeout(editor.signals.redrawToolbarHack.dispatch, 100);
            };

            renderer.domElement.addEventListener('webglcontextlost', onContextLoss);
            renderer.domElement.addEventListener('webglcontextrestored', onContextRestore);
            return new Disposable(() => {
                renderer.domElement.removeEventListener('webglcontextlost', onContextLoss);
                renderer.domElement.removeEventListener('webglcontextrestored', onContextRestore);
            });
        }

        connectedCallback() {
            editor.viewports.add(this.model);

            const pane = this.parentElement as Pane | null;
            pane?.signals?.flexScaleChanged.add(this.resize);
            editor.signals.windowLoaded.add(this.resize);
            editor.signals.windowResized.add(this.resize);

            if (editor.windowLoaded) this.model.start();
        }

        disconnectedCallback() {
            editor.viewports.delete(this.model);
            this.model.dispose();
            this.disposable.dispose();
        }

        private debounce?: NodeJS.Timeout;
        resize = () => {
            if (this.debounce !== undefined) clearTimeout(this.debounce);

            this.debounce = setTimeout(() => {
                this.model.setSize(this.offsetWidth, this.offsetHeight);
                this.model.start();
            }, 30);
        }
    }

    customElements.define('plasticity-viewport', ViewportElement);
}

function makeRenderTarget(renderer: THREE.WebGLRenderer, settings: Settings['Viewport']['renderer']): THREE.WebGLRenderTarget {
    const size = renderer.getSize(new THREE.Vector2());

    if (process.platform === 'linux') {
        // Linux seems to require an explicity float depth texture otherwise there are zbuffer artifacts
        const depthTexture = new THREE.DepthTexture(size.width, size.height, THREE.FloatType);
        return new THREE.WebGLRenderTarget(size.width, size.height, { type: THREE.FloatType, generateMipmaps: false, samples: 4, depthTexture });
    } else {
        const gl = renderer.getContext();
        const debugRendererInfo = gl.getExtension('WEBGL_debug_renderer_info');
        const device: string | undefined = debugRendererInfo === undefined ? undefined : renderer.getContext().getParameter(debugRendererInfo!.UNMASKED_RENDERER_WEBGL);

        const depthTexture = new THREE.DepthTexture(size.width, size.height);
        // depthTexture.format = THREE.DepthStencilFormat;
        // depthTexture.type = THREE.UnsignedInt248Type; // Higher precision than the default, THREE.UnsignedShortType

        // Since we render in Linear/HDR we need at least HalfFloatType for the buffer to avoid banding.
        // Unfortunately, the 
        if (device === "Apple M1") {
            return new THREE.WebGLRenderTarget(size.width, size.height, { type: THREE.HalfFloatType, generateMipmaps: false, samples: 1, depthTexture });
        } else {
            return new THREE.WebGLRenderTarget(size.width, size.height, { type: settings.type, generateMipmaps: false, samples: settings.samples, depthTexture });
        }
    }
}