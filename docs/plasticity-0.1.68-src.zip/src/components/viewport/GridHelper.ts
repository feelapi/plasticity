import * as THREE from 'three';
import { PlaneDatabase } from '../../editor/PlaneDatabase';
import { ConstructionPlane } from '../../editor/snaps/ConstructionPlaneSnap';
import { FloorHelper, OrthoModeGrid } from './FloorHelper';

const floorSize = 120;
const defaultFloorDivisions = floorSize;
const defaultGridDivisions = 1000;
const factors = [0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 5, 10, 50, 100];

export class GridHelper {
    private factorIndex = 6;
    private floor!: FloorHelper;
    private customGrid!: FloorHelper;
    private orthoGrid!: OrthoModeGrid;

    constructor(private readonly color1: THREE.Color, private readonly color2: THREE.Color, private readonly backgroundColor: THREE.Color) {
        this.setupGrid(this.gridFactor);
    }

    getOverlay(isOrthoMode: boolean, constructionPlane: ConstructionPlane, camera: THREE.Camera): THREE.Object3D {
        const { floor, orthoGrid: gridBackground, customGrid } = this;

        if (isOrthoMode) {
            gridBackground.position.copy(constructionPlane.p);
            gridBackground.quaternion.copy(constructionPlane.orientation);
            gridBackground.update(camera);
            return gridBackground;
        } else if (constructionPlane !== PlaneDatabase.XY) {
            customGrid.position.copy(constructionPlane.p);
            customGrid.quaternion.copy(constructionPlane.orientation);
            customGrid.update(camera);
            return customGrid;
        } else {
            floor.update(camera);
            return floor;
        }
    }

    resizeGrid(incr: -1 | 1) {
        this.factorIndex += incr;
        this.factorIndex = Math.max(0, Math.min(factors.length - 1, this.factorIndex));
        const factor = factors[this.factorIndex];

        this.setupGrid(factor);
    }

    private setupGrid(factor: number) {
        this.floor?.dispose();
        this.customGrid?.dispose();
        this.orthoGrid?.dispose();

        this.floor = new FloorHelper(floorSize * factor, defaultFloorDivisions, this.color1, this.color2);
        this.customGrid = new FloorHelper(floorSize * factor, defaultFloorDivisions, this.color1, this.color2);
        this.orthoGrid = new OrthoModeGrid(100 * factor, defaultGridDivisions, this.color1, this.color2, this.backgroundColor);
    }

    get gridFactor() {
        return factors[this.factorIndex];
    }
}

