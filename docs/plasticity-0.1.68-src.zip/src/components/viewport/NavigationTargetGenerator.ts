import * as THREE from 'three';
import { PointResult } from '../../command/point-picker/PointPicker';
import { ReadonlyGeometryDatabase } from "../../editor/DatabaseLike";
import { Empty, ImageEmpty } from '../../editor/Empties';
import { Nodes } from '../../editor/Nodes';
import { PlaneDatabase } from "../../editor/PlaneDatabase";
import { ConstructionPlaneSnap, FaceConstructionPlaneSnap } from "../../editor/snaps/ConstructionPlaneSnap";
import { ReadonlySnapManager } from "../../editor/snaps/SnapManager";
import { FaceSnap } from "../../editor/snaps/Snaps";
import { HasSelection } from '../../selection/SelectionDatabase';
import { X, Y, Z, _X, _Y, _Z } from '../../util/Constants';
import { point2point, vec2vec } from "../../util/Conversion";
import { assertUnreachable } from '../../util/Util';
import * as visual from '../../visual_model/VisualModel';
import { NavigationTarget } from './ViewportNavigationTargetExecutor';
import { Orientation } from "./ViewportNavigator";

export type CardinalDirection = 'north' | 'south' | 'east' | 'west';

export class NavigationTargetGenerator {
    constructor(
        private readonly db: ReadonlyGeometryDatabase,
        private readonly planes: PlaneDatabase,
        private readonly snaps: ReadonlySnapManager,
        private readonly nodes: Nodes,
    ) { }

    navigationTargetFor(to: visual.Face | visual.Region | Orientation | ConstructionPlaneSnap | FaceConstructionPlaneSnap, camera: THREE.Camera): NavigationTarget {
        if (to instanceof visual.Face)
            return this.navigationTargetForFace(to);
        else if (to instanceof visual.Region)
            return this.navigationTargetForRegion(to, camera);
        else if (to instanceof ConstructionPlaneSnap)
            return { tag: 'cplane', cplane: to };
        else if (to instanceof FaceConstructionPlaneSnap)
            return { tag: 'face', targets: new Set(), cplane: to };
        else return this.navigationTargetForOrientation(to);
    }

    navigationTargetForSelection(selection: HasSelection, camera: THREE.Camera): NavigationTarget | undefined {
        if (selection.faces.size === 1) {
            if (selection.edges.size > 0) {
                return this.navigationTargetForFaceAndEdge(selection.faces.first, selection.edges.first);
            } else {
                return this.navigationTargetForFace(selection.faces.first);
            }
        } else if (selection.faces.size > 1) {
            return this.navigationTargetForFaces([...selection.faces]);
        } else if (selection.regions.size > 0) {
            return this.navigationTargetForRegion(selection.regions.first, camera);
        } else if (selection.edges.size === 1) {
            return this.navigationTargetForEdge(selection.edges.first, camera);
        } else if (selection.curves.size === 1) {
            return this.navigationTargetForCurve(selection.curves.first, camera);
        } else if (selection.empties.size === 1) {
            return this.navigationTargetForEmpty(selection.empties.first);
        } else return;
    }

    navigationTargetForCamera(camera: THREE.Camera, point: THREE.Vector3): NavigationTarget {
        const { planes } = this;
        const normal = new THREE.Vector3(0, 0, 1);
        normal.applyQuaternion(camera.quaternion);
        const cplane = planes.temp(new ConstructionPlaneSnap(normal, point));
        return { tag: 'cplane', cplane }
    }

    navigationTargetForRegion(to: visual.Region, camera: THREE.Camera): Extract<NavigationTarget, { tag: 'region' }> {
        const { db, planes } = this;
        const model = db.lookupTopologyItem(to);
        const target = model.GetPoint(0.5, 0.5);
        const { normal } = model.EvalBasis(0.5, 0.5);
        const normal_ = vec2vec(normal, 1);
        _eye.set(0, 0, 1).applyQuaternion(camera.quaternion);
        if (normal_.dot(_eye) < 0) normal_.negate();
        const cplane = planes.temp(new ConstructionPlaneSnap(normal_, point2point(target)));
        return { tag: 'region', target: to, cplane }
    }

    navigationTargetForFace(to: visual.Face): NavigationTarget {
        const { db, planes, snaps } = this;
        const model = db.lookupTopologyItem(to);
        const target = model.GetPoint(0.5, 0.5);
        const { normal } = model.EvalBasis(0.5, 0.5);
        const faceSnap = snaps.lookup(to) as FaceSnap;
        const cplane = planes.temp(new FaceConstructionPlaneSnap(vec2vec(normal, 1), point2point(target), undefined, faceSnap));
        return { tag: 'face', targets: new Set([to]), cplane }
    }

    navigationTargetForFaces(tos: visual.Face[]): NavigationTarget {
        const { db, planes } = this;
        const n = new THREE.Vector3();
        const p = new THREE.Vector3();
        const normals = [];
        for (const to of tos) {
            const model = db.lookupTopologyItem(to);
            const target = model.GetPoint(0.5, 0.5);
            const { normal } = model.EvalBasis(0.5, 0.5);
            const v = vec2vec(normal, 1);
            normals.push(v);
            n.add(v);
            p.add(point2point(target));
        }

        if (n.manhattanLength() < 1e-6) n.copy(normals[0]);
        else n.normalize();

        p.divideScalar(tos.length);

        const cplane = planes.temp(new ConstructionPlaneSnap(n, p));
        return { tag: 'cplane', cplane }
    }

    navigationTargetForFaceAndEdge(faceView: visual.Face, edgeView: visual.CurveEdge): NavigationTarget {
        const { db, planes, snaps } = this;
        const faceModel = db.lookupTopologyItem(faceView);
        const edgeModel = db.lookupTopologyItem(edgeView);
        const target = faceModel.GetPoint(0.5, 0.5);
        const { normal } = faceModel.EvalBasis(0.5, 0.5);
        const faceSnap = snaps.lookup(faceView) as FaceSnap;
        const { tangent } = edgeModel.GetPointAndTangent(0);
        const cplane = planes.temp(new FaceConstructionPlaneSnap(vec2vec(normal, 1), point2point(target), vec2vec(tangent, 1), faceSnap));
        return { tag: 'face', targets: new Set([faceView, edgeView]), cplane }
    }

    navigationTargetForEdge(edgeView: visual.CurveEdge, camera: THREE.Camera): NavigationTarget {
        const { db, planes } = this;
        const edgeModel = db.lookupTopologyItem(edgeView);
        const position = edgeModel.GetPoint(0.5);
        const { normal, tangent } = edgeModel.EvalBasis(0.5);
        const cplane = planes.temp(new ConstructionPlaneSnap(vec2vec(normal, 1), point2point(position), vec2vec(tangent, 1)));
        return { tag: 'cplane', cplane }
    }

    navigationTargetForCurve(view: visual.SpaceInstance, camera: THREE.Camera): NavigationTarget | undefined {
        const { db, planes } = this;
        const model = db.lookup(view);
        const basis = model.FindPlanarBasis();
        if (basis === undefined) return undefined;
        const { Location, Axis } = basis;
        const normal_ = vec2vec(Axis, 1);
        _eye.set(0, 0, 1).applyQuaternion(camera.quaternion);
        if (normal_.dot(_eye) < 0) normal_.negate();
        const cplane = planes.temp(new ConstructionPlaneSnap(normal_, point2point(Location)));
        return { tag: 'cplane', cplane }
    }

    navigationTargetForOrientation(to: Orientation): NavigationTarget {
        switch (to) {
            case Orientation.posX: return { tag: 'orientation', cplane: PlaneDatabase.YZ };
            case Orientation.posY: return { tag: 'orientation', cplane: PlaneDatabase.XZ };
            case Orientation.posZ: return { tag: 'orientation', cplane: PlaneDatabase.XY };
            case Orientation.negX: return { tag: 'orientation', cplane: PlaneDatabase._YZ };
            case Orientation.negY: return { tag: 'orientation', cplane: PlaneDatabase._XZ };
            case Orientation.negZ: return { tag: 'orientation', cplane: PlaneDatabase._XY };
            default: assertUnreachable(to);
        }
    }

    navigationTargetForEmpty(first: Empty): NavigationTarget | undefined {
        if (first instanceof ImageEmpty) {
            const transform = this.nodes.getTransform(first);
            if (transform === undefined) return;
            const { position, quaternion } = transform;
            const normal = new THREE.Vector3(0, 0, 1);
            normal.applyQuaternion(quaternion);
            const cplane = this.planes.temp(new ConstructionPlaneSnap(normal, position));
            return { tag: 'cplane', cplane }
        }
        return undefined;
    }

    navigationTargetForCardinalDirection(to: CardinalDirection, camera: THREE.Camera): NavigationTarget {
        _eye.set(0, 0, 1).applyQuaternion(camera.quaternion);
        _up.set(0, 1, 0).applyQuaternion(camera.quaternion);
        let maxDot = 0;
        let eyeDirection = X;
        for (const dir of [X, _X, Y, _Y, Z, _Z]) {
            const dot = dir.dot(_eye);
            if (dot > maxDot) {
                maxDot = dot;
                eyeDirection = dir;
            }
        }
        maxDot = 0;
        let upDirection = Y;
        for (const dir of [X, _X, Y, _Y]) {
            const dot = dir.dot(_up);
            if (dot > maxDot) {
                maxDot = dot;
                upDirection = dir;
            }
        }
        switch (eyeDirection) {
            case X:
                switch (to) {
                    case 'north': return { tag: 'orientation', cplane: PlaneDatabase._XY };
                    case 'south': return { tag: 'orientation', cplane: PlaneDatabase.XY };
                    case 'east': return { tag: 'orientation', cplane: PlaneDatabase._XZ };
                    case 'west': return { tag: 'orientation', cplane: PlaneDatabase.XZ };
                }
            case _X:
                switch (to) {
                    case 'north': return { tag: 'orientation', cplane: PlaneDatabase._XY };
                    case 'south': return { tag: 'orientation', cplane: PlaneDatabase.XY };
                    case 'east': return { tag: 'orientation', cplane: PlaneDatabase.XZ };
                    case 'west': return { tag: 'orientation', cplane: PlaneDatabase._XZ };
                }
            case Y:
                switch (to) {
                    case 'north': return { tag: 'orientation', cplane: PlaneDatabase._XY };
                    case 'south': return { tag: 'orientation', cplane: PlaneDatabase.XY };
                    case 'east': return { tag: 'orientation', cplane: PlaneDatabase.YZ };
                    case 'west': return { tag: 'orientation', cplane: PlaneDatabase._YZ };
                }
            case _Y:
                switch (to) {
                    case 'north': return { tag: 'orientation', cplane: PlaneDatabase._XY };
                    case 'south': return { tag: 'orientation', cplane: PlaneDatabase.XY };
                    case 'east': return { tag: 'orientation', cplane: PlaneDatabase._YZ };
                    case 'west': return { tag: 'orientation', cplane: PlaneDatabase.YZ };
                }
            case Z:
                switch (upDirection) {
                    case Y:
                        switch (to) {
                            case 'north': return { tag: 'orientation', cplane: PlaneDatabase._XZ };
                            case 'south': return { tag: 'orientation', cplane: PlaneDatabase.XZ };
                            case 'east': return { tag: 'orientation', cplane: PlaneDatabase._YZ };
                            case 'west': return { tag: 'orientation', cplane: PlaneDatabase.YZ };
                        }
                    case _Y:
                        switch (to) {
                            case 'north': return { tag: 'orientation', cplane: PlaneDatabase.XZ };
                            case 'south': return { tag: 'orientation', cplane: PlaneDatabase._XZ };
                            case 'east': return { tag: 'orientation', cplane: PlaneDatabase.YZ };
                            case 'west': return { tag: 'orientation', cplane: PlaneDatabase._YZ };
                        }
                    case X:
                        switch (to) {
                            case 'north': return { tag: 'orientation', cplane: PlaneDatabase._YZ };
                            case 'south': return { tag: 'orientation', cplane: PlaneDatabase.YZ };
                            case 'east': return { tag: 'orientation', cplane: PlaneDatabase.XZ };
                            case 'west': return { tag: 'orientation', cplane: PlaneDatabase._XZ };
                        }
                    case _X:
                        switch (to) {
                            case 'north': return { tag: 'orientation', cplane: PlaneDatabase.YZ };
                            case 'south': return { tag: 'orientation', cplane: PlaneDatabase._YZ };
                            case 'east': return { tag: 'orientation', cplane: PlaneDatabase._XZ };
                            case 'west': return { tag: 'orientation', cplane: PlaneDatabase.XZ };
                        }
                }
            case _Z:
                switch (upDirection) {
                    case Y:
                        switch (to) {
                            case 'north': return { tag: 'orientation', cplane: PlaneDatabase._XZ };
                            case 'south': return { tag: 'orientation', cplane: PlaneDatabase.XZ };
                            case 'east': return { tag: 'orientation', cplane: PlaneDatabase.YZ };
                            case 'west': return { tag: 'orientation', cplane: PlaneDatabase._YZ };
                        }
                    case _Y:
                        switch (to) {
                            case 'north': return { tag: 'orientation', cplane: PlaneDatabase.XZ };
                            case 'south': return { tag: 'orientation', cplane: PlaneDatabase._XZ };
                            case 'east': return { tag: 'orientation', cplane: PlaneDatabase._YZ };
                            case 'west': return { tag: 'orientation', cplane: PlaneDatabase.YZ };
                        }
                    case X:
                        switch (to) {
                            case 'north': return { tag: 'orientation', cplane: PlaneDatabase._YZ };
                            case 'south': return { tag: 'orientation', cplane: PlaneDatabase.YZ };
                            case 'east': return { tag: 'orientation', cplane: PlaneDatabase._XZ };
                            case 'west': return { tag: 'orientation', cplane: PlaneDatabase.XZ };
                        }
                    case _X:
                        switch (to) {
                            case 'north': return { tag: 'orientation', cplane: PlaneDatabase.YZ };
                            case 'south': return { tag: 'orientation', cplane: PlaneDatabase._YZ };
                            case 'east': return { tag: 'orientation', cplane: PlaneDatabase._XZ };
                            case 'west': return { tag: 'orientation', cplane: PlaneDatabase.XZ };
                        }
                }
            default: throw new Error('Unexpected direction');
        }
    }

    navigationTargetForPointResult(pointResult: PointResult): NavigationTarget {
        const { planes } = this;
        const { point, info: { orientation, snap } } = pointResult;
        if (snap instanceof FaceSnap) {
            return this.navigationTargetForFace(snap.view);
        } else {
            const normal = Z.clone();
            normal.applyQuaternion(orientation);
            const cplane = planes.temp(new ConstructionPlaneSnap(normal, point));
            return { tag: 'cplane', cplane };
        }
    }
}

const _eye = new THREE.Vector3();
const _up = new THREE.Vector3();
