import { CompositeDisposable, Disposable } from 'event-kit';
import { render } from 'preact';
import { CreateViewspaceConstructionPlaneAtOrigin } from '../../commands/CommandLike';
import { Editor } from '../../editor/Editor';
import { ConstructionPlane, ConstructionPlaneSnap } from "../../editor/snaps/ConstructionPlaneSnap";

export default (editor: Editor) => {
    class Anon extends HTMLElement {
        private readonly disposable = new CompositeDisposable();

        constructor() {
            super();
            editor.signals.temporaryConstructionPlaneAdded.add(this.render);
            editor.signals.constructionPlanesChanged.add(this.render);
            this.disposable.add(new Disposable(() => {
                editor.signals.temporaryConstructionPlaneAdded.remove(this.render);
                editor.signals.constructionPlanesChanged.remove(this.render);
            }))
        }

        connectedCallback() { this.render() }
        disconnectedCallback() { this.disposable.dispose() }

        render = (temp: ConstructionPlane | void) => {
            render(
                <div class="p-4">
                    <h1 class="mb-4 text-xs font-bold text-neutral-100">Planes</h1>
                    <ul class="flex mb-4">
                        <li
                            class="items-center px-1 py-1 text-xs border border-neutral-500 rounded-l-md hover:text-neutral-100 bg-neutral-400 hover:bg-neutral-500"
                            onClick={e => editor.activeViewport?.navigateToSelection()}
                        >
                            <plasticity-tooltip placement="left">
                                <ul class="text-left">
                                    <li class="whitespace-nowrap">Construction plane from selection (align camera)<plasticity-keybinding class="w-10" command="viewport:navigate:selection"></plasticity-keybinding></li>
                                    <li class="whitespace-nowrap">Construction plane from selection (do not align)<plasticity-keybinding command="viewport:cplane:selection"></plasticity-keybinding></li>
                                </ul>
                            </plasticity-tooltip>
                            <plasticity-icon name="face"></plasticity-icon>
                        </li>
                        <li
                            class="items-center px-1 py-1 text-xs border border-neutral-500 rounded-r-md hover:text-neutral-100 bg-neutral-400 hover:bg-neutral-500"
                            onClick={e => editor.exec(new CreateViewspaceConstructionPlaneAtOrigin(editor))}
                        >
                            <plasticity-tooltip placement="left">
                                <ul class="text-left">
                                    <li class="whitespace-nowrap">Construction plane from camera (through origin)<plasticity-keybinding command="command:create-viewspace-construction-plane-at-origin"></plasticity-keybinding></li>
                                    <li class="whitespace-nowrap">Construction plane from camera (select distance point)<plasticity-keybinding command="command:create-viewspace-construction-plane"></plasticity-keybinding></li>
                                </ul>
                            </plasticity-tooltip>
                            <plasticity-icon name="camera"></plasticity-icon>
                        </li>
                    </ul>
                    <ul class="space-y-1">
                        {[...editor.planes.all].map(plane =>
                            <li
                                class="flex items-center justify-between px-2 py-1 rounded space-x-2 group hover:bg-neutral-700"
                                onClick={e => this.onClick(e, plane)}
                                onDblClick={e => this.onDblClick(e, plane)}
                            >
                                <plasticity-tooltip placement="left">Set plane (double-click to align camera)</plasticity-tooltip>
                                <plasticity-icon name="offset-face" class="text-accent-500"></plasticity-icon>
                                <div class="flex-grow text-xs text-neutral-300 group-hover:text-neutral-100">{plane.name}</div>
                            </li>
                        )}
                    </ul>
                </div>, this);
        }

        onClick = (event: MouseEvent, plane: ConstructionPlaneSnap) => {
            if (editor.activeViewport !== undefined) editor.activeViewport.constructionPlane = plane;
            this.render();
        }

        onDblClick = (event: MouseEvent, plane: ConstructionPlaneSnap) => {
            editor.activeViewport?.navigate(plane);
            this.render();
        }
    }
    customElements.define('plasticity-planes', Anon);
}

