import { Editor } from '../../editor/Editor';
import { createRef, render } from 'preact';

export default (editor: Editor) => {
    class Search extends HTMLElement {
        connectedCallback() {
            this.render();
        }

        disconnectedCallback() { }

        render() {
            const result = <>
                <div class="relative z-40" role="dialog" aria-modal="true">
                    <div class="fixed inset-0 bg-gray-500 bg-opacity-25 transition-opacity"></div>

                    <div class="fixed inset-0 z-10 p-4 overflow-y-auto sm:p-6 md:p-20">
                        <div class="max-w-2xl mx-auto overflow-hidden shadow-md transform divide-y divide-gray-500 divide-opacity-10 rounded-xl bg-dialog bg-opacity-80 ring-1 ring-black ring-opacity-5 backdrop-blur backdrop-filter transition-all">
                            <div class="relative">
                                <svg class="pointer-events-none absolute top-3.5 left-4 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                    <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd" />
                                </svg>
                                <input type="text" class="w-full h-12 pr-4 text-gray-800 placeholder-gray-400 bg-transparent border-0 pl-11 focus:ring-0 sm:text-sm" placeholder="Search..." role="combobox" aria-expanded="false" aria-controls="options"></input>
                            </div>

                            <ul class="p-3 overflow-y-auto max-h-96 scroll-py-3" id="options" role="listbox">
                                <li class="flex p-3 cursor-default select-none group rounded-xl" id="option-1" role="option" tabIndex={-1}>
                                    <div class="flex items-center justify-center flex-none w-10 h-10 bg-indigo-500 rounded-lg">
                                        <svg class="w-6 h-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                        </svg>
                                    </div>
                                    <div class="flex-auto ml-4">
                                        <p class="text-sm font-medium text-gray-700">Text</p>
                                        <p class="text-sm text-gray-500">Add freeform text with basic formatting options.</p>
                                    </div>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>

            </>;
            render(result, this);
        }
    }
    customElements.define('plasticity-search', Search);
}