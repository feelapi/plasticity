import { CompositeDisposable, Disposable } from 'event-kit';
import { createRef, render } from 'preact';
import Stats from 'stats.js';
import { Editor } from '../../editor/Editor';
import * as c3d from '../../kernel/kernel';
import { Measure } from './Measure';

export default (editor: Editor) => {
    class Anon extends HTMLElement {
        private readonly disposable = new CompositeDisposable();

        connectedCallback() { this.render() }
        disconnectedCallback() { this.disposable.dispose() }

        render() {
            const ref = createRef();
            render(
                <div class="p-4">
                    <h1 class="mb-4 text-xs font-bold text-neutral-100">Performance</h1>
                    <div ref={ref} class="flex flex-col w-20 space-y-1"></div>
                </div>, this);

            FrameRate: {
                const stats = Measure.get('frame-rate');
                let cont = true;
                requestAnimationFrame(function loop() {
                    stats.update();
                    if (cont) requestAnimationFrame(loop)
                });
                this.disposable.add(new Disposable(() => { cont = false }));
                ref.current.appendChild(stats.dom);
            }

            Factories: {
                const stats = Measure.get('factory-calculate');
                stats.showPanel(1);
                ref.current.appendChild(stats.dom);
            }

            Triangulation: {
                const stats = Measure.get('create-mesh');
                stats.showPanel(1);
                ref.current.appendChild(stats.dom);
            }

            KernelMemory: {
                const stats = Measure.get('kernel-memory');
                const panel = new Stats.Panel('mb', '#ff8', '#221');
                stats.addPanel(panel);
                const interval = setTimeout(async function loop() {
                    stats.begin();
                    const memory = await c3d.Session.GetMemoryUsage_async();
                    panel.update(memory.total / 1_048_576, 1_048_576);
                    stats.end();
                    setTimeout(loop, 2_000);
                }, 10_000);
                this.disposable.add(new Disposable(() => clearInterval(interval)));
                ref.current.appendChild(stats.dom);
            }
        }
    }
    customElements.define('plasticity-stats', Anon);
}

