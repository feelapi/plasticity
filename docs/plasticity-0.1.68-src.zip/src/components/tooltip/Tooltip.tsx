import { Disposable } from 'event-kit';
import { Editor } from '../../editor/Editor';
import register from 'preact-custom-element';

export default (editor: Editor) => {
    class Tooltip extends HTMLElement {
        dispose?: Disposable

        constructor() {
            super();
            // Content is hidden until shown
            this.attachShadow({ mode: 'open' });
        }

        connectedCallback() {
            this.dispose = editor.tooltips.add(this.parentElement, {
                title: this.innerHTML,
                placement: this.getAttribute('placement') ?? undefined,
                keyBindingCommand: this.getAttribute('command'),
            });
        }

        disconnectedCallback() { this.dispose!.dispose() }
    }
    customElements.define('plasticity-tooltip', Tooltip);

    function Keybinding({ command }: { command: string }) {
        const bindings = editor.keymaps.findKeyBindings({
            command: command,
        });
        if (bindings.length === 0) return <></>;
        else return <span class="keystroke"> &middot; <b>{bindings[0].keystrokes}</b> </span>;
    }
    register(Keybinding, 'plasticity-keybinding', ['command']);
}