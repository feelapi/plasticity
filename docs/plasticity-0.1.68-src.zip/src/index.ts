// Handle creating/removing shortcuts on Windows when installing/uninstalling.
if (require('electron-squirrel-startup')) { // eslint-disable-line global-require
    app.quit();
}

import { app, BrowserWindow, crashReporter, dialog, ipcMain } from 'electron';
import os from 'os';
import { buildMenu } from './Menu';
import { ConfigFiles } from './startup/ConfigFiles';
import window from 'electron-window-state';
declare const MAIN_WINDOW_WEBPACK_ENTRY: any;

crashReporter.start({
    productName: 'plasticity-parasolid',
    submitURL: 'https://submit.backtrace.io/blurbs/8ba2ca632371bdac451b9bef87af76923b0b61191ae04459f622260035ea8a3b/minidump',
    uploadToServer: true
});

export const isMac = process.platform === 'darwin'

const idealNumberOfThreads = Math.max(4, Math.min(8, os.cpus().length / 2));
process.env.UV_THREADPOOL_SIZE = `${idealNumberOfThreads}`;
process.env.APP_VERSION = app.getVersion();
// process.env['DYLD_INSERT_LIBRARIES']='/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/13.1.6/lib/darwin/libclang_rt.asan_osx_dynamic.dylib';

ConfigFiles.create();

const createWindow = (): void => {
    const mainWindowState = window({
        defaultWidth: 2048,
        defaultHeight: 1024
    });

    const mainWindow = new BrowserWindow({
        vibrancy: 'under-window',
        backgroundColor: isMac ? '#1e1c1940' : '#1e1e1c',
        visualEffectState: "followWindow",
        x: mainWindowState.x,
        y: mainWindowState.y,
        width: mainWindowState.width,
        height: mainWindowState.height,
        show: false,
        titleBarStyle: 'hiddenInset',
        frame: false,
        trafficLightPosition: { x: 22, y: 22 },
        webPreferences: {
            // preload: MAIN_WINDOW_PRELOAD_WEBPACK_ENTRY,
            nodeIntegration: true,
            contextIsolation: false,
            nodeIntegrationInWorker: true,
        }
    });
    // mainWindow.webContents.openDevTools()

    // and load the index.html of the app.
    mainWindow.loadURL(MAIN_WINDOW_WEBPACK_ENTRY);
    mainWindowState.manage(mainWindow);

    mainWindow.webContents.on('did-finish-load', () => {
        mainWindow.show();
    });

    mainWindow.webContents.on('unresponsive', () => {
        console.error("Unresponsive")
        mainWindow.webContents.forcefullyCrashRenderer();
        mainWindow.webContents.devToolsWebContents?.reload();
        mainWindow.webContents.reload();
    });

    buildMenu(mainWindow);
};

ipcMain.handle('reload', async (event, args) => {
    const window = BrowserWindow.fromWebContents(event.sender)!;
    window.webContents.forcefullyCrashRenderer();
    window.webContents.reload();
});

ipcMain.handle('show-open-dialog', async (event, args) => {
    return dialog.showOpenDialog(args);
});

ipcMain.handle('show-save-dialog', async (event, args) => {
    return dialog.showSaveDialog(args);
});

ipcMain.on('window-event', (event, eventName: String) => {
    const window = BrowserWindow.fromWebContents(event.sender)!;

    switch (eventName) {
        case 'window-minimize':
            window.minimize()
            break
        case 'window-maximize':
            window.isMaximized() ? window.unmaximize() : window.maximize()
            break
        case 'window-close':
            window.close();
            break
        case 'window-is-maximized':
            event.returnValue = window.isMaximized()
            break
        case 'window-reload':
            window.webContents.reload();
            break
        default:
            break
    }
});

app.commandLine.appendSwitch('remote-debugging-port', '9223');

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.on('ready', createWindow);

app.on('window-all-closed', () => {
    app.quit();
});

app.on('activate', () => {
    // On OS X it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (BrowserWindow.getAllWindows().length === 0) {
        createWindow();
    }
});

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and import them here.
