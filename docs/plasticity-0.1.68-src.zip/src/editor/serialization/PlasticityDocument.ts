import * as fs from 'fs';
import * as THREE from "three";
import { assertUnreachable } from '../../util/Util';
import * as visual from '../../visual_model/VisualModel';
import { Database } from '../db/Database';
import { EmptyId, EmptyInfo } from '../Empties';
import { GroupId } from '../Groups';
import { CameraMemento, ConstructionPlaneMemento, EditorOriginator, GroupMemento, MaterialMemento, Memento, MementoOriginator, NodeMemento, ViewportMemento } from "../History";
import { Images, Objects } from '../Images';
import { NodeKey, Nodes, NodeTransform } from '../Nodes';

export type C3D = {
    buffers: Uint8Array[],
    byteLength: number,
}

export class PlasticityDocument {
    static async load(json: PlasticityJSON, c3d: Buffer, into: EditorOriginator) {
        const viewports = [...into.viewports];
        for (const [i, viewport] of json.viewports.entries()) {
            if (i > viewports.length) break;
            viewports[i].restoreFromMemento(new ViewportMemento(
                new CameraMemento(
                    viewport.camera.type,
                    new THREE.Vector3().fromArray(viewport.camera.translation),
                    new THREE.Quaternion().fromArray(viewport.camera.rotation),
                    viewport.camera.zoom),
                new THREE.Vector3().fromArray(viewport.target),
                viewport.isXRay,
                new ConstructionPlaneMemento(
                    new THREE.Vector3().fromArray(viewport.constructionPlane.normal),
                    new THREE.Vector3().fromArray(viewport.constructionPlane.translation),
                )
            ));
        };
        const materials = new Map<number, { name: string, material: THREE.Material & { color: THREE.Color } }>();
        for (const [i, mat] of json.materials.entries()) {
            const name = mat.name;
            let material;
            if (mat.type === 'basic') {
                material = new THREE.MeshBasicMaterial({
                    opacity: mat.opacity,
                    depthFunc: mat.depthFunc,
                });
            } else {
                const base = mat.pbrMetallicRoughness.baseColorFactor;
                material = new THREE.MeshPhysicalMaterial({
                    color: new THREE.Color().fromArray(base),
                    opacity: base[3],
                    metalness: mat.pbrMetallicRoughness.metallicFactor,
                    roughness: mat.pbrMetallicRoughness.roughnessFactor,
                    clearcoat: mat.clearcoatFactor,
                    clearcoatRoughness: mat.clearcoatRoughnessFactor,
                    ior: mat.ior,
                    sheenColor: mat.sheenColorFactor ? new THREE.Color().fromArray(mat.sheenColorFactor) : undefined,
                    sheenRoughness: mat.sheenRoughnessFactor,
                    specularIntensity: mat.specularFactor,
                    specularColor: mat.specularColorFactor ? new THREE.Color().fromArray(mat.specularColorFactor) : undefined,
                    transmission: mat.transmissionFactor,
                    emissive: mat.emissiveFactor,
                    fog: false,
                });
            }
            materials.set(i, { name, material });
        }
        into.materials.restoreFromMemento(new MaterialMemento(json.materials.length, materials));

        let items: visual.Item[];
        Items: {
            console.time("load backup");
            const buffers = [];
            for (const item of json.items) {
                const bufferView = json.bufferViews[item.bufferView];
                const buffer = c3d.slice(bufferView.byteOffset, bufferView.byteOffset + bufferView.byteLength);
                buffers.push(buffer);
            }
            items = await into.db.deserialize(buffers);
            console.timeEnd("load backup");
        }
        Images: {
            await into.images.loadDefault();
            const buffers = await Promise.all(json.images.map(info => fs.promises.readFile(info.uri).catch(_ => undefined)));
            const existing = buffers.filter(buf => buf !== undefined) as Buffer[];
            const images = existing.map((buf, i) =>
                into.images.add(json.images[i].uri, buf)
            );
            await Promise.all(images);
        }
        Objects: {
            const buffers = await Promise.all(json.objects.map(info => fs.promises.readFile(info.uri).catch(_ => undefined)));
            const existing = buffers.filter(buf => buf !== undefined) as Buffer[];
            const objects = existing.map((buf, i) =>
                into.objects.add(json.objects[i].uri, buf)
            );
            await Promise.all(objects);
        }

        const node2material = new Map<NodeKey, number>();
        const node2name = new Map<NodeKey, string>();
        const node2transform = new Map<NodeKey, NodeTransform>();
        const hidden = new Set<NodeKey>();
        const invisible = new Set<NodeKey>();
        const unselectable = new Set<NodeKey>();
        for (const [, node] of json.nodes.entries()) {
            const key = keyForNode(node, items);
            if (node.material !== undefined) {
                node2material.set(key, node.material);
            }
            if (node.name !== undefined) {
                node2name.set(key, node.name);
            }
            if (node.translation !== undefined && node.rotation !== undefined && node.scale !== undefined) {
                const position = new THREE.Vector3().fromArray(node.translation);
                const quaternion = new THREE.Quaternion().fromArray(node.rotation);
                const scale = new THREE.Vector3().fromArray(node.scale);
                node2transform.set(key, { position, quaternion, scale });
            }
            if (node.hidden === true) hidden.add(key);
            if (node.invisible === true) invisible.add(key);
            if (node.unselectable === true) unselectable.add(key);
        }

        into.empties.deserialize(json.empties);

        const group2children: Map<GroupId, Set<NodeKey>> = new Map();
        const member2parent: Map<NodeKey, GroupId> = new Map();
        for (const [i, group] of json.groups.entries()) {
            const children = group.children.map(i => keyForNode(json.nodes[i], items));
            group2children.set(i, new Set(children));
            for (const child of children) {
                member2parent.set(child, i);
            }
        }
        into.nodes.restoreFromMemento(new NodeMemento(node2material, new Set(), new Set(), new Set(), node2name, node2transform));
        into.groups.restoreFromMemento(new GroupMemento(json.groups.length, member2parent, group2children));
        // NOTE: hidden, invisible, unselectable need to be restored via the database since they have side effects
        await into.db.restore(hidden, invisible, unselectable);
    }

    static async import(json: PlasticityJSON, c3d: Buffer, db: Database) {
        Items: {
            const buffers = [];
            for (const item of json.items) {
                const bufferView = json.bufferViews[item.bufferView];
                const buffer = c3d.slice(bufferView.byteOffset, bufferView.byteOffset + bufferView.byteLength);
                buffers.push(buffer);
            }
            const items = await db.deserialize(buffers);
        }
    }

    static serialize(memento: Memento, images: Images, objects: Objects, viewports: Iterable<MementoOriginator<ViewportMemento>>): { json: PlasticityJSON; c3d: C3D } {
        const { geo, serialize, empties, nodes, groups } = memento;

        // Viewports are not part of undo history, so we need to saveToMemento separately.
        const viewportMementos = [...viewports].map(v => v.saveToMemento());

        let i, j;
        i = 0;
        const materialId2position = new Map<number, number>();
        for (const id of memento.materials.materials.keys()) {
            materialId2position.set(id, i++);
        }
        i = 0; j = 0;
        const node2position = new Map<NodeKey, number>();
        const allNodes = [];
        const views = [];
        for (const { view } of [...geo.geometryModel.values()]) {
            const version = view.simpleName;
            if (geo.automatics.has(version)) continue;
            views.push(view);
        }
        views.sort(sort);
        const items = [];
        for (const view of views) {
            const version = view.simpleName;
            const stable = geo.version2stable.get(version)!;
            const key = Nodes.itemKey(stable);
            allNodes.push({ 'item': j++, key });
            node2position.set(key, i++);
            items.push({ version, stable });
        }
        j = 0;
        for (const id of [...groups.group2children.keys()]) {
            const key = Nodes.groupKey(id);
            allNodes.push({ 'group': j++, key });
            node2position.set(key, i++);
        }
        j = 0;
        for (const id of [...empties.id2info.keys()]) {
            const key = Nodes.emptyKey(id);
            allNodes.push({ 'empty': j++, key });
            node2position.set(key, i++);
        }

        const bufferViews: BufferViewJSON[] = [];
        const buffers = [];
        let byteOffset = 0;
        const item2bufferView = new Map<number, number>();
        j = 0;
        for (const { version, stable } of items) {
            const datum = serialize.version2data.get(version);
            if (datum === undefined) throw new Error(`No data for ${version}`);
            buffers.push(datum);
            bufferViews.push({ buffer: 0, byteOffset, byteLength: datum.byteLength });
            item2bufferView.set(stable, j++);
            byteOffset += datum.byteLength;
        }
        const c3d: C3D = { buffers, byteLength: byteOffset };
        if (byteOffset !== serialize.size) throw new Error(`Expected ${serialize.size} bytes, got ${byteOffset}`);

        const json: PlasticityJSON = {
            asset: { version: 2.0 },
            viewports: [...viewportMementos].map(viewport => (
                {
                    camera: {
                        type: viewport.camera.mode,
                        // fov: viewport.camera.fov,
                        translation: viewport.camera.position.toArray(),
                        rotation: viewport.camera.quaternion.toArray(),
                        zoom: viewport.camera.zoom,
                    } as ViewportCameraJSON,
                    target: viewport.target.toArray(),
                    constructionPlane: {
                        normal: viewport.constructionPlane.n.toArray(),
                        translation: viewport.constructionPlane.o.toArray()
                    },
                    isXRay: viewport.isXRay,
                } as ViewportJSON
            )),
            nodes: allNodes.map(nodeInfo => {
                const { key, item, group, empty } = nodeInfo;
                const materialId = nodes.node2material.get(key);
                const material = materialId !== undefined ? materialId2position.get(materialId)! : undefined;
                const name = nodes.node2name.get(key);
                const transform = nodes.node2transform.get(key);
                const invisible = nodes.invisible.has(key);
                const unselectable = nodes.unselectable.has(key);
                const hidden = nodes.hidden.has(key);
                const { tag } = Nodes.dekey(key);
                const node = {} as NodeJSON;
                if (tag === 'Item') node.item = item;
                else if (tag === 'Group') node.group = group;
                else if (tag === 'Empty') node.empty = empty;
                else if (tag === 'VirtualGroup') throw new Error('invalid condition');
                else assertUnreachable(tag);
                if (material !== undefined) node.material = material;
                if (name !== undefined) node.name = name;
                if (transform !== undefined) {
                    node.translation = transform.position.toArray();
                    node.rotation = transform.quaternion.toArray() as [number, number, number, number];
                    node.scale = transform.scale.toArray();
                }
                if (invisible === true) node.invisible = invisible;
                if (unselectable === true) node.unselectable = unselectable;
                if (hidden === true) node.hidden = hidden;
                return node;
            }),
            items: [...items].map(({ stable }) => {
                return {
                    bufferView: item2bufferView.get(stable)!,
                }
            }),
            groups: [...groups.group2children].map(([gid, children]) => {
                return {
                    children: [...children].map(child => node2position.get(child)!),
                } as GroupJSON
            }),
            empties: [...empties.id2info].map(([id, info]) => {
                const empty = {} as EmptyJSON;
                empty.type = info.tag;
                switch (info.tag) {
                    case 'Image':
                        empty.image = info.path;
                        break;
                    case 'Object':
                        empty.object = info.path;
                        break;
                    default: assertUnreachable(info);
                }
                return empty;
            }),
            images: [...images.paths].map((p) => { return { uri: p } as ImageJSON }),
            objects: [...objects.paths].map((p) => { return { uri: p } as ObjectJSON }),
            materials: [...memento.materials.materials.values()].map(mat => {
                const { name, material } = mat;
                let type: any = { type: 'basic', depthFunc: material.depthFunc };
                if (material instanceof THREE.MeshPhysicalMaterial) {
                    type = {
                        pbrMetallicRoughness: {
                            baseColorFactor: [...material.color.toArray(), material.opacity] as [number, number, number, number],
                            metallicFactor: material.metalness,
                            roughnessFactor: material.roughness,
                        },
                        emmissiveFactor: material.emissive,
                        clearcoatFactor: material.clearcoat,
                        clearcoatRoughnessFactor: material.clearcoatRoughness,
                        ior: material.ior,
                        sheenColorFactor: material.sheenColor.toArray() as [number, number, number],
                        sheenRoughnessFactor: material.sheenRoughness,
                        specularFactor: material.specularIntensity,
                        specularColorFactor: material.specularColor.toArray() as [number, number, number],
                        transmissionFactor: material.transmission,
                    }
                }
                return {
                    name: name,
                    ...type,
                    opacity: material.opacity,
                } as MaterialJSON
            }),
            bufferViews,
        };

        return { json, c3d };
    }
}

type TranslationJSON = [number, number, number];

type RotationJSON = [number, number, number, number];

interface ViewportCameraJSON {
    type: 'perspective' | 'orthographic';
    translation: TranslationJSON;
    rotation: RotationJSON;
    zoom: number;
}

interface ConstructionPlaneJSON {
    normal: TranslationJSON;
    translation: TranslationJSON;
}

interface ViewportJSON {
    camera: ViewportCameraJSON;
    target: TranslationJSON;
    constructionPlane: ConstructionPlaneJSON;
    isXRay: boolean;
}

interface GroupJSON {
    children: number[]
}

export interface EmptyJSON {
    type: EmptyInfo['tag'];
    image?: string;
    object?: string;
}

export interface ImageJSON {
    uri: string;
}

export interface ObjectJSON {
    uri: string;
}

interface NodeJSON {
    item?: visual.ItemId;
    group?: GroupId;
    empty?: EmptyId;
    material: number;
    name: string;

    translation?: [number, number, number];
    rotation?: [number, number, number, number];
    scale?: [number, number, number];

    invisible?: boolean;
    unselectable?: boolean;
    hidden?: boolean;
}

interface ItemJSON {
    bufferView: number;
}

interface MaterialJSON {
    name: string,
    type: 'physical' | 'basic';
    pbrMetallicRoughness: {
        baseColorFactor: [number, number, number, number];
        metallicFactor: number;
        roughnessFactor: number;
    };
    clearcoatFactor?: number;
    clearcoatRoughnessFactor?: number;
    ior?: number;
    sheenColorFactor?: [number, number, number];
    sheenRoughnessFactor?: number;
    specularFactor?: number;
    specularColorFactor?: [number, number, number];
    transmissionFactor?: number;
    emissiveFactor?: number;
    opacity?: number;
    depthFunc?: THREE.DepthModes;
}

export interface PlasticityJSON {
    asset: { version: number },
    viewports: ViewportJSON[];
    materials: MaterialJSON[];
    nodes: NodeJSON[];
    items: ItemJSON[];
    groups: GroupJSON[];
    empties: EmptyJSON[];
    images: ImageJSON[];
    objects: ObjectJSON[];
    bufferViews: BufferViewJSON[];
}

interface BufferViewJSON {
    buffer: number;
    byteOffset: number;
    byteLength: number;
}

function keyForNode(node: NodeJSON, items: visual.Item[]): NodeKey {
    if (node.item !== undefined) return Nodes.itemKey(items[node.item].simpleName)
    else if (node.group !== undefined) return Nodes.groupKey(node.group!);
    else if (node.empty !== undefined) return Nodes.emptyKey(node.empty!);
    else throw new Error("invalid node");
}

function sort(a: visual.Item, b: visual.Item): -1 | 0 | 1 {
    const isShell1 = a instanceof visual.Shell, isShell2 = b instanceof visual.Shell;
    if (isShell1 && isShell2) return a.simpleName < b.simpleName ? -1 : 1;
    else if (isShell1) return -1;
    else if (isShell2) return 1;
    else return a.simpleName < b.simpleName ? -1 : 1;
}