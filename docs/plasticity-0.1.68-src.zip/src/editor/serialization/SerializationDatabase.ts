import { VersionId } from "../DatabaseLike";
import { GeometryDatabase } from "../db/GeometryDatabase";
import { MementoOriginator, SerializationMemento } from "../History";

export interface ReadonlySerializationDatabase {
    get(id: VersionId): Promise<Uint8Array>;
}

export class SerializationDatabase implements ReadonlySerializationDatabase, MementoOriginator<SerializationMemento> {
    private readonly version2data: Map<VersionId, Uint8Array> = new Map();

    constructor(private readonly geo: GeometryDatabase) { }

    async get(id: VersionId): Promise<Uint8Array> {
        const data = this.version2data.get(id);
        if (data) return data
        else {
            const { model } = this.geo.lookupItemById(id);
            const data = await model.Serialize_async();
            this.version2data.set(id, data);
            return data;
        }

    }

    add(map: ReadonlyMap<VersionId, Uint8Array>) {
        for (const [id, data] of map) {
            this.version2data.set(id, data);
        }
    }

    remove(ids: VersionId[]) {
        for (const id of ids) this.version2data.delete(id);
    }

    saveToMemento(): SerializationMemento {
        return new SerializationMemento(new Map(this.version2data));
    }

    restoreFromMemento(m: SerializationMemento) {
        (this['version2data'] as SerializationDatabase['version2data']) = new Map(m.version2data) as SerializationDatabase['version2data'];
    }

    validate() {
        const { version2data, geo } = this;
        for (const [id, data] of version2data) {
            if (data.byteLength === 0) {
                console.warn(`SerializationDatabase: data for ${id} is empty`);
            }
        }
        for (const [id,] of version2data) {
            console.assert(geo.lookupItemById(id) !== undefined, `SerializationDatabase: no model for ${id}`);
        }
    }

    debug() {
        console.group("SerializationDatabase");
        console.group("version2data");
        console.table([...this.version2data]);
        console.groupEnd();
        console.groupEnd();
    }

    clear() {
        this.version2data.clear();
    }
}