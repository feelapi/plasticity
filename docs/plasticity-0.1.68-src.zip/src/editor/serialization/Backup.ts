// TODO:
// - [ ] backpressure if queuing
import * as fs from 'fs';
import * as path from 'path';
import { EditorSignals } from "../EditorSignals";
import { EditorOriginator, Memento } from "../History";
import { Chunkifier } from './Chunkifier';
import { PlasticityDocument } from './PlasticityDocument';
import { TempDir } from './TempDir';

export class Backup {
    constructor(
        private readonly originator: EditorOriginator,
        private readonly signals: EditorSignals
    ) { }

    async save(m: Memento) {
        try {
            await TempDir.create();
            const { originator } = this;
            const { json, c3d } = PlasticityDocument.serialize(m, originator.images, originator.objects, originator.viewports);
            const chunkifier = new Chunkifier('plasticity', 1, json, c3d);
            const data = chunkifier.serialize();
            const tempFilePath = this.makeTempFilePath(), backupFilePath = this.backupFilePath;
            await fs.promises.writeFile(tempFilePath, data);
            await fs.promises.rename(tempFilePath, backupFilePath);
        } catch (e) {
            console.warn(e);
        }
    }

    async load() {
        const path = this.backupFilePath;
        const data = await fs.promises.readFile(path);
        const { json, buffer } = Chunkifier.load(data);
        this.originator.clear();
        await PlasticityDocument.load(json, buffer, this.originator);
        if (process.env.NODE_ENV === 'development') {
            // this.originator.debug();
            // this.originator.validate();
        }
        this.signals.backupLoaded.dispatch();
    }

    async clear() {
        try {
            await TempDir.clear();
            await TempDir.create();
        } catch (e) {
            console.warn(e);
        }
    }

    makeTempFilePath() {
        return path.join(TempDir.dir, `backup.${process.env.NODE_ENV ?? 'env'}.${process.hrtime.bigint()}.plasticity`);
    }

    get backupFilePath() {
        return path.join(TempDir.dir, `backup.${process.env.NODE_ENV ?? 'env'}.plasticity`);
    }
}