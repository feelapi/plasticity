import { C3D, PlasticityJSON } from "./PlasticityDocument";

export class Chunkifier {
    constructor(
        private readonly magic: string,
        private readonly version: number,
        private readonly json: PlasticityJSON,
        private readonly c3d: C3D,
    ) {
    }

    serialize(): (Buffer | Uint8Array)[] {
        const { magic, version, json, c3d } = this;
        const string = Buffer.from(JSON.stringify(json), 'utf-8');
        const header = Buffer.alloc(10 + 4 + 4);
        const length = header.length + 4 + 4 + string.length + 4 + 4 + c3d.byteLength;
        let offset = 0;
        header.write(magic, 'ascii'); offset += 10;
        header.writeUint32LE(version, offset); offset += 4;
        header.writeUint32LE(length, offset); offset += 4;

        const jsonHeader = Buffer.alloc(4 + 4);
        JSON: {
            let offset = 0;
            jsonHeader.writeUint32LE(string.length, offset); offset += 4;
            jsonHeader.writeUint32LE(__JSON__, offset); offset += 4;
        }
        const c3dHeader = Buffer.alloc(4 + 4);
        c3d: {
            let offset = 0;
            c3dHeader.writeUint32LE(c3d.byteLength, offset); offset += 4;
            c3dHeader.writeUint32LE(__BIN__, offset); offset += 4;
        }
        return [header, jsonHeader, string, c3dHeader, ...c3d.buffers];
    }

    static load(from: Buffer): { json: PlasticityJSON; buffer: Buffer; } {
        let offset = 0;
        const magic = from.toString('utf-8', offset, 10); offset += 10;
        if (magic !== 'plasticity') throw new Error('invalid file header');
        const version = from.readUint32LE(offset); offset += 4;
        if (version != 1) throw new Error('invalid version');
        const length = from.readUint32LE(offset); offset += 4;
        if (from.length != length) throw new Error(`invalid buffer length: got ${from.length} but expected ${length}`);
        let json: PlasticityJSON;
        JSON: {
            const length = from.readUint32LE(offset); offset += 4;
            const magic = from.readUint32LE(offset); offset += 4;
            if (magic !== 0x4e4f534a) throw new Error('invalid magic number');
            const string = from.toString('utf-8', offset, offset + length); offset += length;
            json = JSON.parse(string) as PlasticityJSON;
        }
        let c3d: Buffer;
        c3d: {
            const length = from.readUint32LE(offset); offset += 4;
            const magic = from.readUint32LE(offset); offset += 4;
            if (magic !== 0x004e4942) throw new Error('invalid magic number');
            c3d = from.slice(offset, offset + length); offset += length;
        }
        return { json, buffer: c3d };
    }
}


export interface BufferJSON {

}

export interface BufferViewJSON {

}

export interface HasBuffers {
    buffers: BufferJSON[];
    bufferViews: BufferJSON[];
}

const __JSON__ = 0x4e4f534a;
const __BIN__ = 0x004e4942;
