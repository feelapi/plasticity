import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';
import { ReadonlyGeometryDatabase } from "../DatabaseLike";

type Guide = { edgeId: c3d.EdgeId, param: number }[];
type LoftId = number;
type Loft = Readonly<{ id: LoftId; guides: Guide[], profiles: c3d.WireId[] }>;

let counter: LoftId = 0;

export class LoftManager {
    private readonly wire2loft = new Map<c3d.WireId, LoftId>();
    private readonly loft2wire = new Map<LoftId, c3d.WireId[]>();
    private readonly id2loft = new Map<LoftId, Loft>();

    constructor(private readonly geo: ReadonlyGeometryDatabase) {

    }

    async create(profiles: visual.SpaceInstance[]) {
        const models = profiles.map(p => this.geo.lookup(p));

        const coll = await c3d.ProfileCollection.Create_async(models, []);
        const vertss = coll.GetPathVertices();
        const guides: Guide[] = [];
        for (const verts of vertss) {
            const vs = verts.GetVertices();
            const guide: Guide = [];
            for (const v of vs) {
                const { out } = v.GetEdges();
                if (out.Size() !== 1) throw new Error('Invalid profile');
                const originals = out.GetOriginals();
                const edge = originals.Get(0);
                const param = 0;
                guide.push({ edgeId: edge.Id(), param });
            }
            guides.push(guide);
        }

        const loft: Loft = { id: counter++, guides, profiles: models.map(m => m.Id()) };
        this.id2loft.set(loft.id, loft);

        const array: c3d.WireId[] = [];
        this.loft2wire.set(loft.id, array);
        for (const model of models) {
            this.wire2loft.set(model.Id(), loft.id);
            array.push(model.Id());
        }
    }

    makeCurves(loftId: LoftId) {
        const loft = this.id2loft.get(loftId);
        if (!loft) throw new Error('Invalid loft id');
        const { guides } = loft;
        const wires = [];
        for (const guide of guides) {
            const points = [];
            for (const step of guide) {
                const { edgeId, param } = step;
                console.log("processing edge id", edgeId);
                const edge = new c3d.Edge(edgeId);
                const point = edge.GetPoint(param);
                points.push(point);
            }
            const options = new c3d.CreateSplineOptions(closed);
            options.Through = true;
            const spline = c3d.BCurve.CreateSpline(points, options);
            const wire = c3d.Wire.CreateFromCurves([spline]);
            wires.push(wire);
        }
        return wires;
    }

    update() {
        const all = [];
        for (const loft of this.id2loft.values()) {
            const { id } = loft;
            const wires = this.makeCurves(id);
            all.push(...wires);
        }
        return all;
    }
}