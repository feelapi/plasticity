import * as fs from 'fs';
import * as THREE from 'three';
import { Database } from './db/Database';
import { EditorSignals } from './EditorSignals';
import { EditorOriginator, History } from './History';
import { Images, Objects } from "./Images";
import { Nodes } from './Nodes';
import { PlaneDatabase } from './PlaneDatabase';
import { Chunkifier } from './serialization/Chunkifier';
import { PlasticityDocument } from './serialization/PlasticityDocument';
import { ConstructionPlane } from './snaps/ConstructionPlaneSnap';

export const supportedExtensions = ['stp', 'step', 'plasticity', 'igs', 'iges', 'sat', 'x_t', 'x_b', 'png', 'jpg', 'jpeg'];

export class ImporterExporter {
    constructor(
        private readonly originator: EditorOriginator,
        private readonly db: Database,
        private readonly nodes: Nodes,
        private readonly images: Images,
        private readonly objects: Objects,
        private readonly history: History,
        private readonly signals: EditorSignals,
    ) { }

    async open(filePath: string) {
        const data = await fs.promises.readFile(filePath);
        const { json, buffer: c3d } = Chunkifier.load(data);
        this.originator.clear();
        this.signals.historyChanged.dispatch();
        await PlasticityDocument.load(json, c3d, this.originator);
        this.signals.backupLoaded.dispatch();
        if (process.env.NODE_ENV === 'development') {
            // this.originator.debug();
            // this.originator.validate();
        }
    }

    async import(filePaths: string[], cplane?: ConstructionPlane) {
        const { db, images, objects, nodes } = this;
        for (const filePath of filePaths) {
            if (/\.(png|jpg|jpeg)$/i.test(filePath)) {
                if (cplane === undefined) cplane = PlaneDatabase.XY;
                const data = await fs.promises.readFile(filePath);
                await images.add(filePath, data);
                const empty = await db.addEmpty(filePath);
                const transform = { position: cplane.p.clone(), quaternion: cplane.orientation.clone(), scale: new THREE.Vector3(1, 1, 1) };
                nodes.setTransform(empty, transform);
            } else if (/\.(obj)$/i.test(filePath)) {
                const data = await fs.promises.readFile(filePath);
                await objects.add(filePath, data);
                const empty = await db.addEmpty(filePath);
                const transform = { position: new THREE.Vector3(0, 0, 0), quaternion: new THREE.Quaternion(), scale: new THREE.Vector3(1, 1, 1) };
                nodes.setTransform(empty, transform);
            } else if (/\.plasticity$/i.test(filePath)) {
                const data = await fs.promises.readFile(filePath);
                const { json, buffer: c3d } = Chunkifier.load(data);
                await PlasticityDocument.import(json, c3d, db);
            }
        }
    }

    async export(filePath: string) {
        if (/\.plasticity$/.test(filePath!)) {
            const memento = this.history.current.memento;
            const { json, c3d } = PlasticityDocument.serialize(memento, this.images, this.objects, this.originator.viewports);
            const chunkifier = new Chunkifier('plasticity', 1, json, c3d);
            const buffers = chunkifier.serialize();
            return fs.promises.writeFile(filePath, buffers);
        } else if (/\.c3d$/.test(filePath!)) {
            // const model = this.db.saveToMemento().model;
            // const data = await c3d.Writer.WriteItems_async(model);
            // await fs.promises.writeFile(filePath, data.memory);
        } else {
            // const model = this.db.saveToMemento().model;
            // await c3d.Conversion.ExportIntoFile_async(model, filePath!);
        }
    }
}