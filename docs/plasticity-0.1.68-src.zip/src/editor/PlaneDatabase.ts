import { origin, X, Y, Z, _X, _Y, _Z } from "../util/Constants";
import { EditorSignals } from "./EditorSignals";
import { ConstructionPlaneSnap, FaceConstructionPlaneSnap } from "./snaps/ConstructionPlaneSnap";

export class PlaneDatabase {
    private counter = 0;

    static readonly XY = new ConstructionPlaneSnap(Z, origin, undefined, "XY");
    static readonly YZ = new ConstructionPlaneSnap(X, origin, undefined, "YZ");
    static readonly XZ = new ConstructionPlaneSnap(Y, origin, undefined, "XZ");
    static readonly _XY = new ConstructionPlaneSnap(_Z, origin, undefined, "XY");
    static readonly _YZ = new ConstructionPlaneSnap(_X, origin, undefined, "YZ");
    static readonly _XZ = new ConstructionPlaneSnap(_Y, origin, undefined, "XZ");

    private readonly _all = new Set<ConstructionPlaneSnap>([PlaneDatabase.XY, PlaneDatabase.YZ, PlaneDatabase.XZ]);

    constructor(private readonly signals: EditorSignals) { }

    get all(): Iterable<ConstructionPlaneSnap> { return this._all }

    temp<T extends ConstructionPlaneSnap | FaceConstructionPlaneSnap>(plane: T): T {
        this.signals.temporaryConstructionPlaneAdded.dispatch(plane);
        return plane;
    }

    add(plane: ConstructionPlaneSnap | FaceConstructionPlaneSnap) {
        this._all.add(new ConstructionPlaneSnap(plane.n, plane.p, undefined, `Custom plane ${this.counter++}`));
        this.signals.constructionPlanesChanged.dispatch();
    }
}