import KeymapManager from "atom-keymap-plasticity";
import { ipcRenderer, IpcRendererEvent } from "electron";
import { CompositeDisposable, Disposable } from "event-kit";
import * as THREE from "three";
import Command from '../command/Command';
import { CommandExecutor } from "../command/CommandExecutor";
import { GeometryFactory } from "../command/GeometryFactory";
import { GizmoMaterialDatabase } from "../command/GizmoMaterials";
import { SelectionCommandManager } from "../command/SelectionCommandManager";
import { ExportCommand, ImportCommand } from "../commands/CommandLike";
import CommandRegistry from "../components/atom/CommandRegistry";
import TooltipManager from "../components/atom/tooltip-manager";
import { Outliner } from "../components/outliner/Outliner";
import KeyboardEventManager from "../components/viewport/KeyboardEventManager";
import { Viewport } from "../components/viewport/Viewport";
import { ChangeSelectionExecutor } from "../selection/ChangeSelectionExecutor";
import { SelectionCommandRegistrar } from "../selection/CommandRegistrar";
import { SelectionDatabase } from "../selection/SelectionDatabase";
import { ConfigFiles, OrbitMode } from "../startup/ConfigFiles";
import defaultSettings from '../startup/default-settings';
import defaultTheme from '../startup/default-theme';
import { Z } from "../util/Constants";
import { Helpers } from "../util/Helpers";
import { GConstructor } from "../util/Util";
import { RenderedSceneBuilder } from "../visual_model/RenderedSceneBuilder";
import { Clipboard } from "./Clipboard";
import { CrossPointDatabase } from "./curves/CrossPointDatabase";
import { PlanarCurveDatabase } from "./curves/PlanarCurveDatabase";
import { SketchManager } from "./curves/SketchManager";
import { Database } from "./db/Database";
import { GeometryDatabase } from "./db/GeometryDatabase";
import { EditorSignals } from "./EditorSignals";
import { Empties } from "./Empties";
import { Groups } from "./Groups";
import { EditorOriginator, History } from "./History";
import { Images, Objects } from "./Images";
import { ImporterExporter, supportedExtensions } from "./ImporterExporter";
import LayerManager from "./LayerManager";
import { BasicMaterialDatabase } from "./MaterialDatabase";
import { IncrementalMeshCreator } from "./MeshCreator";
import { Nodes } from "./Nodes";
import { PlaneDatabase } from "./PlaneDatabase";
import { LoftManager } from "./profiles/LoftManager";
import { Scene } from "./Scene";
import { Backup } from "./serialization/Backup";
import { SerializationDatabase } from "./serialization/SerializationDatabase";
import { SnapManager } from './snaps/SnapManager';
import { TextureLoader } from "./TextureLoader";
import { ViewBuilder } from "./ViewBuilder";

THREE.Object3D.DefaultUp = Z;

export class Editor {
    private readonly disposable = new CompositeDisposable();
    dispose() { this.disposable.dispose() }

    readonly textures = new TextureLoader();
    readonly viewports: Set<Viewport> = new Set();
    readonly outliners: Set<Outliner> = new Set();

    readonly signals = new EditorSignals();
    readonly registry = new CommandRegistry();
    readonly registrar = new SelectionCommandRegistrar(this);

    readonly materials = new BasicMaterialDatabase(this.signals);
    readonly gizmos = new GizmoMaterialDatabase(this.signals, this.styles);
    readonly meshes = new IncrementalMeshCreator();
    readonly geo = new GeometryDatabase();
    readonly views = new ViewBuilder(this.meshes, this.materials, this.settings['ViewBuilder']);
    readonly groups = new Groups(this.signals);
    readonly images = new Images();
    readonly objects = new Objects();
    readonly empties = new Empties(this.images, this.objects);
    readonly nodes = new Nodes(this.geo, this.groups, this.empties, this.materials, this.signals);
    readonly scene = new Scene(this.geo, this.groups, this.nodes, this.empties, this.materials);
    readonly crosses = new CrossPointDatabase();
    readonly curves = new PlanarCurveDatabase(this.geo);
    readonly snaps = new SnapManager(this.geo, this.curves, this.crosses);
    readonly sketches = new SketchManager();
    readonly selection = new SelectionDatabase(this.geo, this.scene, this.materials, this.signals);
    readonly serialize = new SerializationDatabase(this.geo);
    readonly highlight = new RenderedSceneBuilder(this.scene, this.textures, this.selection, this.crosses, this.styles, this.signals);
    readonly lofts = new LoftManager(this.geo);
    readonly db = new Database(this.meshes, this.views, this.geo, this.serialize, this.empties, this.groups, this.nodes, this.scene, this.materials, this.highlight, this.selection, this.crosses, this.curves, this.snaps, this.sketches, this.lofts, this.viewports, this.signals);

    readonly originator = new EditorOriginator(this.db, this.geo, this.serialize, this.empties, this.scene, this.groups, this.nodes, this.materials, this.selection.selected, this.selection.hovered, this.snaps, this.crosses, this.curves, this.viewports, this.images, this.objects, this.meshes, this.sketches);
    readonly backup = new Backup(this.originator, this.signals);
    readonly history = new History(this.originator, this.backup, this.signals);

    readonly keymaps = new KeymapManager();
    readonly tooltips = new TooltipManager({ keymapManager: this.keymaps, viewRegistry: null });
    readonly layers = new LayerManager(this.selection, this.signals);
    readonly helpers: Helpers = new Helpers(this.signals, this.styles);
    readonly changeSelection = new ChangeSelectionExecutor(this.selection, this.db, this.sketches, this.curves, this.scene, this.signals);
    readonly commandForSelection = new SelectionCommandManager(this);
    readonly executor = new CommandExecutor(this);
    readonly keyboard = new KeyboardEventManager(this.keymaps);
    readonly importer = new ImporterExporter(this.originator, this.db, this.nodes, this.images, this.objects, this.history, this.signals);
    readonly planes = new PlaneDatabase(this.signals);
    readonly clipboard = new Clipboard(this);
    readonly factoryCache = new Map<GConstructor<GeometryFactory<any, any, any>>, any>();

    windowLoaded = false;

    constructor(readonly settings = defaultSettings, readonly styles = defaultTheme) {
        window.addEventListener('resize', this.onWindowResize, false);
        window.addEventListener('load', this.onWindowLoad, false);

        this.signals.viewportActivated.add(this.onViewportActivated);

        this.disposable.add(new Disposable(() => window.removeEventListener('resize', this.onWindowResize)));
        this.disposable.add(new Disposable(() => window.removeEventListener('load', this.onWindowLoad)));

        this.registry.attach(window);
        this.keymaps.defaultTarget = document.body;

        this.registerCommands();
    }

    async exec(command: Command) { await this.executor.exec(command, 'interrupt') }
    async enqueue(command: Command) { await this.executor.exec(command, 'queue') }
    async skip(command: Command) { await this.executor.exec(command, 'skip-if-active') }

    onWindowResize = () => {
        this.signals.windowResized.dispatch();
    }

    onWindowLoad = () => {
        this.windowLoaded = true;
        this.signals.windowLoaded.dispatch();
    }

    private _activeViewport?: Viewport;
    get activeViewport() { return this._activeViewport ?? [...this.viewports][0] }
    onViewportActivated = (v: Viewport) => {
        this._activeViewport = v;
    }

    clear = async () => {
        await this.backup.clear();
        ipcRenderer.invoke('reload');
    }

    async open() {
        const { filePaths } = await ipcRenderer.invoke('show-open-dialog', {
            properties: ['openFile'],
            filters: [
                { name: 'Plasticity files', extensions: ['plasticity'] },
            ]
        });
        const filePath = filePaths[0];
        this.executor.cancelActiveCommand();
        await this.importer.open(filePath);
        this.history.initialize();
        await this.backup.save(this.history.current.memento);
    }

    async import(files?: string[]) {
        if (files === undefined) {
            const { filePaths } = await ipcRenderer.invoke('show-open-dialog', {
                properties: ['openFile', 'multiSelections'],
                filters: [
                    { name: 'All supported', extensions: supportedExtensions },
                    { name: 'STEP files', extensions: ['stp', 'step'] },
                    { name: 'IGES files', extensions: ['igs', 'iges'] },
                    { name: 'SAT files', extensions: ['sat'] },
                    { name: 'Parasolid files', extensions: ['x_t', 'x_b'] },
                    { name: 'Plasticity files', extensions: ['plasticity'] },
                    { name: 'Image files', extensions: ['png', 'jpg', 'jpeg'] }
                ]
            });
            files = filePaths;
        }
        const command = new ImportCommand(this);
        command.filePaths = files!;
        this.exec(command);
    }


    async export() {
        const { canceled, filePath } = await ipcRenderer.invoke('show-save-dialog', {
            filters: [
                { name: 'Plasticity files', extensions: ['plasticity'] },
                // { name: 'STEP files', extensions: ['stp', 'step'] },
                // { name: 'IGES files', extensions: ['igs', 'iges'] },
                // { name: 'SAT files', extensions: ['sat'] },
                // { name: 'Parasolid files', extensions: ['x_t', 'x_b'] },
                { name: 'Wavefront OBJ', extensions: ['obj'] },
            ]
        });
        if (canceled) return;
        if (/\.obj$/.test(filePath!)) {
            const command = new ExportCommand(this);
            command.filePath = filePath!;
            this.exec(command);
        } else {
            this.importer.export(filePath!);
        }
    }

    async undo(): Promise<void> {
        this.executor.cancelActiveCommand();
        this.history.undo();
        return this.executor.enqueueDefaultCommand();
    }

    async redo(): Promise<void> {
        this.executor.cancelActiveCommand();
        this.history.redo();
        return this.executor.enqueueDefaultCommand();
    }

    private registerCommands() {
        const d = this.registry.add(document.body, {
            'file:new': () => this.clear(),
            'file:open': () => this.open(),
            'file:import': () => this.import(),
            'file:save-as': () => this.export(),
            'edit:undo': () => this.undo(),
            'edit:redo': () => this.redo(),
            'edit:copy': () => this.clipboard.copy(),
            'edit:paste': () => this.clipboard.paste(),
            'edit:repeat-last-command': () => this.executor.repeatLastCommand(),
            'settings:orbit-controls:set-default': () => updateOrbitControls('default'),
            'settings:orbit-controls:set-blender': () => updateOrbitControls('blender'),
            'settings:orbit-controls:set-maya': () => updateOrbitControls('maya'),
            'settings:orbit-controls:set-moi3d': () => updateOrbitControls('moi3d'),
            'settings:orbit-controls:set-3dsmax': () => updateOrbitControls('3dsmax'),
            'settings:orbit-controls:set-touchpad': () => updateOrbitControls('touchpad'),
            'noop': () => { },
        });
        ipcRenderer.on('menu-command', this.command);
        this.disposable.add(new Disposable(() => {
            ipcRenderer.removeListener('menu-command', this.command);
        }));
        this.disposable.add(d);
        this.disposable.add(this.registrar.register(this.registry));
    }

    private command = (event: IpcRendererEvent, ...args: any[]) => {
        const element = this.activeViewport?.domElement ?? document.body;
        element.dispatchEvent(new CustomEvent(args[0], { bubbles: true }));
    }

    async loadBackup() {
        try {
            await this.backup.load();
        } finally {
            this.history.initialize();
        }
    }

    debug() {
        this.originator.debug();
        this.executor.debug();
    }
}

export function updateOrbitControls(mode: OrbitMode): void {
    ConfigFiles.updateOrbitControls(mode);
    ipcRenderer.send('window-event', 'window-reload');
}
