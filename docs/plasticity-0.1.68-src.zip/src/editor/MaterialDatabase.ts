import * as THREE from "three";
import { LineMaterial } from 'three/examples/jsm/lines/LineMaterial.js';
import * as c3d from '../kernel/kernel';
import { BetterRaycastingPointsMaterial } from "../visual_model/BetterRaycastingPoints";
import { face_unhighlighted_matcap, region_unhighlighted, surface_unhighlighted_matcap } from "../visual_model/RenderedSceneBuilder";
import { EditorSignals } from "./EditorSignals";
import { MaterialMemento, MementoOriginator } from "./History";

export default interface MaterialDatabase extends MementoOriginator<MaterialMemento> {
    line(o?: c3d.Wire): LineMaterial;
    hull(): THREE.LineBasicMaterial;
    lineDashed(): LineMaterial;
    point(o?: c3d.Body): THREE.Material;
    surface(o?: c3d.Body): THREE.Material;
    region(): THREE.Material;
    controlPoint(): BetterRaycastingPointsMaterial;
    occludedControlPoint(): BetterRaycastingPointsMaterial;
    mesh(): THREE.Material;

    add(name: string, material: THREE.Material): number;
    get(id: number): THREE.Material & { color: THREE.Color };
}

const line = new LineMaterial({ color: 0x0, linewidth: 1.4 });
line.polygonOffset = true;
line.polygonOffsetFactor = -1;
line.polygonOffsetUnits = -1;

const previewLine = new LineMaterial({ color: 0x000088, linewidth: 0.7 });
const line_dashed = new LineMaterial({ color: 0x0, linewidth: 0.3, dashed: true, dashSize: 0.09, gapSize: 0.03 });
line_dashed.depthFunc = THREE.AlwaysDepth;
line_dashed.defines.USE_DASH = "";

const hull = new THREE.LineBasicMaterial();
hull.depthTest = false;
hull.opacity = 0.25;
hull.transparent = true;

const point = new BetterRaycastingPointsMaterial({ color: 0x888888 });
const surface = surface_unhighlighted_matcap;
const mesh = face_unhighlighted_matcap;
const region = region_unhighlighted;
const controlPoint = new BetterRaycastingPointsMaterial({ size: 8, sizeAttenuation: false, vertexColors: true });
const occludedControlPoint = controlPoint.clone();
occludedControlPoint.depthFunc = THREE.AlwaysDepth;
occludedControlPoint.transparent = true;
occludedControlPoint.opacity = 0.5;

const startCounter = 1; // start > 0 since GetStyle() returns 0 for undefined.

export class BasicMaterialDatabase implements MaterialDatabase, MementoOriginator<MaterialMemento> {
    private readonly materials = new Map<number, { name: string, material: THREE.Material & { color: THREE.Color } }>();
    private readonly lines = [line, line_dashed, previewLine];
    private counter = startCounter;

    constructor(signals: EditorSignals) {
        signals.renderPrepared.add(({ resolution }) => this.setResolution(resolution));
    }

    line(o?: c3d.Wire): LineMaterial {
        // if (o === undefined) return line;
        // if (o.GetStyle() === 0) return line;
        // if (o.GetStyle() === 1) return previewLine;
        return line;
    }

    lineDashed(): LineMaterial {
        return line_dashed;
    }

    hull(): THREE.LineBasicMaterial {
        return hull;
    }

    // A quirk of three.js is that to render lines with any thickness, you need to use
    // a LineMaterial whose resolution must be set before each render
    private setResolution(size: THREE.Vector2) {
        for (const material of this.lines) {
            material.resolution.copy(size);
        }
        controlPoint.resolution.copy(size);
        occludedControlPoint.resolution.copy(size);
    }

    point(o?: c3d.Body): THREE.Material {
        return point;
    }

    surface(o?: c3d.Body) {
        return surface;
    }

    mesh() {
        return mesh;
    }

    add(name: string, material: THREE.MeshPhysicalMaterial): number {
        const id = this.counter++;
        this.materials.set(id, { name, material });
        return id;
    }

    get(id: number): THREE.Material & { color: THREE.Color } {
        return this.materials.get(id)!.material;
    }

    region(): THREE.Material { return region }
    controlPoint(): BetterRaycastingPointsMaterial { return controlPoint }
    occludedControlPoint(): BetterRaycastingPointsMaterial { return occludedControlPoint }

    saveToMemento(): MaterialMemento {
        // TODO: deep copy
        return new MaterialMemento(this.counter, new Map(this.materials));
    }

    restoreFromMemento(m: MaterialMemento): void {
        (this.counter as BasicMaterialDatabase['counter']) = m.counter;
        (this.materials as BasicMaterialDatabase['materials']) = new Map(m.materials);
    }

    clear() {
        this.counter = startCounter;
        this.materials.clear();
    }

    validate(): void { }
    debug(): void { }

}

export class CurvePreviewMaterialDatabase extends BasicMaterialDatabase {
    line(o?: c3d.Wire): LineMaterial {
        return previewLine;
    }
}