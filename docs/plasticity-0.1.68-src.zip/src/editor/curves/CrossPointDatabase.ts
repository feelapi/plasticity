// TODO:
// - [ ] When a vertex crosses two or more items, we can prematurely remove() it from the database when one of items is removed.
// CrossInfo.vertices needs to be Map<c3d.VertexId, number>.
import * as THREE from 'three';
import * as c3d from '../../kernel/kernel';
import * as visual from '../../visual_model/VisualModel';
import { ReadonlyGeometryDatabase } from '../DatabaseLike';
import { ComputeCrossPoints } from '../db/transforms/ComputeCrossPoints';
import { UpdateCrossPoints } from '../db/transforms/UpdateCrossPoints';
import { CrossPointMemento, MementoOriginator } from '../History';

export interface ReadonlyCrossPointDatabase {
    get crosses(): ReadonlySet<CrossPoint>;
    saveToMemento(): CrossPointMemento;
    get all(): Set<c3d.WireId>;
    modelId2viewId(id: c3d.WireId): visual.SpaceInstanceId | undefined;
    isTemporaryName(name: number): boolean;
    get disabled(): ReadonlySet<c3d.WireId>;
}

export type CrossInfo = {
    points: ReadonlySet<CrossPoint>;
    vertices: ReadonlySet<c3d.VertexId>;
}

type MutableCrossInfo = {
    points: Set<CrossPoint>;
    vertices: Set<c3d.VertexId>;
}

export type Curve2Touched = Map<visual.SpaceInstanceId, ReadonlySet<visual.SpaceInstanceId>>;
export type Curve2Cross = Map<visual.SpaceInstanceId, CrossInfo>;

export type MutableCurve2Touched = Map<visual.SpaceInstanceId, Set<visual.SpaceInstanceId>>;
export type MutableCurve2Cross = Map<visual.SpaceInstanceId, MutableCrossInfo>;

export type Model2View = Map<c3d.WireId, visual.SpaceInstanceId>;
type View2Model = Map<visual.SpaceInstanceId, c3d.WireId>;

export class CrossPointDatabase implements ReadonlyCrossPointDatabase, MementoOriginator<CrossPointMemento> {
    private readonly curve2touched: Curve2Touched = new Map();
    private readonly curve2cross: Curve2Cross = new Map();
    private readonly model2view: Model2View = new Map();
    private readonly view2model: View2Model = new Map();

    private counter = -1;
    makeTemporaryName() { return this.counter-- }
    isTemporaryName(name: number) { return name < 0 }

    private _crosses: Set<CrossPoint> = new Set();
    get crosses(): ReadonlySet<CrossPoint> { return this._crosses }

    copy(other: ReadonlyCrossPointDatabase) {
        (this._disabled as CrossPointDatabase['_disabled']) = new Set(other.disabled);
        this.restoreFromMemento(other.saveToMemento());
    }

    add(simpleName: visual.SpaceInstanceId, curve: c3d.Wire, addCurve2cross: Curve2Cross, addCurve2touched: Curve2Touched, addCrosses: Set<CrossPoint>) {
        const { curve2touched, curve2cross } = this;
        const entityId = curve.Id();
        this.model2view.set(entityId, simpleName);
        this.view2model.set(simpleName, entityId);
        for (const [name, { points, vertices }] of addCurve2cross) {
            const info = curve2cross.get(name);
            let existingPoints: Set<CrossPoint>, existingVertices: Set<c3d.VertexId>;
            if (info === undefined) {
                existingPoints = new Set();
                existingVertices = new Set();
            } else {
                existingPoints = new Set(info.points);
                existingVertices = new Set(info.vertices);
            }
            for (const c of points) existingPoints.add(c);
            for (const v of vertices) existingVertices.add(v);
            curve2cross.set(name, { points: existingPoints, vertices: existingVertices });
        }
        for (const [name, touched] of addCurve2touched) {
            const existing = new Set(curve2touched.get(name));
            for (const c of touched) existing.add(c);
            curve2touched.set(name, existing);
        }
        for (const c of addCrosses) this._crosses.add(c);
    }

    remove(simpleName: visual.SpaceInstanceId) {
        const { curve2touched, curve2cross, model2view, view2model, _crosses: allCrosses } = this;
        const entityId = view2model.get(simpleName)!;
        view2model.delete(simpleName);
        model2view.delete(entityId);

        const touched = curve2touched.get(simpleName)!;
        if (touched === undefined) return;
        curve2touched.delete(simpleName);

        const { points: theseCrosses, vertices: theseVertices } = curve2cross.get(simpleName)!;
        curve2cross.delete(simpleName);

        for (const touchee of touched) {
            const { points, vertices } = curve2cross.get(touchee)!;
            const toucheeCrosses = new Set(points);
            const toucheeVertices = new Set(vertices);
            for (const cross of theseCrosses) {
                toucheeCrosses.delete(cross);
                if (cross.on1.bodyName === touchee) {
                    toucheeVertices.delete(cross.on1.vertexId);
                } else {
                    toucheeVertices.delete(cross.on2.vertexId);
                }
            }
            curve2cross.set(touchee, { points: toucheeCrosses, vertices: toucheeVertices });

            const touches = curve2touched.get(touchee);
            if (touches === undefined) throw new Error('Invalid precondition');
            const without = new Set(touches)
            without.delete(simpleName);
            curve2touched.set(touchee, without);
        }
        for (const cross of theseCrosses) {
            allCrosses.delete(cross);
        }
    }

    lookup(curve: visual.SpaceInstance) {
        const { curve2cross } = this;
        const simpleName = curve.simpleName;
        const crosses = curve2cross.get(simpleName);
        return crosses;
    }

    modelId2viewId(id: c3d.WireId): visual.SpaceInstanceId | undefined {
        return this.model2view.get(id);
    }

    private readonly _disabled = new Set<c3d.WireId>();
    get disabled(): ReadonlySet<c3d.WireId> { return this._disabled }
    disable(items: visual.Item[]) {
        for (const item of items) {
            if (!(item instanceof visual.SpaceInstance)) return;
            const { view2model, _disabled: disabled } = this;
            const entityId = view2model.get(item.simpleName);
            if (entityId === undefined) throw new Error('Invalid precondition');
            disabled.add(entityId);
        }
    }
    clearDisabled() { this._disabled.clear() }

    get all(): Set<c3d.WireId> {
        const all = new Set([...this.model2view.keys()]);
        for (const id of this._disabled) all.delete(id);
        return all;
    }

    validate() {
        console.assert(this.curve2touched.size === this.curve2cross.size, "maps should have same size", [...this.curve2touched], [...this.curve2cross]);
        console.assert(this.curve2cross.size === this.model2view.size, "maps should have same size", [...this.curve2cross], [...this.model2view]);
        console.assert(this.curve2cross.size === this.view2model.size, "maps should have same size", [...this.curve2cross], [...this.view2model]);
        if (this.curve2touched.size === 0) {
            console.assert(this._crosses.size === 0, "crosses should have be empty", this._crosses);
        }
        for (const [name, touched] of this.curve2touched) {
            for (const touch of touched) {
                console.assert(this.curve2touched.get(touch)!.has(name), "touched should be symmetric", name, touch);
            }
        }
        for (const [name, { points, vertices }] of this.curve2cross) {
            for (const cross of points) {
                console.assert(this.curve2cross.get(cross.on1.bodyName)!.points.has(cross), "crosses should be symmetric", name, cross);
                console.assert(this.curve2cross.get(cross.on2.bodyName)!.points.has(cross), "crosses should be symmetric", name, cross);
            }
        }
    }

    private _snapshot = this.saveToMemento();
    createSnapshot() { this._snapshot = this.saveToMemento() }

    saveToMemento(): CrossPointMemento {
        return new CrossPointMemento(
            this.counter,
            new Map(this.curve2touched),
            new Map(this.curve2cross),
            new Map(this.model2view),
            new Map(this.view2model),
            new Set(this.crosses),
        );
    }

    restoreFromMemento(m: CrossPointMemento) {
        this.counter = m.counter;
        (this.curve2touched as CrossPointDatabase['curve2touched']) = new Map(m.curve2touched);
        (this.curve2cross as CrossPointDatabase['curve2cross']) = new Map(m.name2cross);
        (this.model2view as CrossPointDatabase['model2view']) = new Map(m.model2view);
        (this.view2model as CrossPointDatabase['view2model']) = new Map(m.view2model);
        (this._crosses as CrossPointDatabase['crosses']) = new Set(m.crosses);
    }

    clear() {
        this.restoreFromMemento(this._snapshot);
    }

    debug() { }
}

export type CrossPointId = number;

export class TemporaryCrossPointDatabase implements Omit<ReadonlyCrossPointDatabase, 'saveToMemento'> {
    readonly sync: CrossPointDatabase;
    private readonly computeCrossPoints: ComputeCrossPoints;
    private readonly updateCrossPoints: UpdateCrossPoints;

    makeTemporaryName() { return this.sync.makeTemporaryName() }
    isTemporaryName(name: visual.SpaceInstanceId) { return this.sync.isTemporaryName(name) }

    get crosses(): ReadonlySet<CrossPoint> { return this.sync.crosses }
    get all(): Set<c3d.WireId> { return this.sync.all }
    modelId2viewId(id: number): number | undefined {
        return this.sync.modelId2viewId(id);
    }

    constructor(geo: ReadonlyGeometryDatabase, other?: ReadonlyCrossPointDatabase) {
        this.sync = new CrossPointDatabase();
        if (other !== undefined) this.sync.copy(other);
        this.computeCrossPoints = new ComputeCrossPoints(geo, this.sync);
        this.updateCrossPoints = new UpdateCrossPoints(this.sync);
    }

    async add(simpleName: visual.SpaceInstanceId, curve: c3d.Wire): Promise<Set<CrossPoint>> {
        const { computeCrossPoints, updateCrossPoints } = this;
        const txn = { added: [{ model: curve, view: { simpleName } }], deleted: [], replaced: [], hidden: [], unhidden: [], visible: [], invisible: [], };
        const computeCrossPointResults = await computeCrossPoints.calculate(txn);
        const updateCrossPointResults = updateCrossPoints.calculate(computeCrossPointResults);
        return computeCrossPointResults.added[0].crosses;
    }

    async remove(simpleName: visual.SpaceInstanceId) {
        const txn = { added: [], deleted: [{ view: { simpleName } }] };
        this.updateCrossPoints.calculate(txn);
    }

    validate() { this.sync.validate() }
    clear() { this.sync.clear() }
    disable(items: visual.Item[]) { this.sync.disable(items) }
    get disabled() { return this.sync.disabled }
    clearDisabled() { this.sync.clearDisabled() }
}


export class PointOnCurve {
    constructor(
        readonly bodyName: visual.SpaceInstanceId,
        readonly edgeId: c3d.EdgeId,
        readonly t: number,
        readonly vertexId: c3d.VertexId,
    ) { }
}


export class CrossPoint {
    constructor(
        readonly position: THREE.Vector3,
        readonly on1: PointOnCurve,
        readonly on2: PointOnCurve
    ) { }
}