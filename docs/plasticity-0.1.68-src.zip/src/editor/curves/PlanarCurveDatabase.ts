import * as c3d from '../../kernel/kernel';
import { isSameBasis } from '../../util/Conversion';
import * as visual from "../../visual_model/VisualModel";
import { ReadonlyGeometryDatabase } from "../DatabaseLike";
import { CurveMemento, MementoOriginator } from '../History';

export interface ReadonlyPlanarCurveDatabase {
    getInfoForCurve(curve: c3d.WireId): CurveInfo | undefined;
    getSketchForBasis(basis: c3d.Basis): c3d.Sketch | undefined;
    planarizeAndNormalize(inst: c3d.Wire): c3d.Basis | undefined;
    planarizeAndNormalize(inst: c3d.Face): c3d.Basis | undefined;
    getCoplanarCurves(curve: visual.SpaceInstance): visual.SpaceInstance[];
    lookup(instance: visual.SpaceInstance | visual.SpaceInstanceId): { basis: c3d.Basis, fragments: visual.SpaceInstance[] };
    lookup(face: visual.Face): { basis: c3d.Basis, wires: c3d.Wire[] };
    get faces(): ReadonlyMap<c3d.FaceId, FaceInfo>;
}

export type Curve2Info = Map<c3d.WireId, CurveInfo>;
export type Face2Info = Map<c3d.FaceId, FaceInfo>;

export class PlanarCurveDatabase implements ReadonlyPlanarCurveDatabase, MementoOriginator<CurveMemento> {
    private readonly curve2info: Curve2Info = new Map();
    private readonly basis2sketch = new Map<c3d.Basis, c3d.Sketch>();
    private readonly sketch2basis = new Map<c3d.SketchId, c3d.Basis>();
    private readonly basis2curve = new Map<c3d.Basis, Set<c3d.WireId>>();
    private readonly face2info = new Map<c3d.FaceId, FaceInfo>();

    constructor(
        private readonly db: ReadonlyGeometryDatabase,
    ) {
        const xy = new c3d.Basis(c3d.Origin, c3d.Z, c3d.X);
        const yz = new c3d.Basis(c3d.Origin, c3d.X, c3d.Y);
        const zx = new c3d.Basis(c3d.Origin, c3d.Y, c3d.Z);
        const sketchXY = new c3d.Sketch(xy);
        const sketchYZ = new c3d.Sketch(yz);
        const sketchZX = new c3d.Sketch(zx);
        this.basis2sketch.set(xy, sketchXY);
        this.basis2sketch.set(yz, sketchYZ);
        this.basis2sketch.set(zx, sketchZX);
        this.sketch2basis.set(sketchXY.Id(), xy);
        this.sketch2basis.set(sketchYZ.Id(), yz);
        this.sketch2basis.set(sketchZX.Id(), zx);
    }

    lookup(face: visual.Face): { basis: c3d.Basis, wires: c3d.Wire[] };
    lookup(instance: visual.SpaceInstance | visual.SpaceInstanceId): { basis: c3d.Basis, fragments: visual.SpaceInstance[] };
    lookup(instance: visual.SpaceInstance | visual.SpaceInstanceId | visual.Face): { basis: c3d.Basis, fragments?: visual.SpaceInstance[] } {
        if (instance instanceof visual.Face) {
            const model = this.db.lookupTopologyItem(instance);
            const info = this.face2info.get(model.Id());
            if (info === undefined) throw new Error("invalid precondition");
            return { ...info };
        } else {
            const simpleName = instance instanceof visual.SpaceInstance ? instance.simpleName : instance;
            const model = this.db.lookupItemById(simpleName).model;
            const info = this.curve2info.get(model.Id());
            if (info === undefined) throw new Error("invalid precondition");
            const fragments = info.fragments.map(id => this.db.lookupItemById(id).view) as visual.SpaceInstance[];
            return {
                basis: info.basis,
                fragments
            };
        }
    }

    get faces(): ReadonlyMap<c3d.FaceId, FaceInfo> {
        return new Map(this.face2info);
    }

    getInfoForCurve(curve: c3d.WireId): CurveInfo | undefined {
        return this.curve2info.get(curve);
    }

    getSketchForBasis(basis: c3d.Basis, normalize = false): c3d.Sketch | undefined {
        if (!normalize) {
            return this.basis2sketch.get(basis);
        } else {
            const normalized = normalizeBasis(basis, this.basis2sketch, this.sketch2basis);
            return normalized === undefined ? undefined : this.basis2sketch.get(normalized);
        }
    }

    getCurvesOnSketch(sketchId: c3d.SketchId): visual.SpaceInstance[] {
        const basis = this.sketch2basis.get(sketchId);
        if (basis === undefined) throw new Error("invalid precondition");
        const wireIds = this.basis2curve.get(basis);
        if (wireIds === undefined) throw new Error("invalid precondition");
        const result = [];
        for (const wireId of wireIds) {
            const info = this.curve2info.get(wireId);
            if (info === undefined) throw new Error("invalid precondition");
            const simpleName = info.simpleName;
            const item = this.db.lookupItemById(simpleName);
            result.push(item.view as visual.SpaceInstance);
        }
        return result;
    }

    getCoplanarCurves(curve: visual.SpaceInstance): visual.SpaceInstance[] {
        const model = this.db.lookupItemById(curve.simpleName).model;
        const info = this.curve2info.get(model.Id());
        if (info === undefined) return [];
        const curves = this.basis2curve.get(info.basis);
        if (curves === undefined) throw new Error("invalid precondition");
        const result = [];
        for (const id of curves) {
            const simpleName = this.curve2info.get(id)?.simpleName;
            if (simpleName === undefined) throw new Error("invalid precondition");
            const item = this.db.lookupItemById(simpleName);
            result.push(item.view as visual.SpaceInstance);
        }
        return result;
    }

    add(curve2info: Curve2Info, face2info: Face2Info) {
        for (const [id, info] of curve2info) {
            this.curve2info.set(id, info);
            this.basis2curve.get(info.basis)?.add(id) ?? this.basis2curve.set(info.basis, new Set([id]));
        }
        for (const [id, info] of face2info) {
            this.face2info.set(id, info);
        }
    }

    remove(wires: c3d.WireId[], faces: c3d.FaceId[]) {
        const { curve2info, basis2curve, face2info } = this;
        for (const id of faces) {
            face2info.delete(id);
        }
        for (const id of wires) {
            const info = curve2info.get(id);
            if (info === undefined) continue;

            curve2info.delete(id);
            const curves = basis2curve.get(info.basis);
            if (curves === undefined) continue;
            curves.delete(id);
        }
    }

    planarizeAndNormalize(inst: c3d.Face): c3d.Basis | undefined;
    planarizeAndNormalize(inst: c3d.Wire): c3d.Basis | undefined;
    planarizeAndNormalize(inst: c3d.Wire | c3d.Face): c3d.Basis | undefined {
        if (inst instanceof c3d.Wire) {
            let basis = inst.FindPlanarBasis();
            if (basis === undefined) basis = this.findBestBasisForLinearCurve(inst);
            if (basis === undefined) return;

            return normalizeBasis(basis, this.basis2sketch, this.sketch2basis);
        } else {
            const origin = inst.GetPoint(0.5, 0.5);
            const { normal, uDirection } = inst.EvalBasis(0.5, 0.5);
            const basis = new c3d.Basis(origin, normal, uDirection);
            return normalizeBasis(basis, this.basis2sketch, this.sketch2basis);
        }
    }

    private findBestBasisForLinearCurve(inst: c3d.Wire): c3d.Basis | undefined {
        if (inst.FindLinearAxis() === undefined) return;

        const points = inst.GetVertices().GetPoints();
        for (const [candidate, _] of this.basis2sketch) {
            if (points.AllLieOnPlane(candidate)) return candidate;
        }
        return undefined;
    }

    saveToMemento(): CurveMemento {
        const basis2sketchCopy = copyBasis2Sketch(this.basis2sketch);
        const basis2curveCopy = copyBasis2Curve(this.basis2curve);
        return new CurveMemento(
            new Map(this.curve2info),
            basis2sketchCopy,
            new Map(basis2curveCopy),
            new Map(this.sketch2basis),
            new Map(this.face2info));
    }

    restoreFromMemento(m: CurveMemento) {
        (this.curve2info as PlanarCurveDatabase['curve2info']) = new Map(m.curve2info);
        (this.basis2sketch as PlanarCurveDatabase['basis2sketch']) = copyBasis2Sketch(m.basis2sketch);
        (this.basis2curve as PlanarCurveDatabase['basis2curve']) = copyBasis2Curve(m.basis2curve);
        (this.sketch2basis as PlanarCurveDatabase['sketch2basis']) = new Map(m.sketch2basis);
        (this.face2info as PlanarCurveDatabase['face2info']) = new Map(m.face2info);
    }

    clear() {
        this.curve2info.clear();
        this.basis2sketch.clear();
        this.basis2curve.clear();
        this.sketch2basis.clear();
        this.face2info.clear();
    }

    validate() {
        for (const [id, info] of this.curve2info) {
            console.assert(this.db.lookupItemById(info.simpleName) !== undefined, "curve is in database", info.simpleName);
            const wires = this.basis2curve.get(info.basis)!;
            console.assert(wires !== undefined, "basis is in database", info.basis);
            console.assert(wires.has(id), "wire is in basis", id);
        }
        for (const [sketchId, basis] of this.sketch2basis) {
            console.assert(this.basis2sketch.get(basis)!.Id() === sketchId, "basis is in sketch", basis);
        }
        for (const [basis, sketch] of this.basis2sketch) {
            console.assert(this.sketch2basis.get(sketch.Id()) === basis, "sketch is in basis", sketch);
        }
        for (const [basis, wires] of this.basis2curve) {
            for (const wire of wires) {
                console.assert(this.curve2info.get(wire)!.basis === basis, "wire is in basis", wire);
            }
        }
    }

    debug() {
        const { curve2info } = this;
        console.group("PlanarCurveDatabase");
        console.group("curve2info");
        console.table([...curve2info].map(([number, info]) => { return { number, simpleName: info.simpleName } }));
        console.groupEnd();
        console.groupEnd();
    }
}

export class CurveInfo {
    constructor(readonly simpleName: visual.SpaceInstanceId, readonly basis: c3d.Basis, readonly fragments: ReadonlyArray<visual.SpaceInstanceId> = []) { }
}

export class FaceInfo {
    constructor(readonly basis: c3d.Basis, readonly wires: ReadonlyArray<c3d.Wire>) { }
}

export class MutableCurveInfo extends CurveInfo {
    constructor(simpleName: visual.SpaceInstanceId, basis: c3d.Basis, public fragments: number[]) {
        super(simpleName, basis, fragments)
    }
}

export class MutableFaceInfo extends FaceInfo {
    constructor(basis: c3d.Basis, public wires: c3d.Wire[]) {
        super(basis, wires)
    }
}

function normalizeBasis(basis: c3d.Basis, candidates: Map<c3d.Basis, c3d.Sketch>, sketch2basis: Map<c3d.SketchId, c3d.Basis>): c3d.Basis | undefined {
    let bestExistingBasis;
    for (const [candidate,] of candidates) {
        if (isSameBasis(basis, candidate)) {
            bestExistingBasis = candidate;
            break;
        }
    }
    if (bestExistingBasis === undefined) {
        const sketch = new c3d.Sketch(basis);
        candidates.set(basis, sketch);
        sketch2basis.set(sketch.Id(), basis);
        bestExistingBasis = basis;
    }

    return bestExistingBasis;
}

function copyBasis2Sketch(basis2sketch: ReadonlyMap<c3d.Basis, c3d.Sketch>): Map<c3d.Basis, c3d.Sketch> {
    const basis2sketchCopy = new Map<c3d.Basis, c3d.Sketch>();
    for (const [key, value] of basis2sketch) {
        const clone = value.Clone();
        basis2sketchCopy.set(key, clone);
    }
    return basis2sketchCopy;
}

function copyBasis2Curve(basis2curve: ReadonlyMap<c3d.Basis, ReadonlySet<c3d.WireId>>): Map<c3d.Basis, Set<c3d.WireId>> {
    const basis2curveCopy = new Map<c3d.Basis, Set<c3d.WireId>>();
    for (const [key, value] of basis2curve) {
        basis2curveCopy.set(key, new Set(value));
    }
    return basis2curveCopy;
}