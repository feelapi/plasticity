import * as c3d from '../../kernel/kernel';
import * as visual from "../../visual_model/VisualModel";
import { MementoOriginator, SketchMemento } from '../History';

export interface ReadonlySketchManager {
    getIslands(sketch: c3d.Sketch): readonly visual.SketchIsland[] | undefined;
    getArchipelago(island: visual.SketchIsland): readonly visual.SketchIsland[];
    getSketchId(island: visual.SketchIsland): c3d.SketchId;
}

export class SketchManager implements ReadonlySketchManager, MementoOriginator<SketchMemento> {
    private readonly sketch2info = new Map<c3d.SketchId, readonly visual.SketchIsland[]>();
    private readonly island2sketch = new Map<visual.SketchIslandId, c3d.SketchId>();

    getIslands(sketch: c3d.Sketch): readonly visual.SketchIsland[] | undefined {
        return this.sketch2info.get(sketch.Id());
    }

    getSketchId(island: visual.SketchIsland): c3d.SketchId {
        const id = this.island2sketch.get(island.simpleName);
        if (id === undefined) throw new Error('island not found');
        return id;
    }

    getArchipelago(island: visual.SketchIsland): readonly visual.SketchIsland[] {
        const sketchId = this.island2sketch.get(island.simpleName);
        if (sketchId === undefined) throw new Error('island not found');
        const islands = this.sketch2info.get(sketchId);
        if (islands === undefined) throw new Error('island not found');
        return islands;
    }

    update(map: ReadonlyMap<c3d.Sketch, visual.SketchIsland[]>) {
        for (const [sketch, info] of map) {
            const sketchId = sketch.Id();
            const old = this.sketch2info.get(sketchId);
            if (old !== undefined) {
                for (const island of old) {
                    this.island2sketch.delete(island.simpleName);
                }
            }

            this.sketch2info.set(sketchId, info);
            for (const island of info) {
                this.island2sketch.set(island.simpleName, sketchId);
            }
        }
    }

    saveToMemento(): SketchMemento {
        return new SketchMemento(
            new Map(this.sketch2info),
            new Map(this.island2sketch));
    }

    restoreFromMemento(m: SketchMemento) {
        (this.sketch2info as SketchManager['sketch2info']) = new Map(m.sketch2info);
        (this.island2sketch as SketchManager['island2sketch']) = new Map(m.island2sketch);
    }

    validate() { }
    debug() { }

    clear() { this.sketch2info.clear(); this.island2sketch.clear(); }
}

