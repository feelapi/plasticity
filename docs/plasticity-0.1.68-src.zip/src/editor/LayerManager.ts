import * as THREE from "three";
import { HasSelectedAndHovered } from "../selection/SelectionDatabase";
import { SelectionMode } from "../selection/SelectionModeSet";
import * as visual from '../visual_model/VisualModel';
import { EditorSignals } from './EditorSignals';

export default class LayerManager {
    private readonly _visible = new THREE.Layers();
    get visible(): ReadonlyLayers { return this._visible }

    private readonly _intersectable = new THREE.Layers();
    get intersectable(): ReadonlyLayers { return this._intersectable }

    constructor(readonly selection: HasSelectedAndHovered, private readonly signals: EditorSignals) {
        const { _visible, _intersectable } = this;
        signals.selectionModeChanged.add(this.selectionModeChanged);

        _visible.disableAll();
        _intersectable.disableAll();

        _visible.enableAll();
        // When traversing scene graph, there are intermediary objects with a Default layer; so we need this on
        // TODO: consider redesigning this so everything has a non-default layer
        _intersectable.enable(visual.Layers.Default);

        this.hideFragments();
    }

    refresh() {
        this.selectionModeChanged(this.selection.mode);
    }

    showFragments() {
        const { _visible, _intersectable } = this;

        _visible.enable(visual.Layers.Curve);
        _intersectable.disable(visual.Layers.Curve);

        _visible.enable(visual.Layers.CurveFragment);
        if (this.isXray) _visible.enable(visual.Layers.CurveFragment_XRay);
        _intersectable.enable(visual.Layers.CurveFragment);
        if (this.isXray) _intersectable.enable(visual.Layers.CurveFragment_XRay);

        // _visible.disable(visual.Layers.CurveSegment);
        // _visible.disable(visual.Layers.CurveSegment_XRay);
        _visible.disable(visual.Layers.Vertex);
        _visible.disable(visual.Layers.Vertex_XRay);
        _visible.disable(visual.Layers.CV);
        _visible.disable(visual.Layers.CV_XRay);

        _intersectable.disable(visual.Layers.CurveSegment);
        _intersectable.disable(visual.Layers.CurveSegment_XRay);
        _intersectable.disable(visual.Layers.Region);
        _intersectable.disable(visual.Layers.Face);
        _intersectable.disable(visual.Layers.Vertex);
        _intersectable.disable(visual.Layers.Vertex_XRay);
        _intersectable.disable(visual.Layers.CV);
        _intersectable.disable(visual.Layers.CV_XRay);

        this.signals.visibleLayersChanged.dispatch();
    }

    hideFragments() {
        const { _visible, _intersectable } = this;

        _visible.disable(visual.Layers.CurveFragment);
        _visible.disable(visual.Layers.CurveFragment_XRay);

        _intersectable.disable(visual.Layers.CurveFragment);
        _intersectable.disable(visual.Layers.CurveFragment_XRay);

        // _visible.enable(visual.Layers.CurveSegment);
        // if (this.isXray) _visible.enable(visual.Layers.CurveSegment_XRay);

        this.refresh();
    }

    private selectionModeChanged = (mode: Set<SelectionMode>) => {
        const { _visible, _intersectable, isXray } = this;

        if (mode.has(SelectionMode.Solid)) {
            _intersectable.enable(visual.Layers.Solid);
            _intersectable.enable(visual.Layers.Face);
        } else {
            _intersectable.disable(visual.Layers.Solid);
        }

        if (mode.has(SelectionMode.Sheet)) {
            _intersectable.enable(visual.Layers.Sheet);
            _intersectable.enable(visual.Layers.Face);
        } else {
            _intersectable.disable(visual.Layers.Sheet);
        }

        if (mode.has(SelectionMode.Empty)) {
            _intersectable.enable(visual.Layers.Empty);
        } else {
            _intersectable.disable(visual.Layers.Empty);
        }

        this.isShowingFaces = this.isShowingFaces;
        this.isShowingEdges = this.isShowingEdges;

        if (mode.has(SelectionMode.Curve) || mode.has(SelectionMode.CurveSegment)) {
            _intersectable.enable(visual.Layers.Curve);
            _intersectable.enable(visual.Layers.CurveSegment);
            if (isXray) _intersectable.enable(visual.Layers.CurveSegment_XRay);
        } else {
            _intersectable.disable(visual.Layers.Curve);
            _intersectable.disable(visual.Layers.CurveSegment);
            _intersectable.disable(visual.Layers.CurveSegment_XRay);
        }
        if (isXray) _visible.enable(visual.Layers.CurveSegment_XRay);
        else _visible.disable(visual.Layers.CurveSegment_XRay);

        this.isShowingControlPoints = mode.has(SelectionMode.Vertex);
    }

    private _isXray = true;
    get isXray() { return this._isXray }

    set isXray(isXray: boolean) {
        this._isXray = isXray;
        this.refresh();
    }

    toggleXRay() { this.isXray = !this.isXray }

    showControlPoints() {
        this.isShowingControlPoints = true;
        this.signals.visibleLayersChanged.dispatch();
    }

    hideControlPoints() {
        this.isShowingControlPoints = false;
        this.signals.visibleLayersChanged.dispatch();
    }

    set isShowingControlPoints(show: boolean) {
        const { _visible, _intersectable, selection: { mode } } = this;
        if (show) {
            _intersectable.enable(visual.Layers.Curve);
            _visible.enable(visual.Layers.Vertex);
            _visible.enable(visual.Layers.CV);
            if (mode.has(SelectionMode.Vertex)) {
                _intersectable.enable(visual.Layers.Vertex);
                _intersectable.enable(visual.Layers.CV);
            }
            if (this.isXray) {
                _visible.enable(visual.Layers.Vertex_XRay);
                _visible.enable(visual.Layers.CV_XRay);
                if (mode.has(SelectionMode.Vertex)) {
                    _intersectable.enable(visual.Layers.Vertex_XRay);
                    _intersectable.enable(visual.Layers.CV_XRay);
                }
            } else {
                _visible.disable(visual.Layers.Vertex_XRay);
                _visible.disable(visual.Layers.CV_XRay);
                _intersectable.disable(visual.Layers.Vertex_XRay);
                _intersectable.disable(visual.Layers.CV_XRay);
            }
        } else {
            _visible.disable(visual.Layers.Vertex);
            _visible.disable(visual.Layers.Vertex_XRay);
            _visible.disable(visual.Layers.CV);
            _visible.disable(visual.Layers.CV_XRay);
            _intersectable.disable(visual.Layers.Vertex);
            _intersectable.disable(visual.Layers.Vertex_XRay);
            _intersectable.disable(visual.Layers.CV);
            _intersectable.disable(visual.Layers.CV_XRay);
        }
    }

    private _isShowingEdges = true;
    get isShowingEdges() { return this._isShowingEdges }

    private _isShowingFaces = true;
    get isShowingFaces() { return this._isShowingFaces }

    set isShowingEdges(show: boolean) {
        this._isShowingEdges = show;
        const { _visible, _intersectable, signals, isXray, selection: { mode } } = this;
        if (show) {
            _visible.enable(visual.Layers.Edge);
            if (mode.has(SelectionMode.CurveEdge)) {
                _intersectable.enable(visual.Layers.Solid);
                _intersectable.enable(visual.Layers.Sheet);
                _intersectable.enable(visual.Layers.Edge);
            } else {
                _intersectable.disable(visual.Layers.Edge);
            }
            if (isXray) {
                _visible.enable(visual.Layers.CurveEdge_XRay);
                if (mode.has(SelectionMode.CurveEdge)) _intersectable.enable(visual.Layers.CurveEdge_XRay);
            } else {
                _visible.disable(visual.Layers.CurveEdge_XRay);
                _intersectable.disable(visual.Layers.CurveEdge_XRay);
            }
        } else {
            _visible.disable(visual.Layers.Edge);
            _intersectable.disable(visual.Layers.Edge);
            _visible.disable(visual.Layers.CurveEdge_XRay);
            _intersectable.disable(visual.Layers.CurveEdge_XRay);
        }
        signals.visibleLayersChanged.dispatch();
    }

    set isShowingFaces(show: boolean) {
        this._isShowingFaces = show;
        const { _visible, _intersectable, signals, selection: { mode } } = this;
        if (show) {
            _visible.enable(visual.Layers.Face);
            _visible.enable(visual.Layers.Region);

            // NOTE: when faces are shown, face intersection is ALWAYS enabled, because even if it isn't
            // selectable, it's used for Occlusion in GeometryPicker raycasting
            _intersectable.enable(visual.Layers.Sheet);
            _intersectable.enable(visual.Layers.Solid);
            _intersectable.enable(visual.Layers.Face);
            _intersectable.enable(visual.Layers.Region);
        } else {
            _visible.disable(visual.Layers.Face);
            _intersectable.disable(visual.Layers.Face);
            _intersectable.disable(visual.Layers.Region);
        }
        signals.visibleLayersChanged.dispatch();
    }
}

export interface ReadonlyLayers {
    mask: number;
    test(layers: THREE.Layers): boolean;
    isEnabled(channel: number): boolean;
}
