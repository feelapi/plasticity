import * as cmd from "../command/Command";
import { MoveCommand } from "../commands/translate/TransformCommand";
import * as c3d from "../kernel/kernel";
import { TransactionBuilder } from "./db/DatabaseTransaction";

interface ClipboardItem {
    name: string;
    items: c3d.Body[];
}

export class Clipboard {
    private _all: ClipboardItem[] = [];
    get all(): readonly ClipboardItem[] { return this._all }
    private readonly partition = new c3d.Partition();

    constructor(private readonly editor: cmd.EditorLike) { }

    copy() {
        const { editor: { signals, selection }, partition } = this;
        const solids = selection.selected.solids.models;
        const curves = selection.selected.curves.models;
        const items = [...solids, ...curves].map(i => partition.Copy(i));

        let solidString = "";
        if (solids.length === 1) solidString = `1 solid`;
        else if (solids.length > 1) solidString = `${solids.length} solids`;

        let curveString = undefined;
        if (curves.length === 1) curveString = `1 curve`;
        else if (solids.length > 1) curveString = `${solids.length} solids`;

        const name = [solidString, curveString].filter(x => !!x).join(',');

        this._all.push({ name, items });
        signals.clipboardChanged.dispatch();
    }

    paste(index = this.all.length - 1) {
        const { all } = this;
        if (index < 0) throw new Error("invalid index");
        if (index > this._all.length) throw new Error("invalid index");
        const copied = all[index];
        const command = new PasteCommand(this.editor, copied);
        this.editor.exec(command);
    }

    clear() {
        this._all = [];
        this.editor.signals.clipboardChanged.dispatch();
    }
}

export class PasteCommand extends cmd.CommandLike {
    constructor(
        editor: cmd.EditorLike,
        private readonly item: ClipboardItem
    ) { super(editor) }

    async execute(): Promise<void> {
        const { editor: { db, geo, selection: { selected } } } = this;

        const dups = this.item.items.map(item => item.CopyTo(c3d.Session.GetCurrentPartition()));
        const txn = new TransactionBuilder(geo);
        txn.add(...dups);
        const result = await db.commit(txn);

        selected.removeAll();
        const items = result.added.map(i => i.view);
        selected.add(items);

        const command = new MoveCommand(this.editor);
        command.agent = 'automatic';
        this.editor.exec(command);
    }
}
