import * as THREE from "three";
import { OBJLoader } from 'three/examples/jsm/loaders/OBJLoader';
import iconPng from '../img/default/icon.png';
import { Delay } from "../util/SequentialExecutor";

export class Images {
    private readonly path2texture = new Map<string, THREE.Texture>();

    async add(filePath: string, data: Buffer): Promise<THREE.Texture> {
        const delay = new Delay<THREE.Texture>();
        const manager = new THREE.LoadingManager();
        const objectURLs: string[] = [];
        const blob = new Blob([data]);
        manager.setURLModifier(url => {
            url = URL.createObjectURL(blob);
            objectURLs.push(url);
            return url;
        });
        new THREE.TextureLoader(manager).load(filePath, texture => {
            for (const url of objectURLs) URL.revokeObjectURL(url);
            delay.resolve(texture);
        }, undefined, error => {
            delay.reject(error);
        });
        const texture = await delay.promise;
        texture.encoding = THREE.sRGBEncoding;
        this.path2texture.set(filePath, texture);
        return texture;
    }

    get(filePath: string): THREE.Texture | undefined {
        return this.path2texture.get(filePath);
    }

    clear() {
        this.path2texture.clear();
    }

    get paths() {
        return this.path2texture.keys();
    }

    private _default: THREE.Texture | undefined;
    async loadDefault() {
        if (this._default !== undefined) return;
        const delay = new Delay<THREE.Texture>();
        new THREE.TextureLoader().load(iconPng, texture => {
            texture.encoding = THREE.sRGBEncoding;
            delay.resolve(texture);
            this._default = texture;
        });
        await delay.promise;
    }

    get default() { return this._default! }
}

export class Objects {
    private readonly path2object = new Map<string, THREE.Group>();

    async add(filePath: string, data: Buffer): Promise<THREE.Group> {
        const delay = new Delay<THREE.Group>();
        const manager = new THREE.LoadingManager();
        const objectURLs: string[] = [];
        const blob = new Blob([data]);
        manager.setURLModifier(url => {
            url = URL.createObjectURL(blob);
            objectURLs.push(url);
            return url;
        });
        const loader = new OBJLoader(manager);
        loader.load(filePath, object => {
            for (const url of objectURLs) URL.revokeObjectURL(url);
            delay.resolve(object);
        }, undefined, error => {
            delay.reject(error);
        });
        const object = await delay.promise;
        this.path2object.set(filePath, object);
        return object;
    }

    get(filePath: string): THREE.Group | undefined {
        return this.path2object.get(filePath);
    }

    clear() {
        this.path2object.clear();
    }

    get paths() {
        return this.path2object.keys();
    }

    get default() {
        return defaultObject;
    }
}

const sphereGeometry = new THREE.SphereGeometry(1, 32, 32);
const defaultMesh = new THREE.Mesh(sphereGeometry);
const defaultObject = new THREE.Group();
defaultObject.add(defaultMesh);