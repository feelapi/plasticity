import { Disposable } from "event-kit";
import { Measure } from "../components/stats/Measure";
import * as c3d from '../kernel/kernel';
import { Settings } from "../startup/ConfigFiles";
import * as visual from '../visual_model/VisualModel';
import * as build from '../visual_model/VisualModelBuilder';
import { MaterialOverride } from './DatabaseLike';
import MaterialDatabase from './MaterialDatabase';
import { MeshCreator, MeshLike } from './MeshCreator';

export type PrecisionMode = 'real' | 'temporary' | 'phantom';

export type Builder = build.WireBodyBuilder | build.SheetBuilder | build.PlaneInstanceBuilder | build.SolidBuilder;

export type ViewBuilderSpec = {
    model: c3d.Body;
    name: visual.ItemId;
    material?: MaterialOverride;
};

export class ViewBuilder {
    private readonly low = new c3d.FacetOptions(this.settings.low.curveChordTolerance, this.settings.low.curveChordAngle, this.settings.low.surfacePlaneTolerance, this.settings.low.surfacePlaneAngle);
    private readonly medium = new c3d.FacetOptions(this.settings.medium.curveChordTolerance, this.settings.medium.curveChordAngle, this.settings.medium.surfacePlaneTolerance, this.settings.medium.surfacePlaneAngle);
    private readonly high = new c3d.FacetOptions(this.settings.high.curveChordTolerance, this.settings.high.curveChordAngle, this.settings.high.surfacePlaneTolerance, this.settings.high.surfacePlaneAngle);
    private readonly temporary = new c3d.FacetOptions(this.medium.CurveChordTolerance, this.medium.CurveChordAngle, this.medium.SurfacePlaneTolerance, this.medium.SurfacePlaneAngle);
    private readonly phantom = new c3d.FacetOptions(this.medium.CurveChordTolerance, this.medium.CurveChordAngle, this.medium.SurfacePlaneTolerance, this.medium.SurfacePlaneAngle);

    private readonly mesh_precision_distance: [c3d.FacetOptions, number][] = [[this.low, 1_000_000], [this.medium, 1]];
    private readonly region_precision_distance: [c3d.FacetOptions, number][] = [[this.medium, 1]];
    private readonly wire_precision_distance: [c3d.FacetOptions, number][] = [[this.high, 1]];
    private readonly temporary_precision_distance: [c3d.FacetOptions, number][] = [[this.temporary, 1]];
    private readonly phantom_precision_distance: [c3d.FacetOptions, number][] = [[this.phantom, 1]];

    constructor(
        private readonly meshCreator: MeshCreator,
        private readonly materials: MaterialDatabase,
        private readonly settings: Settings['ViewBuilder'],
    ) {
        const { low, temporary, phantom } = this;
        low.Incremental = c3d.FacetIncrementalType.None;
        temporary.Incremental = c3d.FacetIncrementalType.Yes;
        phantom.Incremental = c3d.FacetIncrementalType.None;
    }

    async build(specs: ViewBuilderSpec[], precisionMode: PrecisionMode): Promise<visual.Item[]> {
        const model2lods = await this.lods(specs, precisionMode);

        const results: visual.Item[] = [];
        for (const { model, name, material } of specs) {
            const lods = model2lods.get(model)!;
            const builder = await this.meshes(model, name, lods, material);
            performance.mark('begin-build');
            const view = builder.build(name);
            performance.mark('end-build');
            performance.measure('build', 'begin-build', 'end-build');
            view.userData.simpleName = name;
            results.push(view);
        }

        return results;
    }

    private async lods(specs: ViewBuilderSpec[], precisionMode: PrecisionMode) {
        const options2models = new Map<[c3d.FacetOptions, number][], c3d.Body[]>();
        for (const { model } of specs) {
            const precision_distance = this.precisionAndDistanceFor(model, precisionMode);
            if (!options2models.has(precision_distance)) {
                options2models.set(precision_distance, []);
            }
            options2models.get(precision_distance)!.push(model);
        }
        const model2lods = new Map<c3d.Body, { mesh: MeshLike; disposable: Disposable; distance: number; }[]>();
        for (const [precision_distance, bodies] of options2models) {
            for (const [precision, distance] of precision_distance) {
                const stats = Measure.get("create-mesh");
                stats.begin();
                const meshes = await this.meshCreator.create(bodies, precision);
                stats.end();
                for (let i = 0; i < bodies.length; i++) {
                    const body = bodies[i], { mesh, disposable } = meshes[i];
                    if (!model2lods.has(body)) {
                        model2lods.set(body, []);
                    }
                    model2lods.get(body)!.push({ mesh, disposable, distance });
                }
            }
        }
        return model2lods;
    }

    private async meshes(obj: c3d.Body, id: visual.ItemId, lods: { mesh: MeshLike, disposable: Disposable, distance: number }[], material?: MaterialOverride): Promise<build.Builder<visual.SpaceInstance | visual.Solid | visual.Sheet | visual.SketchIsland>> {
        let builder;
        switch (obj.IsA()) {
            case c3d.BodyType.SpaceInstance:
                builder = new build.WireBodyBuilder();
                break;
            case c3d.BodyType.PlaneInstance:
                builder = new build.PlaneInstanceBuilder();
                break;
            case c3d.BodyType.Solid:
                builder = new build.SolidBuilder();
                break;
            case c3d.BodyType.SheetBody:
                builder = new build.SheetBuilder();
                break;
            default:
                throw new Error(`type ${c3d.BodyType[obj.IsA()]} not yet supported`);
        }

        const promises = [];
        for (const { mesh, disposable, distance } of lods) {
            const promise = this.object2mesh(builder, obj, id, mesh, disposable, distance, material);
            promises.push(promise);
        }
        await Promise.all(promises);

        return builder;
    }

    private async object2mesh(
        builder: Builder,
        obj: c3d.Body,
        id: visual.ItemId,
        mesh: MeshLike,
        disposable: Disposable,
        distance: number,
        materials?: MaterialOverride
    ): Promise<void> {
        switch (obj.IsA()) {
            case c3d.BodyType.SpaceInstance:
                const wire = obj as c3d.Wire;
                builder = builder as build.WireBodyBuilder;
                const segments = new build.CurveSegmentGroupBuilder();

                const lineMaterial = materials?.line ?? this.materials.line();
                const lineDashed = materials?.lineDashed ?? this.materials.lineDashed();
                const pointMaterial = materials?.controlPoint ?? this.materials.controlPoint();
                const occludedPointsMaterial = materials?.occludedControlPoint ?? this.materials.occludedControlPoint();
                const hullMaterial = materials?.hull ?? this.materials.hull();

                segments.add(mesh.edges, id, lineMaterial, lineDashed);
                const vertices = build.VertexGroupBuilder.build(wire, id, pointMaterial, occludedPointsMaterial);
                const cvs = build.CVGroupBuilder.build(wire, pointMaterial, occludedPointsMaterial, hullMaterial);

                builder.add(segments, vertices, cvs, distance, disposable);
                break;
            case c3d.BodyType.PlaneInstance: {
                builder = builder as build.PlaneInstanceBuilder;
                const regions = new build.RegionGroupBuilder();
                const material = materials?.region ?? this.materials.region();
                regions.add(mesh.faces, id, material);
                builder.add(regions, disposable);
                break;
            }
            case c3d.BodyType.SheetBody: {
                const sheet = builder as build.SheetBuilder;
                const edges = new build.CurveEdgeGroupBuilder();

                const material = materials?.surface ?? this.materials.surface();
                const lineMaterial = materials?.line ?? this.materials.line();
                const lineDashed = materials?.lineDashed ?? this.materials.lineDashed();

                const faces = new build.FaceGroupBuilder();
                faces.add(mesh.faces, id, material);
                edges.add(mesh.edges, id, lineMaterial, lineDashed);
                sheet.add(edges, faces, distance, disposable);
                break;
            }
            case c3d.BodyType.Solid: {
                const solid = builder as build.SolidBuilder;
                const edges = new build.CurveEdgeGroupBuilder();

                const material = materials?.mesh ?? this.materials.mesh();
                const lineMaterial = materials?.line ?? this.materials.line();
                const lineDashed = materials?.lineDashed ?? this.materials.lineDashed();

                const faces = new build.FaceGroupBuilder();
                faces.add(mesh.faces, id, material);
                edges.add(mesh.edges, id, lineMaterial, lineDashed);
                solid.add(edges, faces, distance, disposable);
                break;
            }
            default: throw new Error("type not yet supported");
        }
    }

    private precisionAndDistanceFor(item: c3d.Body, mode: PrecisionMode = 'real'): [c3d.FacetOptions, number][] {
        if (item.IsA() === c3d.BodyType.Solid || item.IsA() === c3d.BodyType.SheetBody) {
            return mode === 'real' ? this.mesh_precision_distance : mode === 'temporary' ? this.temporary_precision_distance : this.phantom_precision_distance;
        } else if (item.IsA() === c3d.BodyType.SpaceInstance) {
            return this.wire_precision_distance;
        } else {
            return this.region_precision_distance;
        }
    }
}
