// TODO:
// - eliminate editor originator and just use Database

import * as THREE from "three";
import { ProxyCamera } from '../components/viewport/ProxyCamera';
import * as c3d from '../kernel/kernel';
import { SelectionKey } from "../selection/SelectionDatabase";
import { RefCounter } from '../util/Util';
import * as visual from "../visual_model/VisualModel";
import { CrossInfo, CrossPoint } from './curves/CrossPointDatabase';
import { CurveInfo, FaceInfo } from "./curves/PlanarCurveDatabase";
import { StableId, VersionId } from "./DatabaseLike";
import { Database } from "./db/Database";
import { EditorSignals } from './EditorSignals';
import { Empty, EmptyId, EmptyInfo } from "./Empties";
import { GroupId } from "./Groups";
import { Images, Objects } from "./Images";
import { NodeKey, ReadonlyNodeTransform } from "./Nodes";
import { Backup } from "./serialization/Backup";
import { EmptyJSON } from "./serialization/PlasticityDocument";
import { DisablableType, SnapsForItem } from "./snaps/SnapManager";

export class Memento {
    constructor(
        readonly version: number,
        readonly geo: GeometryMemento,
        readonly serialize: SerializationMemento,
        readonly empties: EmptyMemento,
        readonly groups: GroupMemento,
        readonly nodes: NodeMemento,
        readonly scene: SceneMemento,
        readonly materials: MaterialMemento,
        readonly selection: SelectionMemento,
        readonly snaps: SnapMemento,
        readonly crosses: CrossPointMemento,
        readonly curves: CurveMemento,
        readonly meshes: MeshMemento,
        readonly sketches: SketchMemento,
    ) { }
}

export class GeometryMemento {
    constructor(
        readonly mark: c3d.SessionMark,
        readonly geometryModel: ReadonlyMap<VersionId, { view: visual.Item, model: c3d.Body }>,
        readonly version2stable: ReadonlyMap<VersionId, StableId>,
        readonly stable2version: ReadonlyMap<StableId, VersionId>,
        readonly automatics: ReadonlySet<visual.ItemId>,
    ) { }

    async serialize(): Promise<Buffer> {
        // const { memory } = await c3d.Writer.WriteItems_async(this.model);
        // return memory;
        throw "";
    }

    get model(): c3d.Model {
        // const { geometryModel } = this;

        // const everything = new c3d.Model();
        // for (const [id, { model }] of geometryModel.entries()) {
        //     if (this.automatics.has(id)) continue;
        //     everything.AddItem(model, id);
        // }
        // return everything;
        throw "";
    }
}

export class NodeMemento {
    constructor(
        readonly node2material: ReadonlyMap<NodeKey, number>,
        readonly hidden: ReadonlySet<NodeKey>,
        readonly invisible: ReadonlySet<NodeKey>,
        readonly unselectable: ReadonlySet<NodeKey>,
        readonly node2name: ReadonlyMap<NodeKey, string>,
        readonly node2transform: ReadonlyMap<NodeKey, ReadonlyNodeTransform>,
    ) { }
}

export class GroupMemento {
    constructor(
        readonly counter: number,
        readonly member2parent: ReadonlyMap<NodeKey, GroupId>,
        readonly group2children: ReadonlyMap<GroupId, ReadonlySet<NodeKey>>,
    ) { }
}

export class SceneMemento {
    constructor() { }
}

export class EmptyMemento {
    constructor(
        readonly counter: number,
        readonly id2info: ReadonlyMap<EmptyId, Readonly<EmptyInfo>>,
        readonly id2empty: ReadonlyMap<EmptyId, Empty>,
    ) { }
}

export class MaterialMemento {
    constructor(
        readonly counter: number,
        readonly materials: ReadonlyMap<number, { name: string, material: THREE.Material & { color: THREE.Color } }>
    ) { }
}

// FIXME: make ReadonlyRefCounter

export class SelectionMemento {
    constructor(
        readonly ids: ReadonlySet<SelectionKey>,
        readonly parentsWithSelectedChildren: RefCounter<visual.ItemId>,
    ) { }
}

export class CameraMemento {
    constructor(
        readonly mode: ProxyCamera["mode"],
        readonly position: Readonly<THREE.Vector3>,
        readonly quaternion: Readonly<THREE.Quaternion>,
        readonly zoom: number
    ) { }
}

export class ConstructionPlaneMemento {
    constructor(
        readonly n: Readonly<THREE.Vector3>,
        readonly o: Readonly<THREE.Vector3>
    ) { }
}

export class ViewportMemento {
    constructor(
        readonly camera: CameraMemento,
        readonly target: Readonly<THREE.Vector3>,
        readonly isXRay: boolean,
        readonly constructionPlane: ConstructionPlaneMemento,
    ) { }
}

export class SnapMemento {
    constructor(
        readonly id2snaps: ReadonlyMap<DisablableType, ReadonlyMap<visual.ItemId, SnapsForItem>>,
        readonly hidden: ReadonlyMap<visual.ItemId, SnapsForItem>
    ) { }
}

export class CrossPointMemento {
    constructor(
        readonly counter: number,
        readonly curve2touched: ReadonlyMap<visual.SpaceInstanceId, ReadonlySet<visual.SpaceInstanceId>>,
        readonly name2cross: ReadonlyMap<visual.SpaceInstanceId, CrossInfo>,
        readonly model2view: ReadonlyMap<c3d.WireId, visual.SpaceInstanceId>,
        readonly view2model: ReadonlyMap<visual.SpaceInstanceId, c3d.WireId>,
        readonly crosses: ReadonlySet<CrossPoint>,
    ) { }
}

export class CurveMemento {
    constructor(
        readonly curve2info: ReadonlyMap<visual.SpaceInstanceId, CurveInfo>,
        readonly basis2sketch: ReadonlyMap<c3d.Basis, c3d.Sketch>,
        readonly basis2curve: ReadonlyMap<c3d.Basis, ReadonlySet<c3d.WireId>>,
        readonly sketch2basis: ReadonlyMap<c3d.SketchId, c3d.Basis>,
        readonly face2info: ReadonlyMap<c3d.FaceId, FaceInfo>,
    ) { }
}

export class MeshMemento {
    constructor(
        readonly id2buffer: ReadonlyMap<c3d.EntityId, c3d.FacetFacesAndEdgesResult>
    ) { }
}

export class SketchMemento {
    constructor(
        readonly sketch2info: ReadonlyMap<c3d.SketchId, ReadonlyArray<visual.SketchIsland>>,
        readonly island2sketch: ReadonlyMap<visual.SketchIslandId, c3d.SketchId>
    ) { }
}

export class SerializationMemento {
    constructor(readonly version2data: ReadonlyMap<VersionId, Uint8Array>) { }

    get size() {
        let result = 0;
        for (const [, data] of this.version2data) {
            result += data.byteLength;
        }
        return result;
    }
}

export type StateChange = (f: () => void) => void;

type OriginatorState = { tag: 'start' } | { tag: 'group', memento: Memento }

export class EditorOriginator {
    private state: OriginatorState = { tag: 'start' }
    private version = 0;

    constructor(
        readonly db: Database,
        readonly geo: MementoOriginator<GeometryMemento>,
        readonly serialize: MementoOriginator<SerializationMemento>,
        readonly empties: MementoOriginator<EmptyMemento> & { deserialize(json: EmptyJSON[]): void },
        readonly scene: MementoOriginator<SceneMemento>,
        readonly groups: MementoOriginator<GroupMemento>,
        readonly nodes: MementoOriginator<NodeMemento>,
        readonly materials: MementoOriginator<MaterialMemento>,
        readonly selection: MementoOriginator<SelectionMemento>,
        readonly hover: MementoOriginator<SelectionMemento>,
        readonly snaps: MementoOriginator<SnapMemento>,
        readonly crosses: MementoOriginator<CrossPointMemento>,
        readonly curves: MementoOriginator<CurveMemento>,
        readonly viewports: Iterable<MementoOriginator<ViewportMemento>>,
        readonly images: Images,
        readonly objects: Objects,
        readonly meshes: MementoOriginator<MeshMemento>,
        readonly sketches: MementoOriginator<SketchMemento>,
    ) { }

    advanceVersion() { this.version++ }
    saveToMemento(): Memento {
        switch (this.state.tag) {
            case 'start':
                return new Memento(
                    this.version,
                    this.geo.saveToMemento(),
                    this.serialize.saveToMemento(),
                    this.empties.saveToMemento(),
                    this.groups.saveToMemento(),
                    this.nodes.saveToMemento(),
                    this.scene.saveToMemento(),
                    this.materials.saveToMemento(),
                    this.selection.saveToMemento(),
                    this.snaps.saveToMemento(),
                    this.crosses.saveToMemento(),
                    this.curves.saveToMemento(),
                    this.meshes.saveToMemento(),
                    this.sketches.saveToMemento());
            case 'group':
                return this.state.memento;
        }
    }

    restoreFromMemento(m: Memento) {
        OrderIsImportant: {
            this.version = m.version;
            this.geo.restoreFromMemento(m.geo);
            this.serialize.restoreFromMemento(m.serialize);
            this.empties.restoreFromMemento(m.empties);
            this.groups.restoreFromMemento(m.groups);
            this.nodes.restoreFromMemento(m.nodes);
            this.scene.restoreFromMemento(m.scene);
            this.selection.restoreFromMemento(m.selection);
            this.crosses.restoreFromMemento(m.crosses);
            this.snaps.restoreFromMemento(m.snaps);
            this.curves.restoreFromMemento(m.curves);
            this.meshes.restoreFromMemento(m.meshes);
            this.sketches.restoreFromMemento(m.sketches);
        }
    }

    discardSideEffects(m: Memento) {
        if (this.version === m.version) {
            this.restoreFromMemento(m);
        } else {
            console.log("Discarding side effects, but version mismatch:", "current: ", this.version, "memento: ", m.version);
        }
    }

    validate() {
        this.snaps.validate();
        this.crosses.validate();
        this.selection.validate();
        this.curves.validate();
        this.geo.validate();
        this.serialize.validate();
        this.groups.validate();
        this.nodes.validate();
        this.meshes.validate();
        this.empties.validate();
        this.sketches.validate();
    }

    debug() {
        console.groupCollapsed("Debug")
        console.info("Version: ", this.version);
        this.snaps.debug();
        this.selection.debug();
        this.curves.debug();
        this.crosses.debug();
        this.geo.debug();
        this.serialize.debug();
        this.groups.debug();
        this.nodes.debug();
        this.meshes.debug();
        this.sketches.debug();
        console.groupEnd();
    }

    clear() {
        this.geo.clear();
        this.serialize.clear();
        this.empties.clear();
        this.groups.clear();
        this.nodes.clear();
        this.selection.clear();
        this.hover.clear();
        this.crosses.clear();
        this.snaps.clear();
        this.curves.clear();
        this.meshes.clear();
        this.sketches.clear();
        this.scene.clear();
    }
}

export interface MementoOriginator<T> {
    saveToMemento(): T;
    restoreFromMemento(m: T): void;
    validate(): void;
    debug(): void;
    clear(): void;
}

export type HistoryStackItem = Readonly<{
    name: String,
    memento: Memento,
}>

export class History {
    private readonly _undoStack: HistoryStackItem[] = [];
    get undoStack(): readonly HistoryStackItem[] { return this._undoStack }

    private readonly _redoStack: HistoryStackItem[] = [];
    get redoStack(): readonly HistoryStackItem[] { return this._redoStack }

    constructor(
        private readonly originator: EditorOriginator,
        private readonly backup: Backup,
        private readonly signals: EditorSignals
    ) { }

    private _current!: HistoryStackItem;
    get current() { return this._current }
    initialize() { this._current = { name: "Start", memento: this.originator.saveToMemento() } }

    add(name: String, before: HistoryStackItem) {
        if (this._undoStack.length > 0 &&
            this._undoStack[this._undoStack.length - 1] === before) return;
        this.originator.advanceVersion();
        const after = this.originator.saveToMemento();
        this._undoStack.push(before);
        this._current = { name, memento: after };
        this._redoStack.length = 0;
        this.signals.historyAdded.dispatch();
        return after;
    }

    undo(): boolean {
        const undo = this._undoStack.pop();
        if (!undo) return false;

        const { memento: before } = undo;
        this.originator.restoreFromMemento(before);
        this._redoStack.push(this._current);
        this._current = undo;

        this.backup.save(before);
        this.signals.historyChanged.dispatch();
        if (process.env.NODE_ENV === 'development') {
            // console.group("Undo");
            // this.originator.debug();
            // console.groupEnd();
        }

        return true;
    }

    redo(): boolean {
        const redo = this._redoStack.pop();
        if (redo === undefined) return false;

        const { memento: after } = redo;
        this.originator.restoreFromMemento(after);
        this._undoStack.push(this._current);
        this._current = redo;
        this.backup.save(after);
        this.signals.historyChanged.dispatch();
        if (process.env.NODE_ENV === 'development') {
            // console.group("Redo");
            // this.originator.debug();
            // console.groupEnd();
        }

        return true;
    }

    restore(before: HistoryStackItem) {
        this.originator.discardSideEffects(before.memento);
    }
}
