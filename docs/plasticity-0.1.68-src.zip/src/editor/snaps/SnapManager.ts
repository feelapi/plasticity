import * as THREE from "three";
import * as c3d from '../../kernel/kernel';
import { origin, X, Y, Z } from "../../util/Constants";
import { assertUnreachable } from "../../util/Util";
import { Intersectable } from "../../visual_model/Intersectable";
import * as visual from '../../visual_model/VisualModel';
import { CrossPointDatabase } from "../curves/CrossPointDatabase";
import { PlanarCurveDatabase } from "../curves/PlanarCurveDatabase";
import { ReadonlyGeometryDatabase } from "../DatabaseLike";
import { DisableOptions } from "../db/Database";
import { MementoOriginator, SnapMemento } from "../History";
import { AxisSnap } from "./AxisSnap";
import { OriginSnap, PointSnap } from "./PointSnap";
import { RaycastableSnap, Snap } from "./Snap";
import { SnapManagerGeometryCache } from "./SnapManagerGeometryCache";
import { AxisCurveCrossPointSnap, CircleCurveCenterPointSnap, CircleEdgeCenterPointSnap, CrossPointSnap, CurveEdgeSnap, CurveEndPointSnap, CurveMidpointSnap, CurveSegmentSnap, EdgeEndpointSnap, EdgePointSnap, FaceCenterPointSnap, FaceSnap, RegionSnap, TopologyPointSnap } from "./Snaps";

export enum SnapType {
    Basic = 1 << 0,
    Geometry = 1 << 1,
    Crosses = 2 << 1,
}

export type DisablableType = typeof visual.Solid | typeof visual.Sheet | typeof visual.SpaceInstance | typeof visual.Region;
export type TopologySnap = FaceSnap | RegionSnap | CurveEdgeSnap | CurveSegmentSnap;
export type SnapsForItem = { faces: SnapsForFaces, edges: SnapsForEdges, segments: SnapsForEdges };
export type SnapsForEdges = {
    halves: {
        edgeIds: Int32Array;
        positions: Float32Array;
        tangents: Float32Array;
    }
    circles: {
        edgeIds: Int32Array;
        quarters: Float32Array;
        tangents: Float32Array;
        centers: Float32Array;
        axes: Float32Array;
    }
}
export type SnapsForFaces = {
    centers: {
        faceIds: Int32Array;
        positions: Float32Array;
        normals: Float32Array;
    }
}

type SnapMap = Map<visual.ItemId, SnapsForItem>;
type BasicSnap = PointSnap | RaycastableSnap;
type AllSnaps = { basicSnaps: ReadonlySet<BasicSnap>, geometrySnaps: { simpleName: visual.ItemId, snaps: SnapsForItem }[], crossSnaps: readonly (CrossPointSnap | AxisCurveCrossPointSnap)[] };

type PointSnapType = 'faces.centers' | 'edges.halves' | 'edges.circles.centers' | 'edges.circles.quarters' | 'segments.halves' | 'segments.circles.centers' | 'segments.circles.quarters';

export interface ReadonlySnapManager {
    lookup(intersectable: Intersectable): Snap | undefined;
    lookupById(simpleName: visual.TopologyId): Snap | undefined;
    lookupPoint(parentName: visual.ItemId, type: PointSnapType, i: number): PointSnap;
    readonly layers: THREE.Layers;
    get enabled(): boolean;
    get snapToGrid(): boolean;
    get all(): AllSnaps;
    get cache(): SnapManagerGeometryCache;
    isDisabled(snap: Snap): boolean;
    get axes(): ReadonlyMap<number, AxisSnap>;
}

export class SnapManager implements ReadonlySnapManager, MementoOriginator<SnapMemento> {
    private _enabled = true;
    set enabled(enabled: boolean) { this._enabled = enabled }
    get enabled() {
        return this._enabled !== this.xor;
    }

    private _snapToGrid = false;
    set snapToGrid(snapToGrid: boolean) { this._snapToGrid = snapToGrid }
    get snapToGrid() {
        return this._snapToGrid && !this.xor;
    }

    private _xor = false;
    get xor() { return this._xor }
    set xor(xor: boolean) {
        if (this._xor === xor) return;

        this._xor = xor;
    }

    options: SnapType = SnapType.Basic | SnapType.Geometry | SnapType.Crosses;
    readonly layers = new THREE.Layers();

    private readonly basicSnaps = new Set([originSnap, xAxisSnap, yAxisSnap, zAxisSnap]);
    private readonly id2snaps = new Map<DisablableType, SnapMap>();
    private readonly hidden = new Map<visual.ItemId, SnapsForItem>()

    readonly cache: SnapManagerGeometryCache = new SnapManagerGeometryCache(this);

    constructor(private readonly geo: ReadonlyGeometryDatabase, private readonly curves: PlanarCurveDatabase, private readonly crosses: CrossPointDatabase) {
        Object.freeze(this.basicSnaps);

        this.layers.enableAll();
        this.layers.disable(visual.Layers.CurveFragment);
        this.init();
    }

    private readonly _axes: Map<number, [c3d.Wire, AxisSnap]> = new Map();
    get axes(): Map<number, AxisSnap> {
        const axes = new Map<number, AxisSnap>();
        for (const [id, [, axis]] of this._axes) {
            axes.set(id, axis);
        }
        return axes;
    }

    private readonly partition = new c3d.Partition();
    private init() {
        const { partition } = this;
        this.reset();

        const crosses = this.crosses;
        const x_ = partition.WireBody.CreateLine(c3d.Origin, c3d.X);
        const y_ = partition.WireBody.CreateLine(c3d.Origin, c3d.Y);
        const z_ = partition.WireBody.CreateLine(c3d.Origin, c3d.Z);
        let xId = crosses.makeTemporaryName(), yId = crosses.makeTemporaryName(), zId = crosses.makeTemporaryName();
        crosses.add(xId, x_, new Map([[xId, { points: new Set(), vertices: new Set() }]]), new Map([[xId, new Set()]]), new Set());
        crosses.add(yId, y_, new Map([[yId, { points: new Set(), vertices: new Set() }]]), new Map([[yId, new Set()]]), new Set());
        crosses.add(zId, z_, new Map([[zId, { points: new Set(), vertices: new Set() }]]), new Map([[zId, new Set()]]), new Set());
        crosses.createSnapshot();
        this._axes.set(xId, [x_, xAxisSnap]);
        this._axes.set(yId, [y_, yAxisSnap]);
        this._axes.set(zId, [z_, zAxisSnap]);
    }

    private reset() {
        this.id2snaps.set(visual.Solid, new Map());
        this.id2snaps.set(visual.Sheet, new Map());
        this.id2snaps.set(visual.SpaceInstance, new Map());
        this.id2snaps.set(visual.Region, new Map());
    }

    get all(): AllSnaps {
        const basicSnaps = (this.options & SnapType.Basic) === SnapType.Basic ? this.basicSnaps : new Set<BasicSnap>();
        const crossSnaps = (this.options & SnapType.Crosses) === SnapType.Crosses ? this.crossSnaps : [];

        let geometrySnaps: { simpleName: visual.ItemId, snaps: SnapsForItem }[] = [];
        if ((this.options & SnapType.Geometry) === SnapType.Geometry) {
            for (const [_, id2snaps] of this.id2snaps) {
                for (const [simpleName, snaps] of id2snaps) geometrySnaps.push({ simpleName, snaps });
            }
        }

        return { basicSnaps, geometrySnaps, crossSnaps }
    }

    lookupById(simpleName: visual.TopologyId): Snap | undefined {
        const { geo } = this;
        const { view, model } = geo.lookupTopologyItemById(simpleName);
        if (view instanceof visual.Face) {
            return new FaceSnap(view, model as c3d.Face);
        } else if (view instanceof visual.Region) {
            return new RegionSnap(view, model as c3d.Face);
        } else if (view instanceof visual.CurveEdge) {
            return new CurveEdgeSnap(view, model as c3d.Edge);
        } else if (view instanceof visual.CurveSegment) {
            const parent = view.parentItem;
            const parentModel = geo.lookup(parent);
            const basis = this.curves.getInfoForCurve(parentModel.Id())?.basis;
            return new CurveSegmentSnap(view, model as c3d.Edge, basis);
        } else {
            return undefined;
        }
    }

    lookup(intersectable: Intersectable): Snap | undefined {
        const { geo } = this;
        if (intersectable instanceof visual.Face) {
            const model = geo.lookupTopologyItem(intersectable);
            return new FaceSnap(intersectable, model);
        } else if (intersectable instanceof visual.Region) {
            const model = geo.lookupTopologyItem(intersectable);
            return new RegionSnap(intersectable, model);
        } else if (intersectable instanceof visual.CurveEdge) {
            const model = geo.lookupTopologyItem(intersectable);
            return new CurveEdgeSnap(intersectable, model);
        } else if (intersectable instanceof visual.CurveSegment) {
            const model = geo.lookupTopologyItem(intersectable);
            const parent = intersectable.parentItem;
            const parentModel = geo.lookup(parent);
            const basis = this.curves.getInfoForCurve(parentModel.Id())?.basis;
            return new CurveSegmentSnap(intersectable, model, basis);
        } else {
            return undefined;
        }
    }

    lookupPoint(parentName: visual.ItemId, type: PointSnapType, i: number): PointSnap {
        if (i < 0) throw new Error('Invalid index');

        const parentItem = this.geo.lookupItemById(parentName).view;
        const id2snaps = this.snapMapFor(parentItem);
        const { faces, edges, segments } = id2snaps.get(parentName)!;
        switch (type) {
            case 'faces.centers': {
                if (i >= faces.centers.positions.length / 3) throw new Error('Invalid index');
                const px = faces.centers.positions[i * 3 + 0], py = faces.centers.positions[i * 3 + 1], pz = faces.centers.positions[i * 3 + 2];
                const nx = faces.centers.normals[i * 3 + 0], ny = faces.centers.normals[i * 3 + 1], nz = faces.centers.normals[i * 3 + 2];
                const position = new THREE.Vector3(px, py, pz);
                const normal = new THREE.Vector3(nx, ny, nz);
                const faceSnap = this.lookupById(visual.Face.simpleName(parentName, faces.centers.faceIds[i])) as FaceSnap;
                return new FaceCenterPointSnap(position, normal, faceSnap);
            }
            case 'edges.halves': {
                if (i >= edges.halves.positions.length / 3) throw new Error('Invalid index');
                const px = edges.halves.positions[i * 3 + 0], py = edges.halves.positions[i * 3 + 1], pz = edges.halves.positions[i * 3 + 2];
                const tx = edges.halves.tangents[i * 3 + 0], ty = edges.halves.tangents[i * 3 + 1], tz = edges.halves.tangents[i * 3 + 2];
                const position = new THREE.Vector3(px, py, pz);
                const tangent = new THREE.Vector3(tx, ty, tz);
                const edgeSnap = this.lookupById(visual.CurveEdge.simpleName(parentName, edges.halves.edgeIds[Math.floor(i / 3)])) as CurveEdgeSnap;
                switch (i % 3) {
                    case 0: return new EdgeEndpointSnap(position, tangent, 0, edgeSnap);
                    case 1: return new EdgePointSnap("Middle", position, tangent, edgeSnap);
                    case 2: return new EdgeEndpointSnap(position, tangent, 1, edgeSnap);
                }
            }
            case 'edges.circles.quarters': {
                if (i >= edges.circles.quarters.length / 3) throw new Error('Invalid index');
                const px = edges.circles.quarters[i * 3 + 0], py = edges.circles.quarters[i * 3 + 1], pz = edges.circles.quarters[i * 3 + 2];
                const nx = edges.circles.tangents[i * 3 + 0], ny = edges.circles.tangents[i * 3 + 1], nz = edges.circles.tangents[i * 3 + 2];
                const position = new THREE.Vector3(px, py, pz);
                const tangent = new THREE.Vector3(nx, ny, nz);
                const edgeSnap = this.lookupById(visual.CurveEdge.simpleName(parentName, edges.circles.edgeIds[Math.floor(i / 2)])) as CurveEdgeSnap;
                switch (i % 2) {
                    case 0: return new EdgePointSnap("1/4", position, tangent, edgeSnap);
                    case 1: return new EdgePointSnap("3/4", position, tangent, edgeSnap);
                }
            }
            case 'edges.circles.centers': {
                if (i >= edges.circles.centers.length / 3) throw new Error('Invalid index');
                const px = edges.circles.centers[i * 3 + 0], py = edges.circles.centers[i * 3 + 1], pz = edges.circles.centers[i * 3 + 2];
                const ax = edges.circles.axes[i * 3 + 0], ay = edges.circles.axes[i * 3 + 1], az = edges.circles.axes[i * 3 + 2];
                const position = new THREE.Vector3(px, py, pz);
                const axis = new THREE.Vector3(ax, ay, az);
                const edgeSnap = this.lookupById(visual.CurveEdge.simpleName(parentName, edges.circles.edgeIds[i])) as CurveEdgeSnap;
                return new CircleEdgeCenterPointSnap(position, axis, edgeSnap.view);
            }
            case 'segments.halves': {
                if (i >= segments.halves.positions.length / 3) throw new Error('Invalid index');
                const px = segments.halves.positions[i * 3 + 0], py = segments.halves.positions[i * 3 + 1], pz = segments.halves.positions[i * 3 + 2];
                const tx = segments.halves.tangents[i * 3 + 0], ty = segments.halves.tangents[i * 3 + 1], tz = segments.halves.tangents[i * 3 + 2];
                const position = new THREE.Vector3(px, py, pz);
                const tangent = new THREE.Vector3(tx, ty, tz);
                const segmentSnap = this.lookupById(visual.CurveSegment.simpleName(parentName, segments.halves.edgeIds[Math.floor(i / 3)])) as CurveSegmentSnap;
                switch (i % 3) {
                    case 0: return new CurveEndPointSnap("Beginning", position, tangent, segmentSnap, 0);
                    case 1: return new CurveMidpointSnap("Middle", position, tangent, segmentSnap, 0.5);
                    case 2: return new CurveEndPointSnap("End", position, tangent, segmentSnap, 1);
                }
            }
            case 'segments.circles.quarters': {
                if (i >= segments.circles.quarters.length / 3) throw new Error('Invalid index');
                const px = segments.circles.quarters[i * 3 + 0], py = segments.circles.quarters[i * 3 + 1], pz = segments.circles.quarters[i * 3 + 2];
                const nx = segments.circles.tangents[i * 3 + 0], ny = segments.circles.tangents[i * 3 + 1], nz = segments.circles.tangents[i * 3 + 2];
                const position = new THREE.Vector3(px, py, pz);
                const tangent = new THREE.Vector3(nx, ny, nz);
                const segmentSnap = this.lookupById(visual.CurveSegment.simpleName(parentName, segments.circles.edgeIds[Math.floor(i / 2)])) as CurveSegmentSnap;
                switch (i % 2) {
                    case 0: return new CurveMidpointSnap("1/4", position, tangent, segmentSnap, 0.25);
                    case 1: return new CurveMidpointSnap("3/4", position, tangent, segmentSnap, 0.75);
                }
            }
            case 'segments.circles.centers': {
                if (i >= segments.circles.centers.length) throw new Error('Invalid index');
                const px = segments.circles.centers[i * 3 + 0], py = segments.circles.centers[i * 3 + 1], pz = segments.circles.centers[i * 3 + 2];
                const ax = segments.circles.axes[i * 3 + 0], ay = segments.circles.axes[i * 3 + 1], az = segments.circles.axes[i * 3 + 2];
                const position = new THREE.Vector3(px, py, pz);
                const axis = new THREE.Vector3(ax, ay, az);
                const segmentSnap = this.lookupById(visual.CurveSegment.simpleName(parentName, segments.circles.edgeIds[i])) as CurveSegmentSnap;
                return new CircleCurveCenterPointSnap(position, axis, segmentSnap.view);
            }
            default: assertUnreachable(type);
        }
    }

    get crossSnaps(): (CrossPointSnap | AxisCurveCrossPointSnap)[] {
        const result = [];
        for (const cross of this.crosses.crosses) {
            const simpleName1 = visual.CurveSegment.simpleName(cross.on1.bodyName, cross.on1.edgeId);
            const simpleName2 = visual.CurveSegment.simpleName(cross.on2.bodyName, cross.on2.edgeId);
            const isAxis = this.crosses.isTemporaryName(cross.on2.bodyName);
            const curveSnap1 = this.lookupById(simpleName1) as CurveSegmentSnap;
            if (!isAxis) {
                const curveSnap2 = this.lookupById(simpleName2) as CurveSegmentSnap;
                result.push(new CrossPointSnap(cross, curveSnap1, curveSnap2));
            } else {
                const [, axis] = this._axes.get(cross.on2.bodyName)!;
                result.push(new AxisCurveCrossPointSnap(cross, axis, curveSnap1));
            }
        }
        return result;
    }

    private snapMapFor(item: visual.Item): SnapMap {
        if (item instanceof visual.Solid) {
            return this.id2snaps.get(visual.Solid)!;
        } else if (item instanceof visual.Sheet) {
            return this.id2snaps.get(visual.Sheet)!;
        } else if (item instanceof visual.SpaceInstance) {
            return this.id2snaps.get(visual.SpaceInstance)!;
        } else if (item instanceof visual.SketchIsland) {
            return this.id2snaps.get(visual.Region)!;
        } else throw new Error(`Unsupported type: ${item.constructor.name}`);
    }

    add(item: visual.Item, snapsForItem: SnapsForItem) {
        const snapMap = this.snapMapFor(item);
        snapMap.set(item.simpleName, snapsForItem);
    }

    delete(item: visual.Item) {
        const id2snaps = this.snapMapFor(item);
        id2snaps.delete(item.simpleName);
        this.hidden.delete(item.simpleName);
    }

    private readonly disabled = new Map<visual.ItemId, DisableOptions>();
    disable(items: visual.Item[], options = DisableOptions.Default) {
        for (const item of items)
            this.disabled.set(item.simpleName, options);
    }
    clearDisabled() { this.disabled.clear() }
    isDisabled(snap: Snap): boolean {
        if (snap instanceof TopologyPointSnap) {
            const item = snap.item;
            const options = this.disabled.get(item.simpleName);
            if (options === undefined) return false;
            if (options & DisableOptions.KeepPointSnaps) return false;
            return true;
        } else if (snap instanceof FaceSnap || snap instanceof CurveEdgeSnap || snap instanceof CurveSegmentSnap) {
            const item = snap.item;
            return this.disabled.has(item.simpleName);
        } else {
            return false;
        }
    }

    hide(item: visual.Item) {
        const id = item.simpleName;
        const id2snaps = this.snapMapFor(item);
        const info = id2snaps.get(id);
        if (info === undefined) return;
        id2snaps.delete(id);
        this.hidden.set(id, info);
    }

    unhide(item: visual.Item) {
        const id = item.simpleName;
        const id2snaps = this.snapMapFor(item);
        const info = this.hidden.get(id);
        if (info === undefined) return;
        id2snaps.set(id, info);
        this.hidden.delete(id);
    }

    saveToMemento(): SnapMemento {
        const id2snaps = this.id2snaps;
        const id2snapsCopy = copyId2Snaps(id2snaps);

        return new SnapMemento(
            id2snapsCopy,
            new Map(this.hidden));
    }

    restoreFromMemento(m: SnapMemento) {
        (this.id2snaps as SnapManager['id2snaps']) = copyId2Snaps(m.id2snaps);
        (this.hidden as SnapManager['hidden']) = new Map(m.hidden);
        this.cache.update();
    }

    clear() {
        this.id2snaps.clear();
        this.hidden.clear();
        this.reset();
    }

    validate() {
        for (const [, snaps] of this.id2snaps) {
            for (const id of snaps.keys()) {
                console.assert(this.geo.lookupItemById(id) !== undefined, "item in database", id);
            }
        }
        for (const id of this.hidden.keys()) {
            console.assert(this.geo.lookupItemById(id) !== undefined, "item in database", id);
        }
    }

    debug() {
        console.group("Snaps");
        for (const [id, snaps] of this.id2snaps) {
            console.group(id.name);
            for (const [id, snap] of snaps) {
                console.log(id);
                console.table(snap);
            }
            console.groupEnd();
        }
        console.groupEnd();
    }
}

export const originSnap = new OriginSnap("Origin");
export const xAxisSnap = new AxisSnap("X", X, origin, Z);
export const yAxisSnap = new AxisSnap("Y", Y, origin, Z);
export const zAxisSnap = new AxisSnap("Z", Z, origin, Z);

function copyId2Snaps(id2snaps: ReadonlyMap<DisablableType, ReadonlyMap<visual.ItemId, SnapsForItem>>) {
    const id2snapsCopy = new Map<DisablableType, SnapMap>();
    for (const [key, value] of id2snaps) {
        id2snapsCopy.set(key, new Map(value));
    }
    return id2snapsCopy;
}
