import * as THREE from "three";
import { Choice } from "../../command/point-picker/PointPickerModel";
import { GridSnapper } from "../../components/snaps/GridSnapper";
import { Viewport } from "../../components/viewport/Viewport";
import { BetterRaycastingPoints } from "../../visual_model/BetterRaycastingPoints";
import { discardOccluded, RaycastOcclusionDiscarder } from "../../visual_model/DiscardOccluded";
import { IntersectableWithTopologyItem, Unprojectable, UnprojectableIntersection } from "../../visual_model/GeometryPicker";
import { Intersectable, RaycastableTopologyItem } from "../../visual_model/Intersectable";
import * as visual from "../../visual_model/VisualModel";
import { Empty } from "../Empties";
import { Scene } from "../Scene";
import { ConstructionPlaneSnap, FaceConstructionPlaneSnap } from "./ConstructionPlaneSnap";
import { PreferrableSnap, Snap } from "./Snap";
import { SnapManagerGeometryCache } from "./SnapManagerGeometryCache";
import { RaycasterParams, SnapManagerLayers, SnapResult } from "./SnapPicker";

const defaultIntersectParams: RaycasterParams = {
    Line: { threshold: 0.1 },
    Line2: { threshold: 30 },
    Points: { threshold: 26 },
    layers: new THREE.Layers(),
};

const defaultNearbyParams: THREE.RaycasterParameters = {
    Points: { threshold: 200 }
};

type SnapAndIntersection = {
    snap: Snap;
    intersection: UnprojectableIntersection;
};

export abstract class SnapPickerStrategy {
    constructor(
        protected readonly intersectParams: RaycasterParams = defaultIntersectParams,
        protected readonly nearbyParams: THREE.RaycasterParameters = defaultNearbyParams,
    ) { }

    configureNearbyRaycaster(raycaster: THREE.Raycaster, snaps: SnapManagerGeometryCache, viewport: Viewport) {
        raycaster.params = this.nearbyParams;
        if (this.intersectParams.layers.mask === SnapManagerLayers.mask) {
            raycaster.layers.mask = snaps.layers.mask;
        } else {
            raycaster.layers.mask = this.intersectParams.layers.mask;
        }
    }

    configureIntersectRaycaster(raycaster: THREE.Raycaster, snaps: SnapManagerGeometryCache, viewport: Viewport) {
        raycaster.params = this.intersectParams;
        if (this.intersectParams.layers.mask === SnapManagerLayers.mask) {
            raycaster.layers.mask = snaps.layers.mask;
        } else {
            raycaster.layers.mask = this.intersectParams.layers.mask;
        }
    }

    intersectWithGeometry(raycaster: THREE.Raycaster, snaps: SnapManagerGeometryCache, scene: Scene): SnapAndIntersection[] {
        let visible = scene.visibleObjects;
        // FIXME: I dislike this approach; make TranslateFactory generate real TemporaryObjects rather than reusing the actual Items
        visible = visible.filter(item => !item.isTemporaryOptimization);
        const geoIntersections = raycaster.intersectObjects(visible, false);
        const geo_intersections_snaps = this.intersections2snaps(snaps, geoIntersections);
        return geo_intersections_snaps;
    }

    inferRestrictionFromPreference(geo_intersections_snaps: SnapAndIntersection[], other_intersections_snaps: SnapAndIntersection[], preference: PreferrableSnap | undefined): Snap | undefined {
        if (preference === undefined) return undefined;

        // If the preference is the closest item, we turn it into a restriction

        let geoResult: Snap | undefined, otherResult: Snap | undefined;
        let geoIntersection: SnapAndIntersection | undefined, otherIntersection: SnapAndIntersection | undefined;

        if (geo_intersections_snaps.length > 0 && preference.equals(geo_intersections_snaps[0].snap)) {
            geoResult = preference;
            geoIntersection = geo_intersections_snaps[0];
        }

        if (other_intersections_snaps.length > 0 && preference.equals(other_intersections_snaps[0].snap)) {
            otherResult = preference;
            otherIntersection = other_intersections_snaps[0];
        }

        if (otherResult === undefined) return geoResult;
        if (geoResult === undefined) return otherResult;

        // If both are the close, we choose the one with the closest intersection point

        if (geoIntersection!.intersection.distance < otherIntersection!.intersection.distance) return geoResult;
        else return otherResult;
    }

    intersectWithSnaps(additional: readonly THREE.Object3D[], pointss: readonly BetterRaycastingPoints[], raycaster: THREE.Raycaster, snaps: SnapManagerGeometryCache): SnapAndIntersection[] {
        const other_intersections = raycaster.intersectObjects([...snaps.basic, ...additional, ...pointss], false);
        const other_intersections_snaps = this.intersections2snaps(snaps, other_intersections);
        return other_intersections_snaps;
    }

    // Project all the intersections (go from approximate to exact values)
    // Fold in any additional results (sometimes the construction plane)
    projectIntersections(
        viewport: Viewport,
        geo_intersections_snaps: SnapAndIntersection[],
        other_intersections_snaps: SnapAndIntersection[],
        cplane_intersection_results: (SnapResult & Unprojectable)[],
        restriction: Snap | undefined,
        grid: GridSnapper | undefined,
    ): (SnapResult & Unprojectable)[] {
        const { isOrthoMode, constructionPlane: { orientation: constructionPlaneOrientation } } = viewport;

        const intersections_snaps = [...geo_intersections_snaps, ...other_intersections_snaps];
        let results: (SnapResult & Unprojectable)[] = [];
        for (const { snap, intersection } of intersections_snaps) {
            const { position, orientation } = snap.project(intersection.point, grid);

            // Step 1: If we are on a preferred face, discard all snaps that aren't also on the face
            if (restriction !== undefined && !restriction.isValid(position)) continue;

            // Step 2: In ortho mode, we ignore the snap orientation
            const snapOrientation = orientation;
            const effectiveOrientation = isOrthoMode ? constructionPlaneOrientation : orientation;
            const { distance, distance2d, pointOnLine, point } = intersection;
            const result = { distance, distance2d, pointOnLine, point, snap, snapOrientation, position, orientation: effectiveOrientation, cursorPosition: position, cursorOrientation: effectiveOrientation };
            results.push(result);
        }
        results = results.concat(cplane_intersection_results)
        return results;
    }

    processXRay(viewport: Viewport, before: (SnapResult & Unprojectable)[], raycaster: THREE.Raycaster, occlusionRaycaster: THREE.Raycaster, intersectedGeometry: SnapAndIntersection[]) {
        const { isXRay } = viewport;
        let after = before;
        if (!isXRay) {
            // discardOccluded "moves" the mouse cursor to be exactly over the object and then checks if it's occluded by possibleOccluders
            // We should use scene.visibleObjects, but that is extremely expensive. Instead, use the geometry we actually intersected,
            // which is a very good approximation of objects that are likely to occlude.
            const possibleOccluders = extractPossibleOccludersFromIntersectedGeometry(intersectedGeometry);
            const raycast = new RaycastOcclusionDiscarder(raycaster, viewport, possibleOccluders);
            after = discardOccluded(before, raycast);
        }
        return after;
    }

    filterByLayer(intersections: SnapAndIntersection[], layers: THREE.Layers): SnapAndIntersection[] {
        return intersections.filter(({ snap }) => layers.test(snap.layers));
    }

    filterDisabled(intersections: SnapAndIntersection[], snaps: SnapManagerGeometryCache): SnapAndIntersection[] {
        return intersections.filter(({ snap }) => {
            return !snaps.isDisabled(snap);
        });
    }

    intersectChoice(choice: Choice, raycaster: THREE.Raycaster): [SnapResult] | [] {
        const snap = choice.snap;
        const intersection = snap.intersect(raycaster, choice.info);
        if (intersection === undefined) return [];
        const { position, orientation } = intersection;
        const snapOrientation = orientation;
        return [{ snap, snapOrientation, orientation, position, cursorPosition: position, cursorOrientation: orientation }];
    }

    projectIntersectionOntoChoice(choice: Choice, intersections: SnapResult[]): SnapResult[] {
        const snap = choice.snap;
        const snapsOtherThanChoice = intersections.filter(info => info.snap !== snap);
        const projectable = snapsOtherThanChoice.filter(i => !(i.snap instanceof FaceConstructionPlaneSnap || i.snap instanceof ConstructionPlaneSnap));
        const compatible = projectable.filter(p => choice.snap.isCompatibleWithSnap(p.snap));

        const result = [];
        for (const info of compatible) {
            const { position, orientation } = snap.projectOntoChoice(info.position, choice.info);
            if (!snap.isValid(position)) continue;
            result.push({ ...info, snap: info.snap, position, orientation });
        };
        return result;
    }

    private intersections2snaps(snaps: SnapManagerGeometryCache, intersections: THREE.Intersection[]): SnapAndIntersection[] {
        const result: SnapAndIntersection[] = [];
        const map = new Map<Intersectable, THREE.Intersection>();
        for (const intersection of intersections) {
            const object = intersection.object;
            let snap: Snap | undefined;
            if (object instanceof visual.Region) {
                continue; // FIXME:
            } else if (object instanceof RaycastableTopologyItem) {
                const hasTopology = intersection as unknown as { topologyItem: Intersectable };
                const topologyItem = hasTopology.topologyItem;
                const alreadySeen = map.get(topologyItem);
                if (alreadySeen !== undefined) {
                    if (alreadySeen.distance < intersection.distance) continue;
                }
                map.set(topologyItem, intersection);
            } else if (object instanceof visual.CurveSegment) {
                snap = snaps.lookup(object);
            } else if (object instanceof visual.Vertex) {
                continue; // FIXME:
            } else if (object instanceof BetterRaycastingPoints) {
                snap = object.userData.lookup(intersection.index!);
            } else if (object instanceof Empty) {
                continue;
            } else {
                if (object === undefined || object.userData === undefined || object.userData.snap === undefined) throw new Error(`invalid precondition: ${object.constructor.name} has no snap`);
                snap = object.userData.snap as Snap;
            }
            if (snap === undefined) continue;
            result.push({ snap, intersection: intersection as UnprojectableIntersection });
        }
        for (const [topologyItem, intersection] of map) {
            const snap = snaps.lookup(topologyItem);
            if (snap === undefined) continue;
            result.push({ snap, intersection: intersection as UnprojectableIntersection });
        }
        return result;
    }
}

function extractPossibleOccludersFromIntersectedGeometry(intersectedGeometry: SnapAndIntersection[]) {
    return intersectedGeometry.map(s => {
        const object = s.intersection.object;
        if (object instanceof RaycastableTopologyItem) {
            const intersection = s.intersection as IntersectableWithTopologyItem;
            return intersection.topologyItem!;
        } else
            return object;
    }) as THREE.Object3D[];
}
