import * as THREE from "three";
import { GridSnapper } from "../../components/snaps/GridSnapper";
import { Viewport } from "../../components/viewport/Viewport";
import { freeze } from "../../util/Constants";
import { BetterRaycastingPoints } from "../../visual_model/BetterRaycastingPoints";
import { Unprojectable, UnprojectableIntersection } from "../../visual_model/GeometryPicker";
import { StopEarlyRaycaster } from "../../visual_model/StopEarlyRaycaster";
import * as visual from "../../visual_model/VisualModel";
import { Scene } from "../Scene";
import { AxisSnap, axisSnapMaterial } from "./AxisSnap";
import { ConstructionPlaneSnap, FaceConstructionPlaneSnap } from "./ConstructionPlaneSnap";
import { PlaneSnap } from "./PlaneSnap";
import { PointSnap } from "./PointSnap";
import { AdvancedPointSnapCache, PointSnapCache } from "./PointSnapCache";
import { PreferrableSnap, Restriction, Snap } from "./Snap";
import { originSnap, xAxisSnap, yAxisSnap, zAxisSnap } from "./SnapManager";
import { SnapManagerGeometryCache } from "./SnapManagerGeometryCache";
import { SnapPickerStrategy } from "./SnapPickerStrategy";
import { CurveEdgeSnap, CurveSegmentSnap, FaceCenterPointSnap, FaceSnap } from "./Snaps";

export const SnapManagerLayers = new THREE.Layers();
freeze(SnapManagerLayers);

/**
 * The SnapPicker is a raycaster-like object specifically for Snaps. It finds snaps directly under
 * as well as "nearby" the mouse cursor, with intersect() and nearby() operations. It performs
 * sorting/prioritization based on distance as well as snap type. It is optimized for performance,
 * using a cache for most point snaps and the existing, (optimized) geometry raycasting targets.
 */

export type RaycasterParams = THREE.RaycasterParameters & {
    Line2: { threshold: number };
    Points: { threshold: number };
    layers: THREE.Layers;
};

export const defaultIntersectParams: RaycasterParams = {
    Line: { threshold: 0.1 },
    Line2: { threshold: 30 },
    Points: { threshold: 26 },
    layers: SnapManagerLayers,
};

export const defaultNearbyParams: THREE.RaycasterParameters = {
    Points: { threshold: 200 }
};

export class SnapPicker {
    private readonly occlusionRaycaster = new StopEarlyRaycaster();

    constructor(
        protected readonly raycaster = new THREE.Raycaster(),
        private readonly strategy: SnapPickerStrategy,
    ) { }

    nearby(points: PointSnapCache[], snaps: SnapManagerGeometryCache): PointSnap[] {
        const { raycaster, strategy, viewport } = this;
        if (!snaps.enabled) return [];
        strategy.configureNearbyRaycaster(raycaster, snaps, viewport);

        const everything = [...points, snaps.geometrySnaps];
        const pointss = this.prepare(everything);

        let intersections = raycaster.intersectObjects(pointss, false);
        intersections = intersections.slice(0, 500); // NOTE: it is better to have an upper bound for when the user zooms out

        let snap_intersections = this.intersections2snaps(snaps, intersections);
        snap_intersections = this.strategy.filterByLayer(snap_intersections, raycaster.layers);
        snap_intersections = this.strategy.filterDisabled(snap_intersections, snaps);

        let i = 0;
        const result: PointSnap[] = [];
        for (const { snap } of snap_intersections) {
            if (i++ >= 15) break;
            result.push(snap as PointSnap);
        }
        return result;
    }

    private prepare(everything: PointSnapCache[]) {
        const { viewport: { renderer: { domElement: { offsetWidth, offsetHeight } } } } = this;

        const pointss: BetterRaycastingPoints[] = [];
        for (const thing of everything) pointss.push(...thing.points);
        axisSnapMaterial.resolution.set(offsetWidth, offsetHeight);
        for (const thing of everything) thing.resolution.set(offsetWidth, offsetHeight);
        return pointss;
    }

    intersect(
        additional: readonly THREE.Object3D[],
        points: readonly PointSnapCache[],
        snaps: SnapManagerGeometryCache,
        scene: Scene,
        cplane_intersection_results: (SnapResult & Unprojectable)[],
        grid: GridSnapper | undefined,
        preference: PreferrableSnap | undefined,
    ): SnapResult[] {
        if (!snaps.enabled) return [];
        const { strategy, raycaster, occlusionRaycaster, viewport } = this;

        strategy.configureIntersectRaycaster(raycaster, snaps, viewport);
        const everything = [...points, snaps.geometrySnaps];
        const pointss = this.prepare(everything);

        let geo_intersections_snaps = strategy.intersectWithGeometry(raycaster, snaps, scene);
        geo_intersections_snaps = strategy.filterDisabled(geo_intersections_snaps, snaps);

        let other_intersections_snaps = strategy.intersectWithSnaps(additional, pointss, raycaster, snaps);
        other_intersections_snaps = strategy.filterByLayer(other_intersections_snaps, raycaster.layers);
        other_intersections_snaps = strategy.filterDisabled(other_intersections_snaps, snaps);
        const restriction = strategy.inferRestrictionFromPreference(geo_intersections_snaps, other_intersections_snaps, preference);

        let results = strategy.projectIntersections(viewport, geo_intersections_snaps, other_intersections_snaps, cplane_intersection_results, restriction, grid);
        results = strategy.processXRay(viewport, results, raycaster, occlusionRaycaster, geo_intersections_snaps);
        return this.sort(results);
    }

    sort(results: SnapResult[]) {
        return results.sort(sort);
    }

    protected intersections2snaps(snaps: SnapManagerGeometryCache, intersections: THREE.Intersection[]): { snap: Snap, intersection: UnprojectableIntersection }[] {
        const result = [];
        for (const intersection of intersections) {
            const object = intersection.object;
            let snap: Snap | undefined;
            if (object instanceof visual.Region) {
                continue; // FIXME:
            } else if (object instanceof visual.Face || object instanceof visual.CurveEdge || object instanceof visual.CurveSegment) {
                snap = snaps.lookup(object);
            } else if (object instanceof visual.Vertex) {
                continue; // FIXME:
            } else if (object instanceof BetterRaycastingPoints) {
                snap = object.userData.lookup(intersection.index!);
            } else {
                snap = object.userData.snap as Snap;
            }
            if (snap === undefined) continue;
            result.push({ snap, intersection: intersection as UnprojectableIntersection });
        }
        return result;
    }

    viewport!: Viewport;
    setFromViewport(e: MouseEvent, viewport: Viewport) {
        this.setFromCamera(viewport.getNormalizedMousePosition(e), viewport.camera);
        this.viewport = viewport;
    }

    private setFromCamera(normalizedScreenPoint: THREE.Vector2, camera: THREE.Camera) {
        this.raycaster.setFromCamera(normalizedScreenPoint, camera);
    }
}

export interface SnapResult {
    snap: Snap;
    snapOrientation: THREE.Quaternion;
    position: THREE.Vector3;
    orientation: THREE.Quaternion;
    cursorPosition: THREE.Vector3;
    cursorOrientation: THREE.Quaternion;
    restriction?: Restriction;
}

function sort(i1: SnapResult, i2: SnapResult) {
    return i1.snap.priority - i2.snap.priority;
}

declare module './Snap' {
    interface Snap {
        priority: number;
    }
}

Snap.prototype.priority = 10;
FaceCenterPointSnap.prototype.priority = 0.99;
// FIXME:
// TanTanSnap.prototype.priority = 0.99;
PointSnap.prototype.priority = 1;
CurveSegmentSnap.prototype.priority = 2;
AxisSnap.prototype.priority = 2;
CurveEdgeSnap.prototype.priority = 2;
FaceConstructionPlaneSnap.prototype.priority = 3;
FaceSnap.prototype.priority = 3;
PlaneSnap.prototype.priority = 4;
ConstructionPlaneSnap.prototype.priority = 5;

originSnap.priority = 2;
xAxisSnap.priority = 4;
yAxisSnap.priority = 4;
zAxisSnap.priority = 4;
