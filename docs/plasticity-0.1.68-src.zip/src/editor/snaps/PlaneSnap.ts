import * as THREE from "three";
import { GridSnapper } from "../../components/snaps/GridSnapper";
import * as c3d from '../../kernel/kernel';
import { origin, X, Y, Z, _X, _Y, _Z } from "../../util/Constants";
import { point2point, vec2vec } from "../../util/Conversion";
import * as visual from '../../visual_model/VisualModel';
import { RaycastableSnap, Snap } from "./Snap";

const material = new THREE.MeshBasicMaterial();
material.side = THREE.DoubleSide;

const overlayLayer = new THREE.Layers();
overlayLayer.set(visual.Layers.Overlay);

export class PlaneSnap extends RaycastableSnap {
    get layers() { return overlayLayer }
    static geometry = new THREE.PlaneGeometry(10000, 10000, 2, 2);

    readonly snapper: THREE.Object3D = new THREE.Mesh(PlaneSnap.geometry, material);

    readonly n: THREE.Vector3;
    readonly p: THREE.Vector3;
    readonly x: THREE.Vector3;
    readonly orientation = new THREE.Quaternion();

    readonly basis = new THREE.Matrix4();
    readonly basisInv = new THREE.Matrix4();

    // Even small (e.g., 10e-4) errors in the orientation can screw up coplanar calculations.
    // mat.lookAt, which is awesome for getting a great orientation for a weird plane, can introduce
    // such errors.
    private static readonly mat = new THREE.Matrix4();
    private static avoidNumericalPrecisionProblems(n: THREE.Vector3, orientation: THREE.Quaternion) {
        if (n.dot(Z) === 1) {
            orientation.identity();
        } else if (n.dot(_Z) === 1) {
            orientation.set(-1, 0, 0, 0);
        } else if (n.dot(X) === 1) {
            orientation.set(0.5, 0.5, 0.5, 0.5);
        } else if (n.dot(_X) === 1) {
            orientation.set(-0.5, 0.5, 0.5, -0.5);
        } else if (n.dot(Y) === 1) {
            orientation.set(0, Math.SQRT1_2, Math.SQRT1_2, 0);
        } else if (n.dot(_Y) === 1) {
            orientation.set(Math.SQRT1_2, 0, 0, Math.SQRT1_2);
        } else {
            const { mat } = this;
            mat.lookAt(n.clone().add(origin), origin, Z);
            orientation.setFromRotationMatrix(mat).normalize();
        }
    }

    private readonly translate = new THREE.Matrix4();
    constructor(normal = Z, p = new THREE.Vector3(), x?: THREE.Vector3, readonly name?: string) {
        super();

        normal = normal.clone();
        p = p.clone();
        this.snapper.lookAt(normal);
        this.snapper.position.copy(p);
        this.n = normal;
        this.p = p;
        if (x !== undefined) {
            const { translate } = this;
            this.x = x;
            PlaneSnap.avoidNumericalPrecisionProblems(normal, this.orientation);
            const wrong_x = new THREE.Vector3(1, 0, 0).applyQuaternion(this.orientation).normalize();
            const wrongToRight = new THREE.Quaternion().setFromUnitVectors(wrong_x, x);
            this.orientation.premultiply(wrongToRight);
            translate.makeTranslation(p.x, p.y, p.z);
            this.basis.makeBasis(x, this.y.crossVectors(x, normal).normalize(), normal).premultiply(translate);
            this.basisInv.copy(this.basis).invert();
        } else {
            const { translate } = this;
            PlaneSnap.avoidNumericalPrecisionProblems(normal, this.orientation);
            this.x = new THREE.Vector3(1, 0, 0).applyQuaternion(this.orientation).normalize();
            translate.makeTranslation(p.x, p.y, p.z);
            this.basis.makeBasis(this.x, this.y.crossVectors(this.x, normal).normalize(), normal).premultiply(translate);
            this.basisInv.copy(this.basis).invert();
        }
        this.init();
    }

    private _gridFactor = 1;
    get gridFactor() { return this._gridFactor; }
    set gridFactor(factor: number) {
        if (factor > 1000 || factor < 0) throw new Error("invalid precondition");
        this._gridFactor = factor;
    }

    private readonly y = new THREE.Vector3();
    project(intersection: THREE.Vector3 | THREE.Intersection, snapToGrid?: GridSnapper) {
        const point = intersection instanceof THREE.Vector3 ? intersection : intersection.point;
        const { plane, orientation } = this;
        let position = plane.projectPoint(point, new THREE.Vector3());
        snapToGrid?.snapToGrid(position, this);
        return { position, orientation };
    }

    get plane(): THREE.Plane {
        const { n, p } = this;
        const plane = new THREE.Plane().setFromNormalAndCoplanarPoint(n, p);
        return plane;
    }

    move(to: THREE.Vector3): PlaneSnap {
        return new PlaneSnap(this.n, to);
    }

    private readonly valid = new THREE.Vector3();
    isValid(pt: THREE.Vector3): boolean {
        const { n, p } = this;
        return Math.abs(this.valid.copy(pt).sub(p).dot(n)) < 10e-4;
    }

    get placement() {
        return new c3d.Basis(point2point(this.p), vec2vec(this.n, 1), vec2vec(this.x, 1));
    }

    get isTemp() { return true }
    isRedundantWithSnap(_: Snap) { return false }
    get isPlanar() { return true }
}

