import { CompositeDisposable, Disposable } from "event-kit";
import * as THREE from "three";
import { PointPickerModel } from "../../command/point-picker/PointPickerModel";
import { GridSnapper } from "../../components/snaps/GridSnapper";
import { Viewport } from "../../components/viewport/Viewport";
import { Unprojectable } from "../../visual_model/GeometryPicker";
import * as visual from "../../visual_model/VisualModel";
import { SnapManagerGeometryCache } from "./SnapManagerGeometryCache";
import { SnapResult } from "./SnapPicker";
import { SnapPickerStrategy } from "./SnapPickerStrategy";

export class PointPickerSnapPickerStrategy extends SnapPickerStrategy {
    readonly disposable = new CompositeDisposable();
    dispose() { this.disposable.dispose(); }

    configureNearbyRaycaster(raycaster: THREE.Raycaster, snaps: SnapManagerGeometryCache, viewport: Viewport) {
        super.configureNearbyRaycaster(raycaster, snaps, viewport);
        this.toggleFaceLayer(raycaster, viewport);
    }

    configureIntersectRaycaster(raycaster: THREE.Raycaster, snaps: SnapManagerGeometryCache, viewport: Viewport) {
        super.configureIntersectRaycaster(raycaster, snaps, viewport);
        this.toggleFaceLayer(raycaster, viewport);
    }

    intersectConstructionPlane(snapToGrid: boolean, pointPicker: PointPickerModel, raycaster: THREE.Raycaster, viewport: Viewport): (SnapResult & Unprojectable)[] {
        const constructionPlane = pointPicker.actualConstructionPlaneGiven(viewport.constructionPlane, viewport.isOrthoMode);
        const intersections = raycaster.intersectObject(constructionPlane.snapper);
        if (intersections.length === 0) return [];
        const approximatePosition = intersections[0].point;
        const distance = intersections[0].distance;
        const grid = snapToGrid ? new GridSnapper(viewport.grid, constructionPlane) : undefined;
        const { position: precisePosition, orientation } = constructionPlane.project(approximatePosition, grid);
        return [{ snap: constructionPlane, snapOrientation: orientation, position: precisePosition, cursorPosition: precisePosition, orientation, cursorOrientation: orientation, distance, point: precisePosition }];
    }

    applyRestrictions(snapToGrid: boolean, pointPicker: PointPickerModel, viewport: Viewport, input: SnapResult[]): SnapResult[] {
        const constructionPlane = pointPicker.actualConstructionPlaneGiven(viewport.constructionPlane, viewport.isOrthoMode);
        const restriction = pointPicker.restrictionFor(constructionPlane, viewport.isOrthoMode);

        if (restriction === undefined) return input.filter(info => !constructionPlane.isRedundantWithSnap(info.snap));

        input = input.filter(info => restriction.isCompatibleWithSnap(info.snap));

        const grid = snapToGrid ? new GridSnapper(viewport.grid, constructionPlane) : undefined;

        const output = [];
        for (const info of input) {
            if (!restriction.isValid(info.position)) continue;
            const { position, orientation, match } = restriction.project(info.position, grid);
            info.position = position;
            info.orientation = orientation;
            info.restriction = match !== undefined ? match : restriction;
            output.push(info);
        }
        return output;
    }

    grid(snapToGrid: boolean, pointPicker: PointPickerModel, viewport: Viewport): GridSnapper | undefined {
        const constructionPlane = pointPicker.actualConstructionPlaneGiven(viewport.constructionPlane, viewport.isOrthoMode);
        return snapToGrid ? new GridSnapper(viewport.grid, constructionPlane) : undefined;
    }

    private toggleFaceLayer(raycaster: THREE.Raycaster, viewport: Viewport) {
        const { disposable } = this;
        if (viewport.isOrthoMode && viewport.isXRay) {
            raycaster.layers.disable(visual.Layers.Face);
            disposable.add(new Disposable(() => { raycaster.layers.enable(visual.Layers.Face); }));
        }
    }
}
