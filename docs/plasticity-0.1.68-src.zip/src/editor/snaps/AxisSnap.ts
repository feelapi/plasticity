import * as THREE from "three";
import { Line2 } from "three/examples/jsm/lines/Line2";
import { LineGeometry } from "three/examples/jsm/lines/LineGeometry";
import { LineMaterial } from "three/examples/jsm/lines/LineMaterial";
import { GridSnapper } from "../../components/snaps/GridSnapper";
import { origin, X, Y, Z } from "../../util/Constants";
import * as visual from "../../visual_model/VisualModel";
import { ChoosableSnap, RaycastableSnap, Snap, SnapProjection } from "./Snap";

const dotGeometry = new THREE.BufferGeometry();
dotGeometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array([0, 0, 0]), 3));
const dotMaterial = new THREE.PointsMaterial({ size: 5, sizeAttenuation: false });
const lineSubtleMaterial = new THREE.LineBasicMaterial({ color: 0xFF00FF, transparent: true, opacity: 0.05 });
const axisGeometry_line = new THREE.BufferGeometry();
const points = [];
points.push(new THREE.Vector3(0, -10_000, 0));
points.push(new THREE.Vector3(0, 10_000, 0));
axisGeometry_line.setFromPoints(points);
const axisGeometry_line2 = new LineGeometry();
axisGeometry_line2.setPositions([0, -10_000, 0, 0, 10_000, 0]);
export const axisSnapMaterial = new LineMaterial({ color: 0xaaaaaa, transparent: true, opacity: 0.1, dashed: true, gapSize: 0.1, dashSize: 0.1 });
const lineBasicMaterial = new THREE.LineBasicMaterial({ color: 0xaaaaaa, transparent: true, opacity: 0.5 });
const planeGeometry = new THREE.PlaneGeometry(100_000, 100_000, 2, 2);

const axisLayer = new THREE.Layers();
axisLayer.set(visual.Layers.Overlay);

export class AxisSnap extends RaycastableSnap implements ChoosableSnap {
    readonly snapper = new Line2(axisGeometry_line2, axisSnapMaterial);
    private readonly _helper: THREE.Object3D = new THREE.Line(axisGeometry_line, lineBasicMaterial);
    get helper() { return this._helper }
    get layers() { return axisLayer }

    static X = new AxisSnap("X", X);
    static Y = new AxisSnap("Y", Y);
    static Z = new AxisSnap("Z", Z);

    readonly n = new THREE.Vector3();
    readonly o = new THREE.Vector3();
    private readonly orientation = new THREE.Quaternion();

    constructor(readonly name: string | undefined, n: THREE.Vector3, o = new THREE.Vector3(), z = n) {
        super();
        this.snapper.position.copy(o);
        this.snapper.quaternion.setFromUnitVectors(Y, n);
        this.helper.position.copy(o);
        this.helper.quaternion.copy(this.snapper.quaternion);
        this.helper.updateMatrixWorld();

        this.n.copy(n).normalize();
        this.o.copy(o);
        this.orientation.setFromUnitVectors(Z, z);

        if (this.constructor === AxisSnap)
            this.init();
        // NOTE: All subclasses must call init()!
    }

    private readonly projection = new THREE.Vector3();
    private readonly intersectionPoint = new THREE.Vector3();
    project(point: THREE.Vector3, snapToGrid?: GridSnapper) {
        const { n, o, orientation } = this;
        const { projection, intersectionPoint } = this;
        const position = projection.copy(n).multiplyScalar(n.dot(intersectionPoint.copy(point).sub(o))).add(o).clone();
        snapToGrid?.snapToGrid(position, this);
        return { position, orientation };
    }

    isValid(pt: THREE.Vector3): boolean {
        const { n, o } = this;
        return _valid.copy(pt).sub(o).cross(n).lengthSq() < 10e-6;
    }

    move(delta: THREE.Vector3) {
        return new PointAxisSnap(this.name!.toLowerCase(), this.n, this.o.clone().add(delta));
    }

    rotate(quat: THREE.Quaternion) {
        const { o } = this;
        return new AxisSnap(this.name?.toLowerCase(), this.n.clone().applyQuaternion(quat), o);
    }

    private readonly plane = new THREE.Mesh(planeGeometry, new THREE.MeshBasicMaterial({ color: 0x11111, side: THREE.DoubleSide }));
    private readonly eye = new THREE.Vector3();
    private readonly dir = new THREE.Vector3();
    private readonly align = new THREE.Vector3();
    private readonly matrix = new THREE.Matrix4();
    private readonly intersection = new THREE.Vector3();
    intersect(raycaster: THREE.Raycaster, info?: { position: THREE.Vector3; orientation: THREE.Quaternion; }): SnapProjection | undefined {
        const { eye, plane, align, dir, o, n, matrix, intersection } = this;

        eye.copy(raycaster.camera.position).sub(o).normalize();

        align.copy(eye).cross(n);
        dir.copy(n).cross(align);

        matrix.lookAt(origin, dir, align);
        plane.quaternion.setFromRotationMatrix(matrix);
        plane.position.copy(o);
        plane.updateMatrixWorld();

        const intersections = raycaster.intersectObject(plane);
        if (intersections.length === 0)
            return;

        const dist = intersections[0].point.sub(o).dot(n);
        const position = intersection.copy(n).multiplyScalar(dist).add(o);
        return { position, orientation: this.orientation };
    }

    get isChoosable(): true { return true }

    projectOntoChoice(point: THREE.Vector3, info?: { position: THREE.Vector3, orientation: THREE.Quaternion }, snapToGrid?: GridSnapper) {
        return this.project(point, snapToGrid);
    }

    isCoplanar(plane: THREE.Plane): boolean {
        const { o, n } = this;
        const a = o, b = o.clone().add(n);
        return plane.distanceToPoint(a) < 10e-6 && Math.abs(plane.distanceToPoint(b)) < 10e-6;
    }

    override isCompatibleWithSnap(snap: Snap): boolean {
        if (snap === this) return true;
        if (snap instanceof AxisSnap && snap.isParallelTo(this)) return false;
        return true;
    }

    isParallelTo(other: AxisSnap) {
        return this.n.dot(other.n) > 0.9999 || this.n.dot(other.n) < -0.9999;
    }
}

export class PointAxisSnap extends AxisSnap {
    private readonly sourcePointIndicator = new THREE.Points(dotGeometry, dotMaterial);

    constructor(readonly name: string, n: THREE.Vector3, position: THREE.Vector3) {
        super(name, n, position);
        const helper = this.helper as THREE.Line;
        helper.material = lineSubtleMaterial;
        helper.add(this.sourcePointIndicator);
        this.init();
    }

    get commandName(): string {
        return `snaps:set-${this.name.toLowerCase()}`;
    }
}

export class NormalAxisSnap extends PointAxisSnap {
    constructor(n: THREE.Vector3, o: THREE.Vector3) {
        super("Normal", n, o);
    }
}

export class LineAxisSnap extends AxisSnap {
    constructor(n: THREE.Vector3, position: THREE.Vector3, private readonly excludeOrigin: boolean) {
        super(undefined, n, position)
        this.init();
    }

    override isValid(pt: THREE.Vector3): boolean {
        const { n, o, excludeOrigin } = this;
        const onLine = _valid.copy(pt).sub(o).cross(n).lengthSq() < 10e-6;
        const atOrigin = pt.distanceTo(o) > 10e-6;
        return onLine && (!excludeOrigin || atOrigin);
    }
}

const _valid = new THREE.Vector3();
