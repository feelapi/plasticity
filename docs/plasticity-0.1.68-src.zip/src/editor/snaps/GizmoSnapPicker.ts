import * as THREE from "three";
import { Choice } from "../../command/point-picker/PointPickerModel";
import { Viewport } from "../../components/viewport/Viewport";
import { Scene } from "../Scene";
import { GizmoSnapPickerStrategy } from "./GizmoSnapPickerStrategy";
import { findAllSnapsInTheSamePlace } from "./PointPickerSnapPicker";
import { PointSnap } from "./PointSnap";
import { PointSnapCache } from "./PointSnapCache";
import { RaycastableSnap } from "./Snap";
import { SnapManagerGeometryCache } from "./SnapManagerGeometryCache";
import { defaultIntersectParams, defaultNearbyParams, RaycasterParams, SnapPicker, SnapResult } from "./SnapPicker";


export class GizmoSnapPicker {
    private readonly strategy = new GizmoSnapPickerStrategy(this.intersectParams, this.nearbyParams);
    private readonly picker = new SnapPicker(this.raycaster, this.strategy);

    constructor(
        private readonly intersectParams: RaycasterParams = defaultIntersectParams,
        private readonly nearbyParams: THREE.RaycasterParameters = defaultNearbyParams,
        private readonly raycaster = new THREE.Raycaster()
    ) { }

    setFromViewport(e: MouseEvent, viewport: Viewport) {
        this.picker.setFromViewport(e, viewport);
    }

    nearby(points: PointSnapCache[], snaps: SnapManagerGeometryCache, scene: Scene): PointSnap[] {
        return this.picker.nearby([], snaps);
    }

    intersect(snaps: SnapManagerGeometryCache, additional: RaycastableSnap[], points: PointSnapCache[], choice: Choice | undefined, scene: Scene): SnapResult[] {
        const { picker, strategy, raycaster } = this;
        const snappers = additional.map(s => s.snapper);
        const intersections = picker.intersect(snappers, points, snaps, scene, [], undefined, undefined);
        if (choice !== undefined) {
            const chosen = strategy.intersectChoice(choice, raycaster);
            const projected = strategy.projectIntersectionOntoChoice(choice, intersections);
            const result = projected.concat(chosen);
            return result;
        }
        return findAllSnapsInTheSamePlace(intersections);
    }
}
