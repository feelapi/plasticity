import * as THREE from "three";
import * as c3d from '../../kernel/kernel';
import { Y, Z } from "../../util/Constants";
import { point2point, vec2vec } from "../../util/Conversion";
import { lookAt } from "../../util/Util";
import { line_helper } from "../../visual_model/RenderedSceneBuilder";
import * as visual from '../../visual_model/VisualModel';
import { CrossPoint } from "../curves/CrossPointDatabase";
import { AxisSnap, NormalAxisSnap, PointAxisSnap } from "./AxisSnap";
import { PlanarOrRestriction } from "./OrRestriction";
import { PlaneSnap } from "./PlaneSnap";
import { PointSnap, TangentPointSnap } from "./PointSnap";
import { ChoosableSnap, PreferrableSnap, RaycastableSnap, Restriction, Snap, SnapProjection } from "./Snap";

const overlayLayer = new THREE.Layers();
overlayLayer.set(visual.Layers.Overlay);

export abstract class TopologyPointSnap extends PointSnap {
    abstract get item(): visual.Item;
}

export class CircleEdgeCenterPointSnap extends TopologyPointSnap {
    get layers() { return overlayLayer }

    constructor(position: THREE.Vector3, axis: THREE.Vector3, private readonly view: visual.CurveEdge) {
        super("Center", position, axis);
    }

    override get helper() {
        const slice = this.view.slice();
        slice.material = line_helper;
        return slice;
    }

    get item() { return this.view.parentItem }
}

export class CircleCurveCenterPointSnap extends TopologyPointSnap {
    get layers() { return overlayLayer }

    constructor(position: THREE.Vector3, axis: THREE.Vector3, private readonly view: visual.CurveSegment) {
        super("Center", position, axis);
    }

    get item() { return this.view.parentItem }
}

export class CircularNurbsCenterPointSnap extends TopologyPointSnap {
    get layers() { return overlayLayer }

    constructor(center: THREE.Vector3, z: THREE.Vector3, private readonly view: visual.CurveEdge) {
        super("Center", center, z);
    }

    override get helper() {
        const slice = this.view.slice();
        slice.material = line_helper;
        return slice;
    }

    get item() { return this.view.parentItem }
}

const segmentLayer = new THREE.Layers();
segmentLayer.set(visual.Layers.CurveSegment);

export class CrossPointSnap extends PointSnap {
    get layers() { return segmentLayer }

    constructor(readonly cross: CrossPoint, readonly curve1: CurveSegmentSnap, readonly curve2: CurveSegmentSnap) {
        super("Intersection", cross.position);
    }

    additionalSnapsFor(point: THREE.Vector3) {
        let result: RaycastableSnap[] = [];
        result = result.concat(this.curve1.additionalSnapsFor(point));
        result = result.concat(this.curve2.additionalSnapsFor(point));
        return result;
    }
}

export class AxisAxisCrossPointSnap extends PointSnap {
    get layers() { return overlayLayer }

    private readonly _helper = new THREE.Group();
    get helper() { return this._helper }

    constructor(readonly cross: CrossPoint, readonly axis1: AxisSnap, readonly axis2: AxisSnap) {
        super("Intersection", cross.position);
        this._helper.add(axis1.helper.clone());
        this._helper.add(axis2.helper.clone());
    }
}

export abstract class CurvePointSnap extends TopologyPointSnap {
    get layers() { return segmentLayer }

    constructor(readonly name: string, position: THREE.Vector3, tangent: THREE.Vector3, readonly curveSnap: CurveSegmentSnap, protected readonly _t: number) {
        super(name, position, tangent);
    }

    t(_: any) { return this._t }

    get view() { return this.curveSnap.view }
    get model() { return this.curveSnap.model }

    additionalSnapsFor(point: THREE.Vector3) {
        return this.curveSnap.additionalSnapsFor(point);
    }

    override restrictionFor(point: THREE.Vector3): Restriction | undefined {
        return this.curveSnap.restrictionFor(point);
    }

    override additionalSnapsGivenPreviousSnap(point: THREE.Vector3, lastPickedSnap?: Snap): (PointSnap | RaycastableSnap)[] {
        return this.curveSnap.additionalSnapsGivenPreviousSnap(point, lastPickedSnap);
    }

    get item() { return this.view.parentItem }

    get tangentSnap(): PointAxisSnap {
        return new PointAxisSnap("Tangent", this.normal, this.position);
    }
}

export class CurveMidpointSnap extends CurvePointSnap {

}

export class CurveClosestPointSnap extends CurvePointSnap {
    constructor(position: THREE.Vector3, tangent: THREE.Vector3, curveSnap: CurveSegmentSnap, t: number) {
        super("Closest", position, tangent, curveSnap, t);
    }
}


export class AxisCurveCrossPointSnap extends CurvePointSnap {
    constructor(readonly cross: CrossPoint, private readonly axis: AxisSnap, readonly curve: CurveSegmentSnap) {
        // FIXME: tangent is wrong
        super("Intersection", cross.position, Z, curve, cross.on2.t);
    }

    get helper() { return this.axis.helper }

    additionalSnapsFor(point: THREE.Vector3) {
        return this.curve.additionalSnapsFor(point);
    }
}

export class CurveEndPointSnap extends CurvePointSnap {
}

const edgeLayer = new THREE.Layers();
edgeLayer.set(visual.Layers.Edge);

export class EdgePointSnap extends TopologyPointSnap {
    get layers() { return edgeLayer }

    constructor(name: string, position: THREE.Vector3, tangent: THREE.Vector3, readonly edgeSnap: CurveEdgeSnap) {
        super(name, position, tangent);
    }

    override get helper() { return this.edgeSnap.helper }

    override restrictionFor(point: THREE.Vector3) {
        return this.edgeSnap.restrictionFor(point);
    }

    get item() { return this.edgeSnap.view.parentItem }

    get tangent() { return this.normal }
}

export class EdgeEndpointSnap extends EdgePointSnap {
    constructor(position: THREE.Vector3, tangent: THREE.Vector3, readonly t: number, edgeSnap: CurveEdgeSnap) {
        super("End", position, tangent, edgeSnap);
    }

    override restrictionFor(point: THREE.Vector3) {
        const planar = this.planes;
        if (planar.length === 0) return undefined;
        else if (planar.length === 1) return planar[0];
        else return new PlanarOrRestriction(planar);
    }

    get planes() {
        const edge = this.edgeSnap.model;
        let faces: c3d.FaceCollection;
        const { left, right } = edge.GetVertices();
        if (this.t === 0 && left !== undefined) {
            faces = left.GetFaces();
        } else if (this.t === 1 && right !== undefined) {
            faces = right.GetFaces();
        } else return [];

        const planar = [];
        for (const face of faces.GetFaces()) {
            const { u, v, position } = face.GetAnyPointOn();
            const { normal } = face.EvalBasis(u, v);
            planar.push(new PlaneSnap(vec2vec(normal, 1), point2point(position)));
        }

        return planar;
    }
}

export class AxisEdgeCrossPointSnap extends EdgePointSnap {
    constructor(readonly cross: CrossPoint, private readonly axis: AxisSnap, readonly edge: CurveEdgeSnap) {
        // FIXME: tangent is wrong
        super("Intersection", cross.position, Z, edge);
    }

    additionalSnapsFor(point: THREE.Vector3): RaycastableSnap[] {
        return this.edge.additionalSnapsFor(point);
    }
}

const faceLayer = new THREE.Layers();
faceLayer.set(visual.Layers.Face);

export class FaceCenterPointSnap extends TopologyPointSnap {
    get layers() { return faceLayer }

    constructor(position: THREE.Vector3, normal: THREE.Vector3, readonly faceSnap: FaceSnap) {
        super("Center", position, normal);
    }

    override project(point: THREE.Vector3) {
        const position = this.position;
        const orientation = lookAt(this.normal);
        return { position, orientation };
    }

    additionalSnapsFor(point: THREE.Vector3) {
        const normalSnap = new NormalAxisSnap(this.normal, point);
        return [normalSnap];
    }

    get normalSnap(): PointAxisSnap {
        return this.faceSnap.additionalSnapsFor(this.position)[0];
    }

    get placement() {
        return this.faceSnap.placement;
    }

    get item() { return this.faceSnap.view.parentItem }

    override restrictionFor(point: THREE.Vector3): PlaneSnap {
        return this.faceSnap.restrictionFor(point);
    }
}

export class CurveEdgeSnap extends Snap implements ChoosableSnap {
    get layers() { return edgeLayer }
    readonly name = "Edge";

    constructor(readonly view: visual.CurveEdge, readonly model: c3d.Edge) {
        super();
    }

    override get helper() {
        const slice = this.view.slice();
        slice.material = line_helper;
        return slice;
    }

    t(point: THREE.Vector3) {
        return this.model.FindPointNear(point2point(point));
    }

    project(point: THREE.Vector3) {
        const { model } = this;
        const { exact, t } = model.FindPointNear(point2point(point));
        const position = point2point(exact);
        const { tangent } = model.GetPointAndTangent(t);
        const orientation = new THREE.Quaternion().setFromUnitVectors(Z, vec2vec(tangent, 1));
        return { position, orientation };
    }

    get isChoosable(): true { return true }

    projectOntoChoice(point: THREE.Vector3) {
        const { model } = this;
        const { curve } = model.GetCurve();
        const { exact, t } = curve.FindPointNear(point2point(point));
        const position = point2point(exact);
        const { tangent } = curve.EvalBasis(t);
        const orientation = new THREE.Quaternion().setFromUnitVectors(Z, vec2vec(tangent, 1));
        return { position, orientation };
    }

    intersect(raycaster: THREE.Raycaster, info?: { position: THREE.Vector3, orientation: THREE.Quaternion }): SnapProjection | undefined {
        const { model } = this;
        const { curve } = model.GetCurve();
        const ray = raycaster.ray;
        const { exact, t } = curve.Raycast(vec2vec(ray.origin, 1), vec2vec(ray.direction, 1));
        const position = point2point(exact);
        const { tangent } = curve.EvalBasis(t);
        const orientation = new THREE.Quaternion().setFromUnitVectors(Z, vec2vec(tangent, 1));
        return { position, orientation };
    }

    isValid(pt: THREE.Vector3): boolean {
        const { exact, t } = this.model.FindPointNear(point2point(pt));
        const result = pt.manhattanDistanceTo(point2point(exact)) < 10e-4;
        return result;
    }

    restrictionFor(point: THREE.Vector3): Restriction | undefined {
        const planar = this.planes;
        if (planar.length === 0) return undefined;
        else if (planar.length === 1) return planar[0];
        else return new PlanarOrRestriction(planar);
    }

    get planes() {
        const faces = this.model.GetFaces().Planar();

        const planar = [];
        for (const face of faces.GetFaces()) {
            const { u, v, position } = face.GetAnyPointOn();
            const { normal } = face.EvalBasis(u, v);
            planar.push(new PlaneSnap(vec2vec(normal, 1), point2point(position)));
        }

        return planar;
    }

    get item() { return this.view.parentItem }
}

const zero = new THREE.Vector3();
const quat = new THREE.Quaternion();
const tmp = new THREE.Vector3();

export class CurveSegmentSnap extends Snap {
    get layers() { return segmentLayer }
    readonly name = "Curve";

    constructor(readonly view: visual.CurveSegment, readonly model: c3d.Edge, private readonly basis: c3d.Basis | undefined) {
        super();
    }

    t(point: THREE.Vector3) {
        return this.model.FindPointNear(point2point(point)).t;
    }

    project(point: THREE.Vector3) {
        const { exact, t } = this.model.FindPointNear(point2point(point));
        const position = point2point(exact);
        const { tangent } = this.model.GetPointAndTangent(t);
        const orientation = new THREE.Quaternion().setFromUnitVectors(Z, vec2vec(tangent, 1));
        if (this.basis !== undefined) {
            tmp.copy(Y).applyQuaternion(orientation);
            quat.setFromUnitVectors(tmp, vec2vec(this.basis.Axis, 1));
            orientation.premultiply(quat);
        }
        return { position, orientation };
    }

    isValid(pt: THREE.Vector3): boolean {
        const { exact } = this.model.FindPointNear(point2point(pt));
        const result = pt.manhattanDistanceTo(point2point(exact)) < 10e-4;
        return result;
    }

    additionalSnapsFor(point: THREE.Vector3) {
        const { model } = this;
        const { t } = model.FindPointNear(point2point(point));
        const basis = model.EvalBasis(t);
        const normal = vec2vec(basis.normal, 1);
        const binormal = vec2vec(basis.binormal, 1);
        const tangent = vec2vec(basis.tangent, 1);

        // in the case of straight lines, there is a tangent but no normal/binormal
        if (normal.manhattanDistanceTo(zero) < 10e-6) {
            normal.copy(tangent).cross(Z);
            if (normal.manhattanDistanceTo(zero) < 10e-6)
                normal.copy(tangent).cross(Y);
            normal.normalize();
        }
        if (binormal.manhattanDistanceTo(zero) < 10e-6) {
            binormal.copy(normal).cross(tangent);
            binormal.normalize();
        }

        const normalSnap = new PointAxisSnap("Normal", normal, point);
        const binormalSnap = new PointAxisSnap("Binormal", binormal, point);
        const tangentSnap = new PointAxisSnap("Tangent", tangent, point);
        return [normalSnap, binormalSnap, tangentSnap];
    }

    override additionalSnapsGivenPreviousSnap(last: THREE.Vector3, lastPickedSnap?: Snap) {
        const result: PointSnap[] = [];
        const { model } = this;
        const { exact, t } = model.FindPointNear(point2point(last));
        const closest = new CurveClosestPointSnap(point2point(exact), new THREE.Vector3(), this, t);
        result.push(closest);

        const { curve } = model.GetCurve();
        if (curve instanceof c3d.Circle) {
            const circle1 = curve;
            if (lastPickedSnap instanceof CurveSegmentSnap || lastPickedSnap instanceof CurvePointSnap) {
                const model = lastPickedSnap.model;
                const { curve: circle2 } = model.GetCurve();
                if (circle2.Id() !== circle1.Id() && circle2 instanceof c3d.Circle) {
                    const points = circle1.CommonTangents(circle2);
                    for (let i = 0; i < points.length; i += 2) {
                        const point1 = point2point(points[i]), point2 = point2point(points[i + 1]);
                        result.push(new TanTanSnap(point1, point2));
                        result.push(new TanTanSnap(point2, point1));
                    }
                }
            } else {
                const points = circle1.TangentsToPoint(point2point(last));
                for (const point of points) {
                    result.push(new TangentPointSnap(point2point(point)));
                }
            }
        }
        return result;
    }

    override restrictionFor(point: THREE.Vector3): Restriction | undefined {
        const { model } = this;
        const { t } = model.FindPointNear(point2point(point));
        const basis = model.EvalBasis(t);
        const tangent = vec2vec(basis.tangent, 1);

        return new PlaneSnap(tangent, point);
    }

    get item() { return this.view.parentItem }
}

export class TanTanSnap extends PointSnap {
    get layers() { return segmentLayer }

    constructor(readonly point1: THREE.Vector3, readonly point2: THREE.Vector3) {
        super("Tan/Tan", point2);
    }
}

abstract class AbstractFaceSnap<T extends visual.Face | visual.Region> extends Snap implements ChoosableSnap, PreferrableSnap {
    constructor(readonly view: T, readonly model: c3d.Face) {
        super();
    }

    project(point: THREE.Vector3) {
        const { model } = this;
        const { u, v, exact } = model.FindPointNear(point2point(point));
        const basis = model.EvalBasis(u, v);
        const position = point2point(exact);
        const normal = vec2vec(basis.normal, 1);
        const orientation = lookAt(normal);
        return { position, orientation };
    }

    uv(point: THREE.Vector3) {
        const { model } = this;
        const { u, v } = model.FindPointNear(point2point(point));
        return { u, v };
    }

    isValid(point: THREE.Vector3): boolean {
        const { model } = this;
        const { exact } = model.FindPointNear(point2point(point));
        const position = point2point(exact);
        const result = point.manhattanDistanceTo(position) < 10e-4;
        return result;
    }

    restrictionFor(point: THREE.Vector3) {
        const { model } = this;
        const { u, v } = model.FindPointNear(point2point(point));
        const basis = model.EvalBasis(u, v);
        const normal = vec2vec(basis.normal, 1);
        const plane = new PlaneSnap(normal, point);
        return plane;
    }

    additionalSnapsFor(point: THREE.Vector3) {
        const { model } = this;
        const { u, v, exact } = model.FindPointNear(point2point(point));
        const basis = model.EvalBasis(u, v);
        const normal = vec2vec(basis.normal, 1);
        const normalSnap = new NormalAxisSnap(normal, point);
        return [normalSnap];
    }

    get isChoosable(): true { return true }

    intersect(raycaster: THREE.Raycaster, info?: { position: THREE.Vector3, orientation: THREE.Quaternion }): SnapProjection | undefined {
        if (info === undefined) return;
        const orientation = info.orientation;
        _z.set(0, 0, 1).applyQuaternion(orientation);
        const plane = _plane.setFromNormalAndCoplanarPoint(_z, info.position);
        const position = raycaster.ray.intersectPlane(plane, new THREE.Vector3());
        if (position === null) return;
        return { position, orientation };
    }

    projectOntoChoice(point: THREE.Vector3, info?: { position: THREE.Vector3, orientation: THREE.Quaternion }) {
        if (info === undefined) throw new Error("invalid state");
        const orientation = info.orientation;
        _z.set(0, 0, 1).applyQuaternion(orientation);
        const plane = _plane.setFromNormalAndCoplanarPoint(_z, info.position);
        const position = plane.projectPoint(point, new THREE.Vector3());
        return { position, orientation };

    }

    get placement() {
        if (!this.model.IsPlanar()) return undefined;
        const { u, v, position } = this.model.GetAnyPointOn();
        const { normal, uDirection } = this.model.EvalBasis(u, v);
        return new c3d.Basis(position, normal, uDirection);
    }

    get item() { return this.view.parentItem }

    equals(other: PreferrableSnap): boolean {
        if (!(other instanceof AbstractFaceSnap)) return false;
        return this.view.simpleName === other.view.simpleName;
    }
}
const _z = new THREE.Vector3(0, 0, 1);
const _plane = new THREE.Plane();

export class FaceSnap extends AbstractFaceSnap<visual.Face> {
    get layers() { return faceLayer }
    readonly name = "Face";
}

const regionLayer = new THREE.Layers();
regionLayer.set(visual.Layers.Region);

export class RegionSnap extends AbstractFaceSnap<visual.Region> {
    get layers() { return regionLayer }
    readonly name = "Region";
}