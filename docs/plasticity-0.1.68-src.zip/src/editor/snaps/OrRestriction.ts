import * as THREE from "three";
import { PlaneSnap } from "./PlaneSnap";
import { Restriction, Snap } from "./Snap";


export class OrRestriction<R extends Restriction> implements Restriction {
    private readonly set = new Set(this.underlying);

    constructor(protected readonly underlying: R[]) { }

    isCompatibleWithSnap(snap: Snap): boolean {
        for (const restriction of this.underlying) {
            if (restriction.isCompatibleWithSnap(snap)) {
                return true;
            }
        }
        return false;
    }

    isValid(pt: THREE.Vector3): boolean {
        for (const restriction of this.underlying) {
            if (restriction.isValid(pt)) {
                return true;
            }
        }
        return false;
    }

    project(point: THREE.Vector3): { position: THREE.Vector3; orientation: THREE.Quaternion; match: R; } {
        for (const restriction of this.underlying) {
            if (restriction.isValid(point)) {
                return { ...restriction.project(point), match: restriction };
            }
        }
        throw new Error("Invalid precondition: no valid matches");
    }

    find(restriction: Restriction | undefined): R {
        if (!this.set.has(restriction as R)) throw new Error("Invalid precondition");
        return restriction as R;
    }

    get isPlanar() { return false }
}

export class PlanarOrRestriction extends OrRestriction<PlaneSnap> {

}