import * as THREE from "three";
import { Z } from "../../util/Constants";
import { lookAt } from "../../util/Util";
import * as visual from "../../visual_model/VisualModel";
import { AxisSnap } from "./AxisSnap";
import { Snap } from "./Snap";

export abstract class PointSnap extends Snap {
    readonly position: THREE.Vector3;

    constructor(readonly name?: string, position = new THREE.Vector3(), protected readonly normal = Z) {
        super();
        this.position = position.clone();
    }

    project(point: THREE.Vector3) {
        const position = this.position;
        const orientation = lookAt(this.normal);
        return { position, orientation };
    }

    axes(axisSnaps: Iterable<AxisSnap>) {
        const o = this.position.clone();
        const result = [];
        for (const snap of axisSnaps) {
            result.push(snap.move(o));
        }

        return result;
    }

    isValid(pt: THREE.Vector3): boolean {
        return this.position.manhattanDistanceTo(pt) < 10e-6;
    }
}

const mat = new THREE.Matrix4();

const overlayLayer = new THREE.Layers();
overlayLayer.set(visual.Layers.Overlay);

export class OriginSnap extends PointSnap {
    get layers() { return overlayLayer }
    project(point: THREE.Vector3) {
        return { position: this.position, orientation: new THREE.Quaternion() };
    }
}

export class PickedPointSnap extends PointSnap {
    get layers() { return overlayLayer }

    constructor(point: THREE.Vector3) {
        super(undefined, point);
    }
}

export class NamedPointSnap extends PointSnap {
    get layers() { return overlayLayer }
}

const segmentLayer = new THREE.Layers();
segmentLayer.set(visual.Layers.CurveSegment);


export class TangentPointSnap extends PointSnap {
    get layers() { return segmentLayer }
    constructor(point: THREE.Vector3) {
        super("Tangent", point);
    }
}