import * as THREE from "three";
import { GridSnapper } from "../../components/snaps/GridSnapper";
import { PointSnap } from "./PointSnap";

export interface Restriction {
    isCompatibleWithSnap(snap: Snap): unknown;
    isValid(pt: THREE.Vector3): boolean;
    project(point: THREE.Vector3, snapToGrid?: GridSnapper): SnapProjection;
    get isPlanar(): boolean;
}

export abstract class Snap implements Restriction {
    readonly name?: string = undefined;
    abstract get layers(): THREE.Layers;

    // another indicator, like a long line for axis snaps
    get helper(): THREE.Object3D | undefined {
        return undefined;
    }

    abstract project(point: THREE.Vector3, snapToGrid?: GridSnapper): SnapProjection;
    abstract isValid(pt: THREE.Vector3): boolean;

    restrictionFor(point: THREE.Vector3): Restriction | undefined { return; }
    additionalSnapsFor(point: THREE.Vector3): RaycastableSnap[] { return []; }
    additionalSnapsGivenPreviousSnap(point: THREE.Vector3, lastPickedSnap?: Snap): (RaycastableSnap | PointSnap)[] { return []; }

    get isChoosable() { return false };
    isCompatibleWithSnap(snap: Snap): boolean { return true }
    get isPlanar() { return false }
}

/**
 * Whereas a Snap represents any snap target, many kinds of snap have specially optimized
 * picking/raycasting implementations. However, some snaps, the "RaycastableSnaps", have
 * a generic raycasting implementation with a "snapper" object.
 * 
 */
export abstract class RaycastableSnap extends Snap {
    abstract readonly snapper: THREE.Object3D; // the actual object to snap to, used in raycasting when snapping

    protected init() {
        const { snapper, helper } = this;
        if (snapper === helper)
            throw new Error("Snapper should not === helper because snappers have userData and helpers should be simple cloneable objects");

        snapper.updateMatrixWorld();

        snapper.userData.snap = this;
        snapper.traverse(c => {
            c.userData.snap = this;
        });
    }
}

export interface ChoosableSnap extends Snap {
    intersect(raycaster: THREE.Raycaster, info?: { position: THREE.Vector3; orientation: THREE.Quaternion; }): SnapProjection | undefined;
    projectOntoChoice(point: THREE.Vector3, info?: { position: THREE.Vector3, orientation: THREE.Quaternion }, snapToGrid?: GridSnapper): SnapProjection;
    get isChoosable(): true;
}

export interface PreferrableSnap extends Snap {
    equals(other: Snap): boolean;
}

export function assertChoosable(snap: Snap): asserts snap is ChoosableSnap {
    if (!snap.isChoosable)
        throw new Error("Snap is not choosable");
}

export type SnapProjection = {
    position: THREE.Vector3;
    orientation: THREE.Quaternion;
    match?: Restriction;
};

