import { SnapPickerStrategy } from "./SnapPickerStrategy";


export class GizmoSnapPickerStrategy extends SnapPickerStrategy {
}
