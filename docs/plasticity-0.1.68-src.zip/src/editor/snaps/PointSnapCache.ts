// TODO:
// - [ ] Unclear if geometry is ever disposed of
import * as THREE from "three";
import { BetterRaycastingPoints, BetterRaycastingPointsMaterial } from "../../visual_model/BetterRaycastingPoints";
import * as visual from "../../visual_model/VisualModel";
import { ReadonlySnapManager, SnapsForItem } from "../snaps/SnapManager";
import { PointSnap } from "./PointSnap";

export interface PointSnapCache {
    get points(): ReadonlySet<BetterRaycastingPoints>;
    get resolution(): THREE.Vector2;
}

export class AbstractPointSnapCache implements PointSnapCache {
    protected readonly material = new BetterRaycastingPointsMaterial();
    get resolution() { return this.material.resolution; }

    protected _points: Set<BetterRaycastingPoints> = new Set();
    get points() { return this._points; }

    add(points: ReadonlySet<PointSnap>) {
        const pointInfo = new Float32Array(points.size * 3);
        let j = 0;
        for (const point of points) {
            pointInfo.set(point.position.toArray(), j * 3);
            j++;
        }
        const pointsGeometry = new THREE.BufferGeometry();
        pointsGeometry.setAttribute('position', new THREE.Float32BufferAttribute(pointInfo, 3));
        const picker = new BetterRaycastingPoints(pointsGeometry, this.material);
        picker.userData.lookup = (index: number) => {
            return Array.from(points)[index];
        }
        this._points.add(picker);
    }
}

export class SimplePointSnapCache extends AbstractPointSnapCache {
    clear() { this._points.clear() }
}

export class AdvancedPointSnapCache extends AbstractPointSnapCache {
    private readonly map = new Map<visual.ItemId, BetterRaycastingPoints>();

    constructor(private readonly snaps: ReadonlySnapManager) { super() }

    addSnapForItem(parentName: visual.ItemId, snapsForItem: SnapsForItem) {
        const { snaps } = this;
        const { faces, edges, segments } = snapsForItem;

        const pointInfo = new Float32Array(faces.centers.positions.length + edges.halves.positions.length + edges.circles.quarters.length + edges.circles.centers.length + segments.halves.positions.length + segments.circles.quarters.length + segments.circles.centers.length);
        let offset = 0;
        pointInfo.set(faces.centers.positions, offset); offset += faces.centers.positions.length;
        pointInfo.set(edges.halves.positions, offset); offset += edges.halves.positions.length;
        pointInfo.set(edges.circles.quarters, offset); offset += edges.circles.quarters.length;
        pointInfo.set(edges.circles.centers, offset); offset += edges.circles.centers.length;
        pointInfo.set(segments.halves.positions, offset); offset += segments.halves.positions.length;
        pointInfo.set(segments.circles.quarters, offset); offset += segments.circles.quarters.length;
        pointInfo.set(segments.circles.centers, offset); offset += segments.circles.centers.length;


        const pointsGeometry = new THREE.BufferGeometry();
        registry.register(this, pointsGeometry);

        pointsGeometry.setAttribute('position', new THREE.Float32BufferAttribute(pointInfo, 3));
        const picker = new BetterRaycastingPoints(pointsGeometry, this.material);

        const lookup = (i: number) => {
            if (i < 0) throw new Error("Invalid index");
            if (i > offset / 3) throw new Error("Invalid index");

            if (i < faces.centers.positions.length / 3) {
                return snaps.lookupPoint(parentName, 'faces.centers', i);
            }
            i -= faces.centers.positions.length / 3;

            if (i < edges.halves.positions.length / 3) {
                return snaps.lookupPoint(parentName, 'edges.halves', i);
            }
            i -= edges.halves.positions.length / 3;

            if (i < edges.circles.quarters.length / 3) {
                return snaps.lookupPoint(parentName, 'edges.circles.quarters', i);
            }
            i -= edges.circles.quarters.length / 3;

            if (i < edges.circles.centers.length / 3) {
                return snaps.lookupPoint(parentName, 'edges.circles.centers', i);
            }
            i -= edges.circles.centers.length / 3;

            if (i < segments.halves.positions.length / 3) {
                return snaps.lookupPoint(parentName, 'segments.halves', i);
            }
            i -= segments.halves.positions.length / 3;

            if (i < segments.circles.quarters.length / 3) {
                return snaps.lookupPoint(parentName, 'segments.circles.quarters', i);
            }
            i -= segments.circles.quarters.length / 3;

            if (i < segments.circles.centers.length / 3) {
                return snaps.lookupPoint(parentName, 'segments.circles.centers', i);
            }

            throw new Error("Invalid index");
        };

        const lookupMap = new Map<number, PointSnap>();
        picker.userData.lookup = (i: number) => {
            const cached = lookupMap.get(i);
            if (cached !== undefined) return cached;
            const point = lookup(i);
            lookupMap.set(i, point);
            return point;
        }

        this._points.add(picker);
        this.map.set(parentName, picker);
    }

    lookupSnapsForItem(parentName: visual.ItemId) {
        return this.map.get(parentName);
    }

    addPrecomputedSnapsForItem(parentName: visual.ItemId, points: BetterRaycastingPoints) {
        points.material = this.material;
        this._points.add(points);
        this.map.set(parentName, points);
    }
}

const registry = new FinalizationRegistry((geo: THREE.BufferGeometry) => {
    geo.dispose();
});