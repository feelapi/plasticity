import * as THREE from "three";
import * as c3d from '../../kernel/kernel';
import { origin, X, Y, Z } from "../../util/Constants";
import * as visual from "../../visual_model/VisualModel";
import { AxisSnap } from "./AxisSnap";
import { PlaneSnap } from "./PlaneSnap";
import { RaycastableSnap, Snap } from "./Snap";
import { FaceSnap } from "./Snaps";

export interface ConstructionPlane extends RaycastableSnap {
    get n(): THREE.Vector3;
    get p(): THREE.Vector3;
    get x(): THREE.Vector3 | undefined;
    get orientation(): THREE.Quaternion;
    get placement(): c3d.Basis;
    move(vector: THREE.Vector3): ConstructionPlane;
    isRedundantWithSnap(snap: Snap): boolean;
    get isTemp(): boolean;
}

const cplaneLayer = new THREE.Layers();
cplaneLayer.set(visual.Layers.Overlay);

// The main purpose of this class is to have a lower priority in raycasting than other, explicitly added snaps.
export class ConstructionPlaneSnap extends PlaneSnap implements ConstructionPlane {
    #nominal: undefined;

    get layers() { return cplaneLayer }

    move(to: THREE.Vector3) {
        return new ConstructionPlaneSnap(this.n, to);
    }

    // NOTE: A construction plane accepts all points, projecting them
    override isValid(pt: THREE.Vector3) { return true }

    get isTemp() { return this.name === undefined }

    get isBasic() {
        return this.p.distanceToSquared(origin) < 1e-6 && this.isAxisAligned;
    }

    get isAxisAligned() {
        return Math.abs(Math.abs(this.n.dot(X)) - 1) < 1e-6 ||
            Math.abs(Math.abs(this.n.dot(Y)) - 1) < 1e-6 ||
            Math.abs(Math.abs(this.n.dot(Z)) - 1) < 1e-6
    };

    override isCompatibleWithSnap(snap: Snap): boolean {
        if (snap instanceof AxisSnap && !snap.isCoplanar(this.plane)) return false;
        return true;
    }

    get isPlanar() { return true }
}

const faceLayer = new THREE.Layers();
faceLayer.set(visual.Layers.Face);

export class FaceConstructionPlaneSnap extends PlaneSnap implements ConstructionPlane {
    #nominal: undefined;

    get layers() { return faceLayer }

    constructor(normal: THREE.Vector3, p: THREE.Vector3, x: THREE.Vector3 | undefined, readonly faceSnap: FaceSnap) {
        super(normal, p, x, "Face plane");
    }

    isRedundantWithSnap(snap: Snap) {
        return snap === this.faceSnap;
    }

    move(pt: THREE.Vector3) {
        return new FaceConstructionPlaneSnap(this.n, pt, this.x, this.faceSnap);
    }

    override isValid(pt: THREE.Vector3) { return true }
    get isTemp() { return true }

    get isBasic() {
        return this.p.distanceToSquared(origin) < 1e-6 && this.isAxisAligned;
    }

    get isAxisAligned() {
        return Math.abs(Math.abs(this.n.dot(X)) - 1) < 1e-6 ||
            Math.abs(Math.abs(this.n.dot(Y)) - 1) < 1e-6 ||
            Math.abs(Math.abs(this.n.dot(Z)) - 1) < 1e-6

    }

    get view() { return this.faceSnap.view }
    get model() { return this.faceSnap.model }
}
