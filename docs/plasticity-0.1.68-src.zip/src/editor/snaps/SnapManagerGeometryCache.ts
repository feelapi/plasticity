import * as THREE from "three";
import { assertUnreachable } from "../../util/Util";
import * as intersectable from "../../visual_model/Intersectable";
import { ReadonlySnapManager } from "../snaps/SnapManager";
import { PointSnap } from "./PointSnap";
import { AdvancedPointSnapCache } from "./PointSnapCache";
import { RaycastableSnap, Snap } from "./Snap";

export class SnapManagerGeometryCache {
    get resolution() { return this._geometrySnaps.resolution; }

    get enabled() { return this.snaps.enabled }
    get snapToGrid() { return this.snaps.snapToGrid }

    constructor(private readonly snaps: ReadonlySnapManager) {
        this.update();
    }

    private _basic: THREE.Object3D[] = [];
    get basic() { return this._basic }

    get layers() { return this.snaps.layers }

    private _geometrySnaps!: AdvancedPointSnapCache;
    get geometrySnaps() { return this._geometrySnaps }

    update() {
        const { basicSnaps, geometrySnaps, crossSnaps } = this.snaps.all;
        const old = this._geometrySnaps;

        const result = [];
        const geometrySnapCache = new AdvancedPointSnapCache(this.snaps);
        this._geometrySnaps = geometrySnapCache;

        for (const { simpleName, snaps } of geometrySnaps) {
            if (old !== undefined) {
                const existing = old.lookupSnapsForItem(simpleName);
                if (existing !== undefined) {
                    geometrySnapCache.addPrecomputedSnapsForItem(simpleName, existing);
                    continue;
                }
                geometrySnapCache.addSnapForItem(simpleName, snaps);
            }
        }
        for (const snap of basicSnaps) {
            if (snap instanceof PointSnap) {
                geometrySnapCache.add(new Set([snap]));
                continue;
            } else if (snap instanceof RaycastableSnap) {
                result.push(snap.snapper);
            } else assertUnreachable(snap);
        }
        geometrySnapCache.add(new Set(crossSnaps));
        this._basic = result;
    }

    lookup(intersectable: intersectable.Intersectable): Snap | undefined {
        return this.snaps.lookup(intersectable);
    }

    isDisabled(snap: Snap): boolean {
        return this.snaps.isDisabled(snap);
    }
}
