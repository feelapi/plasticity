// TODO:
// - if we have an identity map on the Body wrapper objects, the disposable/keepalive code can be simplified

import { Disposable } from 'event-kit';
import * as c3d from '../kernel/kernel';
import { MementoOriginator, MeshMemento } from './History';

export interface FacetEdgesResults {
    position: Float32Array;
    group: Int32Array;
    edge: Int32Array;
    keepAlive: any;
    bbox: Float32Array;
    accelerator?: c3d.FacetFacesAndEdgesResult;
}

export interface FaceBuffers {
    index: Uint32Array;
    position: Float32Array;
    normal: Float32Array;
    group: Int32Array;
    order: Int32Array;
    face: Int32Array;
    bbox: Float32Array;
    keepAlive: any;
    accelerator?: c3d.FacetFacesAndEdgesResult;
}

export interface MeshLike {
    faces: FaceBuffers;
    edges: FacetEdgesResults;
}

export interface MeshCreator extends MementoOriginator<MeshMemento> {
    create(objs: c3d.Body[], options: c3d.FacetOptions): Promise<{ mesh: MeshLike, disposable: Disposable }[]>;
}

const NullFaces: FaceBuffers = {
    index: new Uint32Array(),
    position: new Float32Array(),
    normal: new Float32Array(),
    group: new Int32Array(),
    order: new Int32Array(),
    face: new Int32Array(),
    bbox: new Float32Array(),
    keepAlive: null,
}

export class IncrementalMeshCreator implements MeshCreator {
    // NOTE: FacetFacesAndEdgesResults and FacetEdgesResults will free the underlying memory when they are garbage collected.
    // If any objects have a reference to their underlying memory, those references would become invalid.
    // It is the responsibility of the caller to keep the memory alive; VisualModelBuilder will do this
    // with userData on the THREE.Geometry objects.
    private readonly id2buffer: Map<c3d.EntityId, c3d.FacetFacesAndEdgesResult> = new Map();

    async create(objs: c3d.Body[], options: c3d.FacetOptions): Promise<{ mesh: MeshLike, disposable: Disposable }[]> {
        const { id2buffer } = this;
        const results: { mesh: MeshLike, disposable: Disposable }[] = [];

        const wires: c3d.Body[] = [], incremental: c3d.Body[] = [], refresh: c3d.Body[] = [], none: c3d.Body[] = [];
        for (const obj of objs) {
            if (obj.IsA() === c3d.BodyType.SpaceInstance) {
                wires.push(obj);
            } else {
                const old = id2buffer.get(obj.Id());
                if (old !== undefined && options.Incremental === c3d.FacetIncrementalType.Yes) {
                    incremental.push(obj);
                } else if (options.Incremental === c3d.FacetIncrementalType.Yes || options.Incremental === c3d.FacetIncrementalType.Refresh) {
                    refresh.push(obj);
                } else {
                    none.push(obj);
                }
            }
        }
        for (const wire of wires) {
            const result = await c3d.DisplayHelper.FacetEdges_async(wire, options);
            results.push({
                mesh: {
                    faces: NullFaces,
                    edges: {
                        position: result.position,
                        group: result.group,
                        edge: result.edge,
                        bbox: result.bbox,
                        keepAlive: result,
                    },
                }, disposable: new Disposable(),
            });
        }
        if (incremental.length > 0) {
            const clone = new c3d.FacetOptions(options);
            clone.Incremental = c3d.FacetIncrementalType.Yes;
            let faceteds = await c3d.DisplayHelper.FacetFacesAndEdges_async(incremental, clone);
            for (let i = 0; i < incremental.length; i++) {
                const obj = incremental[i], result = faceteds[i];
                const old = id2buffer.get(obj.Id());
                if (old === undefined) throw new Error("invalid state");
                const merged = old.Merge(result, obj);
                const keepAlive = [result, merged];
                results.push({
                    mesh: {
                        faces: {
                            index: merged.faceIndex, position: merged.facePosition, normal: merged.faceNormal, group: merged.faceGroup, face: merged.face, bbox: merged.faceBBox, order: merged.faceOrder, keepAlive, accelerator: merged,
                        },
                        edges: {
                            position: merged.edgePosition, group: merged.edgeGroup, edge: merged.edge, bbox: merged.edgeBBox, keepAlive, accelerator: merged,
                        },
                    },
                    disposable: new Disposable()
                });
            }
        }
        if (refresh.length > 0) {
            const clone = new c3d.FacetOptions(options);
            clone.Incremental = c3d.FacetIncrementalType.Refresh;
            let faceteds = await c3d.DisplayHelper.FacetFacesAndEdges_async(refresh, clone);
            for (let i = 0; i < refresh.length; i++) {
                const obj = refresh[i], result = faceteds[i];
                const keepAlive = [result];
                id2buffer.set(obj.Id(), result);
                // TODO: if we have an identity map on the wrapper objects, this could be done with a weakmap
                const disposable = new Disposable(() => {
                    // NOTE: if the object is deleted, we remove the buffer from the map;
                    // HOWEVER if the object is being replaced, the map is already updated.
                    const existing = id2buffer.get(obj.Id());
                    if (existing === result) {
                        id2buffer.delete(obj.Id());
                    }
                });
                results.push({
                    mesh: {
                        faces: {
                            index: result.faceIndex, position: result.facePosition, normal: result.faceNormal, group: result.faceGroup, face: result.face, bbox: result.faceBBox, order: result.faceOrder, keepAlive, accelerator: result,
                        },
                        edges: {
                            position: result.edgePosition, group: result.edgeGroup, edge: result.edge, bbox: result.edgeBBox, keepAlive, accelerator: result,
                        },
                    },
                    disposable
                });
            }
        }
        if (none.length > 0) {
            const clone = new c3d.FacetOptions(options);
            clone.Incremental = c3d.FacetIncrementalType.None;
            let faceteds = await c3d.DisplayHelper.FacetFacesAndEdges_async(none, clone);
            for (let i = 0; i < none.length; i++) {
                const result = faceteds[i];
                const keepAlive = [result];
                results.push({
                    mesh: {
                        faces: { index: result.faceIndex, position: result.facePosition, normal: result.faceNormal, group: result.faceGroup, face: result.face, bbox: result.faceBBox, order: result.faceOrder, keepAlive, accelerator: result },
                        edges: { position: result.edgePosition, group: result.edgeGroup, edge: result.edge, bbox: result.edgeBBox, keepAlive, accelerator: result },
                    },
                    disposable: new Disposable()
                });
            }
        }

        return results;
    }

    saveToMemento(): MeshMemento {
        return new MeshMemento(new Map(this.id2buffer));
    }

    restoreFromMemento(m: MeshMemento): void {
        (this.id2buffer as IncrementalMeshCreator['id2buffer']) = new Map(m.id2buffer);
    }

    validate() { }

    debug() {
        const { id2buffer } = this;
        console.group("Meshes");
        console.table([...id2buffer].map(([id, buf]) => { return { id, buf } }));
        console.groupEnd();
    }

    clear() {
        this.id2buffer.clear();
    }
}
