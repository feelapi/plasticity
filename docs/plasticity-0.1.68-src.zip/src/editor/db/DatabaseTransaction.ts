import * as c3d from '../../kernel/kernel';
import * as visual from "../../visual_model/VisualModel";
import { ReadonlyGeometryDatabase } from '../DatabaseLike';
import { Empty } from '../Empties';
import { Group } from '../Groups';
import { NodeItem, RealNodeItem } from '../Nodes';

export interface DatabaseTransaction {
    added: { model: c3d.Body }[];
    deleted: ({ view: visual.Item; model: c3d.Body } | { view: Group } | { view: Empty })[];
    replaced: { from: { view: visual.Item; model: c3d.Body }; model: c3d.Body }[];
    hidden: { view: RealNodeItem }[];
    unhidden: { view: RealNodeItem }[];
    selectable: { view: NodeItem }[];
    unselectable: { view: NodeItem }[];
    visible: { view: NodeItem }[];
    invisible: { view: NodeItem }[];
    moved: { view: RealNodeItem, to: Group }[];
}

export class TransactionBuilder implements DatabaseTransaction {
    readonly added: { model: c3d.Body }[] = [];
    readonly deleted: ({ view: visual.Item; model: c3d.Body } | { view: Group } | { view: Empty })[] = [];
    readonly replaced: { from: { view: visual.Item; model: c3d.Body }; model: c3d.Body }[] = [];
    readonly hidden: { view: RealNodeItem }[] = [];
    readonly unhidden: { view: RealNodeItem }[] = [];
    readonly selectable: { view: NodeItem }[] = [];
    readonly unselectable: { view: NodeItem }[] = [];
    readonly visible: { view: NodeItem }[] = [];
    readonly invisible: { view: NodeItem }[] = [];
    readonly moved: { view: RealNodeItem, to: Group }[] = [];
    readonly sketched: { view: visual.Face }[] = [];
    readonly unsketched: { view: visual.Face }[] = [];

    constructor(private readonly geo: ReadonlyGeometryDatabase) { }

    add(...models: c3d.Body[]) {
        for (const model of models) this.added.push({ model });
    }

    delete(...views: RealNodeItem[]) {
        for (const view of views) {
            if (view instanceof visual.Item) {
                const model = this.geo.lookup(view);
                this.deleted.push({ view, model });
            } else if (view instanceof Group) {
                this.deleted.push({ view });
            } else if (view instanceof Empty) {
                this.deleted.push({ view });
            }
        }
    }

    replace(view: visual.Item, model: c3d.Body) {
        const from = this.geo.lookup(view);
        this.replaced.push({ from: { view, model: from }, model });
    }

    hide(...views: RealNodeItem[]) {
        for (const view of views) this.hidden.push({ view });
    }

    unhide(...views: RealNodeItem[]) {
        for (const view of views) this.unhidden.push({ view });
    }

    select(...views: NodeItem[]) {
        for (const view of views) this.selectable.push({ view });
    }

    unselect(...views: NodeItem[]) {
        for (const view of views) this.unselectable.push({ view });
    }

    makeVisible(...views: NodeItem[]) {
        for (const view of views) this.visible.push({ view });
    }

    makeInvisible(...views: NodeItem[]) {
        for (const view of views) this.invisible.push({ view });
    }

    move(view: RealNodeItem, to: Group) {
        this.moved.push({ view, to });
    }
}
