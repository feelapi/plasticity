import { Viewport } from '../../components/viewport/Viewport';
import * as c3d from '../../kernel/kernel';
import { SelectionDatabase } from '../../selection/SelectionDatabase';
import { SequentialExecutor } from '../../util/SequentialExecutor';
import { GConstructor } from '../../util/Util';
import { RenderedSceneBuilder } from '../../visual_model/RenderedSceneBuilder';
import * as visual from "../../visual_model/VisualModel";
import { CrossPointDatabase } from '../curves/CrossPointDatabase';
import { PlanarCurveDatabase } from '../curves/PlanarCurveDatabase';
import { SketchManager } from '../curves/SketchManager';
import { Agent, ControlPointData, ReadonlyGeometryDatabase, StableId, TemporaryObject, TopologyData, VersionId } from '../DatabaseLike';
import { EditorSignals } from '../EditorSignals';
import { Empties, Empty } from '../Empties';
import { Group, Groups } from '../Groups';
import MaterialDatabase from '../MaterialDatabase';
import { MeshCreator } from '../MeshCreator';
import { NodeItem, NodeKey, Nodes, RealNodeItem } from '../Nodes';
import { LoftManager } from '../profiles/LoftManager';
import { Scene } from '../Scene';
import { SerializationDatabase } from '../serialization/SerializationDatabase';
import { SnapManager } from '../snaps/SnapManager';
import { ViewBuilder } from '../ViewBuilder';
import { DatabaseTransaction, TransactionBuilder } from './DatabaseTransaction';
import { GeometryDatabase } from './GeometryDatabase';
import { ComputeConstructionPlanes } from './transforms/ComputeConstructionPlanes';
import { ComputeCrossPoints } from './transforms/ComputeCrossPoints';
import { ComputeFragments } from './transforms/ComputeFragments';
import { ComputeSerialization } from './transforms/ComputeSerialization';
import { ComputeSketches } from "./transforms/ComputeSketches";
import { ComputeSnaps } from './transforms/ComputeSnaps';
import { ComputeTemporary } from './transforms/ComputeTemporary';
import { ComputeView } from './transforms/ComputeView';
import { ExpandHidden } from './transforms/ExpandHidden';
import { UpdateCrossPoints } from './transforms/UpdateCrossPoints';
import { UpdateFragments } from "./transforms/UpdateFragments";
import { UpdateGeometry } from './transforms/UpdateGeometry';
import { UpdateGroups } from './transforms/UpdateGroups';
import { UpdateNodes } from './transforms/UpdateNodes';
import { UpdatePhantom } from './transforms/UpdatePhantom';
import { UpdateSceneCache } from './transforms/UpdateSceneCache';
import { UpdateSelection } from './transforms/UpdateSelection';
import { UpdateSerialization } from './transforms/UpdateSerialization';
import { UpdateSketches } from "./transforms/UpdateSketches";
import { UpdateSnapCache } from './transforms/UpdateSnapCache';
import { UpdateSnaps } from './transforms/UpdateSnaps';
import { UpdateTemporary } from './transforms/UpdateTemporary';

export class Database implements ReadonlyGeometryDatabase {
    private readonly queue = new SequentialExecutor();

    private readonly expandHidden = new ExpandHidden(this.groups, this.scene);
    private readonly computeCplanes = new ComputeConstructionPlanes(this.viewports, this.geo, this.curves);
    private readonly computeView = new ComputeView(this.geo, this.views);
    private readonly updateGeometry = new UpdateGeometry('user', this.geo);
    private readonly automaticGeometry = new UpdateGeometry('automatic', this.geo);
    private readonly computeFragments = new ComputeFragments(this.geo, this.curves);
    private readonly updateFragments = new UpdateFragments(this.curves);
    private readonly computeSketches = new ComputeSketches(this.sketches);
    private readonly updateSketches = new UpdateSketches(this.sketches);
    private readonly computeCrosses = new ComputeCrossPoints(this.geo, this.crosses);
    private readonly updateCrosses = new UpdateCrossPoints(this.crosses);
    private readonly computeSnaps = new ComputeSnaps();
    private readonly updateSnaps = new UpdateSnaps(this.snaps);
    private readonly updateSnapCache = new UpdateSnapCache(this.snaps);
    private readonly updateSceneCache = new UpdateSceneCache(this.scene);
    private readonly updateNodes = new UpdateNodes(this.groups, this.nodes, this.scene);
    private readonly updateSelection = new UpdateSelection(this.selection);
    private readonly computeSerialization = new ComputeSerialization();
    private readonly updateSerialization = new UpdateSerialization(this.serialize);
    private readonly updateGroups = new UpdateGroups(this.groups, this.nodes, this.scene);

    public readonly computeTemporary = new ComputeTemporary(this.geo, this.views);
    public readonly computePhantom = new ComputeTemporary(this.geo, this.views);
    public readonly updateTemporary = new UpdateTemporary(this.geo, this.highlight);
    public readonly updatePhantom = new UpdatePhantom(this.geo);

    get temporaryObjects() { return this.geo.temporaryObjects }
    get phantomObjects() { return this.geo.phantomObjects }
    get version() { return this.geo.version }

    constructor(
        private readonly meshes: MeshCreator,
        private readonly views: ViewBuilder,
        private readonly geo: GeometryDatabase,
        private readonly serialize: SerializationDatabase,
        private readonly empties: Empties,
        private readonly groups: Groups,
        private readonly nodes: Nodes,
        private readonly scene: Scene,
        private readonly materials: MaterialDatabase,
        private readonly highlight: RenderedSceneBuilder,
        private readonly selection: SelectionDatabase,
        private readonly crosses: CrossPointDatabase,
        private readonly curves: PlanarCurveDatabase,
        private readonly snaps: SnapManager,
        private readonly sketches: SketchManager,
        private readonly lofts: LoftManager,
        private readonly viewports: Iterable<Viewport>,
        private readonly signals: EditorSignals
    ) { }

    async addItem(model: c3d.Solid): Promise<visual.Solid>;
    async addItem(model: c3d.Sheet): Promise<visual.Sheet>;
    async addItem(model: c3d.Wire): Promise<visual.SpaceInstance>;
    async addItem(model: c3d.RegionBody): Promise<visual.SketchIsland>;
    async addItem(model: c3d.Body): Promise<visual.Item>;
    async addItem(model: c3d.Body): Promise<visual.Item> {
        const txn = new TransactionBuilder(this.geo);
        txn.add(model);
        const updateGeometryResult = await this.commit(txn);

        const view = updateGeometryResult.added[0].view;
        this.signals.objectAdded.dispatch(view);
        return view;
    }

    async replaceItem(from: visual.Solid, model: c3d.Solid): Promise<visual.Solid>;
    async replaceItem(from: visual.Sheet, model: c3d.Sheet): Promise<visual.Sheet>;
    async replaceItem(from: visual.SpaceInstance, model: c3d.Wire): Promise<visual.SpaceInstance>;
    async replaceItem(from: visual.SketchIsland, model: c3d.RegionBody): Promise<visual.SketchIsland>;
    async replaceItem(from: visual.Item, model: c3d.Body): Promise<visual.Item>;
    async replaceItem(from: visual.Item, model: c3d.Body): Promise<visual.Item> {
        const txn = new TransactionBuilder(this.geo);
        txn.replace(from, model);
        const updateGeometryResult = await this.commit(txn);

        const to = updateGeometryResult.replaced[0].view;
        this.signals.objectReplaced.dispatch({ from, to });
        return to;
    }

    async removeItem(view: visual.Item, agent: Agent = 'user'): Promise<void> {
        this.signals.objectRemoved.dispatch(view);
        const txn = new TransactionBuilder(this.geo);
        txn.delete(view);
        await this.commit(txn);
    }

    disable(views: visual.Item[], options = DisableOptions.Default) {
        this.snaps.disable(views, options);
        this.crosses.disable(views);
    }

    clearDisabled() {
        this.snaps.clearDisabled();
        this.crosses.clearDisabled();
    }

    async hideItem(view: RealNodeItem, agent: Agent = 'user'): Promise<void> {
        const txn = new TransactionBuilder(this.geo);
        txn.hide(view);
        await this.commit(txn);
    }

    async unhideItem(view: RealNodeItem, agent: Agent = 'user'): Promise<void> {
        const txn = new TransactionBuilder(this.geo);
        txn.unhide(view);
        await this.commit(txn);
    }

    async makeVisible(view: NodeItem, agent: Agent = 'user'): Promise<void> {
        const txn = new TransactionBuilder(this.geo);
        txn.makeVisible(view);
        await this.commit(txn);
    }

    async makeInvisible(view: NodeItem, agent: Agent = 'user'): Promise<void> {
        const txn = new TransactionBuilder(this.geo);
        txn.makeInvisible(view);
        await this.commit(txn);
    }

    async unhideAll() {
        const hidden = this.nodes.allHidden;
        const txn = new TransactionBuilder(this.geo);
        txn.unhide(...hidden);

        await this.commit(txn);
    }

    get allHidden() { return this.nodes.allHidden }

    isHidden(view: RealNodeItem) {
        return this.scene.isHidden(view);
    }

    async makeSelectable(node: NodeItem) {
        const { updateSceneCache } = this;
        this.nodes.makeSelectable(node, true);
        updateSceneCache.calculate({});   
    }

    async makeUnselectable(node: NodeItem) {
        const { updateSceneCache } = this;
        this.nodes.makeSelectable(node, false);
        updateSceneCache.calculate({});   
    }

    async addEmpty(filePath: string): Promise<Empty> {
        const image = this.empties.addFromFilePath(filePath);
        const { updateNodes, updateSceneCache } = this;
        const update = { added: [{ view: image }], deleted: [], hidden: [], unhidden: [], visible: [], invisible: [], replaced: [], selectable: [], unselectable: [] };
        await this.queue.enqueue(async () => {
            updateNodes.calculate(update);
            updateSceneCache.calculate({});
        });
        this.signals.emptyAdded.dispatch(image);
        this.signals.databaseChanged.dispatch();
        return image;
    }

    async removeEmpty(empty: Empty) {
        const { updateNodes, updateSelection, updateSceneCache } = this;
        const update = { added: [], deleted: [{ view: empty }], hidden: [], unhidden: [], visible: [], invisible: [], replaced: [], selectable: [], unselectable: [] };
        await this.queue.enqueue(async () => {
            const result = updateNodes.calculate(update);
            updateSelection.calculate(update);
            updateSceneCache.calculate({});
            return result;
        });
        this.signals.emptyRemoved.dispatch(empty);
        this.signals.databaseChanged.dispatch();
        this.empties.remove(empty);
    }

    async createGroup(): Promise<Group> {
        const group = this.groups.create();
        const { updateNodes, updateSceneCache } = this;
        const update = { added: [{ view: group }], deleted: [], hidden: [], unhidden: [], visible: [], invisible: [], replaced: [], selectable: [], unselectable: [] };
        await this.queue.enqueue(async () => {
            updateNodes.calculate(update);
            updateSceneCache.calculate({});
        });
        this.signals.groupCreated.dispatch(group);
        return group;
    }

    async moveToGroup(node: RealNodeItem, group: Group) {
        const txn = new TransactionBuilder(this.geo);
        txn.move(node, group);
        await this.commit(txn);
    }

    async deleteGroup(group: Group) {
        const txn = new TransactionBuilder(this.geo);
        txn.delete(group);
        await this.commit(txn);
    }

    makeTransaction() {
        return new TransactionBuilder(this.geo);
    }

    async commit(txn: DatabaseTransaction) {
        const { computeView, expandHidden, updateGeometry, computeCplanes, computeFragments, automaticGeometry, updateFragments, computeSketches, updateSketches, computeCrosses, updateCrosses, computeSnaps, updateSnaps, updateSnapCache, updateSceneCache, updateNodes, updateSelection, computeSerialization, updateSerialization, updateGroups } = this;

        const updateGeometryResult = await this.queue.enqueue(async () => {
            const computeViewResult = await computeView.calculate(txn);
            const expandHiddenResult = expandHidden.calculate(computeViewResult);
            const computeCplanesResult = computeCplanes.calculate(expandHiddenResult);
            const computeFragmentsResult = await computeFragments.calculate(computeCplanesResult);
            const computeFragmentViews = await computeView.calculate(computeFragmentsResult);
            const computeSketchesResult = await computeSketches.calculate(computeFragmentViews);
            const computeSketchViews = await computeView.calculate(computeSketchesResult);
            const computeCrossPointsResult = await computeCrosses.calculate(expandHiddenResult);

            // NOTE: compute snaps for all new items, including ones that will be immediately hidden
            const computeSnapsResult = await computeSnaps.calculate(computeViewResult);

            const computeSnapsResult2 = await computeSnaps.calculate(computeSketchViews);
            const computeSerializationResult = await computeSerialization.calculate(computeViewResult);

            /// Atomically (without async interleaving) update the all datastructures ///

            const updateSketchesResult = updateSketches.calculate(computeSketchViews);
            const updateCrossPointsResult = updateCrosses.calculate(computeCrossPointsResult);
            const fragmentsResult = updateFragments.calculate(computeFragmentViews);

            const updateSnapsResult = updateSnaps.calculate(computeSnapsResult);
            const updateSnapsResult2 = updateSnaps.calculate(computeSnapsResult2);
            // NOTE: Snaps that would be hidden processed here
            const updateSnapsResult3 = updateSnaps.calculate({ ...expandHiddenResult, added: [], deleted: [] });

            const updateNodesResult = updateNodes.calculate(computeViewResult);
            const updateGeometryResult = updateGeometry.calculate(computeViewResult);
            const automaticGeometryResult = automaticGeometry.calculate(computeFragmentViews);
            const automaticGeometryResult2 = automaticGeometry.calculate(computeSketchViews);
            const updateSelectionResult = updateSelection.calculate(expandHiddenResult);
            const updateSelectionResult2 = updateSelection.calculate(computeSketchViews);
            const updateSerializationResult = updateSerialization.calculate(computeSerializationResult);
            const updateGroupsResult = updateGroups.calculate(computeViewResult);
            const updateSnapCacheResult = updateSnapCache.calculate({});
            const updateSceneCacheResult = updateSceneCache.calculate({});

            this.geo.createMark();

            return updateGeometryResult;
        })

        this.signals.databaseChanged.dispatch();
        return updateGeometryResult;
    }

    async deserialize(buffers: Buffer[]): Promise<visual.Item[]> {
        const models = [];
        for (const buffer of buffers) {
            const model = await c3d.Body.Deserialize_async(buffer);
            models.push(model);
        }

        const views = [];
        let chunkSize = 32;
        while (models.length > 0) {
            const chunk = models.splice(0, chunkSize);
            const txn = new TransactionBuilder(this.geo);
            for (const model of chunk) txn.add(model);
            const result = await this.commit(txn);
            views.push(...result.added.map(i => i.view));
            chunkSize = Math.min(1024, chunkSize + 32);
        }

        return [...views];
    }

    async restore(hidden: Set<NodeKey>, invisible: Set<NodeKey>, unselectable: Set<NodeKey>) {
        const txn = new TransactionBuilder(this.geo);
        for (const h of hidden) txn.hide(this.scene.key2item(h) as RealNodeItem);
        for (const i of invisible) txn.hide(this.scene.key2item(i) as RealNodeItem);
        for (const u of unselectable) txn.unselect(this.scene.key2item(u) as RealNodeItem);
        await this.commit(txn);
    }

    addPhantom(view: visual.Item): TemporaryObject {
        return this.geo.addTemporaryItem(view);
    }

    addTemporaryItem(view: visual.Item): TemporaryObject {
        return this.geo.addTemporaryItem(view);
    }

    optimization<T>(from: visual.Item, fast: () => T): T {
        return fast();
    }

    clearTemporaryObjects() {
        this.geo.clearTemporaryObjects();
    }

    lookupItemById(id: visual.ItemId): { view: visual.Item, model: c3d.Body } {
        return this.geo.lookupItemById(id);
    }

    lookup(object: visual.Solid): c3d.Solid;
    lookup(object: visual.Sheet): c3d.Sheet;
    lookup(object: visual.SpaceInstance): c3d.Wire;
    lookup(object: visual.SketchIsland): c3d.RegionBody;
    lookup(object: visual.Shell): c3d.Shell;
    lookup(object: visual.Item): c3d.Body;
    lookup(object: visual.Item): c3d.Body {
        return this.geo.lookup(object);
    }

    hasTopologyItem(id: visual.TopologyId): boolean {
        return this.geo.hasTopologyItem(id);
    }

    lookupTopologyItemById(id: visual.TopologyId): TopologyData {
        return this.geo.lookupTopologyItemById(id);
    }

    lookupTopologyItem(object: visual.Face): c3d.Face;
    lookupTopologyItem(object: visual.Region): c3d.Face;
    lookupTopologyItem(object: visual.CurveEdge): c3d.Edge;
    lookupTopologyItem(object: visual.CurveSegment): c3d.Edge;
    lookupTopologyItem(object: visual.Vertex): c3d.Vertex;
    lookupTopologyItem(object: visual.Edge | visual.Face | visual.CurveSegment | visual.Vertex): c3d.Face | c3d.Edge | c3d.Vertex {
        // @ts-expect-error
        return this.geo.lookupTopologyItem(object);
    }

    find<T extends visual.SketchIsland>(klass: GConstructor<T>, includeAutomatics?: boolean): { view: T, model: c3d.RegionBody }[];
    find<T extends visual.SpaceInstance>(klass: GConstructor<T>, includeAutomatics?: boolean): { view: T, model: c3d.Wire }[];
    find<T extends visual.Solid>(klass: GConstructor<T>, includeAutomatics?: boolean): { view: T, model: c3d.Solid }[];
    find<T extends visual.Sheet>(klass: GConstructor<T>, includeAutomatics?: boolean): { view: T, model: c3d.Sheet }[];
    find<T extends visual.Solid>(klass: undefined, includeAutomatics?: boolean): { view: T, model: c3d.Solid }[];
    find<T extends visual.Item>(klass?: GConstructor<T>, includeAutomatics?: boolean): { view: T, model: c3d.Body }[] {
        // @ts-expect-error
        return this.geo.find(klass, includeAutomatics);
    }

    findAll(includeAutomatics?: boolean): { view: visual.Item, model: c3d.Solid }[] {
        return this.geo.findAll(includeAutomatics);
    }

    findAutomatics() {
        return this.geo.findAutomatics()
    }

    async duplicate(...models: visual.Solid[]): Promise<visual.Solid[]>;
    async duplicate(...models: visual.Sheet[]): Promise<visual.Sheet[]>;
    async duplicate(...models: visual.SpaceInstance[]): Promise<visual.SpaceInstance[]>;
    async duplicate(...items: (visual.Solid | visual.Sheet | visual.SpaceInstance)[]): Promise<visual.Item[]> {
        // TODO: we shouldn't duplicate the faceted(?) geometry
        const txn = new TransactionBuilder(this.geo);
        for (const item of items) {
            const model = this.lookup(item);
            const dup = model.Copy();
            txn.add(dup);
        }
        const updateGeometryResult = await this.commit(txn);
        const views = updateGeometryResult.added.map(a => a.view);
        for (const view of views) {
            this.signals.objectAdded.dispatch(view);
        }
        return views;
    }

    get items() {
        return this.geo.items;
    }

    lookupCV(cv: visual.CV): ControlPointData {
        return this.geo.lookupCVById(cv.simpleName);
    }

    lookupCVById(id: visual.CVId): ControlPointData {
        return this.geo.lookupCVById(id);
    }

    lookupStableId(version: VersionId): StableId | undefined {
        return this.geo.lookupStableId(version);
    }

    lookupByStableId(stable: StableId): { view: visual.Item; model: c3d.Body; } {
        return this.geo.lookupByStableId(stable);
    }

    getName(object: RealNodeItem): string | undefined {
        return this.scene.getName(object);
    }

    clear() {
        this.geo.clear();
        this.empties.clear();
        this.nodes.clear();
        this.groups.clear();
        this.selection.selected.clear();
        this.selection.hovered.clear();
        this.crosses.clear();
        this.snaps.clear();
        this.curves.clear();
        this.meshes.clear();
        this.sketches.clear();
    }

    validate() {
        this.snaps.validate();
        this.crosses.validate();
        this.selection.selected.validate();
        this.selection.hovered.validate();
        this.curves.validate();
        this.geo.validate();
        this.nodes.validate();
        this.groups.validate();
        this.meshes.validate();
        this.empties.validate();
        this.sketches.validate();
    }

    debug() {
        console.groupCollapsed("Debug")
        console.info("Version: ", this.version);
        this.snaps.debug();
        this.selection.selected.debug();
        this.curves.debug();
        this.crosses.debug();
        this.geo.debug();
        this.nodes.debug();
        this.groups.debug();
        this.meshes.debug();
        this.sketches.debug();
        console.groupEnd();
    }
}

export enum DisableOptions {
    Default = 0,
    KeepPointSnaps = 1 << 0,
}