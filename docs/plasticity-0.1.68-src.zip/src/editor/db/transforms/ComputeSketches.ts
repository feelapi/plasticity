import * as c3d from '../../../kernel/kernel';
import * as visual from "../../../visual_model/VisualModel";
import { ReadonlySketchManager } from '../../curves/SketchManager';
import { AsyncDatabaseTransform } from './DatabaseTransform';

interface ComputeSketchesInput {
    affectedSketches: readonly c3d.Sketch[];
}

export interface ComputeSketchesOutput {
    added: { model: c3d.RegionBody }[];
    sketches: { model: c3d.Sketch }[];
    deleted: { view: visual.SketchIsland; }[];
}

export class ComputeSketches implements AsyncDatabaseTransform<ComputeSketchesInput, ComputeSketchesOutput> {
    constructor(private readonly sync: ReadonlySketchManager) { }

    async calculate<Input extends ComputeSketchesInput>(input: Input): Promise<ComputeSketchesOutput & Omit<Input, keyof ComputeSketchesOutput>> {
        const { sync } = this;
        const { affectedSketches } = input;

        const result: ComputeSketchesOutput & Omit<Input, keyof ComputeSketchesOutput> = { ...input, added: [], deleted: [], sketches: [] };

        for (const sketch of affectedSketches) {
            const sketches = sync.getIslands(sketch);
            if (sketches === undefined) continue;
            for (const view of sketches) {
                result.deleted.push({ view });
            }
        }

        for (const sketch of affectedSketches) {
            const regions = sketch.GetRegions();
            for (const model of regions) {
                result.added.push({ model });
                result.sketches.push({ model: sketch });
            }
        }

        if (result.added.length !== result.sketches.length)
            throw new Error('Invalid number of added items');

        return result;
    }
}
