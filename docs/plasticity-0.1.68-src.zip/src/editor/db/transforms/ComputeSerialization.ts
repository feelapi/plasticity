import * as c3d from '../../../kernel/kernel';
import * as visual from "../../../visual_model/VisualModel";
import { Empty } from '../../Empties';
import { Group } from '../../Groups';
import { AsyncDatabaseTransform } from './DatabaseTransform';

export interface ComputeSerializationInput {
    added: readonly ({ model: c3d.Body; view: visual.Item } | { view: Group } | { view: Empty })[];
    replaced: readonly { from: { view: visual.Item; model: c3d.Body }; model: c3d.Body; view: visual.Item; }[];
    deleted: readonly ({ view: visual.Item; model: c3d.Body } | { view: Group } | { view: Empty })[];
}

export interface ComputeSerializationOutput {
    added: { model: c3d.Body; view: visual.Item, data: Uint8Array; }[];
    deleted: { view: visual.Item; model: c3d.Body }[];
}

export class ComputeSerialization implements AsyncDatabaseTransform<ComputeSerializationInput, ComputeSerializationOutput> {
    async calculate<Input extends ComputeSerializationInput>(input: Input): Promise<ComputeSerializationOutput & Omit<Input, keyof ComputeSerializationOutput>> {
        const { added: added_, replaced, deleted: deleted_ } = input;

        const alsoAdded = replaced.map(({ model, view }) => ({ model, view }));
        const alsoDeleted = replaced.map(({ from }) => from);

        const addedItems = added_.filter(a => a.view instanceof visual.Item) as { model: c3d.Body; view: visual.Item; }[];
        const deletedItems = deleted_.filter(d => d.view instanceof visual.Item) as { view: visual.Item; model: c3d.Body; }[];

        const added = [...addedItems, ...alsoAdded];
        const deleted = [...deletedItems, ...alsoDeleted];

        const result: ComputeSerializationOutput & Omit<Input, keyof ComputeSerializationOutput> = { ...input, added: [], deleted: [] };

        for (const { model, view } of added) {
            const data = await model.Serialize_async();
            result.added.push({ model, view, data });
        }

        for (const deletion of deleted) {
            result.deleted.push(deletion);
        }

        return result;
    }
}
