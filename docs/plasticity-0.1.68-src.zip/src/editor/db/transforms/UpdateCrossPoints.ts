import * as c3d from '../../../kernel/kernel';
import { NullEntity } from '../../../util/Constants';
import { CrossPoint, CrossPointDatabase, CrossPointId, MutableCurve2Cross, MutableCurve2Touched } from '../../curves/CrossPointDatabase';
import { SyncDatabaseTransform } from './DatabaseTransform';

export interface UpdateCrossPointsInput {
    added: readonly { model: c3d.Wire; view: { simpleName: CrossPointId; }; crosses: Set<CrossPoint>; touched: Set<CrossPointId>; }[];
    deleted: readonly { view: { simpleName: CrossPointId; }; }[];
}

export interface UpdateCrossPointsOutput {
}

export class UpdateCrossPoints implements SyncDatabaseTransform<UpdateCrossPointsInput, UpdateCrossPointsOutput> {
    constructor(private readonly crosses: CrossPointDatabase) { }

    calculate<Input extends UpdateCrossPointsInput>(input: Input): UpdateCrossPointsOutput & Omit<Input, keyof UpdateCrossPointsOutput> {
        const { added, deleted } = input;
        const { crosses: sync } = this;

        for (const { view } of deleted) {
            sync.remove(view.simpleName);
        }

        for (const { model, view, crosses, touched } of added) {
            const simpleName = view.simpleName;

            const curve2cross: MutableCurve2Cross = new Map();
            const curve2touched: MutableCurve2Touched = new Map();
            const allCrosses: Set<CrossPoint> = new Set();

            curve2cross.set(simpleName, { points: new Set(), vertices: new Set() });
            curve2touched.set(simpleName, new Set(touched));

            for (const touchee of touched) {
                if (!curve2touched.has(touchee))
                    curve2touched.set(touchee, new Set());
                const orig = curve2touched.get(touchee)!;
                orig.add(simpleName);
            }

            for (const cross of crosses) {
                if (!curve2cross.has(cross.on1.bodyName))
                    curve2cross.set(cross.on1.bodyName, { points: new Set(), vertices: new Set() });
                const { points: origPoints1, vertices: origVertices1 } = curve2cross.get(cross.on1.bodyName)!;
                origPoints1.add(cross);
                if (cross.on1.vertexId !== NullEntity) origVertices1.add(cross.on1.vertexId);

                if (!curve2cross.has(cross.on2.bodyName))
                    curve2cross.set(cross.on2.bodyName, { points: new Set(), vertices: new Set() });
                const { points: origPoints2, vertices: origVertices2 } = curve2cross.get(cross.on2.bodyName)!;
                origPoints2.add(cross);
                if (cross.on2.vertexId !== NullEntity) origVertices2.add(cross.on2.vertexId);

                allCrosses.add(cross);
            }

            sync.add(simpleName, model, curve2cross, curve2touched, allCrosses);
        }

        const result: UpdateCrossPointsOutput & Omit<Input, keyof UpdateCrossPointsOutput> = { ...input };

        return result;
    }
}
