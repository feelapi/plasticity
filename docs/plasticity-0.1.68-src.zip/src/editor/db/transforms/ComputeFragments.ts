import * as c3d from '../../../kernel/kernel';
import { freeze } from '../../../util/Constants';
import * as visual from "../../../visual_model/VisualModel";
import { Curve2Info, CurveInfo, ReadonlyPlanarCurveDatabase } from '../../curves/PlanarCurveDatabase';
import { ReadonlyGeometryDatabase } from "../../DatabaseLike";
import { Empty } from '../../Empties';
import { Group } from '../../Groups';
import { NodeItem, RealNodeItem } from '../../Nodes';
import { AsyncDatabaseTransform } from './DatabaseTransform';

interface ComputeFragmentsInput {
    added: readonly { model: c3d.Body; view: visual.Item; }[];
    replaced: readonly { from: { view: visual.Item; model: c3d.Body }; model: c3d.Body; view: visual.Item; }[];
    deleted: readonly ({ view: visual.Item; model: c3d.Body } | { view: Group } | { view: Empty })[];
    hidden: readonly { view: RealNodeItem }[];
    unhidden: readonly { view: RealNodeItem }[];
    visible: readonly { view: NodeItem }[];
    invisible: readonly { view: NodeItem }[];
    sketched: { model: c3d.Face }[];
    unsketched: { id: c3d.FaceId, basis: c3d.Basis, wires: c3d.Wire[] }[];
}

export interface ComputeFragmentsOutput {
    added: { model: c3d.Wire }[];
    fragments: { edgeId: c3d.EdgeId; start: number; end: number; basis: c3d.Basis; ancestorModel: c3d.Wire; ancestorView: visual.SpaceInstance; }[];
    deleted: { view: visual.SpaceInstance; }[];
    deletedWires: { model: c3d.Wire; view: visual.SpaceInstance; }[];
    affectedSketches: c3d.Sketch[];
    replaced: never[];
    sketched: { model: c3d.Face, basis: c3d.Basis, wires: c3d.Wire[] }[];
    unsketched: { id: c3d.FaceId }[];
}

const NoOp: ComputeFragmentsOutput = freeze({
    added: [], deleted: [], replaced: [],
    fragments: [],
    deletedWires: [],
    affectedSketches: [],
    sketched: [],
    unsketched: [],
});

export class ComputeFragments implements AsyncDatabaseTransform<ComputeFragmentsInput, ComputeFragmentsOutput> {
    constructor(private readonly geo: ReadonlyGeometryDatabase, private readonly sync: ReadonlyPlanarCurveDatabase) { }

    async calculate<Input extends ComputeFragmentsInput>(input: Input): Promise<ComputeFragmentsOutput & Omit<Input, keyof ComputeFragmentsOutput>> {
        const { sync, geo } = this;

        const sketched = input.sketched;
        const unsketched = input.unsketched;
        let added = input.added.filter(x => x.model instanceof c3d.Wire) as { model: c3d.Wire; view: visual.SpaceInstance; }[];
        let deleted = input.deleted.filter(x => x.view instanceof visual.SpaceInstance) as { model: c3d.Wire; view: visual.SpaceInstance; }[];

        let replaced = input.replaced;
        for (const { from, model, view } of replaced) {
            // NOTE: An object can change type!! For example, patching a hole of a wire can convert it to a sheet.
            // Thus, we need to check if the type of `from` and `to` before trying to planarize them.
            if (from.model instanceof c3d.Wire)
                deleted.push(from as { model: c3d.Wire; view: visual.SpaceInstance });
            if (model instanceof c3d.Wire)
                added.push({ model, view: view as visual.SpaceInstance });
        }

        for (const { view } of [...input.hidden, ...input.invisible]) {
            if (!(view instanceof visual.SpaceInstance)) continue;
            const model = geo.lookup(view);
            deleted.push({ model, view });
        }

        for (const { view } of [...input.unhidden, ...input.visible]) {
            if (!(view instanceof visual.SpaceInstance)) continue;
            const model = geo.lookup(view);
            added.push({ model, view });
        }

        if (added.length === 0 && deleted.length === 0 && sketched.length === 0 && unsketched.length === 0)
            return { ...input, ...NoOp };

        const removals = [];
        const models = [];
        for (const { model } of deleted) {
            const info = this.sync.getInfoForCurve(model.Id());
            if (info === undefined) continue;

            removals.push(info);
            models.push(model);
        }

        type DeletionsAndAdditions = [c3d.Wire[], c3d.Wire[]];
        const sketch2changes: Map<c3d.Sketch, DeletionsAndAdditions> = new Map();

        for (let i = 0; i < removals.length; i++) {
            const info = removals[i];
            const model = models[i];
            if (info === undefined) continue;
            const sketch = sync.getSketchForBasis(info.basis)!;
            if (!sketch2changes.has(sketch)) sketch2changes.set(sketch, [[], []]);
            const [deletions,] = sketch2changes.get(sketch)!;
            deletions.push(model);
        }

        const curve2info: Curve2Info = new Map();
        for (const { model, view } of [...added]) {
            const placement = this.sync.planarizeAndNormalize(model);
            if (placement === undefined) continue;

            const sketch = sync.getSketchForBasis(placement);
            if (sketch === undefined) throw new Error("invalid precondition");

            const info = new CurveInfo(view.simpleName, placement);
            curve2info.set(model.Id(), info);

            if (!sketch2changes.has(sketch)) sketch2changes.set(sketch, [[], []]);
            const [, additions] = sketch2changes.get(sketch)!;
            additions.push(model);
        }

        const sketchedOutput = [];
        for (const { model } of sketched) {
            const basis = this.sync.planarizeAndNormalize(model);
            if (basis === undefined) continue;
            const sketch = sync.getSketchForBasis(basis);
            if (sketch === undefined) throw new Error("invalid precondition");
            const allEdges = model.GetEdges().GetEdges();
            const options = new c3d.WireBodyCreateFromEdgesOptions();
            const { wires } = await c3d.Wire.CreateFromEdges_async(allEdges, options);
            if (!sketch2changes.has(sketch)) sketch2changes.set(sketch, [[], []]);
            const [, additions] = sketch2changes.get(sketch)!;
            additions.push(...wires);
            sketchedOutput.push({ model, basis, wires });
        }

        for (const { basis, wires } of unsketched) {
            const sketch = sync.getSketchForBasis(basis);
            if (sketch === undefined) throw new Error("invalid precondition");
            if (!sketch2changes.has(sketch)) sketch2changes.set(sketch, [[], []]);
            const [deletions,] = sketch2changes.get(sketch)!;
            deletions.push(...wires);
        }

        const allChanges = [];
        const affectedSketches = [];
        const partition = c3d.Session.GetCurrentPartition();
        // NOTE: Creating a mark after a major change can be expensive. It is a huge performance win to create an initial
        // mark before any subsequent marks are created in a loop (where sketch.RemoveAndAdd does this to handle challenging user-data).
        // In `BenchmarkLoadLargeFile` this reduced startup time by 60 (sixty!!) seconds.
        const performanceOptimizationMark = partition.CreateMark();
        for (const [sketch, [deletions, additions]] of sketch2changes) {
            try {
                const updates = await sketch.RemoveAndAdd_async(deletions, additions);
                const updated = updates.GetBodies();
                const originally = await updates.GetOriginals_async();
                const originals = originally.GetBodies();
                for (let i = 0; i < updated.length; i++) {
                    const clone = updated[i] as c3d.Wire;
                    const original = originals[i] as c3d.Wire;
                    allChanges.push([[clone, original]]);
                }
                affectedSketches.push(sketch);
            } catch (e) {
                console.error(e);
            }
        }

        for (const [[, original]] of allChanges) {
            if (curve2info.has(original.Id())) continue;
            const info = sync.getInfoForCurve(original.Id());
            if (info === undefined) continue;
            curve2info.set(original.Id(), info);
        }

        const output: ComputeFragmentsOutput = {
            added: [],
            deleted: [],
            replaced: [],
            fragments: [],
            affectedSketches,
            deletedWires: [],
            sketched: sketchedOutput,
            unsketched: [],
        };

        Deletions: {
            const visited = new Set<visual.SpaceInstanceId>();

            for (const { model, view } of deleted) {
                const info = sync.getInfoForCurve(model.Id())!;
                if (info === undefined) continue;
                const { fragments } = info;

                for (const fragment of fragments) {
                    visited.add(fragment);

                    const view = geo.lookupItemById(fragment).view as visual.SpaceInstance;
                    output.deleted.push({ view });
                }
                output.deletedWires.push({ model, view });
            }

            for (const [[, original]] of allChanges) {
                const info = sync.getInfoForCurve(original.Id());
                if (info === undefined) continue;
                const { fragments } = info;
                const fs = fragments;
                for (const fragment of fs) {
                    if (visited.has(fragment)) continue;
                    const view = geo.lookupItemById(fragment).view as visual.SpaceInstance;
                    output.deleted.push({ view });
                }
            }

            for (const { id } of unsketched) {
                output.unsketched.push({ id });
            }
        }

        Additions: {
            const justAdded = new Map<visual.SpaceInstanceId, visual.SpaceInstance>();
            for (const { view } of added)
                justAdded.set(view.simpleName, view);

            for (const [[clone, original]] of allChanges) {
                const info = curve2info.get(original.Id());
                if (info === undefined) continue;

                const edges = clone.GetEdges();
                const originalEdges = await edges.GetOriginals_async();
                const originalIds = originalEdges.GetIds();
                const intervals = edges.GetIntervals();
                const basis = info.basis;

                const originalView = justAdded.get(info.simpleName) ?? geo.lookupItemById(info.simpleName).view as visual.SpaceInstance;
                for (const [i, fragment] of clone.Explode().entries()) {
                    const edgeId = originalIds[i];
                    const start = intervals[i * 2 + 0];
                    const end = intervals[i * 2 + 1];
                    const ancestorView = originalView;
                    const ancestorModel = original;
                    output.added.push({ model: fragment });
                    output.fragments.push({ edgeId, start, end, basis, ancestorView, ancestorModel });
                }
            }
        }

        if (output.added.length !== output.fragments.length) throw new Error("invalid postcondition");

        return { ...input, ...output };
    }
}
