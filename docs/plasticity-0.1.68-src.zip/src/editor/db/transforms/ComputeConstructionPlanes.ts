import { Viewport } from '../../../components/viewport/Viewport';
import * as c3d from '../../../kernel/kernel';
import * as visual from "../../../visual_model/VisualModel";
import { ReadonlyPlanarCurveDatabase } from '../../curves/PlanarCurveDatabase';
import { ReadonlyGeometryDatabase } from '../../DatabaseLike';
import { Empty } from '../../Empties';
import { Group } from '../../Groups';
import { FaceConstructionPlaneSnap } from '../../snaps/ConstructionPlaneSnap';
import { SyncDatabaseTransform } from './DatabaseTransform';

export interface ComputeConstructionPlaneInput {
    replaced: readonly { from: { view: visual.Item; model: c3d.Body }; model: c3d.Body; }[];
    deleted: ({ view: visual.Item; model: c3d.Body } | { view: Group } | { view: Empty })[];
}

export interface ComputeConstructionPlaneOutput {
    sketched: { model: c3d.Face }[];
    unsketched: { id: c3d.FaceId, basis: c3d.Basis, wires: c3d.Wire[] }[];
}

export class ComputeConstructionPlanes implements SyncDatabaseTransform<ComputeConstructionPlaneInput, ComputeConstructionPlaneOutput> {
    constructor(private readonly viewports: Iterable<Viewport>, private geo: ReadonlyGeometryDatabase, private sync: ReadonlyPlanarCurveDatabase) { }

    calculate<Input extends ComputeConstructionPlaneInput>(input: Readonly<Input>): ComputeConstructionPlaneOutput & Omit<Input, keyof ComputeConstructionPlaneOutput> {
        const { viewports, sync } = this;
        const results: ComputeConstructionPlaneOutput & Omit<Input, keyof ComputeConstructionPlaneOutput> = { ...input, sketched: [], unsketched: [] };

        const previousFaces = sync.faces;
        const currentFaces = new Map<c3d.FaceId, c3d.Face>();
        for (const viewport of viewports) {
            const cplane = viewport.constructionPlane;
            if (cplane instanceof FaceConstructionPlaneSnap) {
                // FIXME: the face can hold a reference to the view and the model even if they no longer exist
                // e.g., if the face has been edited or the parent object has been deleted. I'm not sure what the best solution is
                const model = cplane.model;
                currentFaces.set(model.Id(), model);
            }
        }
        for (const [id, info] of previousFaces) {
            if (!currentFaces.has(id)) {
                results.unsketched.push({ id, basis: info.basis, wires: [...info.wires] });
            }
        }
        for (const [id, model] of currentFaces) {
            if (!previousFaces.has(id)) {
                results.sketched.push({ model });
            }
        }

        return results;
    }
}
