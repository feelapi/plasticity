import * as c3d from '../../../kernel/kernel';
import * as visual from "../../../visual_model/VisualModel";
import { Empty } from '../../Empties';
import { Group, Groups } from '../../Groups';
import { NodeItem, RealNodeItem } from '../../Nodes';
import { Scene } from '../../Scene';
import { SyncDatabaseTransform } from './DatabaseTransform';

export interface ExpandHiddenInput {
    added: readonly { model: c3d.Body; view: visual.Item; }[];
    deleted: readonly ({ view: visual.Item; model: c3d.Body } | { view: Group } | { view: Empty })[];
    hidden: readonly { view: RealNodeItem; }[];
    unhidden: readonly { view: RealNodeItem; }[];
    visible: readonly { view: NodeItem; }[];
    invisible: readonly { view: NodeItem; }[];
    moved: readonly { view: RealNodeItem; to: Group; }[];
}

export interface ExpandHiddenOutput {
    added: { model: c3d.Body; view: visual.Item; }[];
    hidden: { view: RealNodeItem; }[];
    unhidden: { view: RealNodeItem; }[];
}

export class ExpandHidden implements SyncDatabaseTransform<ExpandHiddenInput, ExpandHiddenOutput> {
    constructor(private readonly groups: Groups, private readonly scene: Scene) { }

    calculate<Input extends ExpandHiddenInput>(input: Readonly<Input>): ExpandHiddenOutput & Omit<Input, keyof ExpandHiddenOutput> {
        const { scene } = this;
        const { added, deleted, hidden, unhidden, visible, invisible, moved } = input;
        const results: ExpandHiddenOutput & Omit<Input, keyof ExpandHiddenOutput> = { ...input, hidden: [], unhidden: [], added: [] };

        const { scene: tmp, nodes, groups } = scene.makeTemporary();

        // We don't want to hide an item we're going to delete
        for (const { view } of deleted) {
            if (view instanceof visual.Item) nodes.deleteItem(view);
        }

        let before, after;
        ComputeDeltasToVisibility: {
            before = tmp.snapshot(groups.root, false);

            for (const { view, to } of moved) {
                groups.moveNodeToGroup(nodes.item2key(view), to);
            }
            for (const { view } of deleted) {
                if (view instanceof Group) groups.delete(view);
            }
            for (const { view } of hidden) {
                nodes.makeHidden(view, true);
            }
            for (const { view } of unhidden) {
                nodes.makeHidden(view, false);
            }
            for (const { view } of visible) {
                nodes.makeVisible(view, true);
            }
            for (const { view } of invisible) {
                nodes.makeVisible(view, false);
            }

            after = tmp.snapshot(groups.root, false);
        }

        {
            const { hidden, unhidden } = tmp.processSnapshot(before, after);
            for (const view of hidden) {
                results.hidden.push({ view });
            }
            for (const view of unhidden) {
                results.unhidden.push({ view });
            }
        }

        // Finally, if a newly added item is going to be hidden, hide it
        const parent = groups.cwd;
        const parentIsHidden = scene.isIndirectlyHidden(parent);
        for (const a of added) {
            const { view } = a;
            if (parentIsHidden || scene.isHiddenWithin(view, parent)) continue;
            results.added.push(a);
        }

        return results;
    }
}
