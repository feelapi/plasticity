import * as c3d from '../../../kernel/kernel';
import * as visual from "../../../visual_model/VisualModel";
import { SketchManager } from '../../curves/SketchManager';
import { SyncDatabaseTransform } from './DatabaseTransform';

export interface UpdateSketchesInput {
    added: readonly { view: visual.Item }[];
    sketches: readonly { model: c3d.Sketch }[];
    affectedSketches: readonly c3d.Sketch[];
}

export interface UpdateSketchesOutput {

}

export class UpdateSketches implements SyncDatabaseTransform<UpdateSketchesInput, UpdateSketchesOutput> {
    constructor(private readonly sketches: SketchManager) { }

    calculate<Input extends UpdateSketchesInput>(input: Input): UpdateSketchesOutput & Omit<Input, keyof UpdateSketchesOutput> {
        const { sketches: sync } = this;
        const { added, sketches, affectedSketches } = input;

        if (added.length !== sketches.length) throw new Error('Invalid number of added items');

        const result: UpdateSketchesOutput & Omit<Input, keyof UpdateSketchesOutput> = { ...input };

        const map = new Map<c3d.Sketch, visual.SketchIsland[]>();
        for (const model of affectedSketches) {
            map.set(model, []);
        }

        for (let i = 0; i < added.length; i++) {
            const { model: sketch } = sketches[i];
            const view = added[i].view;

            if (!(view instanceof visual.SketchIsland)) throw new Error('Invalid view type');

            const list = map.get(sketch)!;
            list.push(view);
        }

        sync.update(map);

        return result;
    }
}
