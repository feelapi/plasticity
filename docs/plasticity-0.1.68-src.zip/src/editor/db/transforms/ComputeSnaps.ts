import * as c3d from '../../../kernel/kernel';
import * as visual from '../../../visual_model/VisualModel';
import { Empty } from "../../Empties";
import { Group } from "../../Groups";
import { SnapsForItem } from "../../snaps/SnapManager";
import { AsyncDatabaseTransform } from './DatabaseTransform';

export interface ComputeSnapsInput {
    added: readonly ({ view: visual.Item; model: c3d.Body; } | { view: Group } | { view: Empty })[];
    replaced: readonly { from: { view: visual.Item; }; view: visual.Item; model: c3d.Body; }[];
    deleted: readonly ({ view: visual.Item; } | { view: Group } | { view: Empty })[];
}

export interface ComputeSnapsOutput {
    added: { view: visual.Item, snaps: SnapsForItem; }[];
    replaced: never[];
    deleted: { view: visual.Item; }[];
}

const emptyFaces = { centers: { faceIds: new Int32Array(), positions: new Float32Array(), normals: new Float32Array() }, };
const emptyEdges = { halves: { edgeIds: new Int32Array(), positions: new Float32Array(), tangents: new Float32Array() }, circles: { edgeIds: new Int32Array(), quarters: new Float32Array(), tangents: new Float32Array(), centers: new Float32Array(), axes: new Float32Array() }, };
const emptySnapsForItem: SnapsForItem = { edges: emptyEdges, segments: emptyEdges, faces: emptyFaces };

export class ComputeSnaps implements AsyncDatabaseTransform<ComputeSnapsInput, ComputeSnapsOutput> {
    constructor() { }

    async calculate<Input extends ComputeSnapsInput>(input: Input): Promise<ComputeSnapsOutput & Omit<Input, keyof ComputeSnapsOutput>> {
        const { added, replaced, deleted } = input;

        const result: ComputeSnapsOutput & Omit<Input, keyof ComputeSnapsOutput> = { ...input, added: [], deleted: [], replaced: [] };

        const addedItems = added.filter(item => item.view instanceof visual.Item) as { view: visual.Item; model: c3d.Body; }[];
        const replacedItems = replaced.filter(item => item.view instanceof visual.Item) as { view: visual.Item; model: c3d.Body; }[];

        for (const { view, model } of [...addedItems, ...replacedItems]) {
            if (view instanceof visual.SketchIsland && model instanceof c3d.RegionBody) {
                this.addSketch(view, model);
                result.added.push({ view, snaps: emptySnapsForItem });
            } else if (view instanceof visual.Shell && model instanceof c3d.Shell) {
                const snapsForEdges = await this.addEdges(view, model);
                const snapsForFaces = await this.addFaces(view, model);
                result.added.push({ view, snaps: { edges: snapsForEdges, faces: snapsForFaces, segments: emptyEdges } });
            } else if (view instanceof visual.SpaceInstance && model instanceof c3d.Wire) {
                const snapsForEdges = await this.addCurve(view, model);
                result.added.push({ view, snaps: { segments: snapsForEdges, faces: emptyFaces, edges: emptyEdges } });
            }

        }

        for (const { view } of deleted) {
            if (!(view instanceof visual.Item)) continue;
            result.deleted.push({ view });
        }
        for (const { from: { view } } of replaced)
            result.deleted.push({ view });

        return result;
    }

    private async addSketch(item: visual.SketchIsland, model: c3d.RegionBody) {
    }

    private async addFaces(item: visual.Shell, model: c3d.Shell) {
        const faces = model.GetFaces();
        faces.Sort();
        const faceIds = faces.GetIds();
        const { positions, normals } = await faces.GetMidpoints_async();
        return { centers: { faceIds, positions, normals } };
    }

    private async addEdges(item: visual.Shell, model: c3d.Shell) {
        const edges = model.GetEdges();
        edges.Sort();
        const edgeIds = edges.GetIds();

        const { positions: halfPositions, tangents: halfTangents } = await edges.GetPoints_async([0, 0.5, 1]);
        const halves = { edgeIds, positions: halfPositions, tangents: halfTangents };

        const circular = await edges.Circular_async();
        const circularEdgeIds = circular.GetIds();
        const { positions, tangents } = await circular.GetPoints_async([0.25, 0.75]);
        const { positions: centers, axes } = await circular.GetBases_async();
        const circles = { edgeIds: circularEdgeIds, quarters: positions, tangents, centers, axes };

        return { halves, circles };
    }

    private async addCurve(item: visual.SpaceInstance, model: c3d.Wire) {
        const edges = model.GetEdges();
        edges.Sort();
        const edgeIds = edges.GetIds();
        const { positions: halfPositions, tangents: halfTangents } = await edges.GetPoints_async([0, 0.5, 1]);
        const halves = { edgeIds, positions: halfPositions, tangents: halfTangents };

        const circular = await edges.Circular_async();
        const circularEdgeIds = circular.GetIds();
        const { positions, tangents } = await circular.GetPoints_async([0.25, 0.75]);
        const { positions: centers, axes } = await circular.GetBases_async();
        const circles = { edgeIds: circularEdgeIds, quarters: positions, tangents, centers, axes };

        return { halves, circles }
    }
}
