import * as c3d from '../../../kernel/kernel';
import * as visual from "../../../visual_model/VisualModel";
import { ViewBuilder, ViewBuilderSpec } from '../../ViewBuilder';
import { NameMaker } from '../GeometryDatabase';
import { AsyncDatabaseTransform } from './DatabaseTransform';

export interface ComputeViewInput {
    added: readonly { model: c3d.Body; }[];
    replaced: readonly { from: { view: visual.Item; model: c3d.Body }; model: c3d.Body; }[];
}

export interface ComputeViewOutput {
    added: { model: c3d.Body; view: visual.Item; }[];
    replaced: { from: { view: visual.Item; model: c3d.Body }; model: c3d.Body; view: visual.Item; }[];
}

export class ComputeView implements AsyncDatabaseTransform<ComputeViewInput, ComputeViewOutput> {
    constructor(
        private readonly db: NameMaker,
        private readonly views: ViewBuilder
    ) { }

    async calculate<Input extends ComputeViewInput>(input: Input): Promise<ComputeViewOutput & Omit<Input, keyof ComputeViewOutput>> {
        const { db, views } = this;
        const { added, replaced } = input;

        const result: ComputeViewOutput & Omit<Input, keyof ComputeViewOutput> = { ...input, added: [], replaced: [] };

        {
            const addedSpecs: ViewBuilderSpec[] = [];
            for (const { model } of added) {
                const name = db.makeName();
                addedSpecs.push({ model, name });
            }
            const builts = await views.build(addedSpecs, 'real');
            for (let i = 0; i < builts.length; i++) {
                const view = builts[i];
                const { model } = addedSpecs[i];
                result.added.push({ model, view });
            }
        }

        {
            const replacedSpecs: (ViewBuilderSpec & { from: { view: visual.Item; model: c3d.Body } })[] = [];
            for (const { from, model } of replaced) {
                const name = db.makeName();
                replacedSpecs.push({ from, model, name });
            }
            const builts = await views.build(replacedSpecs, 'real');
            for (let i = 0; i < builts.length; i++) {
                const view = builts[i];
                const { from, model } = replacedSpecs[i];
                result.replaced.push({ from, model, view });
            }
        }

        return result;
    }
}
