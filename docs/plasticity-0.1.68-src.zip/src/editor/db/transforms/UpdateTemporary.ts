import * as c3d from '../../../kernel/kernel';
import { RenderedSceneBuilder } from '../../../visual_model/RenderedSceneBuilder';
import * as visual from "../../../visual_model/VisualModel";
import { MaterialOverride, TemporaryObject } from '../../DatabaseLike';
import { GeometryDatabase } from '../GeometryDatabase';
import { SyncDatabaseTransform } from './DatabaseTransform';

export interface UpdateTemporaryInput {
    added: readonly { model: c3d.Body; view: visual.Item, material?: MaterialOverride }[];
    replaced: readonly { from: { view: visual.Item }; model: c3d.Body; view: visual.Item }[];
}

export type UpdateTemporaryOutput = {
    added: { temp: TemporaryObject }[];
};

export class UpdateTemporary implements SyncDatabaseTransform<UpdateTemporaryInput, UpdateTemporaryOutput> {
    constructor(private readonly geo: GeometryDatabase, private readonly highlight: RenderedSceneBuilder) { }

    calculate<Input extends UpdateTemporaryInput>(input: Input): UpdateTemporaryOutput & Omit<Input, keyof UpdateTemporaryOutput> {
        const { geo, highlight } = this;
        const { added } = input;

        const result: UpdateTemporaryOutput & Omit<Input, keyof UpdateTemporaryOutput> = { ...input, added: [] };

        for (const { model, view, material } of added) {
            const temp = geo.addTemporaryItem(model, view);
            highlight.highlightTemporary(view, undefined, material);
            result.added.push({ temp });
        }

        for (const { from, model, view } of input.replaced) {
            const temp = geo.replaceWithTemporaryItem(from.view, model, view);
            highlight.highlightTemporary(view, from.view);
            result.added.push({ temp });
        }

        return result;
    }
}
