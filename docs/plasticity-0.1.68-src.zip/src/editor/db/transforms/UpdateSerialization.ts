import * as visual from "../../../visual_model/VisualModel";
import { VersionId } from "../../DatabaseLike";
import { SerializationDatabase } from "../../serialization/SerializationDatabase";
import { AsyncDatabaseTransform } from './DatabaseTransform';

export interface UpdateSerializationInput {
    added: readonly { view: visual.Item, data: Uint8Array; }[];
    deleted: readonly { view: visual.Item }[];
}

export interface UpdateSerializationOutput {
}

export class UpdateSerialization implements AsyncDatabaseTransform<UpdateSerializationInput, UpdateSerializationOutput> {
    constructor(private readonly serialize: SerializationDatabase) { }

    async calculate<Input extends UpdateSerializationInput>(input: Input): Promise<UpdateSerializationOutput & Omit<Input, keyof UpdateSerializationOutput>> {
        const { serialize } = this;
        const { added, deleted } = input;

        const result: UpdateSerializationOutput & Omit<Input, keyof UpdateSerializationOutput> = { ...input, added: [], deleted: [] };

        const additions = new Map<VersionId, Uint8Array>();
        for (const { view, data } of added) {
            additions.set(view.simpleName, data);
        }
        serialize.add(additions);

        const deletions: VersionId[] = [];
        for (const { view } of deleted) {
            deletions.push(view.simpleName);
        }
        serialize.remove(deletions);

        return result;
    }
}
