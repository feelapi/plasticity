import { Groups } from '../../Groups';
import { NodeItem, Nodes, RealNodeItem } from '../../Nodes';
import { Scene } from '../../Scene';
import { SyncDatabaseTransform } from './DatabaseTransform';

export interface UpdateNodesInput {
    added: readonly { view: RealNodeItem }[];
    deleted: readonly { view: RealNodeItem }[];
    hidden: readonly { view: RealNodeItem }[];
    unhidden: readonly { view: RealNodeItem }[];
    visible: readonly { view: NodeItem }[];
    invisible: readonly { view: NodeItem }[];
    selectable: readonly { view: NodeItem }[];
    unselectable: readonly { view: NodeItem }[];
}

export interface UpdateNodesOutput {
}

export class UpdateNodes implements SyncDatabaseTransform<UpdateNodesInput, UpdateNodesOutput> {
    constructor(private readonly groups: Groups, private readonly nodes: Nodes, private readonly scene: Scene) { }

    calculate<Input extends UpdateNodesInput>(input: Readonly<Input>): UpdateNodesOutput & Omit<Input, keyof UpdateNodesOutput> {
        const { groups, nodes } = this;
        const { added, deleted, hidden, unhidden, visible, invisible } = input;
        const results: UpdateNodesOutput & Omit<Input, keyof UpdateNodesOutput> = { ...input, hidden: [], unhidden: [] };

        const parent = groups.cwd;
        for (const { view } of added) {
            const k = nodes.item2key(view, view.simpleName);
            groups.addMembership(k, parent);
        }
        for (const { view } of deleted) {
            nodes.deleteItem(view);
        }

        for (const { view } of hidden) {
            this.nodes.makeHidden(view, true);
        }
        for (const { view } of unhidden) {
            this.nodes.makeHidden(view, false);
        }

        for (const { view } of invisible) {
            this.nodes.makeVisible(view, false);
        }
        for (const { view } of visible) {
            this.nodes.makeVisible(view, true);
        }

        return results;
    }
}


