import { Scene } from '../../Scene';
import { SyncDatabaseTransform } from './DatabaseTransform';

export interface UpdateSceneCacheInput {
}

export interface UpdateSceneCacheOutput {
}

export class UpdateSceneCache implements SyncDatabaseTransform<UpdateSceneCacheInput, UpdateSceneCacheOutput> {
    constructor(private readonly sync: Scene) { }

    calculate<Input extends UpdateSceneCacheInput>(input: Input): UpdateSceneCacheOutput & Omit<Input, keyof UpdateSceneCacheOutput> {
        const result: UpdateSceneCacheOutput & Omit<Input, keyof UpdateSceneCacheOutput> = { ...input };
        this.sync.update();
        return result;
    }
}
