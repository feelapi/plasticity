import * as THREE from 'three';
import * as c3d from '../../../kernel/kernel';
import * as visual from '../../../visual_model/VisualModel';
import { CrossPoint, CrossPointId, Model2View, PointOnCurve, ReadonlyCrossPointDatabase } from '../../curves/CrossPointDatabase';
import { ReadonlyGeometryDatabase } from '../../DatabaseLike';
import { Empty } from '../../Empties';
import { Group } from '../../Groups';
import { NodeItem, RealNodeItem } from '../../Nodes';
import { AsyncDatabaseTransform } from './DatabaseTransform';

export interface ComputeCrossPointInput {
    added: readonly { model: c3d.Body; view: { simpleName: CrossPointId; }; }[];
    hidden: readonly { view: RealNodeItem; }[];
    unhidden: readonly { view: RealNodeItem; }[];
    visible: readonly { view: NodeItem; }[];
    invisible: readonly { view: NodeItem; }[];
    deleted: ({ view: visual.Item; model: c3d.Body } | { view: Group } | { view: Empty })[];
    replaced: readonly { from: { view: visual.Item; model: c3d.Body }; model: c3d.Body; view: visual.Item; }[];
}

export interface ComputeCrossPointOutput {
    added: { model: c3d.Wire; view: { simpleName: CrossPointId; }; crosses: Set<CrossPoint>; touched: Set<visual.SpaceInstanceId>; }[];
    deleted: { view: { simpleName: CrossPointId; }; }[];
}

export class ComputeCrossPoints implements AsyncDatabaseTransform<ComputeCrossPointInput, ComputeCrossPointOutput> {
    constructor(private readonly geo: ReadonlyGeometryDatabase, private readonly crosses: ReadonlyCrossPointDatabase) { }

    async calculate<Input extends ComputeCrossPointInput>(input: Input): Promise<ComputeCrossPointOutput & Omit<Input, keyof ComputeCrossPointOutput>> {
        const { geo, crosses } = this;
        const { added: added_, deleted: deleted_, replaced, hidden, unhidden, visible, invisible } = input;

        const result: ComputeCrossPointOutput & Omit<Input, keyof ComputeCrossPointOutput> = { ...input, added: [], deleted: [], replaced: [] };

        const added = [...added_].filter(a => a.model instanceof c3d.Wire);
        const deleted = [...deleted_].filter(d => d.view instanceof visual.SpaceInstance) as { view: visual.SpaceInstance; model: c3d.Wire }[];

        for (const { view } of [...hidden, ...invisible]) {
            if (!(view instanceof visual.SpaceInstance)) continue;
            const model = geo.lookup(view);
            deleted.push({ model, view });
        }

        for (const { view } of [...unhidden, ...visible]) {
            if (!(view instanceof visual.SpaceInstance)) continue;
            const model = geo.lookup(view);
            added.push({ model, view });
        }

        for (const { from, model, view } of replaced) {
            if (!(from.view instanceof visual.SpaceInstance)) continue;
            deleted.push(from as { view: visual.SpaceInstance; model: c3d.Wire });
            added.push({ model, view });
        }

        const deletedIds = new Set(deleted.map(({ model }) => model.Id()));
        const existing = crosses.all;
        const toAdd = new Set(added.map(({ model }) => model.Id()));
        for (const d of deletedIds) {
            existing.delete(d);
        }
        const backup: Model2View = new Map();
        for (const { model, view } of added) {
            backup.set(model.Id(), view.simpleName);
        }

        const into = new Map<visual.SpaceInstanceId, { crosses: Set<CrossPoint>; touched: Set<visual.SpaceInstanceId>; }>();
        await this.computeCrossesWithExisting(existing, toAdd, backup, into);
        await this.computeCrossesWithMutual(toAdd, backup, into);

        for (const { model, view } of added) {
            if (!(model instanceof c3d.Wire)) throw new Error("Not a wire");
            const { crosses, touched } = into.get(view.simpleName) ?? { crosses: new Set(), touched: new Set() };
            result.added.push({ model, view, crosses, touched });
        }

        for (const { view } of deleted) {
            result.deleted.push({ view });
        }

        return result;
    }

    private async computeCrossesWithExisting(existing: Set<number>, toAdd: Set<number>, override: Model2View, into: Map<visual.SpaceInstanceId, { crosses: Set<CrossPoint>; touched: Set<visual.SpaceInstanceId>; }>) {
        const { crosses: sync } = this;

        const existingCollection = new c3d.BodyCollection(new Int32Array([...existing]));
        const toAddCollection = new c3d.BodyCollection(new Int32Array([...toAdd]));
        const { types, targets, tools } = await existingCollection.Clash_async(toAddCollection, new c3d.ClashOptions(true, false));
        if (types.length > 0) {
            const existingEdges = new c3d.EdgeCollection(targets), addedEdges = new c3d.EdgeCollection(tools);
            const { positions, t1s, t2s, bodies1, bodies2, edges1, edges2, vertices1, vertices2 } = await existingEdges.IntersectEdges_async(addedEdges);
            for (let i = 0, ii = positions.length / 3; i < ii; i++) {
                const px = positions[i * 3 + 0], py = positions[i * 3 + 1], pz = positions[i * 3 + 2]; 1
                const t1 = t1s[i], t2 = t2s[i];
                const bodyEntityId1 = bodies1[i], bodyEntityId2 = bodies2[i];
                const curveSimpleName = override.get(bodyEntityId2)!;
                const bodySimpleName = sync.modelId2viewId(bodyEntityId1)!;
                const edge1 = edges1[i], edge2 = edges2[i];
                const vertex1 = vertices1[i], vertex2 = vertices2[i];
                const cross = new CrossPoint(
                    new THREE.Vector3(px, py, pz),
                    new PointOnCurve(curveSimpleName, edge1, t1, vertex1),
                    new PointOnCurve(bodySimpleName, edge2, t2, vertex2)
                );

                if (!into.has(curveSimpleName)) into.set(curveSimpleName, { crosses: new Set(), touched: new Set() });
                const { crosses, touched } = into.get(curveSimpleName)!;
                crosses.add(cross);
                touched.add(bodySimpleName);
            }
        }
    }

    private async computeCrossesWithMutual(toAdd: Set<number>, override: Model2View, into: Map<visual.SpaceInstanceId, { crosses: Set<CrossPoint>; touched: Set<visual.SpaceInstanceId>; }>) {
        const toAddCollection = new c3d.BodyCollection(new Int32Array([...toAdd]));
        const { types, targets, tools } = await toAddCollection.ClashWithSelf_async(new c3d.ClashOptions(true, false));
        if (types.length > 0) {
            const existingEdges = new c3d.EdgeCollection(targets), addedEdges = new c3d.EdgeCollection(tools);
            const { positions, t1s, t2s, bodies1, bodies2, edges1, edges2, vertices1, vertices2 } = await existingEdges.IntersectEdges_async(addedEdges);
            for (let i = 0, ii = positions.length / 3; i < ii; i++) {
                const px = positions[i * 3 + 0], py = positions[i * 3 + 1], pz = positions[i * 3 + 2]; 1
                const t1 = t1s[i], t2 = t2s[i];
                const bodyEntityId1 = bodies1[i], bodyEntityId2 = bodies2[i];
                const curveSimpleName = override.get(bodyEntityId2)!;
                const bodySimpleName = override.get(bodyEntityId1)!;
                const edge1 = edges1[i], edge2 = edges2[i];
                const vertex1 = vertices1[i], vertex2 = vertices2[i];
                const cross = new CrossPoint(
                    new THREE.Vector3(px, py, pz),
                    new PointOnCurve(curveSimpleName, edge1, t1, vertex1),
                    new PointOnCurve(bodySimpleName, edge2, t2, vertex2)
                );

                if (!into.has(curveSimpleName)) into.set(curveSimpleName, { crosses: new Set(), touched: new Set() });
                const { crosses, touched } = into.get(curveSimpleName)!;
                crosses.add(cross);
                touched.add(bodySimpleName);
            }
        }
    }
}
