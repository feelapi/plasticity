import * as c3d from '../../../kernel/kernel';
import * as visual from "../../../visual_model/VisualModel";
import { Agent } from '../../DatabaseLike';
import { Empty } from '../../Empties';
import { Group } from '../../Groups';
import { GeometryDatabase } from '../GeometryDatabase';
import { SyncDatabaseTransform } from './DatabaseTransform';

export interface UpdateGeometryInput {
    added: readonly ({ model: c3d.Body; view: visual.Item; } | { view: Group } | { view: Empty })[];
    replaced: readonly { from: { view: visual.Item; model: c3d.Body }; model: c3d.Body; view: visual.Item; }[];
    deleted: readonly ({ view: visual.Item; } | { view: Group } | { view: Empty })[];
}

export type UpdateGeometryOutput = {
    added: { model: c3d.Body; view: visual.Item; }[];
    replaced: { from: { view: visual.Item; model: c3d.Body }; model: c3d.Body; view: visual.Item; }[];
    deleted: { model: c3d.Body; view: visual.Item; }[];
};

export class UpdateGeometry implements SyncDatabaseTransform<UpdateGeometryInput, UpdateGeometryOutput> {
    constructor(
        private readonly agent: Agent,
        private readonly geo: GeometryDatabase,
    ) { }

    calculate<Input extends UpdateGeometryInput>(input: Input): UpdateGeometryOutput & Omit<Input, keyof UpdateGeometryOutput> {
        const { agent, geo } = this;
        const { added, deleted } = input;

        const result: UpdateGeometryOutput & Omit<Input, keyof UpdateGeometryOutput> = { ...input, added: [], deleted: [], replaced: [] };

        const addedItems = added.filter(a => a.view instanceof visual.Item) as { model: c3d.Body; view: visual.Item; }[];
        const deletedItems = deleted.filter(d => d.view instanceof visual.Item) as { view: visual.Item; model: c3d.Body; }[];

        for (const { view } of deletedItems) {
            const model = geo.removeItem(view, agent);
            result.deleted.push({ model, view });
        }

        for (const { model, view } of addedItems) {
            geo.addItem(model, view, agent);
            result.added.push({ model, view });
        }

        for (const { from, model, view } of input.replaced) {
            geo.replaceItem(from.view, model, view);
            result.replaced.push({ from, model, view });
        }

        return result;
    }
}
