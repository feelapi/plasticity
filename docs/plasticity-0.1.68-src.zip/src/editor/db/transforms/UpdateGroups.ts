import * as c3d from '../../../kernel/kernel';
import * as visual from "../../../visual_model/VisualModel";
import { Empty } from '../../Empties';
import { Group, Groups } from '../../Groups';
import { Nodes, RealNodeItem } from '../../Nodes';
import { Scene } from '../../Scene';
import { SyncDatabaseTransform } from './DatabaseTransform';

export interface UpdateGroupsInput {
    moved: readonly { view: RealNodeItem, to: Group }[];
    deleted: readonly ({ view: visual.Item; model: c3d.Body } | { view: Group } | { view: Empty })[];
}

export interface UpdateGroupsOutput {
}

export class UpdateGroups implements SyncDatabaseTransform<UpdateGroupsInput, UpdateGroupsOutput> {
    constructor(private readonly groups: Groups, private readonly nodes: Nodes, private readonly scene: Scene) { }

    calculate<Input extends UpdateGroupsInput>(input: Readonly<Input>): UpdateGroupsOutput & Omit<Input, keyof UpdateGroupsOutput> {
        const { groups, nodes } = this;
        const { moved, deleted } = input;
        const results: UpdateGroupsOutput & Omit<Input, keyof UpdateGroupsOutput> = { ...input };

        for (const { view, to } of moved) {
            groups.moveNodeToGroup(nodes.item2key(view), to)
        }

        for (const { view } of deleted) {
            if (view instanceof Group) groups.delete(view);
        }

        return results;
    }
}


