import * as c3d from '../../../kernel/kernel';
import * as visual from "../../../visual_model/VisualModel";
import { TemporaryObject } from '../../DatabaseLike';
import { GeometryDatabase } from '../GeometryDatabase';
import { SyncDatabaseTransform } from './DatabaseTransform';

export interface UpdatePhantomInput {
    added: readonly { model: c3d.Body; view: visual.Item }[];
}

export type UpdatePhantomOutput = {
    added: { temp: TemporaryObject }[];
};

export class UpdatePhantom implements SyncDatabaseTransform<UpdatePhantomInput, UpdatePhantomOutput> {
    constructor(
        private readonly geo: GeometryDatabase,
    ) { }

    calculate<Input extends UpdatePhantomInput>(input: Input): UpdatePhantomOutput & Omit<Input, keyof UpdatePhantomOutput> {
        const { geo } = this;
        const { added } = input;

        const result: UpdatePhantomOutput & Omit<Input, keyof UpdatePhantomOutput> = { ...input, added: [] };

        for (const { model, view, } of added) {
            const temp = geo.addPhantom(model, view);
            result.added.push({ temp });
        }

        return result;
    }
}
