import * as c3d from '../../../kernel/kernel';
import * as visual from "../../../visual_model/VisualModel";
import { MaterialOverride } from '../../DatabaseLike';
import { ViewBuilder, ViewBuilderSpec } from '../../ViewBuilder';
import { NameMaker } from '../GeometryDatabase';
import { AsyncDatabaseTransform } from './DatabaseTransform';

export interface ComputeTemporaryInput {
    added: readonly { model: c3d.Body; material?: MaterialOverride }[];
    replaced: readonly { from: { view: visual.Item }; model: c3d.Body; material?: MaterialOverride }[];
}

export interface MutableComputeTemporaryInput {
    added: { model: c3d.Body; material?: MaterialOverride }[];
    replaced: { from: { view: visual.Item }; model: c3d.Body; material?: MaterialOverride }[];
}

export interface ComputeTemporaryOutput {
    added: { model: c3d.Body; view: visual.Item; material?: MaterialOverride; }[];
    replaced: { from: { view: visual.Item }; model: c3d.Body; view: visual.Item; material?: MaterialOverride }[];
}

export class ComputeTemporary implements AsyncDatabaseTransform<ComputeTemporaryInput, ComputeTemporaryOutput> {
    constructor(
        private readonly geo: NameMaker,
        private readonly views: ViewBuilder
    ) { }

    async calculate<Input extends ComputeTemporaryInput>(input: Input): Promise<ComputeTemporaryOutput & Omit<Input, keyof ComputeTemporaryOutput>> {
        const { geo, views } = this;
        const { added, replaced } = input;

        const result: ComputeTemporaryOutput & Omit<Input, keyof ComputeTemporaryOutput> = { ...input, added: [], replaced: [] };

        {
            const addedSpecs: ViewBuilderSpec[] = [];
            for (const { model, material } of added) {
                const tempId = geo.makeTemporaryName();
                addedSpecs.push({ model, name: tempId, material });
            }
            const builts = await views.build(addedSpecs, 'temporary');
            for (let i = 0; i < builts.length; i++) {
                const view = builts[i];
                const { model, material } = addedSpecs[i];
                result.added.push({ model, view, material });
            }
        }

        {
            const replacedSpecs: (ViewBuilderSpec & { from: { view: visual.Item } })[] = [];
            for (const { from, model, material } of replaced) {
                const tempId = geo.makeTemporaryName();
                replacedSpecs.push({ from, model, name: tempId, material });
            }
            const builts = await views.build(replacedSpecs, 'temporary');
            for (let i = 0; i < builts.length; i++) {
                const view = builts[i];
                const { from, model, material } = replacedSpecs[i];
                result.replaced.push({ from, model, view, material });
            }
        }

        return result;
    }
}
