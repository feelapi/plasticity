import * as c3d from '../../../kernel/kernel';
import * as visual from "../../../visual_model/VisualModel";
import { MutableCurveInfo, MutableFaceInfo, PlanarCurveDatabase } from '../../curves/PlanarCurveDatabase';
import { SyncDatabaseTransform } from './DatabaseTransform';

interface UpdateFragmentsInput {
    added: readonly { view: visual.Item }[];
    fragments: readonly { edgeId: c3d.EdgeId; start: number; end: number; basis: c3d.Basis; ancestorModel: c3d.Wire; ancestorView: visual.SpaceInstance }[];
    deletedWires: readonly { model: c3d.Wire; view: visual.SpaceInstance; }[];
    affectedSketches: readonly c3d.Sketch[];
    sketched: { model: c3d.Face, basis: c3d.Basis, wires: c3d.Wire[] }[];
    unsketched: { id: c3d.FaceId }[];
}

interface UpdateFragmentsOutput {
}

export class UpdateFragments implements SyncDatabaseTransform<UpdateFragmentsInput, UpdateFragmentsOutput> {
    constructor(private readonly sync: PlanarCurveDatabase) { }

    calculate<Input extends UpdateFragmentsInput>(input: Readonly<Input>): UpdateFragmentsOutput & Omit<Input, keyof UpdateFragmentsOutput> {
        const { sync } = this;
        const { added, fragments, deletedWires, sketched, unsketched } = input;

        if (added.length !== fragments.length) throw new Error('added.length !== fragments.length');

        const result: UpdateFragmentsOutput & Omit<Input, keyof UpdateFragmentsOutput> = { ...input };

        const curve2info = new Map<c3d.WireId, MutableCurveInfo>();
        for (const { basis, ancestorView, ancestorModel } of fragments) {
            if (curve2info.has(ancestorModel.Id())) continue;
            curve2info.set(ancestorModel.Id(), new MutableCurveInfo(ancestorView.simpleName, basis, []));
        }

        const face2info = new Map<c3d.FaceId, MutableFaceInfo>();
        for (const { model, basis, wires } of sketched) {
            face2info.set(model.Id(), new MutableFaceInfo(basis, wires));
        }

        for (let i = 0; i < added.length; i++) {
            const { edgeId, start, end, ancestorModel, ancestorView } = fragments[i];
            const { view } = added[i];
            if (!(view instanceof visual.SpaceInstance)) throw new Error("Expected SpaceInstance");
            const inst = view;
            inst.befragment(edgeId, start, end, ancestorView);
            const info = curve2info.get(ancestorModel.Id())!;
            info.fragments.push(inst.simpleName);
        }

        sync.remove(
            deletedWires.map(({ model }) => model.Id()),
            unsketched.map(({ id }) => id)
        );

        sync.add(curve2info, face2info);

        return result;
    }
}
