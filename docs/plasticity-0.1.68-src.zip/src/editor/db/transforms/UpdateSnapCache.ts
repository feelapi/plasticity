import { SnapManager } from "../../snaps/SnapManager";
import { SyncDatabaseTransform } from './DatabaseTransform';

export interface UpdateSnapCacheInput {
}

export interface UpdateSnapCacheOutput {
}

export class UpdateSnapCache implements SyncDatabaseTransform<UpdateSnapCacheInput, UpdateSnapCacheOutput> {
    constructor(private readonly sync: SnapManager) { }

    calculate<Input extends UpdateSnapCacheInput>(input: Input): UpdateSnapCacheOutput & Omit<Input, keyof UpdateSnapCacheOutput> {
        const result: UpdateSnapCacheOutput & Omit<Input, keyof UpdateSnapCacheOutput> = { ...input };
        this.sync.cache.update();
        return result;
    }
}
