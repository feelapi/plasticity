import { SelectionDatabase } from '../../../selection/SelectionDatabase';
import { NodeItem, RealNodeItem } from '../../Nodes';
import { SyncDatabaseTransform } from './DatabaseTransform';
import * as visual from '../../../visual_model/VisualModel';
import { VirtualGroup } from '../../Groups';

export interface UpdateSelectionInput {
    added: readonly { view: RealNodeItem }[];
    deleted: readonly { view: RealNodeItem }[];
    hidden: readonly { view: RealNodeItem }[];
    unhidden: readonly { view: RealNodeItem }[];
    visible: readonly { view: NodeItem }[];
    invisible: readonly { view: NodeItem }[];
    replaced: readonly { from: { view: RealNodeItem } }[];
}

export interface UpdateSelectionOutput {
    hidden: { view: RealNodeItem }[];
    unhidden: { view: RealNodeItem }[];
}

export class UpdateSelection implements SyncDatabaseTransform<UpdateSelectionInput, UpdateSelectionOutput> {
    constructor(private readonly selection: SelectionDatabase) { }

    calculate<Input extends UpdateSelectionInput>(input: Readonly<Input>): UpdateSelectionOutput & Omit<Input, keyof UpdateSelectionOutput> {
        const { selection } = this;
        const { deleted, hidden, invisible, replaced } = input;
        const results: UpdateSelectionOutput & Omit<Input, keyof UpdateSelectionOutput> = { ...input, hidden: [], unhidden: [] };

        for (const { view } of deleted) {
            selection.selected.objectDeleted(view);
            selection.hovered.objectDeleted(view);
        }

        for (const { from: { view } } of replaced) {
            selection.selected.objectDeleted(view);
            selection.hovered.objectDeleted(view);
        }

        for (const { view } of hidden) {
            selection.selected.objectDeleted(view);
            selection.hovered.objectDeleted(view);
        }

        for (const { view } of invisible) {
            if (view instanceof VirtualGroup) continue;
            selection.selected.objectDeleted(view);
            selection.hovered.objectDeleted(view);
        }

        return results;
    }
}