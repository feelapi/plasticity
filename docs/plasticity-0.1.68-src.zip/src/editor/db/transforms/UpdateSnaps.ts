import * as visual from '../../../visual_model/VisualModel';
import { NodeItem, RealNodeItem } from '../../Nodes';
import { SnapManager, SnapsForItem } from "../../snaps/SnapManager";
import { SyncDatabaseTransform } from './DatabaseTransform';

export interface UpdateSnapsInput {
    added: readonly { view: visual.Item; snaps: SnapsForItem; }[];
    deleted: readonly { view: visual.Item; }[];
    hidden: readonly { view: RealNodeItem; }[];
    unhidden: readonly { view: RealNodeItem; }[];
    visible: readonly { view: NodeItem; }[];
    invisible: readonly { view: NodeItem; }[];
}

export interface UpdateSnapsOutput {
}

export class UpdateSnaps implements SyncDatabaseTransform<UpdateSnapsInput, UpdateSnapsOutput> {
    constructor(private readonly sync: SnapManager) { }

    calculate<Input extends UpdateSnapsInput>(input: Input): UpdateSnapsOutput & Omit<Input, keyof UpdateSnapsOutput> {
        const { sync } = this;
        const { added, deleted, hidden, unhidden, visible, invisible } = input;
        const result: UpdateSnapsOutput & Omit<Input, keyof UpdateSnapsOutput> = { ...input };
        for (const d of deleted) sync.delete(d.view);
        for (const a of added) sync.add(a.view, a.snaps);

        for (const h of [...hidden, ...invisible]) {
            if (!(h.view instanceof visual.Item)) continue;
            sync.hide(h.view);
        }
        for (const h of [...unhidden, ...visible]) {
            if (!(h.view instanceof visual.Item)) continue;
            sync.unhide(h.view);
        }

        return result;
    }
}
