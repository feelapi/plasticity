import * as THREE from 'three';
import * as c3d from '../../kernel/kernel';
import { GConstructor } from '../../util/Util';
import * as visual from '../../visual_model/VisualModel';
import { Agent, ControlPointData, ReadonlyGeometryDatabase, StableId, TemporaryObject, TopologyData, VersionId } from '../DatabaseLike';
import { GeometryMemento, MementoOriginator } from '../History';

export type GeometryModel = Map<VersionId, { view: visual.Item, model: c3d.Body }>;
export type TopologyModel = Map<visual.TopologyId, TopologyData>;

export interface NameMaker {
    makeName(): visual.ItemId;
    makeTemporaryName(): visual.ItemId;
}

export class GeometryDatabase implements ReadonlyGeometryDatabase, NameMaker, MementoOriginator<GeometryMemento> {
    readonly temporaryObjects = new THREE.Scene();
    readonly phantomObjects = new THREE.Scene();

    private readonly geometryModel: GeometryModel = new Map();
    private readonly version2stable = new Map<VersionId, StableId>();
    private readonly stable2version = new Map<StableId, VersionId>();
    private readonly automatics = new Set<visual.ItemId>();

    private positiveCounter = 1; // ids must be positive to distinguish real objects from temps/phantoms
    private negativeCounter = -1;

    makeName(): visual.ItemId { return this.positiveCounter++ }
    makeTemporaryName(): visual.ItemId { return this.negativeCounter-- }

    get version() { return this.positiveCounter }

    addItem(model: c3d.Body, view: visual.Item, agent: Agent): void {
        this.insertItem(model, view, agent);
        this.version2stable.set(view.simpleName, view.simpleName);
        this.stable2version.set(view.simpleName, view.simpleName);
    }

    replaceItem(from: visual.Item, model: c3d.Body, to: visual.Item): void {
        const stableName = this.version2stable.get(from.simpleName)!;

        this.insertItem(model, to, 'user');
        this.version2stable.set(to.simpleName, stableName);
        this.stable2version.set(stableName, to.simpleName);

        this._removeItem(from);
        this.version2stable.delete(from.simpleName);
    }

    removeItem(view: visual.Item, agent: Agent): c3d.Body {
        const result = this._removeItem(view);
        const old = this.version2stable.get(view.simpleName)!;
        this.version2stable.delete(view.simpleName);
        this.stable2version.delete(old);
        return result;
    }

    private insertItem(model: c3d.Body, view: visual.Item, agent: Agent) {
        const name = view.simpleName;
        this.geometryModel.set(name, { view, model });
        if (agent === 'automatic') this.automatics.add(name);
    }

    addPhantom(item: c3d.Body, view: visual.Item): TemporaryObject;
    addPhantom(view: visual.Item): TemporaryObject;
    addPhantom(item: c3d.Body | visual.Item, view?: visual.Item): TemporaryObject {
        if (item instanceof c3d.Body) {
            if (view === undefined) throw new Error('invalid precondition: temporary object must be provided');
            return this._addTemporaryItem(item, view, undefined, this.phantomObjects);
        } else {
            const { phantomObjects } = this;
            phantomObjects.add(item);
            item.visible = false;
            const temp = {
                underlying: item,
                show() { item.visible = true },
                hide() { item.visible = false },
                cancel() { phantomObjects.remove(item) }
            };
            return temp;
        }
    }

    replaceWithTemporaryItem(from: visual.Item, to: c3d.Body, view: visual.Item): TemporaryObject {
        return this._addTemporaryItem(to, view, from, this.temporaryObjects);
    }

    addTemporaryItem(model: c3d.Body, view: visual.Item): TemporaryObject;
    addTemporaryItem(view: visual.Item): TemporaryObject;
    addTemporaryItem(item: c3d.Body | visual.Item, view?: visual.Item): TemporaryObject {
        if (item instanceof c3d.Body) {
            if (view === undefined) throw new Error('invalid precondition: temporary object must be provided');
            return this._addTemporaryItem(item, view, undefined, this.temporaryObjects);
        } else {
            const { temporaryObjects } = this;
            temporaryObjects.add(item);
            item.visible = false;
            const temp = {
                underlying: item,
                show() { item.visible = true },
                hide() { item.visible = false },
                cancel() { temporaryObjects.remove(item) }
            };
            return temp;
        }
    }

    private _addTemporaryItem(model: c3d.Body, view: visual.Item, ancestor: visual.Item | undefined, into: THREE.Scene): TemporaryObject {
        into.add(view);

        view.visible = false;
        return {
            underlying: view,
            show() {
                view.visible = true;
                if (ancestor !== undefined) ancestor.visible = false;
            },
            hide() {
                view.visible = false;
                if (ancestor !== undefined) ancestor.visible = true;
            },
            cancel() {
                into.remove(view);
                if (ancestor !== undefined) ancestor.visible = true;
                view.dispose();
            }
        }
    }

    clearTemporaryObjects() {
        this.temporaryObjects.clear();
        this.phantomObjects.clear();
    }

    private _removeItem(view: visual.Item) {
        const simpleName = view.simpleName;
        const result = this.geometryModel.get(simpleName);
        if (result === undefined) throw new Error('invalid precondition: item must exist');
        this.geometryModel.delete(simpleName);
        this.automatics.delete(simpleName);
        view.dispose();
        return result.model;
    }

    lookupItemById(id: visual.ItemId): { view: visual.Item, model: c3d.Body } {
        const result = this.geometryModel.get(id);
        if (result === undefined) throw new Error(`invalid precondition: object ${id} missing from geometry model`);
        return result;
    }

    lookup(object: visual.Solid): c3d.Solid;
    lookup(object: visual.Sheet): c3d.Sheet;
    lookup(object: visual.SpaceInstance): c3d.Wire;
    lookup(object: visual.SketchIsland): c3d.RegionBody;
    lookup(object: visual.Item): c3d.Body;
    lookup(object: visual.Item): c3d.Body {
        return this.lookupItemById(object.simpleName).model;
    }

    hasTopologyItem(id: visual.TopologyId): boolean {
        const [, parentId,] = visual.TopologyItem.decompose(id);
        return this.geometryModel.has(parentId);
    }

    lookupTopologyItemById(id: visual.TopologyId): TopologyData {
        const [topologyClass, parentId, entityId] = visual.TopologyItem.decompose(id);
        const { view: parent } = this.lookupItemById(parentId);
        switch (topologyClass) {
            case 'f': {
                const shell = parent as visual.Solid | visual.Sheet;
                const view = shell.faces.lookup(entityId);
                const model = new c3d.Face(entityId);
                return { view, model };
            }
            case 'r': {
                const island = parent as visual.SketchIsland
                const view = island.regions.lookup(entityId);
                const model = new c3d.Face(entityId);
                return { view, model };
            }
            case 'e': {
                const shell = parent as visual.Solid | visual.Sheet;
                const view = shell.edges.lookup(entityId);
                const model = new c3d.Edge(entityId);
                return { view, model };
            }
            case 's': {
                const wire = parent as visual.SpaceInstance;
                const view = wire.segments.lookup(entityId);
                const model = new c3d.Edge(entityId);
                return { view, model };
            }
            case 'v': {
                const wire = parent as visual.SpaceInstance;
                const view = wire.vertices.lookup(entityId);
                const model = new c3d.Vertex(entityId);
                return { view, model };
            }
        }
    }

    lookupTopologyItem(object: visual.Face): c3d.Face;
    lookupTopologyItem(object: visual.Region): c3d.Face;
    lookupTopologyItem(object: visual.CurveEdge): c3d.Edge;
    lookupTopologyItem(object: visual.CurveSegment): c3d.Edge;
    lookupTopologyItem(object: visual.Vertex): c3d.Vertex;
    lookupTopologyItem(object: visual.Edge | visual.Face | visual.CurveSegment | visual.Vertex): c3d.Face | c3d.Edge | c3d.Vertex {
        return this.lookupTopologyItemById(object.simpleName).model;
    }

    find<T extends visual.SketchIsland>(klass: GConstructor<T>, includeAutomatics?: boolean): { view: T, model: c3d.RegionBody }[];
    find<T extends visual.SpaceInstance>(klass: GConstructor<T>, includeAutomatics?: boolean): { view: T, model: c3d.Wire }[];
    find<T extends visual.Solid>(klass: GConstructor<T>, includeAutomatics?: boolean): { view: T, model: c3d.Solid }[];
    find<T extends visual.Sheet>(klass: GConstructor<T>, includeAutomatics?: boolean): { view: T, model: c3d.Sheet }[];
    find<T extends visual.Solid>(klass: undefined, includeAutomatics?: boolean): { view: T, model: c3d.Solid }[];
    find<T extends visual.Item>(klass?: GConstructor<T>, includeAutomatics?: boolean): { view: T, model: c3d.Body }[] {
        const automatics = this.automatics;
        const result: { view: visual.Item, model: c3d.Body }[] = [];
        if (klass === undefined) {
            for (const [id, { view, model }] of this.geometryModel.entries()) {
                if (!includeAutomatics && automatics.has(id)) continue;
                result.push({ view, model });
            }
        } else {
            for (const [id, { view, model }] of this.geometryModel.entries()) {
                if (!includeAutomatics && automatics.has(id)) continue;
                if (view instanceof klass) result.push({ view, model });
            }
        }
        return result as { view: T, model: c3d.Body }[];
    }

    findAll(includeAutomatics?: boolean): { view: visual.Item, model: c3d.Solid }[] {
        return this.find(undefined, includeAutomatics);
    }

    findAutomatics() {
        return [...this.automatics].map(id => this.geometryModel.get(id)!.view)
    }

    lookupStableId(version: VersionId): StableId | undefined {
        return this.version2stable.get(version);
    }


    get items() {
        return [...this.geometryModel.values()];
    }

    lookupCVById(id: visual.CVId): ControlPointData {
        const [parentId, entityId] = visual.CV.decompose(id);
        const { view: parent } = this.lookupItemById(parentId);
        const wire = parent as visual.SpaceInstance;
        const view = wire.cvs.get(entityId);
        return { index: entityId, view };
    }

    lookupByStableId(stable: StableId): { view: visual.Item; model: c3d.Body; } {
        const version = this.stable2version.get(stable);
        if (version === undefined) throw new Error(`invalid precondition: object ${stable} missing from version model`);
        return this.lookupItemById(version);
    }

    private currentMark = c3d.Session.CreateMark();
    createMark() { this.currentMark = c3d.Session.CreateMark() }

    saveToMemento(): GeometryMemento {
        return new GeometryMemento(
            this.currentMark,
            new Map(this.geometryModel),
            new Map(this.version2stable),
            new Map(this.stable2version),
            new Set(this.automatics));
    }

    restoreFromMemento(m: GeometryMemento) {
        m.mark.Goto();
        this.currentMark = m.mark;
        (this.geometryModel as GeometryDatabase['geometryModel']) = new Map(m.geometryModel);
        (this.version2stable as GeometryDatabase['version2stable']) = new Map(m.version2stable);
        (this.stable2version as GeometryDatabase['stable2version']) = new Map(m.stable2version);
        (this.automatics as GeometryDatabase['automatics']) = new Set(m.automatics);
    }

    clear() {
        this.clearTemporaryObjects();
        this.geometryModel.clear();
        this.version2stable.clear();
        this.stable2version.clear();
        this.automatics.clear();
        this.positiveCounter = 1;
        this.negativeCounter = -1;
    }

    validate() {
        console.assert(this.stable2version.size === this.version2stable.size, "maps should have same size", this.stable2version, this.version2stable);
    }

    debug() {
        console.group("GeometryDatabase");
        console.info("Version: ", this.version);
        const { geometryModel, stable2version: id2version, version2stable: version2name } = this;
        console.group("geometryModel");
        console.table([...geometryModel].map(([name]) => { return { name } }));
        console.groupEnd();
        console.groupCollapsed("id2version");
        console.table([...id2version].map(([name, version]) => { return { name, version } }));
        console.groupEnd();
        console.groupCollapsed("version2name");
        console.table([...version2name].map(([version, name]) => { return { version, name } }));
        console.groupEnd();
        console.groupEnd();
    }
}

export type Replacement = { from: visual.Item, to: visual.Item }
