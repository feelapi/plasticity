import { CompositeDisposable } from 'event-kit';
import { assertUnreachable } from '../util/Util';
import * as visual from '../visual_model/VisualModel';
import { ReadonlyGeometryDatabase } from './DatabaseLike';
import { EditorSignals } from "./EditorSignals";
import { Empty, EmptyId, ReadonlyEmpties } from './Empties';
import { Group, GroupId, GroupListing, Groups, ReadonlyGroups, VirtualGroup } from './Groups';
import { MementoOriginator, SceneMemento } from './History';
import MaterialDatabase from "./MaterialDatabase";
import { LeafNodeItem, NodeDekey, NodeIdentityTransform, NodeItem, NodeKey, Nodes, ReadonlyNodes, ReadonlyNodeTransform, RealNodeItem } from "./Nodes";

type SnapshotDelta = {
    nodeChange: 'hidden' | 'unhidden' | 'none'
    hidden: RealNodeItem[];
    unhidden: RealNodeItem[];
};

/**
 * The Scene (not to be confused with THREE.Scene) is a collection of all the visible/selectable objects in the
 * Plasticity universe. It coordinates the GeometryDatabase (NURBS solids and curves) and the Empties database (image planes)
 * with the Nodes (visibility/selectablility modifiers) and Groups (organization) stuff.
 * 
 * A Node is EITHER an NURBS item OR an Empty OR a Group. Nodes can be visible/hidden and have group membership relationships.
 * 
 * In the current implementation, the Nodes and Groups objects are relatively dumb collections, and the Scene is responsible
 * for keeping them up-to-date when objects are deleted and so forth.
 */

export class Scene implements MementoOriginator<SceneMemento> {
    private readonly disposable = new CompositeDisposable();
    dispose() { this.disposable.dispose() }

    constructor(
        private readonly db: ReadonlyGeometryDatabase,
        private readonly groups: ReadonlyGroups,
        private readonly nodes: ReadonlyNodes,
        private readonly empties: ReadonlyEmpties,
        private readonly materials: MaterialDatabase,
    ) {
        this.update();
    }

    private _visibleObjects: visual.SpaceItem[] = [];
    get visibleObjects() { return this._visibleObjects; }

    private _selectableObjects: visual.SpaceItem[] = [];
    get selectableObjects() { return this._selectableObjects; }

    update() {
        const { all, visibleItems, visibleGroups } = this.computeVisibleObjects();
        this._visibleObjects = all;
        this._visibleItems = visibleItems;
        this._visibleGroups = visibleGroups;
        this._selectableObjects = this.computeSelectableObjects();
    }

    computeVisibleObjects(includeAutomatics = true): { all: visual.SpaceItem[]; visibleItems: Set<visual.Item>; visibleGroups: Set<number>; } {
        const visibleItems = new Set<visual.Item>(), visibleGroups = new Set<GroupId>();
        const acc = this.computeVisibleObjectsInGroup(this.root, visibleItems, visibleGroups, false);
        const incl = includeAutomatics ? [...acc].concat(this.db.findAutomatics()) : [...acc];
        return { all: incl, visibleItems, visibleGroups };
    }

    private _visibleItems: Set<LeafNodeItem> = new Set();
    private _visibleGroups: Set<GroupId> = new Set();
    get visibility(): SceneDisplayInfo {
        return { visibleItems: this._visibleItems, visibleGroups: this._visibleGroups };
    }

    private computeVisibleObjectsInGroup(start: NodeItem, accItem: Set<visual.SpaceItem>, accGroup: Set<GroupId>, checkSelectable: boolean): Set<visual.SpaceItem> {
        const { nodes } = this;
        if (start instanceof Group) {
            if (nodes.isHidden(start)) return accItem;
            if (!nodes.isVisible(start)) return accItem;
            if (checkSelectable && !nodes.isSelectable(start)) return accItem;
            accGroup.add(start.id);
            for (const listing of this.list(start)) {
                const tag = listing.tag;
                switch (tag) {
                    case 'Group':
                        this.computeVisibleObjectsInGroup(listing.group, accItem, accGroup, checkSelectable);
                        break;
                    case 'Item':
                        this.computeVisibleObjectsInGroup(listing.item, accItem, accGroup, checkSelectable);
                        break;
                    case 'Empty':
                        this.computeVisibleObjectsInGroup(listing.empty, accItem, accGroup, checkSelectable);
                        break;
                    default: assertUnreachable(tag);
                }
            }
        } else if (start instanceof visual.Item) {
            if (nodes.isHidden(start)) return accItem;
            if (!nodes.isVisible(start)) return accItem;
            if (checkSelectable && !nodes.isSelectable(start)) return accItem;
            const parent = this.parent(start)!;
            if (this.isHiddenWithin(start, parent)) return accItem;
            accItem.add(start);
        } else if (start instanceof VirtualGroup) {
            return this.computeVisibleObjectsInGroup(start.parent, accItem, accGroup, checkSelectable);
        } else if (start instanceof Empty) {
            if (nodes.isHidden(start)) return accItem;
            if (!nodes.isVisible(start)) return accItem;
            if (checkSelectable && !nodes.isSelectable(start)) return accItem;
            const parent = this.parent(start)!;
            if (!nodes.isVisible(parent.empties)) return accItem;
            accItem.add(start);
        } else assertUnreachable(start);
        return accItem;
    }

    isHiddenWithin(start: NodeItem, parent: Group) {
        const { nodes } = this;
        if (start instanceof visual.Solid && !nodes.isVisible(parent.solids)) return true;
        if (start instanceof visual.SpaceInstance && !nodes.isVisible(parent.curves)) return true;
        if (start instanceof Empty && !nodes.isVisible(parent.empties)) return true;
        return false;
    }

    computeSelectableObjects(): visual.SpaceItem[] {
        const acc = this.computeVisibleObjectsInGroup(this.root, new Set(), new Set(), true);
        return [...acc].concat(this.db.findAutomatics());
    }

    snapshot(node: NodeItem, checkSelectable: boolean): Snapshot {
        const isIndirectlyHidden = this.isIndirectlyHidden(node);
        const visibleItems = new Set<LeafNodeItem>();
        const visibleGroups = new Set<GroupId>();
        this.computeVisibleObjectsInGroup(node, visibleItems, visibleGroups, checkSelectable);
        return { isIndirectlyHidden, visibleItems, visibleGroups };
    }

    processSnapshot(before: Snapshot, after: Snapshot): SnapshotDelta {
        const hidden = [], unhidden = [];
        for (const item of before.visibleItems) {
            if (after.visibleItems.has(item)) continue;
            hidden.push(item);
        }
        for (const item of after.visibleItems) {
            if (before.visibleItems.has(item)) continue;
            unhidden.push(item);
        }
        for (const groupId of before.visibleGroups) {
            if (after.visibleGroups.has(groupId)) continue;
            hidden.push(this.lookupGroupById(groupId));
        }
        for (const groupId of after.visibleGroups) {
            if (before.visibleGroups.has(groupId)) continue;
            unhidden.push(this.lookupGroupById(groupId));
        }
        let nodeChange: SnapshotDelta['nodeChange'];
        if (before.isIndirectlyHidden && !after.isIndirectlyHidden) {
            nodeChange = 'unhidden';
        } else if (!before.isIndirectlyHidden && after.isIndirectlyHidden) {
            nodeChange = 'hidden';
        } else {
            nodeChange = 'none';
        }
        return { nodeChange, hidden, unhidden };
    }

    isDirectlyHidden(node: NodeItem) {
        if ((node instanceof visual.Item || node instanceof Group || node instanceof Empty) && this.isHidden(node)) return true;
        if (!this.isVisible(node)) return true;
        return false;
    }

    isIndirectlyHidden(node: NodeItem) {
        if (this.isDirectlyHidden(node)) return true;
        let parent = this.groups.parent(this.nodes.item2key(node));
        if (parent === undefined) return false;
        if (this.isHiddenWithin(node, parent)) return true;
        while (!parent.isRoot) {
            if (this.nodes.isHidden(parent)) return true;
            parent = this.groups.parent(this.nodes.item2key(parent))!;
        }
        return false;
    }

    parent(node: RealNodeItem): Group | undefined {
        return this.groups.parent(this.nodes.item2key(node));
    }

    lookupGroupById(id: GroupId): Group {
        return this.groups.lookupById(id);
    }

    lookupEmptyById(id: EmptyId): Empty {
        return this.empties.lookupById(id);
    }

    get root() { return this.groups.root }
    isHidden(node: RealNodeItem): boolean { return this.nodes.isHidden(node) }
    isVisible(node: NodeItem): boolean { return this.nodes.isVisible(node) }
    isSelectable(node: NodeItem): boolean { return this.nodes.isSelectable(node) }
    getName(node: RealNodeItem): string | undefined { return this.nodes.getName(node) }
    key2item(key: NodeKey): NodeItem { return this.nodes.key2item(key) }
    item2key(item: NodeItem): NodeKey { return this.nodes.item2key(item) }

    list(group: Group = this.root): GroupListing[] {
        const members = this.groups.list(group);
        return this.nodeDekey2GroupListing(members);
    }

    walk(group: Group): GroupListing[] {
        const members = this.groups.walk(group);
        return this.nodeDekey2GroupListing(members);
    }

    private nodeDekey2GroupListing(members: NodeDekey[]) {
        const result = [];
        for (const { tag, id } of members) {
            switch (tag) {
                case 'Group':
                    result.push({ tag, group: this.groups.lookupById(id) });
                    break;
                case 'Item':
                    result.push({ tag, item: this.db.lookupByStableId(id).view });
                    break;
                case 'Empty':
                    result.push({ tag, empty: this.empties.lookupById(id) });
                    break;
                case 'VirtualGroup':
                    break;
                default: assertUnreachable(tag);
            }
        }
        return result;
    }

    getMaterial(node: RealNodeItem, walk = false): THREE.Material & { color: THREE.Color } | undefined {
        const thisMaterial = this.nodes.getMaterial(node);
        if (!walk || thisMaterial) return thisMaterial;
        let parent = this.parent(node);
        if (parent === undefined) return undefined;
        while (!parent.isRoot) {
            const mat = this.nodes.getMaterial(parent);
            if (mat !== undefined) return mat;
            parent = this.parent(parent)!;
        }
        return undefined;
    }

    getTransform(node: RealNodeItem, walk = false): ReadonlyNodeTransform {
        let thisTransform = this.nodes.getTransform(node);
        if (thisTransform === undefined) thisTransform = NodeIdentityTransform;
        return thisTransform;
    }

    makeTemporary() {
        const signals = new EditorSignals();
        const groups = new Groups(signals);
        groups.restoreFromMemento(this.groups.saveToMemento());
        const nodes = new Nodes(this.db, groups, this.empties, this.materials, signals);
        nodes.restoreFromMemento(this.nodes.saveToMemento());
        const scene = new Scene(
            this.db,
            groups,
            nodes,
            this.empties,
            this.materials);
        return { groups, nodes, scene };
    }

    // The scene does not have any explicit state, so having it be a MementoOriginator is a bit of a hack
    // It does have a cache, which needs to be updated when the scene's history is changed
    saveToMemento(): SceneMemento {
        return new SceneMemento();
    }
    restoreFromMemento(m: SceneMemento) {
        this.update();
    }
    validate() { }
    debug() { }
    clear() { this.update(); }

}


type Snapshot = {
    isIndirectlyHidden: boolean,
    visibleItems: Set<LeafNodeItem>;
    visibleGroups: Set<number>;
};

export type SceneDisplayInfo = {
    visibleItems: Set<LeafNodeItem>;
    visibleGroups: Set<number>;
};
