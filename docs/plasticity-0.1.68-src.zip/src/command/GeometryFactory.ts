import { Disposable } from "event-kit";
import { Measure } from "../components/stats/Measure";
import { MaterialOverride, TemporaryObject } from '../editor/DatabaseLike';
import { Database } from '../editor/db/Database';
import { MutableComputeTemporaryInput } from "../editor/db/transforms/ComputeTemporary";
import { EditorSignals } from '../editor/EditorSignals';
import MaterialDatabase from '../editor/MaterialDatabase';
import * as c3d from '../kernel/kernel';
import { toArray } from "../util/Conversion";
import { Delay } from "../util/SequentialExecutor";
import { assertUnreachable, AtomicRef, later, zip } from '../util/Util';
import * as visual from '../visual_model/VisualModel';
import { AbstractFactory } from "./AbstractFactory";

type State<V extends visual.Item, A extends undefined | [] = undefined> =
    { tag: 'none' }
    | { tag: 'updated', mark: c3d.PartitionMark }
    | { tag: 'updating', finished: Promise<void>, hasNext: boolean, failed?: any, step: SubStep, mark: c3d.PartitionMark }
    | { tag: 'failed', error: any, mark: c3d.PartitionMark }
    | { tag: 'paused' }
    | { tag: 'cancelled' }
    | { tag: 'committing' }
    | { tag: 'aborting-commit' }
    | { tag: 'committed', result: A extends [] ? V[] : V }

/**
 * A GeometryFactory is an object responsible for making and transforming geometrical objects, like
 * solids and curves. All of the spheres and circles and fillets and boolean operations are represented
 * as factories. The factories take various arguments (such as a fillet radius) and have commit(), update(),
 * and cancel() methods. Commit() computes the geometry and adds it to the database whereas update() creates
 * a temporary object for visualization before the user decides to commit().
 * 
 * A typical subclass only implements the calculate() template method. So the default superclass update()
 * and commit() (which call calculate()) are sufficient in 90% of cases; the exceptions are usually to allow
 * update() to have optimizations. Scale, for example, can show results to the user without having to invoke
 * c3d commands (which are often slower and always generate a lot of garbage).
 * 
 * Further, one should be aware that some factories create objects (like a new sphere), some create
 * and CONSUME objects such as boolean union (where two objects become one), some replace like fillet, and so
 * forth. Thus there is some code complexity in managing the inserting, replacing, deleting, etc. of objects
 * in the databases. All of this is implemented in AbstractGeometryFactory -- it is the "essential" functionality.
 * 
 * In addition to the above, a GeometryFactory is a state machine. Because computations can succeed and fail,
 * and because computations can take a long time (and happen asynchronously), the GeometryFactory has states
 * like none/updating/updated/failed/cancelled/committed. For the purposes of code organization and unit testing,
 * the state machine behavior is implemented in the abstract subclass GeometryFactory.
 * 
 * Particularly in the case of update(), where the user is interactively trying one value after another,
 * the factory can temporarily be in a failure state. Similarly, if an update takes too long, the user
 * might request another update before the last has finished. Hence there are states like 'updating',
 * 'failed', 'updated', etc.
 * 
 * In general, if the user is requesting updates too fast we drop all but the most recent request; this
 * is implemented with the hasNext field on the updating state. We also need to ensure some synchronization;
 * if an update is taking too long and in the meantime the user cancels or commits, the system needs to
 * end up in a coherent state. We could queue everything to do this, which would be simple but slow. Instead,
 * after every `await` check if the state has changed and if so perform whatever cleanup is necessary.
 * 
 */

export abstract class AbstractGeometryFactory<M extends c3d.Body, V extends visual.Item, A extends undefined | [] = undefined> extends AbstractFactory<V> {
    protected readonly computeTemporary = this.db.computeTemporary;
    protected readonly updateTemporary = this.db.updateTemporary;
    protected readonly computePhantom = this.db.computePhantom;
    protected readonly updatePhantom = this.db.updatePhantom;

    constructor(
        protected readonly db: Database,
        protected readonly materials: MaterialDatabase,
        protected readonly signals: EditorSignals,
    ) { super() }

    protected phants: TemporaryObject[] = [];
    private hidden: THREE.Object3D[] = [];

    protected async doPhantoms(abortEarly: () => boolean): Promise<TemporaryObject[]> {
        const infos = await this.calculatePhantoms(this.phantomArguments);
        if (abortEarly()) return [];

        const txn: MutableComputeTemporaryInput = { added: [], replaced: [] };
        for (const { phantom, material } of infos) {
            txn.added.push({ model: phantom, material });
        }
        const computePhantomResult = await this.computePhantom.calculate(txn);
        if (abortEarly()) return Promise.resolve([]);

        const updatePhantomResult = this.updatePhantom.calculate(computePhantomResult);
        if (abortEarly()) return [];

        const phantoms = updatePhantomResult.added.map(x => x.temp);

        this.cleanupPhantoms();
        return this.phants = this.showTemps(phantoms);
    }

    async doUpdate(abortEarly: () => boolean): Promise<TemporaryObject[]> {
        const { temps, toHide } = await this.calculateTemps(abortEarly);
        if (abortEarly()) return Promise.resolve([]);

        // When all async work is complete, we can safely show/hide items to the user;
        // The specific order of operations is designed to avoid any flicker: compute
        // everything async, then sync show/hide objects when all data is ready.
        const finished = await Promise.all(temps);

        // a. remove any previous temporary items.
        this.cleanupTemps();

        // b. Bring the original items to the correct state
        this.restoreOriginalItems();
        toHide.forEach(h => h.visible = false);
        this.hidden = toHide;

        if (abortEarly()) {
            for (const p of finished) p.cancel();
            return Promise.resolve([]);
        }

        // 3.c. show the newly created temporary items.
        return this.temps = this.showTemps(finished);
    }

    protected async calculateTemps(abortEarly: () => boolean): Promise<{ temps: TemporaryObject[]; toHide: visual.Item[]; }> {
        // 1. Asynchronously compute the geometry
        let result;
        const stats = Measure.get('factory-calculate');
        stats.begin();
        try {
            result = await this.calculateForUpdate();
        } catch (e) {
            // TODO: FIXME: investigate if checking if ValidationError is right. It seems like we should always cleanup?
            if (e instanceof ValidationError) this.cleanupTemps();
            this.restoreOriginalItems();
            this.signals.factoryUpdated.dispatch();
            throw e;
        } finally {
            stats.end();
        }
        if (abortEarly()) {
            return Promise.resolve({ temps: [], toHide: [] });
        }

        // 2. Asynchronously compute the mesh for temporary items.
        const geometries = toArray(result);
        const zipped = this.zip(this.originalItems, geometries, this.shouldHideOriginalItemDuringUpdate);

        const txn: MutableComputeTemporaryInput = { added: [], replaced: [] };
        const toHide = [];
        for (const [from, to] of zipped) {
            if (from === undefined) {
                if (to === undefined) throw new Error("Invalid precondition");
                txn.added.push({ model: to, material: this.materialOverride });
            } else if (to === undefined) {
                toHide.push(from);
            } else {
                txn.replaced.push({ from: { view: from }, model: to });
            }
        }
        const computeTemporaryResult = await this.computeTemporary.calculate(txn);
        if (abortEarly()) {
            return Promise.resolve({ temps: [], toHide: [] });
        }
        const updateTemporaryResult = this.updateTemporary.calculate(computeTemporaryResult);
        const temps = updateTemporaryResult.added.map(x => x.temp);
        return { temps, toHide };
    }

    protected get materialOverride(): MaterialOverride | undefined {
        return undefined;
    }

    protected async doCommit(): Promise<A extends [] ? V[] : V> {
        try {
            const unarray = await this.calculateForCommit();
            const geometries = toArray(unarray);
            const zipped = this.zip(this.originalItems, geometries, this.shouldRemoveOriginalItemOnCommit);
            const txn = this.db.makeTransaction();
            for (const [from, to] of zipped) {
                if (from === undefined && to !== undefined) {
                    txn.add(to);
                } else if (from !== undefined && to === undefined) {
                    txn.delete(from);
                } else if (from !== undefined && to !== undefined) {
                    txn.replace(from, to);
                } else {
                    throw new Error("Invalid precondition");
                }
            }
            const { added, replaced } = await this.db.commit(txn);
            const items = [...added, ...replaced];
            const views = items.map(i => i.view);
            return dearray(views, unarray) as A extends [] ? V[] : V;
        } finally {
            await Promise.resolve(); // This removes flickering when rendering. // FIXME: is that still true?
            this.finalize();
        }
    }

    protected finalize() {
        super.finalize();
        this.cleanupPhantoms();
        this.dispose();
    }

    protected restoreOriginalItems() {
        for (const i of this.hidden) i.visible = true;
        super.restoreOriginalItems();
    }

    protected cleanupPhantoms() {
        for (const phantom of this.phants) phantom.cancel();
        this.phants = [];
    }

    dispose() { }

    zip(originals: visual.Item[], replacements: c3d.Body[], shouldRemoveOriginal: boolean) {
        if (shouldRemoveOriginal) {
            return zip(originals, replacements);
        } else {
            return zip([], replacements);
        }
    }

    protected calculateForUpdate(options?: any): Promise<A extends [] ? M[] : M> { return this.calculate(options) }
    protected calculateForCommit(options?: any): Promise<A extends [] ? M[] : M> { return this.calculate(options) }
    protected abstract calculate(options?: any): Promise<A extends [] ? M[] : M>;
    protected calculatePhantoms(options?: any): Promise<PhantomInfo[]> { return Promise.resolve([]) }
    protected get phantomArguments(): any { return undefined }

    protected get shouldRemoveOriginalItemOnCommit() { return true }
    protected get shouldHideOriginalItemDuringUpdate() { return this.shouldRemoveOriginalItemOnCommit }
}

export abstract class GeometryFactory<M extends c3d.Body = c3d.Body, V extends visual.Item = visual.Item, A extends undefined | [] = undefined> extends AbstractGeometryFactory<M, V, A> {
    private readonly _state: AtomicRef<State<V, A>> = new AtomicRef({ tag: 'none' });
    get state(): { clock: number, state: State<V, A> } {
        const { clock, value } = this._state.get();
        return { clock, state: value }
    }
    set state(state: { clock: number, state: State<V, A> }) {
        const set = this._state.compareAndSet(state.clock, state.state);
        if (set === undefined) throw new Error('Invalid state transition');
        switch (state.state.tag) {
            case 'updated':
            case 'updating':
            case 'failed':
            case 'committing':
            case 'committed':
                this.changed.dispatch();
                break;
            case 'none':
            case 'cancelled': // nothing
        }
    }

    get isCommitted() { return this.state.state.tag === 'committed' }

    constructor(
        db: Database,
        materials: MaterialDatabase,
        signals: EditorSignals,
    ) {
        super(db, materials, signals);
    }

    async update() {
        const { clock, state } = this.state;
        const mark = this.createInitialMark();
        const abortEarlyUnless = (previousClock: number) => () => {
            if (this.state.state.tag === 'failed') return this.state.clock !== previousClock + 1;
            else return this.state.clock !== previousClock;
        }

        switch (state.tag) {
            case 'none':
            case 'failed':
            case 'updated': {
                const delay = new Delay<void>();
                const state: State<V, A> = { tag: 'updating', finished: delay.promise, hasNext: false, step: 'begin', mark };
                this.state = { clock, state };
                const stillUpdating = this.state.clock;
                const abortEarly = abortEarlyUnless(stillUpdating);

                try {
                    mark.Goto(); // NOTE: this can fail, if the user aborts at the wrong time.

                    const phantoms = this.doPhantoms(abortEarly);
                    const temps = this.doUpdate(abortEarly);
                    phantoms.then(() => {
                        if (state.step === 'begin') state.step = 'phantoms-completed';
                        else state.step = 'all-completed';
                        // ensure phantoms are rendered as soon as they're ready:
                        if (!abortEarly()) this.signals.factoryUpdated.dispatch();
                    }, () => { });
                    temps.then(() => {
                        if (state.step === 'begin') state.step = 'calculate-completed';
                        else state.step = 'all-completed';
                        // rerender now that we're done calculating the temps:
                        if (!abortEarly()) this.signals.factoryUpdated.dispatch();
                    }, () => { });
                    await Promise.all([phantoms, temps]);
                } catch (e) {
                    if (!abortEarly()) state.failed = e ?? new Error("unknown error");
                } finally {
                    delay.resolve();
                    await this.continueUpdatingIfMoreWork(stillUpdating);
                }
                break;
            }
            case 'updating': {
                const stillUpdating = clock;
                const abortEarly = abortEarlyUnless(stillUpdating);
                if (state.hasNext) console.warn("Dropping job because of latency");
                state.hasNext = true;
                if (state.step === 'phantoms-completed') {
                    state.step = 'begin';
                    try { await this.doPhantoms(abortEarly) } catch (e) {
                        console.error(e);
                    }
                    if (state.step === 'begin') state.step = state.step = 'phantoms-completed';
                    else state.step = 'all-completed';
                }

                break;
            }
            default:
                throw new Error('invalid state: ' + state.tag);
        }
    }

    protected calculateForUpdate(options?: any): Promise<A extends [] ? M[] : M> { return this.calculate(this.partition) }
    protected calculateForCommit(options?: any): Promise<A extends [] ? M[] : M> { return this.calculate(this.partition) }
    protected calculate(partition: c3d.Partition = this.partition): Promise<A extends [] ? M[] : M> { throw new Error("Implement this for simple factories"); }
    protected override get phantomArguments(): any { return this.phantomPartition }

    private createInitialMark() {
        const { state } = this.state;
        switch (state.tag) {
            case 'none':
                return this.partition.CreateMark();
            case 'updated':
            case 'updating':
            case 'failed':
                return state.mark;
            default:
                throw new Error("invalid state: " + state.tag);
        }
    }

    protected get partition() { return c3d.Session.GetCurrentPartition() }
    protected phantomPartition = new c3d.Partition();

    get done() {
        const { state } = this.state;
        return state.tag === 'cancelled' || state.tag === 'committed';
    }

    // If another update() job was "enqueued" while still doing the previous one, do that too
    private async continueUpdatingIfMoreWork(stillUpdating: number) {
        const { clock, state } = this.state;
        if (clock !== stillUpdating) return;
        switch (state.tag) {
            case 'updating':
                const hasNext = state.hasNext;
                const error = state.failed;
                if (error) {
                    this.state = { clock: stillUpdating, state: { tag: 'failed', error, mark: state.mark } };
                    if (hasNext) await this.update();
                    else await this.notifyOfError();
                } else {
                    this.state = { clock: stillUpdating, state: { tag: 'updated', mark: state.mark } };
                    if (hasNext) await this.update();
                }
                break;
            default: break;
        }
    }

    private async notifyOfError() {
        const { state } = this.state;
        switch (state.tag) {
            case 'failed':
                const e = state.error;
                if (!(e instanceof NoOpError)) {
                    if (e instanceof ValidationError || e.isKernelError) {
                        console.warn(`${this.constructor.name}: ${e.message}`);
                        console.warn(e);
                    }
                }

                for (const temp of this.temps) temp.hide();

                if (!(e instanceof NoOpError)) {
                    if (e instanceof ValidationError || e.isKernelError) {
                        this.signals.factoryUpdateFailed.dispatch(e);
                    } else throw e;
                }
                break;
            case 'updating': break;
            default:
                throw new Error("invalid state: " + state.tag);
        }
    }

    async commit(): Promise<A extends [] ? V[] : V> {
        const mark = this.createInitialMark();

        const { clock, state } = this.state;
        switch (state.tag) {
            case 'updating':
            case 'none':
            case 'updated':
            case 'failed':
                this.state = { clock, state: { tag: 'committing' } };
                const stillCommitting = this.state.clock;
                if (state.tag === 'updating') {
                    console.info("Committing while outstanding update job is still running. Interrupting");
                    c3d.interrupt();
                    const timeout = later(500);
                    await Promise.race([state.finished, timeout]);
                }
                try {
                    mark.Goto();
                    const result = await this.doCommit();
                    this.state = { clock: stillCommitting, state: { tag: 'committed', result } };
                    this.signals.factoryCommitted.dispatch();
                    return result;
                } catch (error) {
                    const { clock: nextClock, state: nextState } = this.state;
                    if (nextClock !== stillCommitting && nextState.tag !== 'aborting-commit') {
                        console.error('Unexpected state change during commit' + nextState.tag);
                    }
                    this.state = { clock: nextClock, state: { tag: 'failed', error, mark } };
                    this.doCancel();
                    this.signals.factoryCancelled.dispatch();
                    throw error;
                }
            default:
                console.trace();
                throw new Error('invalid state: ' + state.tag);
        }
    }

    cancel() {
        const { clock, state } = this.state;
        switch (state.tag) {
            case 'none':
            case 'cancelled':
            case 'aborting-commit':
            case 'paused':
                break;
            case 'committed':
                throw new Error(`Factory ${this.constructor.name} in invalid state: ${state.tag}`);
            case 'committing':
                console.info("Cancelling while in the process of committing. Interrupting");
                this.state = { clock, state: { tag: 'aborting-commit' } };
                c3d.interrupt();
                return;
            case 'updating':
                console.info("Cancelling while outstanding update job is still running. Interrupting");
                c3d.interrupt();
            case 'failed':
            case 'updated':
                state.mark.Goto();
                break;
            default: assertUnreachable(state);
        }

        switch (state.tag) {
            case 'aborting-commit':
                break;
            case 'paused':
            case 'none':
            case 'updated':
            case 'cancelled':
            case 'failed':
            case 'updating':
                this.doCancel();
                this.state = { clock, state: { tag: 'cancelled' } };
                this.signals.factoryCancelled.dispatch();
                return;
            default: assertUnreachable(state);
        }
    }

    get isPaused() {
        const { state } = this.state;
        return state.tag === 'paused';
    }

    pause(shouldHide = true) {
        const { clock, state } = this.state;
        switch (state.tag) {
            case 'none':
            case 'updating':
            case 'paused':
                // We allow nested pausing as a no-op
                return new Disposable();
            case 'updated':
            case 'failed':
                const pause = c3d.Session.GetCurrentPartition().CreateMark();
                if (shouldHide) {
                    for (const temp of this.temps) temp.hide();
                    for (const phant of this.phants) phant.hide();
                }
                state.mark.Goto();
                this.state = { clock, state: { tag: 'paused' } };
                const stillPaused = this.state.clock;
                return new Disposable(() => {
                    const { clock: nextClock } = this.state;
                    if (nextClock !== stillPaused) throw new Error('Unexpected state change during pause');
                    if (shouldHide) {
                        for (const temp of this.temps) temp.show();
                        for (const phant of this.phants) phant.show();
                    }
                    pause.Goto();
                    this.state = { clock: stillPaused, state };
                });
            default:
                throw new Error(`Factory ${this.constructor.name} in invalid state: ${state.tag}`);
        }
    }
}

function dearray<S, T>(array: S[], antecedent: T | T[]): S | S[] {
    if (Array.isArray(antecedent)) return array;
    return array[0];
}

export class ValidationError extends Error { }
export class NoOpError extends ValidationError {
    constructor() {
        super("Operation has no effect");
    }
}

type SubStep = 'begin' | 'phantoms-completed' | 'calculate-completed' | 'all-completed';

export type PhantomInfo = { phantom: c3d.Body, material: MaterialOverride, ancestor?: visual.Item }
export type GeometryFactoryCache = Map<string, Promise<c3d.Body | c3d.Body[]>>;
