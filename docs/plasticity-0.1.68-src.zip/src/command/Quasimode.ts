import { CompositeDisposable, Disposable } from "event-kit";
import CommandRegistry from "../components/atom/CommandRegistry";
import { EditorSignals } from "../editor/EditorSignals";
import { CancellablePromise } from "../util/CancellablePromise";
import { GeometryFactory } from "./GeometryFactory";

export interface EditorLike {
    signals: EditorSignals;
    registry: CommandRegistry;
}

export interface Executable<I, O> {
    execute(cb: (i: I) => O, ...args: any[]): CancellablePromise<O>;
}

interface FactoryLike {
    pause(): Disposable;
    update(): void;
}

export class Quasimode {
    constructor(
        private readonly name: string,
        private readonly editor: EditorLike,
        private readonly factory: FactoryLike,
    ) { }

    execute(cb: () => CancellablePromise<any>, ...args: any[]): CancellablePromise<void> {
        const { factory, editor: { registry, signals }, name } = this;

        const disposables = new CompositeDisposable();
        const cancellable = new CancellablePromise<void>((resolve, reject) => {
            const start = registry.addOne(document.body, "command:quasimode:start", e => {
                document.body.setAttribute('quasimode', name);
                const resume = factory.pause();
                const execution = cb();
                disposables.add(new Disposable(() => execution.finish()));

                const stop = registry.addOne(document.body, "command:quasimode:stop", e => {
                    document.body.removeAttribute('quasimode');
                    resume.dispose();
                    stop.dispose();
                    execution.finish();
                    factory.update();
                    signals.quasimodeChanged.dispatch();
                })
                disposables.add(stop);

                signals.quasimodeChanged.dispatch();
            });
            disposables.add(start);

            const dispose = () => disposables.dispose();
            const finish = () => resolve();
            return { dispose, finish };
        });
        return cancellable;
    }
}
