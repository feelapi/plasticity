import * as visual from "../visual_model/VisualModel";
import { GeometryFactory, PhantomInfo } from "./GeometryFactory";
import * as c3d from '../kernel/kernel';
import { toArray } from "../util/Conversion";

export interface FactoryHelpers<M, A extends undefined | [] = undefined> {
    get originalItems(): visual.Item[];
    calculate(partition: c3d.Partition): Promise<A extends [] ? M[] : M>;
    calculatePhantoms(partition: c3d.Partition): Promise<PhantomInfo[]>;
}

export type MultiplyableFactory<M extends c3d.Body, V extends visual.Item, A extends undefined | [] = undefined> = GeometryFactory<M, V, A> & FactoryHelpers<M, A>;

export abstract class MultiGeometryFactory<
    T extends MultiplyableFactory<M, V, A>,
    M extends c3d.Body = c3d.Body,
    V extends visual.Item = visual.Item,
    A extends undefined | [] = undefined
> extends GeometryFactory<M, V, []> {
    private _factories: T[] = [];
    get factories() { return this._factories }
    set factories(factories: T[]) {
        this._factories = factories;
        this.updateFactories();
    }

    async calculate(partition: c3d.Partition = this.partition) {
        const { factories } = this;
        const acc: M[][] = [];
        for (const factory of factories) {
            acc.push(toArray(await factory.calculate(partition)));
        }
        const result = [] as M[];

        return interleave(acc);
    }

    async calculatePhantoms(partition: c3d.Partition): Promise<PhantomInfo[]> {
        const { factories } = this;
        const result = [];
        for (const factory of factories) {
            result.push(await factory.calculatePhantoms(partition));
        }
        return result.flat();
    }

    protected get originalItems(): V[] {
        let acc: V[][] = [];
        for (const i of this.factories) {
            const originals = i.originalItems;
            acc.push(originals);
        }
        return interleave(acc);
    }

    protected updateFactories() { }
}

function interleave<M>(acc: M[][]): M[] {
    const result = [] as M[];
    while (acc.length > 0) {
        const head = acc.shift()!;
        if (head.length === 0) {
        } else if (head.length === 1) {
            result.push(head.shift()!);
        } else {
            result.push(head.shift()!);
            acc.push(head);
        }
    }
    return result;
}

export function groupBy<K extends keyof O, O>(property: K, objects: O[]) {
    const map = new Map<O[K], O[]>();
    for (const obj of objects) {
        const key = obj[property];
        if (!map.has(key)) map.set(key, []);
        map.get(key)!.push(obj);
    }
    return map;
}