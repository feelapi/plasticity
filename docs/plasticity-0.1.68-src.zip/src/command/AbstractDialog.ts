import { CompositeDisposable, Disposable } from "event-kit";
import * as THREE from 'three';
import { Prompt } from "../components/dialog/Prompt";
import { EditorSignals } from "../editor/EditorSignals";
import { AlreadyFinishedError, CancellablePromise } from "../util/CancellablePromise";
import { AtomicRef } from "../util/Util";
import { Executable } from "./Quasimode";

type PromptState = { tag: 'none' } | { tag: 'executing', key: string, finish: Disposable }
type DialogState<T> = { tag: 'none' } | { tag: 'executing', cb: (sv: T) => void, cancellable: CancellablePromise<void>, prompt: AtomicRef<PromptState> } | { tag: 'finished' }

export abstract class AbstractDialog<T> extends HTMLElement implements Executable<T, void> {
    private state: DialogState<T> = { tag: 'none' };
    protected abstract readonly params: T;

    connectedCallback() { this.render() }
    disconnectedCallback() { }

    constructor(private readonly signals: EditorSignals) {
        super();
        this.render = this.render.bind(this);
    }

    abstract get name(): string;
    abstract render(): void;

    protected onChange = (e: Event) => {
        e.stopPropagation();
        switch (this.state.tag) {
            case 'executing':
                let value: any = undefined;
                if (e.target instanceof HTMLInputElement) {
                    if (e.target.type === 'checkbox')
                        value = e.target.checked;
                    else if (e.target.type === 'text')
                        value = e.target.value;
                    else if (e.target.type === 'radio')
                        value = Number(e.target.value);
                    else if (e.target.type === 'color')
                        value = new THREE.Color(e.target.value);
                } else if (e.target instanceof HTMLSelectElement) {
                    value = e.target.value;
                } else if (e.target instanceof HTMLElement && e.target.tagName == 'PLASTICITY-NUMBER-SCRUBBER') {
                    value = Number(e.target.getAttribute('value'));
                } else {
                    throw new Error("invalid precondition");
                }

                const key = e.target.getAttribute('name')!;
                if (/\./.test(key)) {
                    const [key1, key2] = key.split(/\./);
                    this.params[key1 as keyof T][key2 as keyof T[keyof T]] = value;
                } else {
                    this.params[key as keyof T] = value as unknown as T[keyof T];
                }
                this.state.cb(this.params);
                break;
            default: throw new Error('invalid state');
        }
    }

    execute(cb: (sv: T) => void) {
        if (this.state.tag !== 'none') throw new Error('invalid precondition');

        const cancellable = new CancellablePromise<void>((resolve, reject) => {
            const disposables = new CompositeDisposable();
            disposables.add(new Disposable(() => this.state = { tag: 'finished' }));

            this.signals.dialogAdded.dispatch(this);
            disposables.add(new Disposable(() => this.signals.dialogRemoved.dispatch()));

            return { dispose: () => disposables.dispose(), finish: resolve };
        });
        this.state = { tag: 'executing', cb, cancellable, prompt: new AtomicRef({ tag: 'none' }) };
        return cancellable;
    }

    finish() {
        switch (this.state.tag) {
            case 'executing': this.state.cancellable.finish();
                this.state = { tag: 'finished' };
                break;
            case 'none': throw new Error('invalid precondition');
        }
    }

    cancel() {
        switch (this.state.tag) {
            case 'executing': this.state.cancellable.cancel();
                break;
            case 'none': throw new Error('invalid precondition');
        }
    }

    prompt<T>(key: string, execute: () => CancellablePromise<T>, clear?: () => void, replace = false): () => CancellablePromise<T> {
        switch (this.state.tag) {
            case 'executing':
                const element = this.querySelector(`plasticity-prompt[name='${key}']`);
                if (element === null) throw new Error("invalid prompt: " + key);
                const prompt = element as Prompt;
                if (!replace && prompt.onclick !== null) throw new Error("Already bound");
                const trigger = () => {
                    switch (this.state.tag) {
                        case 'executing': {
                            let { clock, value: pstate } = this.state.prompt.get();
                            switch (pstate.tag) {
                                case 'executing':
                                    pstate.finish.dispose();
                                    let { clock: nextClock, value: nextPstate } = this.state.prompt.get();
                                    if (nextPstate.tag !== 'none') throw new Error("invalid state");
                                    clock = nextClock;
                                case 'none':
                                    const p = prompt.execute();
                                    const executed = execute();
                                    let next: number;
                                    const promptState: PromptState = {
                                        key,
                                        tag: 'executing',
                                        finish: new Disposable(() => {
                                            p.finish();
                                            executed.finish();
                                            if (this.state.tag !== 'executing') throw new Error("invalid state");
                                            this.state.prompt.compareAndSet(next, { tag: 'none' });
                                        })
                                    };
                                    const worked = this.state.prompt.compareAndSet(clock, promptState);
                                    if (worked === undefined) throw new Error("invalid state");
                                    next = worked;

                                    executed.then(() => {
                                        switch (this.state.tag) {
                                            case 'executing':
                                                const { clock, value: pstate } = this.state.prompt.get();
                                                if (clock !== next) return;
                                                switch (pstate.tag) {
                                                    case 'executing':
                                                        promptState.finish.dispose();
                                                        break;
                                                    default: throw new Error("invalid state");
                                                }
                                        }
                                    }, () => { });
                                    return executed;
                            }
                        }
                        default: throw new Error('invalid state: ' + this.state.tag);
                    }
                }
                prompt.onclick = () => {
                    switch (this.state.tag) {
                        case 'executing':
                            let { value: pstate } = this.state.prompt.get();
                            switch (pstate.tag) {
                                case 'executing':
                                    if (key === pstate.key) {
                                        pstate.finish.dispose();
                                        return;
                                    }
                            }
                    }
                    trigger();
                }
                prompt.onclear = clear;
                prompt.render();
                return trigger;
            case 'finished': throw new AlreadyFinishedError();
            default: throw new Error('invalid state: ' + this.state.tag);
        }
    }

    replace<T>(key: string, execute: () => CancellablePromise<T>, clear?: () => void): () => CancellablePromise<T> {
        return this.prompt(key, execute, clear, true);
    }
}
