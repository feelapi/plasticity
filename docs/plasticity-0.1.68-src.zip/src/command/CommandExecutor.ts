// FIXME:
// - There is a race where we can overwrite the backup if a command is invoked before the backup finishes being loaded
import { CompositeDisposable, Disposable } from "event-kit";
import { EditorOriginator, History } from "../editor/History";
import { MeshCreator } from "../editor/MeshCreator";
import { Backup } from "../editor/serialization/Backup";
import { SnapManager } from "../editor/snaps/SnapManager";
import { Cancel, Finish, Interrupt } from "../util/Cancellable";
import { AlreadyFinishedError } from "../util/CancellablePromise";
import Command, * as cmd from "./Command";
import { NoOpError, ValidationError } from "./GeometryFactory";
import { SelectionCommandManager } from "./SelectionCommandManager";

export interface EditorLike extends cmd.EditorLike {
    commandForSelection: SelectionCommandManager;
    originator: EditorOriginator;
    history: History;
    snaps: SnapManager;
    meshes: MeshCreator;
    backup: Backup;
    undo: () => Promise<void>;
}

export type ExecutionMode = 'queue' | 'interrupt' | 'skip-if-active';

export class CommandExecutor {
    constructor(private readonly editor: EditorLike) { }

    private active?: Command;
    private next?: Command;
    private lastCommand?: Command;

    // (Optionally) interrupt any active commands and "enqueue" another.
    // Ensure commands are executed ATOMICALLY.
    // That is, do not start a new command until the previous is fully completed,
    // including any cancelation cleanup. (await this.execute(next))
    async exec(command: Command, mode: ExecutionMode = 'interrupt', remember = true) {
        if (remember && command.remember && command.agent !== 'automatic')
            this.lastCommand = command;

        const isActive = this.active !== undefined;
        const isFactoryChanged = this.active?.isFactoryChanged ?? false;
        const isAutomatic = this.active?.agent === 'automatic' ?? false;
        if (mode === 'queue')
            this.next = command;
        else if (mode === 'interrupt') {
            this.active?.interrupt();
            this.next = command;
        } else if (mode === 'skip-if-active' && (!isActive || !isFactoryChanged)) {
            if (isAutomatic) this.active?.interrupt();
            this.next = command;
        }

        if (!isActive) await this.dequeue();
    }

    repeatLastCommand(): Promise<void> {
        if (this.lastCommand === undefined) return Promise.resolve();
        return this.exec(this.lastCommand.repeat(this.editor), 'interrupt', false);
    }

    private async dequeue() {
        let next!: Command;
        while (this.next) {
            next = this.next;
            this.active = next;
            this.next = undefined;
            try {
                await this.execute(next);
                if (this.next === undefined) {
                    this.enqueueDefaultCommand(next)
                }
            } catch (e) {
                if (!(e instanceof Cancel) && !(e instanceof Finish) && !(e instanceof Interrupt) && !(e instanceof NoOpError) && !(e instanceof AlreadyFinishedError)) {
                    if (e instanceof ValidationError) console.warn(`${next.title}: ${e.message}`);
                    else console.warn(e);
                }
            } finally { delete this.active }
        }
    }

    private async execute(command: Command) {
        const { snaps, signals, registry, originator, history, db, helpers, backup } = this.editor;
        signals.commandStarted.dispatch(command);
        let processUndoAfterCommandFinished = new Disposable();
        const disposable = new CompositeDisposable();
        disposable.add(registry.add('plasticity-viewport', {
            'command:finish': () => command.finish(),
            'command:abort': () => command.cancel(),
            'command:undo': () => {
                command.cancel();
                if (!command.isFactoryChanged) {
                    processUndoAfterCommandFinished = new Disposable(() => {
                        history.undo();
                        this.enqueueDefaultCommand();
                    });
                }
            },
        }));
        const state = history.current;
        disposable.add(this.decorateBody(command));
        try {
            let selectionChanged = false;
            signals.selectionChanged.addOnce(() => selectionChanged = true);
            disposable.add(this.disableViewportSelector(command));
            await command.execute();
            command.finish(); // ensure all resources are cleaned up
            if (command.state === 'Finished') {
                if (command.shouldAddToHistory(selectionChanged)) {
                    const m = history.add(command.pretty, state);
                    if (m === undefined) throw new Error(`Unable to add to history`);
                    if (command.shouldUpdateBackup()) backup.save(m);
                }
                signals.commandFinishedSuccessfully.dispatch(command);
            } else {
                console.warn(`Command ${command.title} did not finish successfully, ${command.state}`);
                history.restore(state);
            }
        } catch (e) {
            command.cancel();
            history.restore(state);
            throw e;
        } finally {
            PostCommandInvariants: {
                for (const viewport of this.editor.viewports) {
                    viewport.enableControls();
                }
                disposable.dispose();
                db.clearTemporaryObjects();
                db.clearDisabled();
                snaps.xor = false;
                if (helpers.scene.children.length > 0) {
                    console.error("Helpers scene is not empty");
                    console.error([...helpers.scene.children]);
                }
                helpers.clear();
            }

            signals.commandEnded.dispatch(command);

            DebugValidate: {
                if (process.env.NODE_ENV === 'development') {
                    // originator.validate();
                    // console.groupCollapsed(command.title);
                    // originator.debug();
                    // for (const viewport of this.editor.viewports) {
                    //     viewport.validate();
                    // }
                    // console.groupEnd();
                }
            }

            // Undo must happen after any history.restore() calls.
            processUndoAfterCommandFinished.dispose();
        }
    }

    private decorateBody(command: Command) {
        document.body.setAttribute("command", command.identifier);
        const buttons = document.querySelectorAll(`plasticity-command[name=${command.identifier}] > div`);
        for (const button of Array.from(buttons)) {
            button.classList.add('active');
        }
        return new Disposable(() => {
            document.body.removeAttribute("command");
            for (const button of Array.from(buttons)) {
                button.classList.remove('active');
            }
        });
    }

    private disableViewportSelector(command: Command) {
        if (command.agent === 'automatic') {
            command.factoryChanged.addOnce(() => {
                for (const viewport of this.editor.viewports) {
                    viewport.selector.enable(false);
                }
            });
        } else {
            for (const viewport of this.editor.viewports) {
                viewport.selector.enable(false);
            }
        }
        command.factoryChanged.addOnce(() => {
            document.body.setAttribute("changed", "");
        });
        return new Disposable(() => {
            document.body.removeAttribute("changed");
        });
    }

    cancelActiveCommand() {
        const active = this.active;
        if (active) active.cancel();
        return active;
    }

    async enqueueDefaultCommand(prev?: Command) {
        const command = this.editor.commandForSelection.commandFor(prev);
        if (command !== undefined) {
            command.agent = 'automatic';
            await this.exec(command, 'queue', false);
        }
    }

    debug() {
        console.group("Debug")
        console.info("Active: ", this.active);
        console.info("Command: ", this.next);
        console.groupEnd();
    }
}