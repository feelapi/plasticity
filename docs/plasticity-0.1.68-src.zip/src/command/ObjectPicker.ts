import { CompositeDisposable, Disposable } from 'event-kit';
import * as THREE from "three";
import { Outliner, OutlinerSelector } from '../components/outliner/Outliner';
import { makeCustomKeyboardEvent } from '../components/viewport/KeyboardEventManager';
import { Viewport } from '../components/viewport/Viewport';
import { RaycasterParameters } from '../components/viewport/ViewportControl';
import { ReadonlyPlanarCurveDatabase } from '../editor/curves/PlanarCurveDatabase';
import { ReadonlySketchManager } from '../editor/curves/SketchManager';
import { ReadonlyGeometryDatabase } from '../editor/DatabaseLike';
import { EditorSignals } from '../editor/EditorSignals';
import { Empty } from '../editor/Empties';
import { Group } from '../editor/Groups';
import LayerManager from '../editor/LayerManager';
import MaterialDatabase from '../editor/MaterialDatabase';
import { RealNodeItem } from '../editor/Nodes';
import { Scene } from '../editor/Scene';
import { ChangeSelectionExecutor, ChangeSelectionModifier, ChangeSelectionOption, SelectionDelta } from '../selection/ChangeSelectionExecutor';
import { NonemptyClickStrategy } from '../selection/Click';
import { SelectionAccumulator } from '../selection/SelectionAccumulator';
import { HasSelectedAndHovered, HasSelection, Selectable } from '../selection/SelectionDatabase';
import { SelectionKeypressStrategy } from '../selection/SelectionKeypressStrategy';
import { SelectionMode } from '../selection/SelectionModeSet';
import { CurveSelection, CVSelection, EdgeSelection, EmptySelection, FaceSelection, GroupSelection, RegionSelection, SegmentSelection, SheetSelection, ShellSelection, SolidSelection, TypedSelection, VertexSelection } from '../selection/TypedSelection';
import { AbstractViewportSelector } from '../selection/ViewportSelector';
import { CancellablePromise } from "../util/CancellablePromise";
import { assertUnreachable } from '../util/Util';
import { Intersection } from '../visual_model/Intersectable';
import { RenderedSceneBuilder } from '../visual_model/RenderedSceneBuilder';
import * as visual from '../visual_model/VisualModel';
import { Executable } from './Quasimode';

export interface EditorLike {
    db: ReadonlyGeometryDatabase;
    viewports: Iterable<Viewport>;
    outliners: Iterable<Outliner>;
    signals: EditorSignals;
    materials: MaterialDatabase;
    changeSelection: ChangeSelectionExecutor;
    layers: LayerManager;
    keymaps: AtomKeymap.KeymapManager;
    selection: HasSelectedAndHovered;
    highlight: RenderedSceneBuilder;
    scene: Scene;
    sketches: ReadonlySketchManager;
    curves: ReadonlyPlanarCurveDatabase;
}

export class ObjectPickerViewportSelector extends AbstractViewportSelector {
    private readonly nonempty = new NonemptyClickStrategy(this.editor.db, this.editor.sketches, this.editor.curves, this.editor.scene, this.selection.mode, this.selection.selected, this.selection.hovered, this.selection.selected);
    private readonly changeSelection = new ChangeSelectionExecutor(this.selection, this.editor.db, this.editor.sketches, this.editor.curves, this.editor.scene, this.selection.signals, item => this.filter(item), this.nonempty);

    constructor(
        viewport: Viewport,
        private readonly editor: EditorLike,
        private readonly selection: HasSelectedAndHovered,
        raycasterParams: RaycasterParameters,
        layers: LayerManager,
        private readonly prohibitions: ReadonlySet<Selectable>,
        keymapSelector?: string,
    ) {
        const keypress = new SelectionKeypressStrategy(editor.keymaps, keymapSelector);
        super(viewport, layers, editor.db, editor.scene, keypress, editor.signals, raycasterParams);
    }

    // Normally a viewport selector enqueues a ChangeSelectionCommand; however,
    // This class is used in commands to modify a "temporary" selection
    processClick(intersections: Intersection[], upEvent: MouseEvent) {
        this.changeSelection.onClick(intersections, this.keypress.event2modifier(upEvent), this.keypress.event2option(upEvent));
    }

    protected processDblClick(intersects: Intersection[], dblClickEvent: MouseEvent) {
        if (intersects.length === 0) {
            const gestureEvent = makeCustomKeyboardEvent('dblclick+empty', dblClickEvent);
            this.editor.keymaps.handleKeyboardEvent(gestureEvent);
        }
    }

    processBoxSelect(selected: SelectionAccumulator, upEvent: MouseEvent, movingRight: boolean): void {
        if (selected.size === 0) {
            const name = movingRight ? 'dragright+empty' : 'dragleft+empty';
            const gestureEvent = makeCustomKeyboardEvent(name, upEvent);
            this.editor.keymaps.handleKeyboardEvent(gestureEvent);
        } else {
            this.changeSelection.onBoxSelect(selected, this.keypress.event2modifier(upEvent));
        }
    }

    processHover(intersects: Intersection[], moveEvent?: MouseEvent) {
        this.changeSelection.onHover(intersects, this.keypress.event2modifier(moveEvent), this.keypress.event2option(moveEvent));
    }

    processBoxHover(selected: SelectionAccumulator, moveEvent: MouseEvent): void {
        this.changeSelection.onBoxHover(selected, this.keypress.event2modifier(moveEvent));
    }

    protected filter(item: Selectable): boolean {
        return !this.prohibitions.has(item)
    }
}

export class ObjectPickerOutlinerSelector implements OutlinerSelector {
    private readonly nonempty = new NonemptyClickStrategy(this.editor.db, this.editor.sketches, this.editor.curves, this.editor.scene, this.selection.mode, this.selection.selected, this.selection.hovered, this.selection.selected);
    private readonly changeSelection = new ChangeSelectionExecutor(this.selection, this.editor.db, this.editor.sketches, this.editor.curves, this.editor.scene, this.selection.signals, item => !this.prohibitions.has(item), this.nonempty);

    constructor(
        private readonly editor: EditorLike,
        private readonly selection: HasSelectedAndHovered,
        private readonly prohibitions: ReadonlySet<Selectable>,
    ) { }

    select(selected: RealNodeItem[], modifier: ChangeSelectionModifier, option: ChangeSelectionOption): void {
        this.changeSelection.onOutlinerSelect(selected, modifier, option);
    }

    hover(selected: RealNodeItem[], modifier: ChangeSelectionModifier, option: ChangeSelectionOption): void {
        this.changeSelection.onOutlinerHover(selected, modifier, option);
    }
}

type CancelableSelectionArray =
    CancellablePromise<FaceSelection> |
    CancellablePromise<EdgeSelection> |
    CancellablePromise<SegmentSelection> |
    CancellablePromise<SolidSelection> |
    CancellablePromise<CurveSelection> |
    CancellablePromise<VertexSelection> |
    CancellablePromise<CVSelection> |
    CancellablePromise<EdgeSelection | FaceSelection | RegionSelection | SolidSelection | CurveSelection | VertexSelection> |
    CancellablePromise<EmptySelection> |
    CancellablePromise<GroupSelection>

export class ObjectPicker implements Executable<HasSelection, HasSelection> {
    readonly selection: HasSelectedAndHovered;
    readonly layers: LayerManager;

    min = 1; max = 1;
    get mode() { return this.selection.mode }
    private prohibitions: ReadonlySet<Selectable> = new Set();

    readonly raycasterParams: THREE.RaycasterParameters & { Line2: { threshold: number } } = {
        Mesh: { threshold: 0 },
        Line: { threshold: 0.1 },
        Line2: { threshold: 10 },
        Points: { threshold: 10 }
    };

    constructor(private readonly editor: EditorLike, selection?: HasSelectedAndHovered, private readonly keymapSelector?: string) {
        this.selection = selection ?? editor.selection.makeTemporary();
        this.layers = new LayerManager(this.selection, this.selection.signals);
    }

    execute(cb?: (o: HasSelection) => void, min = this.min, max = this.max, mode?: SelectionMode): CancellablePromise<HasSelection> {
        if (min <= 0) return CancellablePromise.resolve(this.selection.selected);

        const { editor, selection, selection: { signals } } = this;
        const disposables = new CompositeDisposable();

        if (cb !== undefined) {
            const onDelta = (_: SelectionDelta) => cb(selection.selected);
            signals.selectionDelta.add(onDelta);
            disposables.add(new Disposable(() => {
                signals.selectionDelta.remove(onDelta);
            }));
        }

        if (mode !== undefined) this.mode.set(mode);

        // NOTE: Because the selection is about to get swapped out, it will not receive endHover events that would clear
        // the hovered set. So we need to clear it manually.
        editor.selection.hovered.removeAll();
        selection.hovered.removeAll();

        disposables.add(editor.highlight.useTemporary(selection));

        const cancellable = new CancellablePromise<HasSelection>((resolve, reject) => {
            const finish = () => cancellable.finish();

            let count = 0;
            const selected = signals.selectionDelta.add(delta => {
                count += this.tally(delta.added);
                count -= this.tally(delta.removed);
                count = Math.max(0, count);
                if (count >= min && count >= max) finish();
            });
            disposables.add(new Disposable(() => {
                selected.detach();
            }));

            for (const viewport of this.editor.viewports) {
                const selector = this.makeSelector(viewport, editor, selection, this.raycasterParams, this.layers, this.prohibitions, this.keymapSelector);
                disposables.add(viewport.multiplexer.only(selector));
                disposables.add(new Disposable(() => selector.dispose()));
            }

            for (const outliner of this.editor.outliners) {
                const selector = new ObjectPickerOutlinerSelector(editor, selection, this.prohibitions);
                disposables.add(outliner.push(selector));
            }

            return {
                dispose: () => disposables.dispose(),
                finish: () => resolve(selection.selected)
            };
        });

        return cancellable;
    }

    protected makeSelector(viewport: Viewport, editor: EditorLike, selection: HasSelectedAndHovered, raycasterParams: RaycasterParameters, layers: LayerManager, prohibitions: ReadonlySet<Selectable>, keymapSelector?: string): AbstractViewportSelector {
        return new ObjectPickerViewportSelector(viewport, editor, selection, raycasterParams, layers, prohibitions, keymapSelector);
    }

    private tally(selectable: Set<Selectable>): number {
        let result = 0;
        for (const s of selectable) {
            if (s instanceof visual.Solid) {
                if (this.mode.has(SelectionMode.Solid)) result++;
            } else if (s instanceof visual.Sheet) {
                if (this.mode.has(SelectionMode.Sheet)) result++;
            } else if (s instanceof visual.SpaceInstance) {
                if (this.mode.has(SelectionMode.Curve)) result++;
            } else if (s instanceof visual.Region) {
                if (this.mode.has(SelectionMode.Region)) result++;
            } else if (s instanceof visual.Face) {
                if (this.mode.has(SelectionMode.Face)) result++;
            } else if (s instanceof visual.SpaceInstance) {
                if (this.mode.has(SelectionMode.Curve)) result++;
            } else if (s instanceof visual.CurveEdge) {
                if (this.mode.has(SelectionMode.CurveEdge)) result++;
            } else if (s instanceof visual.CurveSegmentGroup) {
                if (this.mode.has(SelectionMode.CurveSegment)) result++;
            } else if (s instanceof visual.Vertex) {
                if (this.mode.has(SelectionMode.Vertex)) result++;
            } else if (s instanceof visual.CV) {
                if (this.mode.has(SelectionMode.CV)) result++;
            } else if (s instanceof Empty) {
                if (this.mode.has(SelectionMode.Empty)) result++;
            } else if (s instanceof Group) {
                if (this.mode.has(SelectionMode.Group)) result++;
            } else {
                throw new Error('Unknown selectable: ' + s.constructor.name);
            }
        }
        return result;
    }

    prohibit(prohibitions: Iterable<Selectable>) {
        this.prohibitions = new Set(prohibitions);
    }

    private get(mode: SelectionMode.Face, min?: number, max?: number, shouldMutate?: boolean): CancellablePromise<FaceSelection>;
    private get(mode: SelectionMode.Region, min?: number, max?: number, shouldMutate?: boolean): CancellablePromise<RegionSelection>;
    private get(mode: SelectionMode.CurveEdge, min?: number, max?: number, shouldMutate?: boolean): CancellablePromise<EdgeSelection>;
    private get(mode: SelectionMode.CurveSegment, min?: number, max?: number, shouldMutate?: boolean): CancellablePromise<SegmentSelection>;
    private get(mode: SelectionMode.Solid, min?: number, max?: number, shouldMutate?: boolean): CancellablePromise<SolidSelection>;
    private get(mode: SelectionMode.Sheet, min?: number, max?: number, shouldMutate?: boolean): CancellablePromise<SheetSelection>;
    private get(mode: SelectionMode.Shell, min?: number, max?: number, shouldMutate?: boolean): CancellablePromise<ShellSelection>;
    private get(mode: SelectionMode.Empty, min?: number, max?: number, shouldMutate?: boolean): CancellablePromise<EmptySelection>;
    private get(mode: SelectionMode.Group, min?: number, max?: number, shouldMutate?: boolean): CancellablePromise<GroupSelection>;
    private get(mode: SelectionMode.Curve, min?: number, max?: number, shouldMutate?: boolean): CancellablePromise<CurveSelection>;
    private get(mode: SelectionMode.Vertex, min?: number, max?: number, shouldMutate?: boolean): CancellablePromise<VertexSelection>;
    private get(mode: SelectionMode.CV, min?: number, max?: number, shouldMutate?: boolean): CancellablePromise<CVSelection>;
    private get(mode: SelectionMode, min = 1, max = min, shouldRemove = true): CancelableSelectionArray {
        if (min < 0) throw new Error("min must be > 0");
        if (min === 0) return CancellablePromise.resolve([] as any);

        const result = this.selection.makeTemporary();

        let collection;
        switch (mode) {
            case SelectionMode.Face: collection = mode2collection(SelectionMode.Face, this.selection.selected); break;
            case SelectionMode.Region: collection = mode2collection(SelectionMode.Region, this.selection.selected); break;
            case SelectionMode.CurveEdge: collection = mode2collection(SelectionMode.CurveEdge, this.selection.selected); break;
            case SelectionMode.CurveSegment: collection = mode2collection(SelectionMode.CurveSegment, this.selection.selected); break;
            case SelectionMode.Solid: collection = mode2collection(SelectionMode.Solid, this.selection.selected); break;
            case SelectionMode.Sheet: collection = mode2collection(SelectionMode.Sheet, this.selection.selected); break;
            case SelectionMode.Shell: collection = mode2collection(SelectionMode.Shell, this.selection.selected); break;
            case SelectionMode.Curve: collection = mode2collection(SelectionMode.Curve, this.selection.selected); break;
            case SelectionMode.Vertex: collection = mode2collection(SelectionMode.Vertex, this.selection.selected); break;
            case SelectionMode.CV: collection = mode2collection(SelectionMode.CV, this.selection.selected); break;
            case SelectionMode.Empty: collection = mode2collection(SelectionMode.Empty, this.selection.selected); break;
            case SelectionMode.Group: collection = mode2collection(SelectionMode.Group, this.selection.selected); break;
            default: assertUnreachable(mode);
        }

        if (collection.size >= min) {
            let i = 0;
            for (const item of collection) {
                if (++i > max) break;
                if (shouldRemove) this.selection.selected.remove(item);
                result.selected.add(item);
            }
            switch (mode) {
                case SelectionMode.Face: return CancellablePromise.resolve(mode2collection(SelectionMode.Face, result.selected));
                case SelectionMode.Region: return CancellablePromise.resolve(mode2collection(SelectionMode.Region, result.selected));
                case SelectionMode.CurveEdge: return CancellablePromise.resolve(mode2collection(SelectionMode.CurveEdge, result.selected));
                case SelectionMode.CurveSegment: return CancellablePromise.resolve(mode2collection(SelectionMode.CurveSegment, result.selected));
                case SelectionMode.Solid: return CancellablePromise.resolve(mode2collection(SelectionMode.Solid, result.selected));
                case SelectionMode.Sheet: return CancellablePromise.resolve(mode2collection(SelectionMode.Sheet, result.selected));
                case SelectionMode.Shell: return CancellablePromise.resolve(mode2collection(SelectionMode.Shell, result.selected));
                case SelectionMode.Empty: return CancellablePromise.resolve(mode2collection(SelectionMode.Empty, result.selected));
                case SelectionMode.Group: return CancellablePromise.resolve(mode2collection(SelectionMode.Group, result.selected));
                case SelectionMode.Curve: return CancellablePromise.resolve(mode2collection(SelectionMode.Curve, result.selected));
                case SelectionMode.Vertex: return CancellablePromise.resolve(mode2collection(SelectionMode.Vertex, result.selected));
                case SelectionMode.CV: return CancellablePromise.resolve(mode2collection(SelectionMode.CV, result.selected));
                default: assertUnreachable(mode);
            }
        }

        const picker = new ObjectPicker(this.editor);
        min -= collection.size;
        picker.mode.set(mode);
        picker.min = min;
        picker.max = min;
        picker.copy(this.selection);

        return picker.execute().map(selected => {
            if (!shouldRemove) this.copy(picker.selection);
            let result;
            switch (mode) {
                case SelectionMode.Face: result = mode2collection(SelectionMode.Face, selected); break;
                case SelectionMode.Region: result = mode2collection(SelectionMode.Region, selected); break;
                case SelectionMode.CurveEdge: result = mode2collection(SelectionMode.CurveEdge, selected); break;
                case SelectionMode.CurveSegment: result = mode2collection(SelectionMode.CurveSegment, selected); break;
                case SelectionMode.Solid: result = mode2collection(SelectionMode.Solid, selected); break;
                case SelectionMode.Sheet: result = mode2collection(SelectionMode.Sheet, selected); break;
                case SelectionMode.Shell: result = mode2collection(SelectionMode.Shell, selected); break;
                case SelectionMode.Empty: result = mode2collection(SelectionMode.Empty, selected); break;
                case SelectionMode.Group: result = mode2collection(SelectionMode.Group, selected); break;
                case SelectionMode.Curve: result = mode2collection(SelectionMode.Curve, selected); break;
                case SelectionMode.Vertex: result = mode2collection(SelectionMode.Vertex, selected); break;
                case SelectionMode.CV: result = mode2collection(SelectionMode.CV, selected); break;
                default: assertUnreachable(mode);
            }
            return result;
        }) as CancelableSelectionArray;
    }

    slice(mode: SelectionMode.Face, min?: number, max?: number): CancellablePromise<FaceSelection>;
    slice(mode: SelectionMode.Region, min?: number, max?: number): CancellablePromise<RegionSelection>;
    slice(mode: SelectionMode.CurveEdge, min?: number, max?: number): CancellablePromise<EdgeSelection>;
    slice(mode: SelectionMode.CurveSegment, min?: number, max?: number): CancellablePromise<SegmentSelection>;
    slice(mode: SelectionMode.Solid, min?: number, max?: number): CancellablePromise<SolidSelection>;
    slice(mode: SelectionMode.Sheet, min?: number, max?: number): CancellablePromise<SheetSelection>;
    slice(mode: SelectionMode.Shell, min?: number, max?: number): CancellablePromise<ShellSelection>;
    slice(mode: SelectionMode.Empty, min?: number, max?: number): CancellablePromise<EmptySelection>;
    slice(mode: SelectionMode.Group, min?: number, max?: number): CancellablePromise<GroupSelection>;
    slice(mode: SelectionMode.Curve, min?: number, max?: number): CancellablePromise<CurveSelection>;
    slice(mode: SelectionMode.Vertex, min?: number, max?: number): CancellablePromise<VertexSelection>;
    slice(mode: SelectionMode.CV, min?: number, max?: number): CancellablePromise<CVSelection>;
    slice(mode: SelectionMode, min = 1, max = min): CancelableSelectionArray {
        switch (mode) {
            case SelectionMode.Face: return this.get(mode, min, max, false);
            case SelectionMode.Region: return this.get(mode, min, max, false);
            case SelectionMode.CurveEdge: return this.get(mode, min, max, false);
            case SelectionMode.CurveSegment: return this.get(mode, min, max, false);
            case SelectionMode.Solid: return this.get(mode, min, max, false);
            case SelectionMode.Sheet: return this.get(mode, min, max, false);
            case SelectionMode.Shell: return this.get(mode, min, max, false);
            case SelectionMode.Empty: return this.get(mode, min, max, false);
            case SelectionMode.Group: return this.get(mode, min, max, false);
            case SelectionMode.Curve: return this.get(mode, min, max, false);
            case SelectionMode.Vertex: return this.get(mode, min, max, false);
            case SelectionMode.CV: return this.get(mode, min, max, false);
            default: assertUnreachable(mode);
        }
    }

    shift(mode: SelectionMode.Face, min?: number, max?: number): CancellablePromise<FaceSelection>;
    shift(mode: SelectionMode.Region, min?: number, max?: number): CancellablePromise<RegionSelection>;
    shift(mode: SelectionMode.CurveEdge, min?: number, max?: number): CancellablePromise<EdgeSelection>;
    shift(mode: SelectionMode.CurveSegment, min?: number, max?: number): CancellablePromise<SegmentSelection>;
    shift(mode: SelectionMode.Solid, min?: number, max?: number): CancellablePromise<SolidSelection>;
    shift(mode: SelectionMode.Sheet, min?: number, max?: number): CancellablePromise<SheetSelection>;
    shift(mode: SelectionMode.Shell, min?: number, max?: number): CancellablePromise<ShellSelection>;
    shift(mode: SelectionMode.Empty, min?: number, max?: number): CancellablePromise<EmptySelection>;
    shift(mode: SelectionMode.Group, min?: number, max?: number): CancellablePromise<GroupSelection>;
    shift(mode: SelectionMode.Curve, min?: number, max?: number): CancellablePromise<CurveSelection>;
    shift(mode: SelectionMode.Vertex, min?: number, max?: number): CancellablePromise<VertexSelection>;
    shift(mode: SelectionMode.CV, min?: number, max?: number): CancellablePromise<CVSelection>;
    shift(mode: SelectionMode, min = 1, max = min): CancelableSelectionArray {
        switch (mode) {
            case SelectionMode.Face: return this.get(mode, min, max, true);
            case SelectionMode.Region: return this.get(mode, min, max, true);
            case SelectionMode.CurveEdge: return this.get(mode, min, max, true);
            case SelectionMode.CurveSegment: return this.get(mode, min, max, true);
            case SelectionMode.Solid: return this.get(mode, min, max, true);
            case SelectionMode.Sheet: return this.get(mode, min, max, true);
            case SelectionMode.Shell: return this.get(mode, min, max, true);
            case SelectionMode.Empty: return this.get(mode, min, max, true);
            case SelectionMode.Group: return this.get(mode, min, max, true);
            case SelectionMode.Curve: return this.get(mode, min, max, true);
            case SelectionMode.Vertex: return this.get(mode, min, max, true);
            case SelectionMode.CV: return this.get(mode, min, max, true);
            default: assertUnreachable(mode);
        }
    }

    copy(selection: HasSelectedAndHovered, ...modes: SelectionMode[]) {
        if (modes.length === 0) modes = [...this.mode];
        this.selection.copy(selection, ...modes);
    }
}

function mode2collection(mode: SelectionMode.Face, selected: HasSelection): FaceSelection;
function mode2collection(mode: SelectionMode.Region, selected: HasSelection): RegionSelection;
function mode2collection(mode: SelectionMode.CurveEdge, selected: HasSelection): EdgeSelection;
function mode2collection(mode: SelectionMode.CurveSegment, selected: HasSelection): SegmentSelection;
function mode2collection(mode: SelectionMode.Curve, selected: HasSelection): CurveSelection;
function mode2collection(mode: SelectionMode.Vertex, selected: HasSelection): VertexSelection;
function mode2collection(mode: SelectionMode.CV, selected: HasSelection): CVSelection;
function mode2collection(mode: SelectionMode.Solid, selected: HasSelection): SolidSelection;
function mode2collection(mode: SelectionMode.Sheet, selected: HasSelection): SheetSelection;
function mode2collection(mode: SelectionMode.Shell, selected: HasSelection): ShellSelection;
function mode2collection(mode: SelectionMode.Empty, selected: HasSelection): EmptySelection;
function mode2collection(mode: SelectionMode.Group, selected: HasSelection): GroupSelection;
function mode2collection(mode: SelectionMode, selected: HasSelection): TypedSelection<any, any> {
    let collection;
    switch (mode) {
        case SelectionMode.CurveEdge: collection = selected.edges; break;
        case SelectionMode.CurveSegment: collection = selected.segments; break;
        case SelectionMode.Face: collection = selected.faces; break;
        case SelectionMode.Region: collection = selected.regions; break;
        case SelectionMode.Solid: collection = selected.solids; break;
        case SelectionMode.Sheet: collection = selected.sheets; break;
        case SelectionMode.Shell: collection = selected.shells; break;
        case SelectionMode.Curve: collection = selected.curves; break;
        case SelectionMode.Vertex: collection = selected.vertices; break;
        case SelectionMode.CV: collection = selected.cvs; break;
        case SelectionMode.Empty: collection = selected.empties; break;
        case SelectionMode.Group: collection = selected.groups; break;
        default: assertUnreachable(mode);
    }
    return collection;
}