import * as gizmo from '../command/AbstractGizmo';
import Command, * as cmd from '../command/Command';
import { ExtendCommand } from '../commands/extend/ExtendCommand';
import { ExtrudeCommand } from "../commands/extrude/ExtrudeCommand";
import { FilletSolidCommand } from "../commands/fillet/FilletSolidCommand";
import { PushFaceCommand } from "../commands/offset-face/PushFaceCommand";
import { Database } from '../editor/db/Database';
import MaterialDatabase from '../editor/MaterialDatabase';
import { ClickChangeSelectionCommand } from '../selection/ViewportSelector';

export interface EditorLike extends gizmo.EditorLike, cmd.EditorLike {
    db: Database;
    materials: MaterialDatabase;
}

export class SelectionCommandManager {
    constructor(private readonly editor: EditorLike) { }

    commandFor(command?: Command): Command | undefined {
        const point = command instanceof ClickChangeSelectionCommand ? command.point : undefined;
        const selected = this.editor.selection.selected;

        if (selected.regions.size > 0) {
            const command = new ExtrudeCommand(this.editor);
            command.point = point;
            return command;
        } else if (selected.faces.size > 0) {
            const command = new PushFaceCommand(this.editor);
            command.point = point;
            return command;
        } else if (selected.edges.size > 0) {
            const collection = selected.edges.collection;
            if (collection.IsLaminar()) {
                const command = new ExtendCommand(this.editor);
                command.point = point;
                return command;
            } else {
                const command = new FilletSolidCommand(this.editor);
                command.point = point;
                return command;
            }
        }
    }
}
