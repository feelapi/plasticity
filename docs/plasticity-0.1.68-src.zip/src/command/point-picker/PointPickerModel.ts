import * as THREE from "three";
import { NavigationTargetGenerator } from "../../components/viewport/NavigationTargetGenerator";
import { ReadonlyCrossPointDatabase } from '../../editor/curves/CrossPointDatabase';
import { ReadonlyGeometryDatabase } from "../../editor/DatabaseLike";
import { AxisSnap, LineAxisSnap, PointAxisSnap } from "../../editor/snaps/AxisSnap";
import { ConstructionPlane, ConstructionPlaneSnap } from "../../editor/snaps/ConstructionPlaneSnap";
import { OrRestriction, PlanarOrRestriction } from "../../editor/snaps/OrRestriction";
import { PlaneSnap } from "../../editor/snaps/PlaneSnap";
import { PickedPointSnap, PointSnap } from "../../editor/snaps/PointSnap";
import { ChoosableSnap, PreferrableSnap, RaycastableSnap, Restriction, Snap } from "../../editor/snaps/Snap";
import { ReadonlySnapManager } from "../../editor/snaps/SnapManager";
import { CurveEdgeSnap, CurveEndPointSnap, CurveMidpointSnap, CurveSegmentSnap, EdgePointSnap, FaceCenterPointSnap, FaceSnap } from "../../editor/snaps/Snaps";
import { X, Y, Z } from "../../util/Constants";
import * as visual from "../../visual_model/VisualModel";
import { SnapInfo } from "../SnapPresenter";
import { PointResult, SnapCollection } from './PointPicker';
import { SnapCollector } from "./SnapCollector";

export const XYZSnap = [AxisSnap.X, AxisSnap.Y, AxisSnap.Z];
export type Choice = { snap: ChoosableSnap; info?: { position: THREE.Vector3, orientation: THREE.Quaternion }; sticky: boolean, lock: boolean };
export type Choices = 'Normal' | 'Binormal' | 'Tangent' | 'x' | 'y' | 'z';
export type PreferenceMode = 'none' | 'weak' | 'strong';

type Preference = { snap: PreferrableSnap; info?: { position: THREE.Vector3; orientation: THREE.Quaternion; }; };
type RestrictionState = { tag: 'plane', plane: PlaneSnap } | { tag: 'plane-through-point', restriction?: Restriction, point: THREE.Vector3 } | { tag: 'generic', restriction: Restriction };

export class PointPickerModel {
    private readonly collector = new SnapCollector(this.geo, this.originalCrosses, this.snapManager);
    private readonly pickedPointSnaps = new Array<PointResult>(); // Snaps inferred from points the user actually picked
    private readonly disabled = new Set<Snap>();

    private restriction?: RestrictionState;
    private readonly _restrictionSnaps = new Array<RaycastableSnap>(); // Snap targets for the restrictions
    // FIXME: this can be gotten from last.info
    private lastRestrictionPlane?: PlaneSnap;

    constructor(
        private readonly geo: ReadonlyGeometryDatabase,
        private readonly originalCrosses: ReadonlyCrossPointDatabase,
        private readonly snapManager: ReadonlySnapManager,
        private readonly generator: NavigationTargetGenerator,
    ) { }

    restrictionSnapsFor(): RaycastableSnap[] {
        return this._restrictionSnaps;
    }

    restrictionFor(baseConstructionPlane: ConstructionPlane, isOrtho: boolean): Restriction | undefined {
        const { restriction, pickedPointSnaps } = this;
        if (isOrtho) {
            if (restriction === undefined) {
                if (pickedPointSnaps.length > 0) {
                    const last = pickedPointSnaps[pickedPointSnaps.length - 1];
                    return baseConstructionPlane.move(last.point);
                } else return baseConstructionPlane;
            } else {
                if (restriction.tag === 'plane-through-point') {
                    return baseConstructionPlane.move(restriction.point);
                } else if (restriction.tag === 'plane') {
                    return restriction.plane;
                } else {
                    return restriction.restriction;
                }
            }
        }

        if (restriction === undefined) return undefined;
        
        if (restriction.tag === 'plane-through-point' && restriction.restriction === undefined) {
            return baseConstructionPlane.move(restriction.point);
        } else if (restriction.tag === 'plane-through-point' && restriction.restriction instanceof PlaneSnap) {
            return restriction.restriction;
        } else if (restriction.tag === 'plane-through-point' && restriction.restriction !== undefined) {
            return new OrRestriction([restriction.restriction, baseConstructionPlane.move(restriction.point)]);
        } else if (restriction.tag === 'plane') {
            return restriction.plane;
        } else {
            return restriction.restriction;
        }
    }

    actualConstructionPlaneGiven(baseConstructionPlane: ConstructionPlane, isOrtho: boolean): ConstructionPlane {
        const { restriction, pickedPointSnaps, lastRestrictionPlane } = this;
        if (isOrtho) {
            if (restriction === undefined) {
                if (pickedPointSnaps.length > 0) {
                    const last = pickedPointSnaps[pickedPointSnaps.length - 1];
                    return baseConstructionPlane.move(last.point);
                } else return baseConstructionPlane;
            } else {
                if (restriction.tag === 'plane-through-point') {
                    return baseConstructionPlane.move(restriction.point);
                } else if (restriction.tag === 'plane') {
                    return restriction.plane;
                } else if (pickedPointSnaps.length > 0) {
                    const last = pickedPointSnaps[pickedPointSnaps.length - 1];
                    return baseConstructionPlane.move(last.point);
                } else return baseConstructionPlane;
            }
        }

        if (restriction === undefined) return baseConstructionPlane;

        if (restriction.tag === 'plane-through-point') {
            if (restriction.restriction instanceof PlanarOrRestriction && lastRestrictionPlane !== undefined) {
                return lastRestrictionPlane;
            } else if (restriction.restriction instanceof PlaneSnap) {
                return restriction.restriction;
            } else {
                return baseConstructionPlane.move(restriction.point);
            }
        } else if (restriction.tag === 'plane') {
            return restriction.plane;
        } else return baseConstructionPlane;
    }

    noteLastRestriction(restriction: Restriction | undefined) {
        if (restriction === undefined) return;
        if (this.restriction instanceof PlanarOrRestriction) {
            if (restriction instanceof ConstructionPlaneSnap || restriction instanceof PlaneSnap) {
                this.lastRestrictionPlane = restriction;
            }
        } else {
            this.lastRestrictionPlane = undefined;
        }
    }

    get straightSnaps() { return this.collector.straightSnaps }

    private snapsForLastPickedPoint = new SnapCollection();
    private activatedSnaps = new SnapCollection();
    private async makeSnapsForPickedPoints() {
        const { pickedPointSnaps, straightSnaps, facePreferenceMode } = this;

        this.collector.resetCrosses();

        const snapsForLastPickedPoint = new SnapCollection();
        if (pickedPointSnaps.length > 0) {
            FirstPoint: {
                if (facePreferenceMode !== 'none') {
                    const first = pickedPointSnaps[0];
                    const snap = first.info.snap;
                    const info = { position: first.point, orientation: first.info.orientation };
                    if (snap instanceof FaceSnap) {
                        this._preference = { snap, info };
                    } else if (snap instanceof FaceCenterPointSnap) {
                        this._preference = { snap: snap.faceSnap, info };
                    }
                }
            }
            LastPoint: {
                const last = pickedPointSnaps[pickedPointSnaps.length - 1];
                const lastSnap = last.info.snap;
                const lastOrientation = last.info.snapOrientation;
                let work: (PointSnap | RaycastableSnap)[] = [];
                let axes = [...straightSnaps];
                if (facePreferenceMode === 'strong') {
                    const rotated = axes.map(s => s.rotate(lastOrientation));
                    work = work.concat(new PickedPointSnap(last.point).axes(rotated));
                } else if (facePreferenceMode === 'weak') {
                    const rotated = axes.map(s => s.rotate(lastOrientation));
                    const oriented = new PickedPointSnap(last.point).axes(rotated);
                    for (const axis of oriented) {
                        if (isAxisAligned(axis)) continue;
                        else work.push(axis);
                    }
                    work = work.concat(new PickedPointSnap(last.point).axes(axes));
                } else {
                    work = work.concat(new PickedPointSnap(last.point).axes(axes));
                }
                work = work.concat(lastSnap.additionalSnapsFor(last.point));
                for (const snap of work) {
                    if (snap instanceof PointAxisSnap) { // Such as normal/binormal/tangent
                        await this.collector.addAxis(snap, snapsForLastPickedPoint, []);
                    } else {
                        snapsForLastPickedPoint.push(snap);
                    }
                }
            }
        }
        snapsForLastPickedPoint.update();
        this.snapsForLastPickedPoint = snapsForLastPickedPoint;
        this._activatedHelpers = [];
        this.activatedSnaps = new SnapCollection();
        this.dontActivateSameSnapTwice.clear();
        this.disabled.clear();
        this.collector.updateChoice();
        this.mutualSnaps.clear();
    }

    get lastPickedPoint() {
        const { pickedPointSnaps } = this;
        if (pickedPointSnaps.length === 0) return undefined;
        else return pickedPointSnaps[pickedPointSnaps.length - 1];
    }

    facePreferenceMode: PreferenceMode = 'none';
    private _preference?: Preference;
    get preference(): Preference | undefined { return this._preference; }
    set preference(value: { snap: PreferrableSnap; info?: { position: THREE.Vector3; orientation: THREE.Quaternion; }; } | PreferrableSnap | undefined) {
        if (value === undefined) this._preference = undefined
        else if (value instanceof Snap) this._preference = { snap: value }
        else this._preference = value;
    }

    toggle(snap: Snap) {
        const { disabled } = this;
        if (disabled.has(snap))
            disabled.delete(snap);
        else
            disabled.add(snap);
    }

    isEnabled(snap: Snap): boolean {
        return !this.disabled.has(snap);
    }

    get snaps(): { disabled: Set<Snap>; snapsForLastPickedPoint: SnapCollection; activatedSnaps: SnapCollection; otherAddedSnaps: SnapCollection; } {
        const { disabled, snapsForLastPickedPoint, activatedSnaps, collector: { otherAddedSnaps } } = this;
        return { disabled, snapsForLastPickedPoint, activatedSnaps, otherAddedSnaps };
    }

    restrictToPlaneThroughPoint(point: THREE.Vector3, snap?: Snap): Restriction | undefined {
        let restriction: Restriction | undefined = undefined;
        if (snap !== undefined) {
            if (snap instanceof PlaneSnap) {
                this.restriction = { tag: 'plane-through-point', restriction: snap, point };
            } else if (snap instanceof FaceSnap || snap instanceof FaceCenterPointSnap) {
                const plane = snap.restrictionFor(point);
                this.restriction = { tag: 'plane-through-point', restriction: plane, point };
            } else {
                const restriction = snap.restrictionFor(point);
                this.restriction = { tag: 'plane-through-point', restriction, point };
            }
        } else {
            this.restriction = { tag: 'plane-through-point', restriction: undefined, point };
        }
        return restriction;
    }

    restrictToPlane(plane: PlaneSnap) {
        this.restriction = { tag: 'plane', plane };
    }

    restrictToLine(origin: THREE.Vector3, direction: THREE.Vector3, excludeOrigin: boolean) {
        const line = new LineAxisSnap(direction, origin, excludeOrigin);
        this.restriction = { tag: 'generic', restriction: line };
        this.choose(line, undefined, false, true);
    }

    restrictToEdges(edges: visual.CurveEdge[]): OrRestriction<CurveEdgeSnap> {
        const restrictions = [];
        for (const edge of edges) {
            const model = this.geo.lookupTopologyItem(edge);
            const restriction = new CurveEdgeSnap(edge, model);
            // FIXME: this isn't used by snap picker, which is relying on all geometry. Not as efficient as it could be ...
            // this._restrictionSnaps.push(restriction);
            restrictions.push(restriction);
        }
        const restriction = new OrRestriction(restrictions);
        this.restriction = { tag: 'generic', restriction };
        return restriction;
    }

    restrictToCurves(curves: visual.SpaceInstance[]): OrRestriction<CurveSegmentSnap> {
        const restrictions = [];
        for (const curve of curves) {
            for (const segment of curve.segments) {
                const model = this.geo.lookupTopologyItem(segment);
                const restriction = new CurveSegmentSnap(segment, model, undefined);
                restrictions.push(restriction);
            }
        }
        const restriction = new OrRestriction(restrictions);
        this.restriction = { tag: 'generic', restriction };
        return restriction;
    }

    async addPickedPoint(pointResult: PointResult) {
        this.pickedPointSnaps.push(pointResult);
        await this.makeSnapsForPickedPoints();
    }

    get choice() { return this.collector.choice }
    choose(which: Choices | Snap | undefined, info?: { position: THREE.Vector3; orientation: THREE.Quaternion; }, sticky = false, lock = false) {
        if (typeof which === 'string') {
            let chosen: Choices | Snap | undefined = this.snapsForLastPickedPoint.other.filter(s => s.name == which)[0] as AxisSnap | undefined;
            chosen = chosen ?? which;
            this.collector.choose(chosen, info, sticky, lock);
        } else {
            this.collector.choose(which, info, sticky, lock);
        }
    }

    undo() {
        this.pickedPointSnaps.pop();
        this.makeSnapsForPickedPoints();
    }

    // Sometimes additional snaps are "activated" when the user mouses over an existing snap and hits shift
    private _activatedHelpers: Snap[] = [];
    get activatedHelpers(): readonly Snap[] { return this._activatedHelpers; }
    private readonly dontActivateSameSnapTwice = new Set<Snap>();

    async activateSnapped(info: SnapInfo, viewportInfo: { isOrthoMode: boolean; constructionPlane: ConstructionPlane; }) {
        const { activatedSnaps, _activatedHelpers, pickedPointSnaps } = this;
        const { all: snaps, snapOrientation, position } = info;

        const quat = viewportInfo.isOrthoMode ? viewportInfo.constructionPlane.orientation : new THREE.Quaternion();
        for (const snap of snaps) {
            if (this.dontActivateSameSnapTwice.has(snap)) continue;
            this.dontActivateSameSnapTwice.add(snap);

            const last = pickedPointSnaps[pickedPointSnaps.length - 1];
            if (snap instanceof CurveEndPointSnap || snap instanceof CurveMidpointSnap) {
                await this.collector.addAxesAt(snap.position, quat, XYZSnap, activatedSnaps, _activatedHelpers);
                const tangentSnap = snap.tangentSnap;
                await this.collector.addAxis(tangentSnap, activatedSnaps, _activatedHelpers);
                if (pickedPointSnaps.length > 0) {
                    const parallel = new PointAxisSnap("Parallel", tangentSnap.n, last.point);
                    await this.collector.addAxis(parallel, activatedSnaps, _activatedHelpers);
                }
            } else if (snap instanceof FaceCenterPointSnap) {
                await this.collector.addAxesAt(snap.position, quat, XYZSnap, activatedSnaps, _activatedHelpers);
                await this.collector.addAxis(snap.normalSnap, activatedSnaps, _activatedHelpers);
            } else if (snap instanceof EdgePointSnap) {
                await this.collector.addAxesAt(snap.position, quat, XYZSnap, activatedSnaps, _activatedHelpers);
                const tangent = new PointAxisSnap("Tangent", snap.tangent, snap.position);
                await this.collector.addAxis(tangent, activatedSnaps, _activatedHelpers);
                if (pickedPointSnaps.length > 0) {
                    const parallel = new PointAxisSnap("Parallel", snap.tangent, last.point);
                    await this.collector.addAxis(parallel, activatedSnaps, _activatedHelpers);
                }
            } else if (snap instanceof PointSnap) {
                await this.collector.addAxesAt(snap.position, quat, XYZSnap, activatedSnaps, _activatedHelpers);
            } else if (snap instanceof CurveSegmentSnap) {
                const n = new THREE.Vector3(0, 0, 1);
                n.applyQuaternion(snapOrientation);
                const coincident = new PointAxisSnap("Coincident", n, position);
                await this.collector.addAxis(coincident, activatedSnaps, _activatedHelpers);
                if (pickedPointSnaps.length > 0) {
                    const parallel = new PointAxisSnap("Parallel", n, last.point);
                    await this.collector.addAxis(parallel, activatedSnaps, _activatedHelpers);
                }
            } else if (snap instanceof CurveEdgeSnap) {
                const n = new THREE.Vector3(0, 0, 1);
                n.applyQuaternion(snapOrientation);
                const coincident = new PointAxisSnap("Coincident", n, position);
                await this.collector.addAxis(coincident, activatedSnaps, _activatedHelpers);
                if (pickedPointSnaps.length > 0) {
                    const parallel = new PointAxisSnap("Parallel", n, last.point);
                    await this.collector.addAxis(parallel, activatedSnaps, _activatedHelpers);
                }
                await this.collector.addEdge(snap, position, activatedSnaps, _activatedHelpers);
            } else if (snap instanceof PointAxisSnap) {
                const parallel = new PointAxisSnap("Parallel", snap.n, last.point);
                await this.collector.addAxis(parallel, activatedSnaps, _activatedHelpers);
            }
        }
        activatedSnaps.update();
    }

    // Activate snaps like tan/tan and perp/perp which only make sense when the previously selected point and the
    // current nearby snaps match certain conditions.
    private readonly mutualSnaps = new Set<Snap>();
    activateMutualSnaps(intersected: Iterable<Snap>) {
        const { mutualSnaps, pickedPointSnaps } = this;
        if (pickedPointSnaps.length === 0) return;

        const last = pickedPointSnaps[pickedPointSnaps.length - 1];
        const lastPickedSnap = last.info.snap;
        if (lastPickedSnap === undefined) return;

        for (const snap of intersected) {
            if (mutualSnaps.has(snap)) continue;
            mutualSnaps.add(snap); // idempotent

            if (snap instanceof CurveSegmentSnap) {
                const additional = snap.additionalSnapsGivenPreviousSnap(last.point, lastPickedSnap);
                this.snapsForLastPickedPoint.push(...additional);
                this.snapsForLastPickedPoint.update();
            }
        }
    }

    async addAxesAt(point: THREE.Vector3, orientation: THREE.Quaternion = new THREE.Quaternion()) {
        await this.collector.addAxesAt(point, orientation);
        this.collector.otherAddedSnaps.update();
    }

    async addAxis(axis: AxisSnap) {
        await this.collector.addAxis(axis);
        this.collector.otherAddedSnaps.update();
    }

    addSnap(...snaps: (PointSnap | RaycastableSnap)[]) {
        this.collector.addSnap(...snaps);
    }

    update() {
        this.collector.update();
    }

    clearAddedSnaps() { this.collector.clearAddedSnaps() }

    navigationTargetForLastPickedPoint(current: SnapInfo | undefined): ConstructionPlaneSnap | undefined {
        const { lastPickedPoint, generator } = this;
        const last = lastPickedPoint;
        let cplane: ConstructionPlaneSnap;
        if (last !== undefined) {
            cplane = generator.navigationTargetForPointResult(last).cplane as ConstructionPlaneSnap;
        } else if (current !== undefined) {
            cplane = generator.navigationTargetForPointResult({ point: current.position, info: current }).cplane as ConstructionPlaneSnap;
        } else return;
        return cplane;
    }

    navigationTargetForScreenSpace(current: SnapInfo | undefined, camera: THREE.Camera): ConstructionPlaneSnap | undefined {
        const { lastPickedPoint, generator } = this;
        let position: THREE.Vector3;
        const last = lastPickedPoint;
        if (last !== undefined) {
            position = last.point;
        } else if (current !== undefined) {
            position = current.position;
        } else return;
        const cplane = generator.navigationTargetForCamera(camera, position).cplane as ConstructionPlaneSnap;
        return cplane;
    }
}

export function isAxisAligned(axis: PointAxisSnap): boolean {
    const n = axis.n;
    return (Math.abs(n.dot(X)) > 1 - 10e-6) || (Math.abs(n.dot(Y)) > 1 - 10e-6) || (Math.abs(n.dot(Z)) > 1 - 10e-6)
}
