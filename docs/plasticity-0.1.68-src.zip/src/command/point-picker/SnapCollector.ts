// TODO:
// - remove the 'into' parameter from addAxes at

import * as THREE from "three";
import { CrossPoint, ReadonlyCrossPointDatabase, TemporaryCrossPointDatabase } from '../../editor/curves/CrossPointDatabase';
import { ReadonlyGeometryDatabase } from "../../editor/DatabaseLike";
import { AxisSnap } from "../../editor/snaps/AxisSnap";
import { PickedPointSnap, PointSnap } from "../../editor/snaps/PointSnap";
import { assertChoosable, RaycastableSnap, Snap } from "../../editor/snaps/Snap";
import { ReadonlySnapManager } from "../../editor/snaps/SnapManager";
import { AxisAxisCrossPointSnap, AxisCurveCrossPointSnap, AxisEdgeCrossPointSnap, CurveEdgeSnap, CurveSegmentSnap } from "../../editor/snaps/Snaps";
import * as c3d from '../../kernel/kernel';
import { point2point, vec2vec } from '../../util/Conversion';
import * as visual from "../../visual_model/VisualModel";
import { SnapCollection } from './PointPicker';
import { Choice, Choices, XYZSnap } from "./PointPickerModel";

type AxisId = number;

export class SnapCollector {
    private crosses = new TemporaryCrossPointDatabase(this.geo, this.originalCrosses);
    readonly otherAddedSnaps = new SnapCollection();
    readonly straightSnaps = new Set(XYZSnap); // Snaps going straight off the last picked point
    private readonly keepAlive: Set<c3d.Wire> = new Set();
    private readonly partition = new c3d.Partition();

    constructor(
        private readonly geo: ReadonlyGeometryDatabase,
        private readonly originalCrosses: ReadonlyCrossPointDatabase,
        private readonly snaps: ReadonlySnapManager,
    ) {
        for (const [counter, axis] of snaps.axes) {
            this.cross2axis.set(counter, axis);
        }
    }

    private readonly cross2axis = new Map<AxisId, AxisSnap>();
    private async addAxisCrosses(axis: AxisSnap, into = this.crosses): Promise<Set<CrossPoint>> {
        const counter = this.crosses.makeTemporaryName();
        const line = this.partition.WireBody.CreateLine(point2point(axis.o), vec2vec(axis.n, 1));
        const crosses = await into.add(counter, line);
        this.keepAlive.add(line);
        this.cross2axis.set(counter, axis);
        return crosses;
    }

    resetCrosses() {
        this.crosses = new TemporaryCrossPointDatabase(this.geo, this.originalCrosses);
    }

    clearAddedSnaps() {
        this.otherAddedSnaps.clear();
    }

    addSnap(...snaps: (PointSnap | RaycastableSnap)[]) {
        this.otherAddedSnaps.push(...snaps);
        this.update();
    }

    async addAxesAt(point: THREE.Vector3, orientation = new THREE.Quaternion(), axisSnaps: Iterable<AxisSnap> = this.straightSnaps, into: SnapCollection = this.otherAddedSnaps, other: Snap[] = []) {
        const rotated = [];
        for (const snap of axisSnaps)
            rotated.push(snap.rotate(orientation));
        const axes = new PickedPointSnap(point).axes(rotated);
        for (const axis of axes)
            await this.addAxis(axis, into, other);
    }

    async addAxis(axis: AxisSnap, into: SnapCollection = this.otherAddedSnaps, other: Snap[] = []) {
        into.push(axis); other.push(axis);
        const crosses = await this.addAxisCrosses(axis);
        for (const cross of crosses) {
            if (cross.position.manhattanDistanceTo(axis.o) < 1e-3) continue;

            const isAntecedentAxis = cross.on2.bodyName < 0;
            const antecedentAxis = this.cross2axis.get(cross.on2.bodyName);

            if (isAntecedentAxis) {
                if (antecedentAxis === undefined) continue;
                into.push(new AxisAxisCrossPointSnap(cross, axis, antecedentAxis));
            } else {
                const topologyId = visual.CurveSegment.simpleName(cross.on2.bodyName, cross.on2.edgeId);
                const { view } = this.geo.lookupTopologyItemById(topologyId);
                const snap = this.snaps.lookup(view);
                if (!(snap instanceof CurveSegmentSnap)) continue;
                into.push(new AxisCurveCrossPointSnap(cross, axis, snap));
            }
        }
    }

    async addEdge(edge: CurveEdgeSnap, at: THREE.Vector3, into: SnapCollection = this.otherAddedSnaps, other: Snap[] = []): Promise<void> {
        const model = this.geo.lookupTopologyItem(edge.view);
        const { wires } = await this.partition.WireBody.CreateFromEdges_async([model], new c3d.WireBodyCreateFromEdgesOptions());
        for (const copy of wires) this.keepAlive.add(copy);
        const allCrosses: CrossPoint[] = [];

        for (const copy of wires) {
            const simpleName = this.crosses.makeTemporaryName();
            const crosses = await this.crosses.add(simpleName, copy);
            allCrosses.push(...crosses);
        }
        let alreadyAddedACrossAtThisPoint = false;
        for (const cross of allCrosses) {
            if (!alreadyAddedACrossAtThisPoint && cross.position.manhattanDistanceTo(at) < 1e-3) {
                alreadyAddedACrossAtThisPoint = true;
                continue;
            }

            const isAntecedentAxis = cross.on2.bodyName < 0;
            const antecedentAxis = this.cross2axis.get(cross.on2.bodyName);

            if (isAntecedentAxis) {
                if (antecedentAxis === undefined) continue;
                into.push(new AxisEdgeCrossPointSnap(cross, antecedentAxis, edge));
            }
        }
    }

    find(which: string) {
        return this.otherAddedSnaps.other.filter(s => s.name == which)[0] as AxisSnap | undefined;
    }

    update() {
        this.otherAddedSnaps.update();
    }

    private _choice?: Choice;
    get choice() { return this._choice; }
    choose(which: Choices | Snap | undefined, info?: { position: THREE.Vector3; orientation: THREE.Quaternion; }, sticky = false, lock = false) {
        if (this._choice?.lock) return;
        if (which === undefined) {
            this._choice = undefined;
        } else if (which instanceof Snap) {
            if (which.isChoosable) {
                assertChoosable(which);
                this._choice = { snap: which, info, sticky, lock };
            }
        } else {
            const chosen = this.find(which);
            if (chosen !== undefined)
                this._choice = { snap: chosen, info, sticky, lock };
        }
    }

    updateChoice() {
        if (this._choice !== undefined && !this._choice.sticky)
            this.choose(undefined);
    }
}