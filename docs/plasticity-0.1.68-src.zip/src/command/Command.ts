import _ from "underscore-plus";
import CommandRegistry from "../components/atom/CommandRegistry";
import { Outliner } from "../components/outliner/Outliner";
import { Viewport } from "../components/viewport/Viewport";
import { ReadonlyCrossPointDatabase } from "../editor/curves/CrossPointDatabase";
import { PlanarCurveDatabase } from "../editor/curves/PlanarCurveDatabase";
import { SketchManager } from "../editor/curves/SketchManager";
import { Agent } from "../editor/DatabaseLike";
import { Database } from "../editor/db/Database";
import { GeometryDatabase } from "../editor/db/GeometryDatabase";
import { EditorSignals } from "../editor/EditorSignals";
import { Empties } from "../editor/Empties";
import { ImporterExporter } from "../editor/ImporterExporter";
import LayerManager from "../editor/LayerManager";
import MaterialDatabase from "../editor/MaterialDatabase";
import { Nodes } from "../editor/Nodes";
import { PlaneDatabase } from "../editor/PlaneDatabase";
import { LoftManager } from "../editor/profiles/LoftManager";
import { Scene } from "../editor/Scene";
import { ReadonlySnapManager } from "../editor/snaps/SnapManager";
import { ChangeSelectionExecutor } from "../selection/ChangeSelectionExecutor";
import { HasSelectedAndHovered } from "../selection/SelectionDatabase";
import { CancellableRegistor } from "../util/CancellableRegistor";
import { Helpers } from "../util/Helpers";
import { GConstructor } from "../util/Util";
import { RenderedSceneBuilder } from "../visual_model/RenderedSceneBuilder";
import { ExecutionMode } from "./CommandExecutor";
import { GeometryFactory } from "./GeometryFactory";
import { GizmoMaterialDatabase } from "./GizmoMaterials";

/**
 * Commands have two responsibilities. They are usually a step-by-step interactive workflow for geometrical
 * operations, like creating a cylinder. But they also encapsulate any state change that needs to be atomic,
 * for the purposes of UNDO. Thus, selection changes are also commands.
 * 
 * For the most part, a Command is a user-friendly wrapper around a Factory. The factory actually creates 
 * geometrical objects and adds them to the database. Whereas the Command shows the users a dialog box,
 * interactive gizmos, etc. While the user interacts with the gizmo or dialog fields, the factory is
 * "updated". When the user is finished the factory is "committed".
 * 
 * Commands can be written such that they complete immediately after the user's first interaction
 * (as in the Move command), or they can stick around allowing the user to refine values and finish
 * only when the user clicks "ok" (as in the Fillet command).
 * 
 * A key implementation detail of Commands is that they have "resources". Resources include gizmos, dialogs,
 * and factories. A resource represents something that can be "finished" or "cancelled." Modeling all of
 * these objects as resources makes it easy to clean-up a command when finishing or cancelling. Because
 * most resources deal with Promises, it's important to make sure all exceptions are handled. Normally,
 * `await gizmo.execute()` is most natural, but for more complicated commands, `await this.finished` is
 * an option.
 */

export interface EditorLike {
    db: Database;
    geo: GeometryDatabase;
    curves: PlanarCurveDatabase;
    signals: EditorSignals;
    materials: MaterialDatabase;
    viewports: Iterable<Viewport>;
    outliners: Iterable<Outliner>;
    snaps: ReadonlySnapManager;
    helpers: Helpers;
    registry: CommandRegistry;
    selection: HasSelectedAndHovered;
    gizmos: GizmoMaterialDatabase;
    changeSelection: ChangeSelectionExecutor;
    layers: LayerManager;
    activeViewport?: Viewport;
    exec(command: Command): Promise<void>;
    enqueue(command: Command): Promise<void>;
    skip(command: Command): Promise<void>;
    crosses: ReadonlyCrossPointDatabase;
    keymaps: AtomKeymap.KeymapManager;
    highlight: RenderedSceneBuilder;
    scene: Scene;
    nodes: Nodes;
    importer: ImporterExporter;
    factoryCache: Map<GConstructor<GeometryFactory<any, any, any>>, any>;
    empties: Empties;
    planes: PlaneDatabase;
    sketches: SketchManager;
    lofts: LoftManager;
}

export default abstract class Command extends CancellableRegistor {
    static get title() { return this.name.replace(/Command/, '') }
    static get identifier() { return _.dasherize(this.title) }

    get title() { return this.constructor.name.replace(/Command/, '') }
    get identifier() { return _.dasherize(this.title) }
    get pretty() { return _.undasherize(this.identifier) }

    remember: boolean = true;
    agent: Agent = 'user';

    constructor(protected readonly editor: EditorLike) { super() }

    abstract execute(): Promise<void>;

    shouldAddToHistory(selectionChanged: boolean) {
        return true;
    }

    shouldUpdateBackup() {
        return true;
    }

    repeat(editor: EditorLike) {
        const constructor = this.constructor as GConstructor<Command>;
        return new constructor(editor);
    }
}

export abstract class CommandLike extends Command {
    remember = false;
}