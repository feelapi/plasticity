import * as c3d from '../kernel/kernel';
import { assertUnreachable } from '../util/Util';
import * as visual from '../visual_model/VisualModel';
import { GeometryFactory } from './GeometryFactory';

function registerKey<T extends GeometryFactory<any, any, any>>(target: GeometryFactory<any, any, []> & { factories: T[] }, propertyKey: keyof T) {
    const privatePropertyKey = `_${String(propertyKey)}`;
    if (!('delegated' in Object.getOwnPropertyNames(target))) {
        // In the clase of @delegate in class hierarchy, we need to copy over the delegated properties so we can insert into it without polluting the parent
        const value: any[] = ((target as any)['delegated']) ?? [];
        Object.defineProperty(target, 'delegated', { value: Array.from(value), writable: false, configurable: true });
    }
    ((target as any)['delegated'] as (keyof T)[]).push(propertyKey);
    return privatePropertyKey;
}

function _delegate(initial?: any) {
    return function <T extends GeometryFactory<any, any, any>>(target: GeometryFactory<any, any, []> & { factories: T[] }, propertyKey: keyof T) {
        const privatePropertyKey = registerKey(target, propertyKey);
        Object.defineProperty(target, privatePropertyKey, { value: initial, writable: true })
        Object.defineProperty(target, propertyKey, {
            get() { return this[privatePropertyKey] },
            set(t: any) {
                this[privatePropertyKey] = t;
                const that = this as GeometryFactory & { factories: T[] };
                const factories = that['factories'] as T[];
                factories.forEach(i => i[propertyKey] = t);
            },
            configurable: true,
        })
    }
}

export function delegate<T extends GeometryFactory<any, any, any>>(target: GeometryFactory<any, any, []> & { factories: T[] }, propertyKey: keyof T) {
    _delegate(undefined)(target, propertyKey);
}

delegate.default = function (initial?: any) {
    return _delegate(initial);
}

// Call when adding a subfactory: copy over all the other parameters that are delegated
delegate.update = function <T extends GeometryFactory<any, any, any>>(target: GeometryFactory<any, any, []> & { factories: T[] }, propertyKey: string, descriptor: PropertyDescriptor) {
    const old = descriptor.set;
    descriptor.set = function (this: typeof target, value: any) {
        if (old !== undefined) old.call(this, value);
        const delegated = ((this as any)['delegated'] as (keyof typeof target)[]) ?? [];
        for (const delegation of delegated) {
            if (this[delegation] !== undefined) {
                // @ts-expect-error
                this[delegation] = this[delegation];
            }
        }
    }
}

delegate.some = function <T extends GeometryFactory>(target: GeometryFactory & { factories: T[] }, propertyKey: keyof T, descriptor: PropertyDescriptor) {
    descriptor.get = function (this: GeometryFactory & { factories: T[] }) {
        return this.factories.some(f => f[propertyKey]);
    }
}

delegate.get = function <T extends GeometryFactory<any, any, any>>(target: GeometryFactory<any, any, []> & { factories: T[] }, propertyKey: keyof T) {
    Object.defineProperty(target, propertyKey, {
        get() {
            const that = this as GeometryFactory & { factories: T[] };
            const factories = that['factories'] as T[];
            return factories[factories.length - 1][propertyKey];
        },
        set(t: any) {
            const that = this as GeometryFactory & { factories: T[] };
            const factories = that['factories'] as T[];
            factories.forEach(i => i[propertyKey] = t);
        },
        configurable: true
    })
}

delegate.register = function <T extends GeometryFactory<any, any, any>>(target: GeometryFactory<any, any, []> & { factories: T[] }, propertyKey: keyof T) {
    registerKey(target, propertyKey);
}

type Derivable =
    typeof visual.Shell |
    typeof visual.Solid |
    typeof visual.Face |
    typeof visual.SpaceInstance |
    typeof visual.Region |
    typeof visual.SketchIsland |
    typeof visual.Sheet |
    typeof visual.Vertex |
    typeof visual.CurveSegment |
    typeof visual.CurveEdge |
    [typeof visual.Face] |
    [typeof visual.CurveEdge] |
    [typeof visual.SpaceInstance] |
    [typeof visual.Region] |
    [typeof visual.Item] |
    [typeof visual.Vertex] |
    [typeof visual.CV];

export function derive<T extends Derivable>(type: T) {
    return function <T extends GeometryFactory<any, any, any>>(target: T, propertyKey: keyof T, descriptor: PropertyDescriptor) {
        switch (type) {
            case visual.Shell: {
                descriptor.set = function (this: GeometryFactory, t: visual.Sheet | visual.Solid | c3d.Sheet | c3d.Solid) {
                    const value: { view?: visual.Sheet | visual.Solid, model?: c3d.Sheet | c3d.Solid } = {};
                    if (t instanceof c3d.Solid || t instanceof c3d.Sheet) value.model = t;
                    else {
                        value.view = t;
                        if (t instanceof visual.Solid) value.model = this.db.lookup(t);
                        else if (t instanceof visual.Sheet) value.model = this.db.lookup(t);
                        else assertUnreachable(t);
                    }
                    // @ts-ignore
                    this[`_${String(propertyKey)}`] = value;
                }
                Object.defineProperty(target, `_${String(propertyKey)}`, { value: {}, writable: true });
                descriptor.get = function (this: GeometryFactory) {
                    // @ts-ignore
                    return this[`_${String(propertyKey)}`].view;
                }
                break;
            }
            case visual.Solid: {
                descriptor.set = function (this: GeometryFactory, t: visual.Solid | c3d.Solid) {
                    const value: { view?: visual.Solid, model?: c3d.Solid } = {};
                    if (t instanceof c3d.Solid) value.model = t;
                    else {
                        value.view = t;
                        value.model = this.db.lookup(t);
                    }
                    // @ts-ignore
                    this[`_${String(propertyKey)}`] = value;
                }
                Object.defineProperty(target, `_${String(propertyKey)}`, { value: {}, writable: true });
                descriptor.get = function (this: GeometryFactory) {
                    // @ts-ignore
                    return this[`_${String(propertyKey)}`].view;
                }
                break;
            }
            case visual.Sheet: {
                descriptor.set = function (this: GeometryFactory, t: visual.Sheet | c3d.Sheet) {
                    const value: { view?: visual.Sheet, model?: c3d.Sheet } = {};
                    if (t instanceof c3d.Sheet) value.model = t;
                    else {
                        value.view = t;
                        value.model = this.db.lookup(t);
                    }
                    // @ts-ignore
                    this[`_${String(propertyKey)}`] = value;
                }
                Object.defineProperty(target, `_${String(propertyKey)}`, { value: {}, writable: true });
                descriptor.get = function (this: GeometryFactory) {
                    // @ts-ignore
                    return this[`_${String(propertyKey)}`].view;
                }
                break;
            }
            case visual.Face: {
                descriptor.set = function (this: GeometryFactory, t: visual.Face | c3d.Face) {
                    const value: { view?: visual.Face, model?: c3d.Face } = {};
                    if (t instanceof c3d.Face) value.model = t;
                    else {
                        value.view = t;
                        value.model = this.db.lookupTopologyItem(t);
                    }
                    // @ts-ignore
                    this[`_${String(propertyKey)}`] = value;
                }
                Object.defineProperty(target, `_${String(propertyKey)}`, { value: {}, writable: true });
                descriptor.get = function (this: GeometryFactory) {
                    // @ts-ignore
                    return this[`_${String(propertyKey)}`].view;
                }
                break;
            }
            case visual.CurveEdge: {
                descriptor.set = function (this: GeometryFactory, t: visual.CurveEdge | c3d.Edge) {
                    const value: { view?: visual.CurveEdge, model?: c3d.Edge } = {};
                    if (t instanceof c3d.Edge) value.model = t;
                    else {
                        value.view = t;
                        value.model = this.db.lookupTopologyItem(t);
                    }
                    // @ts-ignore
                    this[`_${String(propertyKey)}`] = value;
                }
                Object.defineProperty(target, `_${String(propertyKey)}`, { value: {}, writable: true });
                descriptor.get = function (this: GeometryFactory) {
                    // @ts-ignore
                    return this[`_${String(propertyKey)}`].view;
                }
                break;
            }
            case visual.CurveSegment: {
                descriptor.set = function (this: GeometryFactory, t: visual.CurveSegment | c3d.Edge) {
                    const value: { view?: visual.CurveSegment, model?: c3d.Edge } = {};
                    if (t instanceof c3d.Edge) value.model = t;
                    else {
                        value.view = t;
                        value.model = this.db.lookupTopologyItem(t);
                    }
                    // @ts-ignore
                    this[`_${String(propertyKey)}`] = value;
                }
                Object.defineProperty(target, `_${String(propertyKey)}`, { value: {}, writable: true });
                descriptor.get = function (this: GeometryFactory) {
                    // @ts-ignore
                    return this[`_${String(propertyKey)}`].view;
                }
                break;
            }
            case visual.SpaceInstance: {
                descriptor.set = function (this: GeometryFactory, t: visual.SpaceInstance | c3d.Wire) {
                    const value: { view?: visual.SpaceInstance, model?: c3d.Wire } = {};
                    if (t instanceof c3d.Wire) value.model = t;
                    else {
                        value.view = t;
                        value.model = this.db.lookup(t) as c3d.Wire;
                    }
                    // @ts-ignore
                    this[`_${String(propertyKey)}`] = value;
                }
                Object.defineProperty(target, `_${String(propertyKey)}`, { value: {}, writable: true });
                descriptor.get = function (this: GeometryFactory) {
                    // @ts-ignore
                    return this[`_${String(propertyKey)}`].view;
                }
                break;
            }
            case visual.Region: {
                descriptor.set = function (this: GeometryFactory, t: visual.Region | c3d.Face) {
                    const value: { view?: visual.Region, model?: c3d.Face } = {};
                    if (t instanceof c3d.Face) value.model = t;
                    else {
                        value.view = t;
                        value.model = this.db.lookupTopologyItem(t);
                    }
                    // @ts-ignore
                    this[`_${String(propertyKey)}`] = value;
                }
                Object.defineProperty(target, `_${String(propertyKey)}`, { value: {}, writable: true });
                descriptor.get = function (this: GeometryFactory) {
                    // @ts-ignore
                    return this[`_${String(propertyKey)}`].view;
                }
                break;
            }
            case visual.SketchIsland: {
                descriptor.set = function (this: GeometryFactory, t: visual.SketchIsland | c3d.RegionBody) {
                    const value: { view?: visual.SketchIsland, model?: c3d.RegionBody } = {};
                    if (t instanceof c3d.RegionBody) value.model = t;
                    else {
                        value.view = t;
                        value.model = this.db.lookup(t) as c3d.RegionBody;
                    }
                    // @ts-ignore
                    this[`_${String(propertyKey)}`] = value;
                }
                Object.defineProperty(target, `_${String(propertyKey)}`, { value: {}, writable: true });
                descriptor.get = function (this: GeometryFactory) {
                    // @ts-ignore
                    return this[`_${String(propertyKey)}`].view;
                }
                break;
            }
            case visual.Vertex: {
                descriptor.set = function (this: GeometryFactory, t: visual.Vertex) {
                    const value: { view?: visual.Vertex, model?: c3d.Vertex } = {};
                    if (t instanceof c3d.Vertex) value.model = t;
                    else {
                        value.view = t;
                        value.model = this.db.lookupTopologyItemById(t.simpleName).model as c3d.Vertex;
                    }
                    // @ts-ignore
                    this[`_${String(propertyKey)}`] = value;
                }
                Object.defineProperty(target, `_${String(propertyKey)}`, { value: {}, writable: true });
                descriptor.get = function (this: GeometryFactory) {
                    // @ts-ignore
                    return this[`_${String(propertyKey)}`].view;
                }
                break;
            }
            default:
                if (Array.isArray(type) && type[0] === visual.Face) {
                    descriptor.set = function (this: GeometryFactory, t: visual.Face[] | c3d.Face[]) {
                        const value: { views?: visual.Face[], models?: c3d.Face[] } = { views: [], models: [] };
                        if (t[0] instanceof visual.Face) {
                            const views = t as visual.Face[];

                            const models = [];
                            for (const face of views) {
                                const model = this.db.lookupTopologyItem(face);
                                models.push(model);
                            }
                            value.views = views;
                            value.models = models;
                        } else {
                            value.models = t as c3d.Face[];
                        }
                        // @ts-ignore
                        this[`_${String(propertyKey)}`] = value;
                    }
                    Object.defineProperty(target, `_${String(propertyKey)}`, { value: { views: [], models: [] }, writable: true });
                    descriptor.get = function (this: GeometryFactory) {
                        // @ts-ignore
                        return this[`_${String(propertyKey)}`].views;
                    }
                } else if (Array.isArray(type) && type[0] === visual.Region) {
                    descriptor.set = function (this: GeometryFactory, t: visual.Region[] | c3d.Face[]) {
                        const value: { views?: visual.Region[], models?: c3d.Face[] } = { views: [], models: [] };
                        if (t[0] instanceof visual.Region) {
                            const views = t as visual.Region[];

                            const models = [];
                            for (const region of views) {
                                const model = this.db.lookupTopologyItem(region);
                                models.push(model);
                            }
                            value.views = views;
                            value.models = models;
                        } else {
                            value.models = t as c3d.Face[];
                        }
                        // @ts-ignore
                        this[`_${String(propertyKey)}`] = value;
                    }
                    Object.defineProperty(target, `_${String(propertyKey)}`, { value: { views: [], models: [] }, writable: true });
                    descriptor.get = function (this: GeometryFactory) {
                        // @ts-ignore
                        return this[`_${String(propertyKey)}`].views;
                    }
                } else if (Array.isArray(type) && type[0] === visual.CurveEdge) {
                    descriptor.set = function (this: GeometryFactory, t: visual.CurveEdge[] | c3d.Edge[]) {
                        const value: { views?: visual.CurveEdge[], models?: c3d.Edge[] } = { views: [], models: [] };
                        if (t[0] instanceof visual.CurveEdge) {
                            const views = t as visual.CurveEdge[];

                            const models = [];
                            for (const edge of views) {
                                const model = this.db.lookupTopologyItem(edge);
                                models.push(model);
                            }
                            value.views = views;
                            value.models = models;
                        } else {
                            value.models = t as c3d.Edge[];
                        }
                        // @ts-ignore
                        this[`_${String(propertyKey)}`] = value;
                    }
                    Object.defineProperty(target, `_${String(propertyKey)}`, { value: { views: [], models: [] }, writable: true });
                    descriptor.get = function (this: GeometryFactory) {
                        // @ts-ignore
                        return this[`_${String(propertyKey)}`].views;
                    }
                } else if (Array.isArray(type) && type[0] === visual.SpaceInstance) {
                    descriptor.set = function (this: GeometryFactory, t: visual.SpaceInstance[] | c3d.Wire[]) {
                        const value: { views?: visual.SpaceInstance[], models?: c3d.Wire[] } = { views: [], models: [] };
                        if (t[0] instanceof visual.SpaceInstance) {
                            const views = t as visual.SpaceInstance[];

                            const models = [];
                            for (const edge of views) {
                                const model = this.db.lookup(edge);
                                models.push(model);
                            }
                            value.views = views;
                            value.models = models;
                        } else {
                            value.models = t as c3d.Wire[];
                        }
                        // @ts-ignore
                        this[`_${String(propertyKey)}`] = value;
                    }
                    Object.defineProperty(target, `_${String(propertyKey)}`, { value: { views: [], models: [] }, writable: true });
                    descriptor.get = function (this: GeometryFactory) {
                        // @ts-ignore
                        return this[`_${String(propertyKey)}`].views;
                    }
                } else if (Array.isArray(type) && type[0] === visual.Region) {
                    descriptor.set = function (this: GeometryFactory, t: visual.SketchIsland[] | c3d.RegionBody[]) {
                        const value: { views?: visual.SketchIsland[], models?: c3d.RegionBody[] } = { views: [], models: [] };
                        if (t[0] instanceof visual.Region) {
                            const views = t as visual.SketchIsland[];

                            const models = [];
                            for (const region of views) {
                                const model = this.db.lookup(region);
                                models.push(model);
                            }
                            value.views = views;
                            value.models = models;
                        } else {
                            value.models = t as c3d.RegionBody[];
                        }
                        // @ts-ignore
                        this[`_${String(propertyKey)}`] = value;
                    }
                    Object.defineProperty(target, `_${String(propertyKey)}`, { value: { views: [], models: [] }, writable: true });
                    descriptor.get = function (this: GeometryFactory) {
                        // @ts-ignore
                        return this[`_${String(propertyKey)}`].views;
                    }
                } else if (Array.isArray(type) && type[0] === visual.Item) {
                    descriptor.set = function (this: GeometryFactory, t: visual.Item[] | c3d.Body[]) {
                        const value: { views?: visual.Item[], models?: c3d.Body[] } = { views: [], models: [] };
                        if (t[0] instanceof visual.Item) {
                            const views = t as visual.Item[];

                            const models = [];
                            for (const region of views) {
                                const model = this.db.lookup(region);
                                models.push(model);
                            }
                            value.views = views;
                            value.models = models;
                        } else {
                            value.models = t as c3d.Body[];
                        }
                        // @ts-ignore
                        this[`_${String(propertyKey)}`] = value;
                    }
                    Object.defineProperty(target, `_${String(propertyKey)}`, { value: { views: [], models: [] }, writable: true });
                    descriptor.get = function (this: GeometryFactory) {
                        // @ts-ignore
                        return this[`_${String(propertyKey)}`].views;
                    }
                } else if (Array.isArray(type) && type[0] === visual.Solid) {
                    descriptor.set = function (this: GeometryFactory, t: any) {
                        const value: { views?: visual.Solid[], models?: c3d.Solid[] } = { views: [], models: [] };
                        if (t[0] instanceof visual.Solid) {
                            const views = t as visual.Solid[];

                            const models = [];
                            for (const region of views) {
                                const model = this.db.lookup(region);
                                models.push(model);
                            }
                            value.views = views;
                            value.models = models;
                        } else {
                            value.models = t as c3d.Solid[];
                        }
                        // @ts-ignore
                        this[`_${String(propertyKey)}`] = value;
                    }
                    Object.defineProperty(target, `_${String(propertyKey)}`, { value: { views: [], models: [] }, writable: true });
                    descriptor.get = function (this: GeometryFactory) {
                        // @ts-ignore
                        return this[`_${String(propertyKey)}`].views;
                    }
                } else if (Array.isArray(type) && type[0] === visual.Sheet) {
                    descriptor.set = function (this: GeometryFactory, t: any) {
                        const value: { views?: visual.Sheet[], models?: c3d.Sheet[] } = { views: [], models: [] };
                        if (t[0] instanceof visual.Sheet) {
                            const views = t as visual.Sheet[];

                            const models = [];
                            for (const region of views) {
                                const model = this.db.lookup(region);
                                models.push(model);
                            }
                            value.views = views;
                            value.models = models;
                        } else {
                            value.models = t as c3d.Sheet[];
                        }
                        // @ts-ignore
                        this[`_${String(propertyKey)}`] = value;
                    }
                    Object.defineProperty(target, `_${String(propertyKey)}`, { value: { views: [], models: [] }, writable: true });
                    descriptor.get = function (this: GeometryFactory) {
                        // @ts-ignore
                        return this[`_${String(propertyKey)}`].views;
                    }
                } else if (Array.isArray(type) && type[0] === visual.Shell) {
                    descriptor.set = function (this: GeometryFactory, t: any) {
                        const value: { views?: visual.Shell[], models?: c3d.Shell[] } = { views: [], models: [] };
                        if (t[0] instanceof visual.Shell) {
                            const views = t as visual.Shell[];

                            const models = [];
                            for (const shell of views) {
                                const model = this.db.lookup(shell);
                                models.push(model);
                            }
                            value.views = views;
                            value.models = models;
                        } else {
                            value.models = t as c3d.Shell[];
                        }
                        // @ts-ignore
                        this[`_${String(propertyKey)}`] = value;
                    }
                    Object.defineProperty(target, `_${String(propertyKey)}`, { value: { views: [], models: [] }, writable: true });
                    descriptor.get = function (this: GeometryFactory) {
                        // @ts-ignore
                        return this[`_${String(propertyKey)}`].views;
                    }
                } else if (Array.isArray(type) && type[0] === visual.Vertex) {
                    descriptor.set = function (this: GeometryFactory, t: any) {
                        const value: { views?: visual.Vertex[], models?: c3d.Vertex[] } = { views: [], models: [] };
                        if (t[0] instanceof visual.Vertex) {
                            const views = t as visual.Vertex[];

                            const models = [];
                            for (const point of views) {
                                const model = this.db.lookupTopologyItemById(point.simpleName).model as c3d.Vertex;
                                models.push(model);
                            }
                            value.views = views;
                            value.models = models;
                        } else {
                            value.models = t as c3d.Vertex[];
                        }
                        // @ts-ignore
                        this[`_${String(propertyKey)}`] = value;
                    }
                    Object.defineProperty(target, `_${String(propertyKey)}`, { value: { views: [], models: [] }, writable: true });
                    descriptor.get = function (this: GeometryFactory) {
                        // @ts-ignore
                        return this[`_${String(propertyKey)}`].views;
                    }
                } else if (Array.isArray(type) && type[0] === visual.CV) {
                    descriptor.set = function (this: GeometryFactory, t: any) {
                        const value: { views?: visual.CV[], models?: c3d.CV[] } = { views: [], models: [] };
                        if (t[0] instanceof visual.CV) {
                            const views = t as visual.CV[];

                            const models = [];
                            for (const point of views) {
                                const model = point.id;
                                models.push(model);
                            }
                            value.views = views;
                            value.models = models;
                        } else {
                            value.models = t as c3d.CV[];
                        }
                        // @ts-ignore
                        this[`_${String(propertyKey)}`] = value;
                    }
                    Object.defineProperty(target, `_${String(propertyKey)}`, { value: { views: [], models: [] }, writable: true });
                    descriptor.get = function (this: GeometryFactory) {
                        // @ts-ignore
                        return this[`_${String(propertyKey)}`].views;
                    }
                } else
                    throw new Error('Unsupported type');
                break;
        }
    }
}