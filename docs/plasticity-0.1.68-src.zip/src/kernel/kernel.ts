import pk from '../../build/Release/pk.node';
import '../../lib/pk/ts/enums';

import { unit, vec2vec } from '../util/Conversion';

export const Point = pk.Vector;
export type Point = pk.Vector;
export const Vector = pk.Vector;
export type Vector = pk.Vector;
export const Matrix = pk.Matrix;
export type Matrix = pk.Matrix;
export const Transform = pk.Transform;
export type Transform = pk.Transform;
export type FacetFacesAndEdgesResult = pk.FacetFacesAndEdgesResult;
export type FacetEdgesResult = pk.FacetEdgesResult;
export type Edge = pk.Edge;
export const Edge = pk.Edge;
export type Face = pk.Face;
export const Face = pk.Face;
export type Geometry = pk.Geometry;
export const Geometry = pk.Geometry;
export type Surface = pk.Surface;
export const Surface = pk.Surface;
export type Plane = pk.Plane;
export const Plane = pk.Plane;
export type Curve3D = pk.Curve;
export type SectionOptions = pk.SectionOptions;
export const SectionOptions = pk.SectionOptions;
export type Sheet = pk.SheetBody;
export const Sheet = pk.SheetBody;
export type Shell = pk.ShellBody;
export const Shell = pk.ShellBody;
export type Circle = pk.Circle;
export const Circle = pk.Circle;
export type SessionMark = pk.SessionMark;
export const SessionMark = pk.SessionMark;
export type Model = Object;
export const Model = Object;
export const Session = pk.Session;
export type EntityId = ReturnType<typeof pk.Entity.prototype.Id>;
export type SketchId = ReturnType<typeof pk.Sketch.prototype.Id>;
export type HollowOptions = pk.HollowOptions;
export const HollowOptions = pk.HollowOptions;
export type ThickenOptions = pk.ThickenOptions;
export const ThickenOptions = pk.ThickenOptions;
export type BodyIntersectionCurveOptions = pk.BodyIntersectionCurveOptions;
export const BodyIntersectionCurveOptions = pk.BodyIntersectionCurveOptions;
export type ProjectCurveOptions = pk.ProjectCurveOptions;
export const ProjectCurveOptions = pk.ProjectCurveOptions;
export type SheetBodyMakeFromFacesOptions = pk.SheetBodyMakeFromFacesOptions;
export const SheetBodyMakeFromFacesOptions = pk.SheetBodyMakeFromFacesOptions;
export type WireBodyCreateFromEdgesOptions = pk.WireBodyCreateFromEdgesOptions;
export const WireBodyCreateFromEdgesOptions = pk.WireBodyCreateFromEdgesOptions;
export type FaceBlendOptions = pk.FaceBlendOptions;
export const FaceBlendOptions = pk.FaceBlendOptions;
export type FillHoleOptions = pk.FillHoleOptions;
export const FillHoleOptions = pk.FillHoleOptions;
export type FillHolePreferenceType = pk.FillHolePreferenceType;
export const FillHolePreferenceType = pk.FillHolePreferenceType;
export type FillHoleInternalSmoothnessType = pk.FillHoleInternalSmoothnessType;
export const FillHoleInternalSmoothnessType = pk.FillHoleInternalSmoothnessType;
export type ContinuityType = pk.ContinuityType;
export const ContinuityType = pk.ContinuityType;
export type ClashType = pk.ClashType;
export const ClashType = pk.ClashType;
export type BlendShape = pk.BlendShape;
export const BlendShape = pk.BlendShape;
export type Loop = pk.Loop;
export const Loop = pk.Loop;
export type CreateSplineOptions = pk.CreateSplineOptions;
export const CreateSplineOptions = pk.CreateSplineOptions;
export type SplineDerivativeCondition = pk.SplineDerivativeCondition;
export const SplineDerivativeCondition = pk.SplineDerivativeCondition;
export type BCurve = pk.BCurve;
export const BCurve = pk.BCurve;
export type CVCollection = pk.CVCollection;
export const CVCollection = pk.CVCollection;

export type CV = number;

export type ExtrudeOptions = pk.ExtrudeOptions;
export const ExtrudeOptions = pk.ExtrudeOptions;
export type LoftOptions = pk.LoftOptions;
export const LoftOptions = pk.LoftOptions;
export const SweepOptions = pk.SweepOptions;
export type SweepOptions = pk.SweepOptions;
export const SweptToolOptions = pk.SweptToolOptions;
export type SweptToolOptions = pk.SweptToolOptions;

export type OffsetEdgeOptions = pk.OffsetEdgeOptions;
export const OffsetEdgeOptions = pk.OffsetEdgeOptions;
export type OffsetFaceLoopOptions = pk.OffsetFaceLoopOptions;
export const OffsetFaceLoopOptions = pk.OffsetFaceLoopOptions;

export type Vertex = pk.Vertex;
export const Vertex = pk.Vertex;
export type VertexCollection = pk.VertexCollection;
export const VertexCollection = pk.VertexCollection;
export type PointCollection = pk.PointCollection;
export const PointCollection = pk.PointCollection;
export type ProfileCollection = pk.ProfileCollection;
export const ProfileCollection = pk.ProfileCollection;


export type FaceTransformStep = pk.FaceTransformStep;
export const FaceTransformStep = pk.FaceTransformStep;

export type Solid = pk.SolidBody;
export const Solid = pk.SolidBody;
export type Body = pk.Body;
export const Body = pk.Body;
export type BooleanOptions = pk.BooleanOptions;
export const BooleanOptions = pk.BooleanOptions;

export type FaceChangeOffsetOperation = pk.FaceChangeOffsetOperation;
export const FaceChangeOffsetOperation = pk.FaceChangeOffsetOperation;
export type FaceChangeBlendOperation = pk.FaceChangeBlendOperation;
export const FaceChangeBlendOperation = pk.FaceChangeBlendOperation;
export type FaceChangeReplaceOperation = pk.FaceChangeReplaceOperation;
export const FaceChangeReplaceOperation = pk.FaceChangeReplaceOperation;

export type FaceChangeDraftOperation = pk.FaceChangeDraftOperation;
export const FaceChangeDraftOperation = pk.FaceChangeDraftOperation;

export type FaceChangeOptions = pk.FaceChangeOptions;
export const FaceChangeOptions = pk.FaceChangeOptions;
export type FaceChangeTransformOperation = pk.FaceChangeTransformOperation;
export const FaceChangeTransformOperation = pk.FaceChangeTransformOperation;
export type EdgeChangeTransformOperation = pk.EdgeChangeTransformOperation;
export const EdgeChangeTransformOperation = pk.EdgeChangeTransformOperation;
export type TransformControlPointsTrackRecord = pk.TransformControlPointsTrackRecord;
export const TransformControlPointsTrackRecord = pk.TransformControlPointsTrackRecord;

export type FaceGrowType = pk.FaceGrowType;
export const FaceGrowType = pk.FaceGrowType;
export type ProjectionMethod = pk.ProjectionMethod;
export const ProjectionMethod = pk.ProjectionMethod;

export type SheetBodyExtendOptions = pk.SheetBodyExtendOptions;
export const SheetBodyExtendOptions = pk.SheetBodyExtendOptions;
export type ExtensionShape = pk.ExtensionShape;
export const ExtensionShape = pk.ExtensionShape;
export type BodyExtensionType = pk.BodyExtensionType;
export const BodyExtensionType = pk.BodyExtensionType;

export type FacetIncrementalType = pk.FacetIncrementalType;
export const FacetIncrementalType = pk.FacetIncrementalType;

export type BlendIdentifyType = pk.BlendIdentifyType;
export const BlendIdentifyType = pk.BlendIdentifyType;

export type LoftClampType = pk.LoftClampType;
export const LoftClampType = pk.LoftClampType;

export type LoftCurvatureType = pk.LoftCurvatureType;
export const LoftCurvatureType = pk.LoftCurvatureType;

export type FaceIdentifyBlendsOptions = pk.FaceIdentifyBlendsOptions;
export const FaceIdentifyBlendsOptions = pk.FaceIdentifyBlendsOptions;

export type FaceDeleteOptions = pk.FaceDeleteOptions;
export const FaceDeleteOptions = pk.FaceDeleteOptions;
export type FaceDissolveOptions = pk.FaceDissolveOptions;
export const FaceDissolveOptions = pk.FaceDissolveOptions;
export type EdgeDeleteOptions = pk.EdgeDeleteOptions;
export const EdgeDeleteOptions = pk.EdgeDeleteOptions;

export type CreateSolidFromFacesOptions = pk.CreateSolidFromFacesOptions;
export const CreateSolidFromFacesOptions = pk.CreateSolidFromFacesOptions;
export type CreateSheetFromFacesOptions = pk.CreateSheetFromFacesOptions;
export const CreateSheetFromFacesOptions = pk.CreateSheetFromFacesOptions;
export type SewBodiesOptions = pk.SewBodiesOptions;
export const SewBodiesOptions = pk.SewBodiesOptions;

export type OffsetPlanarWireOptions = pk.OffsetPlanarWireOptions;
export const OffsetPlanarWireOptions = pk.OffsetPlanarWireOptions;


export const Wire = pk.WireBody;
export type Wire = pk.WireBody;

export const Curve = pk.Curve;
export type Curve = pk.Curve;

export type Region = pk.Face;
export const Region = pk.Face;

export type RegionBody = pk.RegionBody;
export const RegionBody = pk.RegionBody;

export type BodyType = pk.BodyType;
export const BodyType = pk.BodyType;
export type SweepAlignmentType = pk.SweepAlignmentType;
export const SweepAlignmentType = pk.SweepAlignmentType;
export type BooleanResult = pk.BooleanResult;
export const BooleanResult = pk.BooleanResult;
export type EdgeBlendOptions = pk.EdgeBlendOptions;
export const EdgeBlendOptions = pk.EdgeBlendOptions;
export type EdgeBlendVariationPoint = pk.EdgeBlendVariationPoint;
export const EdgeBlendVariationPoint = pk.EdgeBlendVariationPoint;
export type EdgeBlendLimitPoint = pk.EdgeBlendLimitPoint;
export const EdgeBlendLimitPoint = pk.EdgeBlendLimitPoint;
export type ChamferOptions = pk.ChamferOptions;
export const ChamferOptions = pk.ChamferOptions;

export enum StepType {
    SpaceStep
}
export class Grid { }
export type OperationType = pk.OperationType;
export const OperationType = pk.OperationType;

export type VertexGapFillType = pk.VertexGapFillType;
export const VertexGapFillType = pk.VertexGapFillType;

export type SpaceItem = pk.Curve;
export const SpaceItem = pk.Curve;

export class Mutex {
    static EnterParallelRegion() { }
    static ExitParallelRegion() { }
}

export class ActionSolid {
    static CreateSphere(center: THREE.Vector3, radius: number): pk.Body {
        const basis = new pk.Basis();
        basis.Location = vec2vec(center);
        return pk.SolidBody.CreateSphere(unit(radius), basis);
    }

    static MakeWireBody(curves: pk.Curve[]): pk.Body {
        return pk.WireBody.CreateFromCurves(curves);
    }
}

export class ActionCurve3D {
    static RegularPolygon(radius: number, vertexCount: number, basis: pk.Basis): Wire {
        if (vertexCount < 3) return pk.WireBody.CreateCircle(radius, basis);
        else return pk.WireBody.CreatePolygon(radius, vertexCount, basis);
    }

    static Polyline(points: Point[], closed = false): Wire {
        return pk.WireBody.CreatePolyline(points, closed);
    }
}

export class FilletOptions {
    constructor(public radius: number) { }
}

export type Basis = pk.Basis;
export const Basis = pk.Basis;
export type Axis = pk.Axis;
export const Axis = pk.Axis;
export type Ray = pk.Ray;
export const Ray = pk.Ray;

export type Sketch = pk.Sketch;
export const Sketch = pk.Sketch;
export type BodyArrayOptions = pk.BodyArrayOptions;
export const BodyArrayOptions = pk.BodyArrayOptions;

export type FacetOptions = pk.FacetOptions;
export const FacetOptions = pk.FacetOptions;
export type TransformOptions = pk.TransformOptions;
export const TransformOptions = pk.TransformOptions;
export type DisplayHelper = pk.DisplayHelper;
export const DisplayHelper = pk.DisplayHelper;

export type SpinOptions = pk.SpinOptions;
export const SpinOptions = pk.SpinOptions;

export type BodyCollection = pk.BodyCollection;
export const BodyCollection = pk.BodyCollection;

export type ClashOptions = pk.ClashOptions;
export const ClashOptions = pk.ClashOptions;

export type EdgeCollection = pk.EdgeCollection;
export const EdgeCollection = pk.EdgeCollection;

export type FaceCollection = pk.FaceCollection;
export const FaceCollection = pk.FaceCollection;

export const X = pk.X;
export const Y = pk.Y;
export const Z = pk.Z;
export const _X = pk._X;
export const _Y = pk._Y;
export const _Z = pk._Z;
export const XY = pk.XY;
export const YZ = pk.YZ;
export const XZ = pk.XZ;
export const Origin = pk.Origin;

export type OffsetFaceLoopsTrackRecord = pk.OffsetFaceLoopsTrackRecord;
export const OffsetFaceLoopsTrackRecord = pk.OffsetFaceLoopsTrackRecord;
export type ImprintWiresTrackRecord = pk.ImprintWiresTrackRecord;
export const ImprintWiresTrackRecord = pk.ImprintWiresTrackRecord;
export type FaceChangeTrackRecord = pk.FaceChangeTrackRecord;
export const FaceChangeTrackRecord = pk.FaceChangeTrackRecord;
export type BlendEdgesTrackRecord = pk.BlendEdgesTrackRecord;
export const BlendEdgesTrackRecord = pk.BlendEdgesTrackRecord;

export type VertexId = number;
export type EdgeId = number;
export type FaceId = number;
export type CVId = number;
export type BodyId = number;
export type SheetId = number;
export type WireId = number;
export type TopologyId = EdgeId | FaceId | VertexId;

export const PartitionMark = pk.PartitionMark;
export type PartitionMark = pk.PartitionMark;
export const Partition = pk.Partition;
export type Partition = pk.Partition;

export function interrupt() {
    console.info("Triggering interrupt");
    Session.TriggerUserInterrupt();
}
