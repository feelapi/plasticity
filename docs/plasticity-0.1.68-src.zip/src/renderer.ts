import pk from '../build/Release/pk.node';
import Dialog from './components/dialog/Dialog';
import NumberScrubber from './components/dialog/NumberScrubber';
import Prompt from './components/dialog/Prompt';
import Menu from './components/menu/Menu';
import Outliner from './components/outliner/Outliner';
import './components/pane/Pane';
import Planes from './components/planes/Planes';
import Search from './components/search/Search';
import Snaps from './components/snaps/Snaps';
import Stats from './components/stats/Stats';
import TitleBar from './components/title-bar/TitleBar';
import CommandButton from './components/toolbar/CommandButton';
import Icon from './components/toolbar/Icon';
import Palette from './components/toolbar/Palette';
import Toolbar from './components/toolbar/Toolbar';
import registerDefaultCommands from './components/toolbar/Tooltips';
import Tooltip from './components/tooltip/Tooltip';
import Keybindings from './components/viewport/Keybindings';
import SnapOverlay from './components/viewport/SnapOverlay';
import Viewport from './components/viewport/Viewport';
import ViewportHeader from './components/viewport/ViewportHeader';
import { Editor } from './editor/Editor';
import './index.css';
import { ConfigFiles } from './startup/ConfigFiles';

pk.Session.Init();

ConfigFiles.loadTheme();
ConfigFiles.loadSettings();
const editor = new Editor();

Object.defineProperty(window, 'editor', {
    value: editor,
    writable: false
}); // Make available to debug console

ConfigFiles.loadKeymap(editor.keymaps);


registerDefaultCommands(editor);

Icon(editor);
CommandButton(editor);
TitleBar(editor);
Toolbar(editor);
Keybindings(editor);
Palette(editor);
Viewport(editor);
NumberScrubber(editor);
Dialog(editor);
ViewportHeader(editor);
SnapOverlay(editor);
Prompt(editor);
Outliner(editor);
// UndoHistory(editor);
Tooltip(editor);
Stats(editor);
Snaps(editor);
Planes(editor);
// Clipboard(editor);
Menu(editor);
Search(editor);

editor.loadBackup();

export const supportedExtensions = ['stp', 'step', 'plasticity', 'igs', 'iges', 'sat', 'x_t', 'x_b', 'png', 'jpg', 'jpeg', 'obj'];
const res = new RegExp(`\\.${supportedExtensions.join('|')}$`, 'i')

document.addEventListener('drop', e => {
    e.preventDefault();
    if (e.dataTransfer === null) return;
    const files = [];
    for (let i = 0; i < e.dataTransfer.files.length; i++) {
        const file = e.dataTransfer.files[i].path;
        if (!res.test(file)) continue;
        files.push(file);
    }
    editor.import(files);
});

document.addEventListener('dragover', e => {
    e.preventDefault();
    e.stopPropagation();
});


function hotErrorHandler(err: any) {
    console.error(err);
    require.cache[module.id]?.hot?.accept(hotErrorHandler);
}
module.hot?.accept(hotErrorHandler);

// const basis = new pk.Basis();
// const block = pk.SolidBody.CreateBlock(1, 1, 1, basis);
// editor.db.addItem(block);
