export default {
    "body:not([gizmo]) plasticity-viewport": {
        "/": "viewport:focus",
        ".": "command:focus",

        "space": "viewport:navigate:selection",
        "shift-space": "viewport:cplane:selection",
        "ctrl-space": "command:create-viewspace-construction-plane-at-origin",
        "ctrl-shift-space": "command:create-viewspace-construction-plane",
    },

    "body:not([gizmo]) plasticity-viewport, body[gizmo='point-picker'] plasticity-viewport": {
        "numpad1": "viewport:navigate:front",
        "numpad3": "viewport:navigate:right",
        "numpad7": "viewport:navigate:top",

        "ctrl-numpad1": "viewport:navigate:back",
        "ctrl-numpad3": "viewport:navigate:left",
        "ctrl-numpad7": "viewport:navigate:bottom",

        "numpad5": "viewport:toggle-orthographic",

        "ctrl-alt-cmd-z": "viewport:depth:show",
    },

    "body[gizmo='point-picker'] plasticity-viewport": {
        "space": "point-picker:navigate:last-picked-point",
        "shift-space": "point-picker:cplane:last-picked-point",
        "ctrl-space": "point-picker:cplane:screen-space",
        "ctrl-shift-space": "point-picker:cplane:screen-space",
    },

    "plasticity-viewport": {
        "alt-z": "viewport:toggle-x-ray",
        "shift-alt-z": "viewport:toggle-overlays",
    },

    "body:not([gizmo])": {
        "1": "selection:mode:set:control-point",
        "2": "selection:mode:set:edge",
        "3": "selection:mode:set:face",
        "4": "selection:mode:set:solid",
        "tab": "selection:mode:set:all",
        "5": "selection:mode:set:all",

        "ctrl-1": "selection:convert:control-point",
        "ctrl-2": "selection:convert:edge",
        "ctrl-3": "selection:convert:face",
        "ctrl-4": "selection:convert:solid",

        "shift-1": "selection:mode:toggle:control-point",
        "shift-2": "selection:mode:toggle:edge",
        "shift-3": "selection:mode:toggle:face",
        "shift-4": "selection:mode:toggle:solid",

        "alt-1": "command:subdivide-curve",

        "c": "command:cut",
        "j": "command:join",
        "alt-j": "command:explode",
        "g": "command:move",
        "r": "command:rotate",
        "shift-s": "command:draft-face",
        "s": "command:scale",
        "shift-p": "command:sweep",
        "p": "command:pipe",
        "b": "command:fillet",
        "e": "command:extrude",
        "t": "command:trim",
        "shift-o": "command:offset-face",
        "o": "command:offset-curve",
        "alt-x": "command:mirror",
        "l": "command:loft",
        "alt-l": "command:loft-guide",
        "shift-l": "command:live-loft",
        "i": "command:project",
        "shift-i": "command:imprint",

        "x": "command:delete",
        "delete": "command:delete",
        "backspace": "command:delete",
        "shift-x": "command:delete-face",
        "shift-delete": "command:delete-face",
        "shift-backspace": "command:delete-face",

        "m": "command:set-material",
        "alt-m": "command:remove-material",

        "shift-d": "command:duplicate",
        "alt-d": "command:create-solid-from-faces",
        "ctrl-d": "command:place",

        "shift-a": "command:line",
        // "shift-b": "command:corner-rectangle",
        "shift-c": "command:cylinder",
        "shift-b": "command:corner-box",
        // "ctrl-c": "command:cylinder",

        "q": "command:boolean",

        "h": "command:hide-selected",
        "shift-h": "command:hide-unselected",
        "alt-h": "command:unhide-all",
        "ctrl-h": "command:invert-hidden",

        "ctrl-g": "command:group-selected",
        "alt-g": "command:ungroup-selected",

        "ctrl-r": "command:isoparam",

        "shift-r": "edit:repeat-last-command",
        "cmd-shift-z": "edit:redo",
        "ctrl-shift-z": "edit:redo",

        "ctrl-c": "edit:copy",
        "cmd-c": "edit:copy",
        "ctrl-v": "edit:paste",
        "cmd-v": "edit:paste",

        "cmd-n": "file:new",
        "ctrl-n": "file:new",
        "cmd-shift-s": "file:save-as",
        "ctrl-shift-s": "file:save-as",
        "cmd-o": "file:open",
        "ctrl-o": "file:open",

        "alt-A": "command:deselect-all",
        "a": "command:select-all",
        "escape": "command:deselect-all",
    },

    "orbit-controls": {
        "mouse1": "orbit:rotate",
        "mouse2": "orbit:pan",
        "alt-mouse1": "orbit:align",
    },

    "viewport-selector": {
        "mouse0": "selection:replace",
        "shift-mouse0": "selection:add",
        "ctrl-mouse0": "selection:remove",

        "alt-shift-mouse0": "selection:add",
        "ctrl-alt-mouse0": "selection:replace",
        "ctrl-alt-shift-mouse0": "selection:add",

        "cmd": "selection:option:ignore-mode",
        "alt": "selection:option:extend",
        "shift-alt": "selection:option:extend",
        "ctrl-alt": "selection:option:extend-alt",
        "ctrl-shift-alt": "selection:option:extend-alt",
    },

    "viewport-selector[quasimode]": {
        "mouse0": "selection:toggle",
        "ctrl-mouse0": "selection:toggle",

        "ctrl-alt-mouse0": "selection:toggle",
        "ctrl-shift-alt-mouse0": "selection:toggle",

        "cmd": "selection:option:ignore-mode",
        "alt": "selection:option:extend",
        "ctrl-alt": "selection:option:extend",
        "ctrl-shift-alt": "selection:option:extend-alt",
    },

    "body[gizmo=point-picker]": {
        "n": "snaps:set-normal",
        "b": "snaps:set-binormal",
        "t": "snaps:set-tangent",
        "x": "snaps:set-x",
        "y": "snaps:set-y",
        "z": "snaps:set-z",
        "s": "snaps:set-square",

        "mouse2": "point-picker:finish",
        "enter": "point-picker:finish",
        "dblclick+empty": "point-picker:finish",

        "ctrl": "snaps:temporarily-disable",
        "^ctrl": "snaps:temporarily-enable",

        "ctrl-shift": "snaps:temporarily-disable",
        "^ctrl-shift": "snaps:temporarily-enable",
    },

    "body": {
        "alt": "noop",
    },

    ////// Command related functionality //////

    "[command] plasticity-viewport": {
        "escape": "command:abort",
        "cmd-z": "command:undo",
        "ctrl-z": "command:undo",
    },

    "body:not([command])": {
        "cmd-z": "edit:undo",
        "ctrl-z": "edit:undo",
    },

    "[command]:not([gizmo]) plasticity-viewport": {
        "enter": "command:finish",
        "mouse2": "command:finish",
        "dblclick+empty": "command:finish",

        "ctrl": "command:quasimode:start",
        "^ctrl": "command:quasimode:stop",
    },

    "[command][gizmo]:not([gizmo='point-picker']) plasticity-viewport": {
        "enter": "gizmo:finish", // for `sz0<enter>`, etc
    },

    ///// Specific commands come last, having higher precedence /////

    "[command='center-circle'] plasticity-viewport, [command='two-point-circle'] plasticity-viewport": {
        "v": "gizmo:circle:mode",
        "k": "gizmo:circle:knife",
    },

    "[command='edit-circle'] plasticity-viewport": {
        "d": "gizmo:circle:radius",
    },

    "[command='edit-center-rectangle'] plasticity-viewport, [command='edit-corner-rectangle'] plasticity-viewport, [command='edit-three-point-rectangle'] plasticity-viewport": {
        "d": "gizmo:rectangle:width",
        "f": "gizmo:rectangle:length",
        "k": "gizmo:rectangle:knife",
    },

    "[command='center-rectangle'] plasticity-viewport, [command='corner-rectangle'] plasticity-viewport, [command='three-point-rectangle'] plasticity-viewport": {
        "k": "gizmo:rectangle:knife",
    },

    "[command='corner-rectangle'] plasticity-viewport, [command='center-rectangle'] plasticity-viewport, [command='corner-box'] plasticity-viewport, [command='center-box'] plasticity-viewport": {
        "tab": "keyboard:rectangle:mode",
    },

    "[command='polygon'] plasticity-viewport": {
        "shift-wheel+up": "gizmo:polygon:add-vertex",
        "shift-wheel+down": "gizmo:polygon:subtract-vertex",
        "v": "gizmo:polygon:mode",
        "k": "gizmo:polygon:knife",
    },

    "[command='radial-array'] plasticity-viewport, [command='rectangular-array'] plasticity-viewport": {
        "shift-wheel+up": "gizmo:array:add",
        "shift-wheel+down": "gizmo:array:subtract",
    },

    "[command='rebuild'] plasticity-viewport": {
        "shift-wheel+up": "gizmo:rebuild:forward",
        "shift-wheel+down": "gizmo:rebuild:backward",
    },

    "[command='spiral'] plasticity-viewport": {
        "a": "gizmo:spiral:angle",
        "d": "gizmo:spiral:length",
        "r": "gizmo:spiral:radius",
    },

    "[command='revolution'] plasticity-viewport": {
        "a": "gizmo:revolution:angle",
        "shift-t": "gizmo:revolution:thickness",
    },

    "[command='loft'] plasticity-viewport": {
        "shift-t": "gizmo:loft:thickness",
    },

    "[command='sweep'] plasticity-viewport": {
        "shift-t": "gizmo:sweep:thickness",
        "d": "gizmo:sweep:twist",
    },

    "[command='pipe'] plasticity-viewport": {
        "d": "gizmo:pipe:section-size",
        "shift-t": "gizmo:pipe:thickness",
        "a": "gizmo:pipe:angle",
        "c": "gizmo:pipe:custom-profile",

        "shift-q": "keyboard:pipe:slice",
        "q": "keyboard:pipe:union",
        "w": "keyboard:pipe:difference",
        "shift-e": "keyboard:pipe:intersect",
        "b": "keyboard:pipe:new-body",
        "t": "keyboard:pipe:keep-tools",
    },

    "[command='boolean'] plasticity-viewport": {
        "shift-q": "gizmo:boolean:slice",
        "q": "gizmo:boolean:union",
        "w": "gizmo:boolean:difference",
        "shift-e": "gizmo:boolean:intersect",
        "t": "gizmo:boolean:keep-tools",

        "g": "keyboard:boolean:move",
        "r": "keyboard:boolean:rotate",
        "s": "keyboard:boolean:scale",

        "x": "gizmo:move:x",
        "y": "gizmo:move:y",
        "z": "gizmo:move:z",
        "shift-z": "gizmo:move:xy",
        "shift-x": "gizmo:move:yz",
        "shift-y": "gizmo:move:xz",
        // "g": "gizmo:move:screen",
    },

    "[command='center-box'] plasticity-viewport, [command='corner-box'] plasticity-viewport, [command='three-point-box'] plasticity-viewport": {
        "shift-q": "keyboard:box:slice",
        "q": "keyboard:box:union",
        "w": "keyboard:box:difference",
        "shift-e": "keyboard:box:intersect",
        "b": "keyboard:box:new-body",
        "t": "keyboard:box:keep-tools",

        "d": "gizmo:box:width",
        "f": "gizmo:box:length",
        "h": "gizmo:box:height",
    },

    "[command='sphere'] pasticity-viewport": {
        "shift-q": "keyboard:sphere:slice",
        "q": "keyboard:sphere:union",
        "w": "keyboard:sphere:difference",
        "shift-e": "keyboard:sphere:intersect",
        "b": "keyboard:sphere:new-body",
        "t": "keyboard:sphere:keep-tools",
    },

    "[command='cylinder'] plasticity-viewport": {
        "shift-q": "keyboard:cylinder:slice",
        "q": "keyboard:cylinder:union",
        "w": "keyboard:cylinder:difference",
        "shift-e": "keyboard:cylinder:intersect",
        "b": "keyboard:cylinder:new-body",
        "t": "keyboard:cylinder:keep-tools",

        "v": "gizmo:circle:mode",

        "d": "gizmo:cylinder:height",
        "f": "gizmo:cylinder:radius",
    },

    "[command='sphere'] plasticity-viewport": {
        "shift-q": "keyboard:sphere:slice",
        "q": "keyboard:sphere:union",
        "w": "keyboard:sphere:difference",
        "shift-e": "keyboard:sphere:intersect",
        "b": "keyboard:sphere:new-body",
    },

    "[command='extrude'] plasticity-viewport": {
        "a": "gizmo:extrude:angle1",
        "s": "gizmo:extrude:angle2",
        "d": "gizmo:extrude:distance1",
        "shift-t": "gizmo:extrude:thickness",
        "tab": "gizmo:extrude:lock-distances",

        "shift-q": "keyboard:extrude:slice",
        "q": "keyboard:extrude:union",
        "w": "keyboard:extrude:difference",
        "shift-e": "keyboard:extrude:intersect",
        "b": "keyboard:extrude:new-body",
        "t": "keyboard:extrude:keep-tools",

        "f": "direction:extrude:free",
        "v": "direction:extrude:pivot",
    },

    "[command='offset-face'] plasticity-viewport": {
        "d": "gizmo:offset-face:distance",
        "a": "gizmo:offset-face:angle",
        "tab": "keyboard:change-face:toggle",
    },

    "[command='draft-face'] plasticity-viewport": {
        "a": "gizmo:offset-face:angle",
        "tab": "keyboard:change-face:toggle",
    },

    "[command='isoparam'] plasticity-viewport": {
        "tab": "gizmo:isoparam:toggle",
        "shift-wheel+up": "gizmo:isoparam:add-cut",
        "shift-wheel+down": "gizmo:isoparam:subtract-cut",
    },

    "[command='refillet-face'] plasticity-viewport": {
        "d": "gizmo:refillet-face:distance",
    },

    "[command='cut'] plasticity-viewport": {
        "s": "gizmo:cut:screen-space",
    },

    "[command='project-curve-body'] plasticity-viewport": {
        "s": "gizmo:project:screen-space",
    },

    "[command='imprint-curve-body'] plasticity-viewport": {
        "s": "gizmo:imprint:screen-space",
    },

    "[command='offset-face-loop'] plasticity-viewport, [command='offset-edge'] plasticity-viewport, [command='offset-planar-curve'] plasticity-viewport, [command='offset-region'] plasticity-viewport": {
        "d": "gizmo:offset-edge:distance",
        "tab": "gizmo:offset-edge:toggle",
        "i": "gizmo:offset-edge:individual",
    },

    "[command='move'] plasticity-viewport, [command='move-item'] plasticity-viewport, [command='move-empty'] plasticity-viewport, [command='duplicate'] plasticity-viewport, [command='move-control-point'] plasticity-viewport, [command='move-face'] plasticity-viewport": {
        "x": "gizmo:move:x",
        "y": "gizmo:move:y",
        "z": "gizmo:move:z",
        "shift-z": "gizmo:move:xy",
        "shift-x": "gizmo:move:yz",
        "shift-y": "gizmo:move:xz",
        "g": "gizmo:move:screen",

        "f": "keyboard:move:free",
        "v": "keyboard:move:pivot",
        "w": "keyboard:move:worldspace",
    },

    "[command='scale'] plasticity-viewport, [command='scale-item'] plasticity-viewport, [command='scale-empty'] plasticity-viewport, [command='scale-control-point'] plasticity-viewport": {
        "x": "gizmo:scale:x",
        "y": "gizmo:scale:y",
        "z": "gizmo:scale:z",
        "shift-z": "gizmo:scale:xy",
        "shift-x": "gizmo:scale:yz",
        "shift-y": "gizmo:scale:xz",
        "s": "gizmo:scale:xyz",
        "f": "keyboard:scale:free",
        "v": "keyboard:scale:pivot",
        "w": "keyboard:scale:worldspace"
    },

    "[command='fillet-solid'] plasticity-viewport": {
        "d": "gizmo:fillet-solid:fillet",
        "c": "gizmo:fillet-solid:chamfer",
        "a": "gizmo:fillet-solid:angle",
    },

    "[command='fillet-solid'][changed] plasticity-viewport": {
        "v": "gizmo:fillet-solid:add-variation-point",
        "l": "gizmo:fillet-solid:add-limit-point",
    },

    "[command='modify-contour'] plasticity-viewport": {
        "d": "gizmo:modify-contour:fillet-all",
    },

    "[command='rotate'] plasticity-viewport, [command='rotate-item'] plasticity-viewport, [command='rotate-empty'] plasticity-viewport, [command='rotate-control-point'] plasticity-viewport, [command='rotate-face'] plasticity-viewport": {
        "x": "gizmo:rotate:x",
        "y": "gizmo:rotate:y",
        "z": "gizmo:rotate:z",
        "r": "gizmo:rotate:screen",
        "f": "keyboard:rotate:free",
        "v": "keyboard:rotate:pivot",
        "w": "keyboard:rotate:worldspace"
    },

    "[command='rotate-face'] plasticity-viewport, [command='move-face'] plasticity-viewport": {
        "tab": "keyboard:change-face:toggle",
    },

    "[command='curve'] plasticity-viewport": {
        "tab": "gizmo:curve:toggle",
        "cmd-z": "gizmo:curve:undo",
        "ctrl-z": "gizmo:curve:undo",
        "k": "gizmo:curve:knife",
    },

    "[command='line'] plasticity-viewport": {
        "cmd-z": "gizmo:line:undo",
        "ctrl-z": "gizmo:line:undo",
        "k": "gizmo:line:knife",
    },

    "[command='mirror'] plasticity-viewport": {
        "x": "gizmo:mirror:x",
        "y": "gizmo:mirror:y",
        "z": "gizmo:mirror:z",
        "shift-x": "gizmo:mirror:-x",
        "shift-y": "gizmo:mirror:-y",
        "shift-z": "gizmo:mirror:-z",
        "f": "gizmo:mirror:free",
        "v": "gizmo:mirror:pivot",
        "q": "gizmo:mirror:union",
    },

    "[command='freestyle-mirror'] plasticity-viewport": {
        "q": "gizmo:mirror:union",
    },

    "[command='thicken-sheet'] plasticity-viewport": {
        "d": "gizmo:thicken-sheet:thickness",
    },

    "[command='hollow-solid'] plasticity-viewport": {
        "d": "gizmo:hollow-solid:thickness",
    },

    "[command='place'] plasticity-viewport": {
        "d": "gizmo:place:offset",
        "f": "gizmo:place:flip",
        "a": "gizmo:place:angle",
        "s": "gizmo:place:scale",

        "shift-q": "keyboard:place:slice",
        "q": "keyboard:place:union",
        "w": "keyboard:place:difference",
        "shift-e": "keyboard:place:intersect",
        "b": "keyboard:place:new-body",

        "x": "gizmo:place:x",
        "y": "gizmo:place:y",
        "z": "gizmo:place:z",
    },

    "[command='loft-guide'] plasticity-viewport": {
          "v": "gizmo:loft-guide:add-vertex",
    },
}