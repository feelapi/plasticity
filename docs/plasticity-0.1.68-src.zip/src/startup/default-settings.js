const THREE = require('three');

module.exports = {
    Viewport: {
        navigator: {
            size: 100,
            padding: 24,
        },
        renderer: {
            samples: 4,
            type: THREE.HalfFloatType,
        }
    },

    OrbitControls: {
        zoomSpeed: 1,
        rotateSpeed: 1,
        panSpeed: 1,
        alignGestureDistance: 10,
        minZoom: 0.01,
        maxZoom: 100,
        zoomToCursor: true,
        zoomVertical: true,
    },

    ViewBuilder: {
        low: {
            curveChordTolerance: 0.05,
            curveChordAngle: Math.PI / 5,
            surfacePlaneTolerance: 0.05,
            surfacePlaneAngle: Math.PI / 5,
        },
        medium: {
            curveChordTolerance: 0.001,
            curveChordAngle: Math.PI / 17,
            surfacePlaneTolerance: 0.001,
            surfacePlaneAngle: Math.PI / 12,
        },
        high: {
            curveChordTolerance: 0.0001,
            curveChordAngle: Math.PI / 18,
            surfacePlaneTolerance: 0.0001,
            surfacePlaneAngle: Math.PI / 12,
        }
    }
}