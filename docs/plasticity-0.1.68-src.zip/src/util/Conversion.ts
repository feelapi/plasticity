import * as THREE from "three";
import * as c3d from '../kernel/kernel';
import { findOrthogonal } from "./Util";

export function point2point(from: THREE.Vector3, factor?: number): c3d.Point;
export function point2point(from: c3d.Point, factor?: number): THREE.Vector3;
export function point2point(from: c3d.Point, factor?: number): THREE.Vector3;
export function point2point(from: THREE.Vector3 | c3d.Point | c3d.Point, factor = unit(1)): THREE.Vector3 | c3d.Point {
    if (from instanceof c3d.Point || from instanceof c3d.Point) {
        return new THREE.Vector3(from.x / factor, from.y / factor, from.z / factor);
    } else {
        return new c3d.Point(from.x * factor, from.y * factor, from.z * factor);
    }
}

export function vec2vec(from: THREE.Vector3, factor?: number): c3d.Vector;
export function vec2vec(from: c3d.Vector, factor?: number): THREE.Vector3;
export function vec2vec(from: THREE.Vector3 | c3d.Vector, factor = unit(1)): THREE.Vector3 | c3d.Vector {
    if (from instanceof c3d.Vector) {
        return new THREE.Vector3(from.x / factor, from.y / factor, from.z / factor);
    } else {
        return new c3d.Vector(from.x * factor, from.y * factor, from.z * factor);
    }
}

export function mat2mat(mat: c3d.Matrix, into?: THREE.Matrix4): THREE.Matrix4;
export function mat2mat(mat: THREE.Matrix4, into?: c3d.Matrix): c3d.Matrix;
export function mat2mat(mat: THREE.Matrix4 | c3d.Matrix, into?: THREE.Matrix4 | c3d.Matrix): THREE.Matrix4 | c3d.Matrix {
    if (mat instanceof c3d.Matrix) {
        if (into === undefined) into = new THREE.Matrix4();
        if (!(into instanceof THREE.Matrix4)) throw new Error('into must be a THREE.Matrix4');
        const array = mat.Get();
        into.set(
            array[0], array[1], array[2], array[3],
            array[4], array[5], array[6], array[7],
            array[8], array[9], array[10], array[11],
            array[12], array[13], array[14], array[15],
        );
        return into;
    } else {
        if (into === undefined) into = new c3d.Matrix();
        if (!(into instanceof c3d.Matrix)) throw new Error('into must be a c3d.Matrix');
        const elements = mat.elements;
        into.Set(new Float64Array([
            elements[0], elements[4], elements[8], elements[12],
            elements[1], elements[5], elements[9], elements[13],
            elements[2], elements[6], elements[10], elements[14],
            elements[3], elements[7], elements[11], elements[15]]));
        return into;
    }
}

export function plane2plane(from: c3d.Basis, factor?: number): THREE.Plane;
export function plane2plane(from: THREE.Plane, factor?: number): c3d.Basis;
export function plane2plane(from: c3d.Basis | THREE.Plane, factor = unit(1)): THREE.Plane | c3d.Basis {
    if (from instanceof c3d.Basis) {
        const plane = new THREE.Plane();
        plane.setFromNormalAndCoplanarPoint(vec2vec(from.Axis, 1), point2point(from.Location, factor));
        return plane;
    } else {
        const plane = new c3d.Basis();
        plane.Axis = vec2vec(from.normal, 1);
        plane.Ref = vec2vec(findOrthogonal(vec2vec(plane.Axis)), 1);
        plane.Location.x = from.constant * from.normal.x * factor;
        plane.Location.y = from.constant * from.normal.y * factor;
        plane.Location.z = from.constant * from.normal.z * factor;
        return plane;
    }
}

export function axis2line(axis: c3d.Axis): THREE.Line3 {
    const line = new THREE.Line3();
    line.start.copy(point2point(axis.Location));
    line.end.copy(point2point(axis.Location).add(point2point(axis.Direction)));
    return line;
}

export function ray2ray(ray: THREE.Ray): c3d.Ray {
    const origin = point2point(ray.origin);
    const direction = vec2vec(ray.direction, 1);
    return new c3d.Ray(origin, direction);
}

export function truncunit(x: number, precision?: number) {
    if (precision !== undefined) return trunc(unit(x), precision);
    else return unit(x);
}

export function trunc(x: number, precision: number) {
    return Math.trunc(x * precision) / precision;
}

export function unit(x: number): number {
    return x * 1;
}

export function deunit(x: number): number {
    return x / 1;
}

export function toArray<T>(x: T | T[] | undefined): T[] {
    if (x === undefined) return [];
    if (Array.isArray(x)) return x;
    else return [x];
}

export function deg2rad(degrees: number) {
    return 2 * Math.PI * (degrees / 360);
}

export function rad2deg(radians: number) {
    return (radians * 360) / (2 * Math.PI);
}

export function isSameBasis(basis1: c3d.Basis, basis2: c3d.Basis): boolean {
    const Z1 = vec2vec(basis1.Axis, 1);
    const Z2 = vec2vec(basis2.Axis, 1);

    const origin2 = point2point(basis2.Location);
    const delta = point2point(basis1.Location).sub(origin2);
    const ZdotOffset = Math.abs(Z1.dot(delta));

    return Math.abs(Math.abs(Z1.dot(Z2)) - 1) < 10e-6 && ZdotOffset < 1e-4;
}