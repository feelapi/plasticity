// Originally from millermedeiros / js-signals
// rewritten for TypeScript and Promises

type Listener<T> = ((arg: T) => void) | ((arg: T) => Promise<void>);

export class SignalBinding<T> {
    active: boolean = true;
    params: any;

    _isOnce: boolean;
    _listener: Listener<T> | undefined;
    _signal: Signal<T> | undefined;
    _priority: number;

    constructor(signal: Signal<T>, listener: Listener<T>, isOnce: boolean, priority = 0) {
        this._listener = listener;
        this._isOnce = isOnce;
        this._signal = signal;
        this._priority = priority;
    }

    /**
     * Call listener passing arbitrary parameters.
     * <p>If binding was added using `Signal.addOnce()` it will be automatically removed from signal dispatch queue, this method is used internally for the signal dispatch.</p>
     * @param {Array} [paramsArr] Array of parameters that should be passed to the listener
     * @return {*} Value returned by the listener.
     */
    execute(params: T): void | Promise<void> {
        let handlerReturn;
        if (this.active && !!this._listener) {
            handlerReturn = this._listener(params);
            if (this._isOnce) {
                this.detach();
            }
        }
        return handlerReturn;
    }

    detach() {
        return this.isBound() ? this._signal!.remove(this._listener!) : null;
    }

    /**
     * @return {Boolean} `true` if binding is still bound to the signal and have a listener.
     */
    isBound() {
        return (!!this._signal && !!this._listener);
    }

    /**
     * @return {boolean} If SignalBinding will only be executed once.
     */
    isOnce() {
        return this._isOnce;
    }

    getListener() {
        return this._listener;
    }

    getSignal() {
        return this._signal;
    }

    _destroy() {
        delete this._signal;
        delete this._listener;
    }

    toString() {
        return '[SignalBinding isOnce:' + this._isOnce + ', isBound:' + this.isBound() + ', active:' + this.active + ']';
    }
};

function validateListener<T>(listener: Listener<T>, fnName: string) {
    if (typeof listener !== 'function') {
        throw new Error('listener is a required param of {fn}() and should be a Function.'.replace('{fn}', fnName));
    }
}

export class Signal<T = void> {
    _bindings: SignalBinding<T>[] = [];
    _shouldPropagate = true;
    active = true;

    dispatch = async (args: T): Promise<void> => {
        if (!this.active) {
            return;
        }

        let n = this._bindings.length,
            bindings;

        if (n === 0) return;

        bindings = this._bindings.slice(); //clone array in case add/remove items during dispatch
        this._shouldPropagate = true; //in case `halt` was called before dispatch or during the previous dispatch.

        const promises = [];
        //execute all callbacks until end of the list or until a callback returns `false` or stops propagation
        //reverse loop since listeners with higher priority will be added at the end of the list
        for (let i = n - 1; i >= 0; i--) {
            if (!this._shouldPropagate) break;
            const result = bindings[i].execute(args);
            if (result instanceof Promise) promises.push(result);
        }
        await Promise.all(promises);
    }

    _registerListener(listener: Listener<T>, isOnce: boolean, priority?: number) {
        var prevIndex = this._indexOfListener(listener),
            binding;

        if (prevIndex !== -1) {
            binding = this._bindings[prevIndex];
            if (binding.isOnce() !== isOnce) {
                throw new Error('You cannot add' + (isOnce ? '' : 'Once') + '() then add' + (!isOnce ? '' : 'Once') + '() the same listener without removing the relationship first.');
            }
        } else {
            binding = new SignalBinding<T>(this, listener, isOnce, priority);
            this._addBinding(binding);
        }

        return binding;
    }


    _addBinding(binding: SignalBinding<T>) {
        //simplified insertion sort
        var n = this._bindings.length;
        do { --n; } while (this._bindings[n] && binding._priority <= this._bindings[n]._priority);
        this._bindings.splice(n + 1, 0, binding);
    }


    _indexOfListener(listener: Listener<T>) {
        var n = this._bindings.length,
            cur;
        while (n--) {
            cur = this._bindings[n];
            if (cur._listener === listener) {
                return n;
            }
        }
        return -1;
    }

    has(listener: Listener<T>) {
        return this._indexOfListener(listener) !== -1;
    }

    add(listener: Listener<T>, priority?: number) {
        validateListener(listener, 'add');
        return this._registerListener(listener, false, priority);
    }


    addOnce(listener: Listener<T>, priority?: number) {
        validateListener(listener, 'addOnce');
        return this._registerListener(listener, true, priority);
    }

    remove(listener: Listener<T>) {
        validateListener(listener, 'remove');

        var i = this._indexOfListener(listener);
        if (i !== -1) {
            this._bindings[i]._destroy(); //no reason to a SignalBinding exist if it isn't attached to a signal
            this._bindings.splice(i, 1);
        }
        return listener;
    }

    removeAll() {
        var n = this._bindings.length;
        while (n--) {
            this._bindings[n]._destroy();
        }
        this._bindings.length = 0;
    }

    getNumListeners() {
        return this._bindings.length;
    }


    halt() {
        this._shouldPropagate = false;
    }

    dispose() {
        this.removeAll();
        this._bindings.length = 0;
    }

    toString() {
        return '[Signal active:' + this.active + ' numListeners:' + this.getNumListeners() + ']';
    }
};
