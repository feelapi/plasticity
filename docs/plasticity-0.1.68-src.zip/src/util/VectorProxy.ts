import * as THREE from "three";

export class VectorProxy implements THREE.Vector3 {
    readonly underlying = new THREE.Vector3();
    constructor(private readonly cb: (v: THREE.Vector3) => void) { }
    isVector3: true = true;

    get x() { return this.underlying.x; this.cb(this.underlying); }
    set x(x: number) { this.underlying.x = x; this.cb(this.underlying); }
    get y() { return this.underlying.y; this.cb(this.underlying); }
    set y(y: number) { this.underlying.y = y; this.cb(this.underlying); }
    get z() { return this.underlying.z; this.cb(this.underlying); }
    set z(z: number) { this.underlying.z = z; this.cb(this.underlying); }

    set(x: number, y: number, z: number) { this.underlying.set(x, y, z); this.cb(this.underlying); return this; }
    copy(v: THREE.Vector3) { this.underlying.copy(v); this.cb(this.underlying); return this; }

    setScalar(scalar: number): this {
        this.underlying.setScalar(scalar);
        this.cb(this.underlying);
        return this;
    }
    setX(x: number): THREE.Vector3 {
        this.underlying.setX(x);
        this.cb(this.underlying);
        return this;
    }
    setY(y: number): THREE.Vector3 {
        this.underlying.setY(y);
        this.cb(this.underlying);
        return this;
    }
    setZ(z: number): THREE.Vector3 {
        this.underlying.setZ(z);
        this.cb(this.underlying);
        return this;
    }
    setComponent(index: number, value: number): this {
        this.underlying.setComponent(index, value);
        this.cb(this.underlying);
        return this;
    }
    getComponent(index: number): number {
        return this.underlying.getComponent(index);
    }
    clone(): this {
        return this.underlying.clone() as unknown as this;
    }
    add(v: THREE.Vector3): this {
        this.underlying.add(v);
        this.cb(this.underlying);
        return this;
    }
    addScalar(s: number): this {
        this.underlying.addScalar(s);
        this.cb(this.underlying);
        return this;
    }
    addScaledVector(v: THREE.Vector3, s: number): this {
        this.underlying.addScaledVector(v, s);
        this.cb(this.underlying);
        return this;
    }
    addVectors(a: THREE.Vector3, b: THREE.Vector3): this {
        this.underlying.addVectors(a, b);
        this.cb(this.underlying);
        return this;
    }
    sub(a: THREE.Vector3): this {
        this.underlying.sub(a);
        this.cb(this.underlying);
        return this;
    }

    subScalar(s: number): this {
        this.underlying.subScalar(s);
        this.cb(this.underlying);
        return this;
    }
    subVectors(a: THREE.Vector3, b: THREE.Vector3): this {
        this.underlying.subVectors(a, b);
        this.cb(this.underlying);
        return this;
    }
    multiply(v: THREE.Vector3): this {
        this.underlying.multiply(v);
        this.cb(this.underlying);
        return this;
    }
    multiplyScalar(s: number): this {
        this.underlying.multiplyScalar(s);
        this.cb(this.underlying);
        return this;
    }
    multiplyVectors(a: THREE.Vector3, b: THREE.Vector3): this {
        this.underlying.multiplyVectors(a, b);
        this.cb(this.underlying);
        return this;
    }
    applyEuler(euler: THREE.Euler): this {
        this.underlying.applyEuler(euler);
        this.cb(this.underlying);
        return this;
    }
    applyAxisAngle(axis: THREE.Vector3, angle: number): this {
        this.underlying.applyAxisAngle(axis, angle);
        this.cb(this.underlying);
        return this;
    }
    applyMatrix3(m: THREE.Matrix3): this {
        this.underlying.applyMatrix3(m);
        this.cb(this.underlying);
        return this;
    }
    applyNormalMatrix(m: THREE.Matrix3): this {
        this.underlying.applyNormalMatrix(m);
        this.cb(this.underlying);
        return this;
    }
    applyMatrix4(m: THREE.Matrix4): this {
        this.underlying.applyMatrix4(m);
        this.cb(this.underlying);
        return this;
    }
    applyQuaternion(q: THREE.Quaternion): this {
        this.underlying.applyQuaternion(q);
        this.cb(this.underlying);
        return this;
    }
    project(camera: THREE.Camera): this {
        this.underlying.project(camera);
        this.cb(this.underlying);
        return this;
    }
    unproject(camera: THREE.Camera): this {
        this.underlying.unproject(camera);
        this.cb(this.underlying);
        return this;
    }
    transformDirection(m: THREE.Matrix4): this {
        this.underlying.transformDirection(m);
        this.cb(this.underlying);
        return this;
    }
    divide(v: THREE.Vector3): this {
        this.underlying.divide(v);
        this.cb(this.underlying);
        return this;
    }
    divideScalar(s: number): this {
        this.underlying.divideScalar(s);
        this.cb(this.underlying);
        return this;
    }
    min(v: THREE.Vector3): this {
        this.underlying.min(v);
        this.cb(this.underlying);
        return this;
    }
    max(v: THREE.Vector3): this {
        this.underlying.max(v);
        this.cb(this.underlying);
        return this;
    }
    clamp(min: THREE.Vector3, max: THREE.Vector3): this {
        this.underlying.clamp(min, max);
        this.cb(this.underlying);
        return this;
    }
    clampScalar(min: number, max: number): this {
        this.underlying.clampScalar(min, max);
        this.cb(this.underlying);
        return this;
    }
    clampLength(min: number, max: number): this {
        this.underlying.clampLength(min, max);
        this.cb(this.underlying);
        return this;
    }
    floor(): this {
        this.underlying.floor();
        this.cb(this.underlying);
        return this;
    }
    ceil(): this {
        this.underlying.ceil();
        this.cb(this.underlying);
        return this;
    }
    round(): this {
        this.underlying.round();
        this.cb(this.underlying);
        return this;
    }
    roundToZero(): this {
        this.underlying.roundToZero();
        this.cb(this.underlying);
        return this;
    }
    negate(): this {
        this.underlying.negate();
        this.cb(this.underlying);
        return this;
    }
    dot(v: THREE.Vector3): number {
        return this.underlying.dot(v);
    }
    lengthSq(): number {
        return this.underlying.lengthSq();
    }
    length(): number {
        return this.underlying.length();
    }
    lengthManhattan(): number {
        return this.underlying.lengthManhattan();
    }
    manhattanLength(): number {
        return this.underlying.manhattanLength();
    }
    manhattanDistanceTo(v: THREE.Vector3): number {
        return this.underlying.manhattanDistanceTo(v);
    }
    normalize(): this {
        this.underlying.normalize();
        this.cb(this.underlying);
        return this;
    }
    setLength(l: number): this {
        this.underlying.setLength(l);
        this.cb(this.underlying);
        return this;
    }
    lerp(v: THREE.Vector3, alpha: number): this {
        this.underlying.lerp(v, alpha);
        this.cb(this.underlying);
        return this;
    }
    lerpVectors(v1: THREE.Vector3, v2: THREE.Vector3, alpha: number): this {
        this.underlying.lerpVectors(v1, v2, alpha);
        this.cb(this.underlying);
        return this;
    }
    cross(a: THREE.Vector3): this {
        this.underlying.cross(a);
        this.cb(this.underlying);
        return this;
    }
    crossVectors(a: THREE.Vector3, b: THREE.Vector3): this {
        this.underlying.crossVectors(a, b);
        this.cb(this.underlying);
        return this;
    }
    projectOnVector(v: THREE.Vector3): this {
        this.underlying.projectOnVector(v);
        this.cb(this.underlying);
        return this;
    }
    projectOnPlane(planeNormal: THREE.Vector3): this {
        this.underlying.projectOnPlane(planeNormal);
        this.cb(this.underlying);
        return this;
    }
    reflect(vector: THREE.Vector3): this {
        this.underlying.reflect(vector);
        this.cb(this.underlying);
        return this;
    }
    angleTo(v: THREE.Vector3): number {
        return this.underlying.angleTo(v);
    }
    distanceTo(v: THREE.Vector3): number {
        return this.underlying.distanceTo(v);
    }
    distanceToSquared(v: THREE.Vector3): number {
        return this.underlying.distanceToSquared(v);
    }
    distanceToManhattan(v: THREE.Vector3): number {
        return this.underlying.distanceToManhattan(v);
    }
    setFromSpherical(s: THREE.Spherical): this {
        this.underlying.setFromSpherical(s);
        this.cb(this.underlying);
        return this;
    }
    setFromSphericalCoords(r: number, phi: number, theta: number): this {
        this.underlying.setFromSphericalCoords(r, phi, theta);
        this.cb(this.underlying);
        return this;
    }
    setFromCylindrical(s: THREE.Cylindrical): this {
        this.underlying.setFromCylindrical(s);
        this.cb(this.underlying);
        return this;
    }
    setFromCylindricalCoords(radius: number, theta: number, y: number): this {
        this.underlying.setFromCylindricalCoords(radius, theta, y);
        this.cb(this.underlying);
        return this;
    }
    setFromMatrixPosition(m: THREE.Matrix4): this {
        this.underlying.setFromMatrixPosition(m);
        this.cb(this.underlying);
        return this;
    }
    setFromMatrixScale(m: THREE.Matrix4): this {
        this.underlying.setFromMatrixScale(m);
        this.cb(this.underlying);
        return this;
    }
    setFromMatrixColumn(matrix: THREE.Matrix4, index: number): this {
        this.underlying.setFromMatrixColumn(matrix, index);
        this.cb(this.underlying);
        return this;
    }
    setFromMatrix3Column(matrix: THREE.Matrix3, index: number): this {
        this.underlying.setFromMatrix3Column(matrix, index);
        this.cb(this.underlying);
        return this;
    }
    setFromEuler(e: THREE.Euler): this {
        this.underlying.setFromEuler(e);
        this.cb(this.underlying);
        return this;
    }
    equals(v: THREE.Vector3): boolean {
        return this.underlying.equals(v);
    }
    fromArray(array: number[] | ArrayLike<number>, offset?: number | undefined): this {
        this.underlying.fromArray(array, offset);
        this.cb(this.underlying);
        return this;
    }
    toArray(array?: number[] | undefined, offset?: number | undefined): number[];
    toArray(array?: THREE.Vector3Tuple | undefined, offset?: 0 | undefined): THREE.Vector3Tuple;
    toArray(array: ArrayLike<number>, offset?: number | undefined): ArrayLike<number>;
    toArray(array?: unknown, offset?: unknown): number[] | ArrayLike<number> | THREE.Vector3Tuple {
        return this.underlying.toArray(array as any, offset as any);
    }
    fromBufferAttribute(attribute: THREE.BufferAttribute | THREE.InterleavedBufferAttribute, index: number): this {
        this.underlying.fromBufferAttribute(attribute, index);
        this.cb(this.underlying);
        return this;
    }
    random(): this {
        this.underlying.random();
        this.cb(this.underlying);
        return this;
    }
    randomDirection(): this {
        this.underlying.randomDirection();
        this.cb(this.underlying);
        return this;
    }
}

export class QuaternionProxy implements THREE.Quaternion {
    readonly underlying = new THREE.Quaternion();
    constructor(private readonly cb: (v: THREE.Quaternion) => void) { }

    get x() { return this.underlying.x; this.cb(this.underlying); }
    set x(x: number) { this.underlying.x = x; this.cb(this.underlying); }
    get y() { return this.underlying.y; this.cb(this.underlying); }
    set y(y: number) { this.underlying.y = y; this.cb(this.underlying); }
    get z() { return this.underlying.z; this.cb(this.underlying); }
    set z(z: number) { this.underlying.z = z; this.cb(this.underlying); }
    get w() { return this.underlying.w; this.cb(this.underlying); }
    set w(w: number) { this.underlying.w = w; this.cb(this.underlying); }

    set(x: number, y: number, z: number, w: number): THREE.Quaternion {
        this.underlying.set(x, y, z, w);
        this.cb(this.underlying);
        return this.underlying;
    }
    clone(): this {
        return this.underlying.clone() as unknown as this;
    }
    copy(q: THREE.Quaternion): this {
        this.underlying.copy(q);
        this.cb(this.underlying);
        return this;
    }
    setFromEuler(euler: THREE.Euler, update?: boolean | undefined): THREE.Quaternion {
        this.underlying.setFromEuler(euler, update);
        this.cb(this.underlying);
        return this;
    }
    setFromAxisAngle(axis: THREE.Vector3, angle: number): THREE.Quaternion {
        this.underlying.setFromAxisAngle(axis, angle);
        this.cb(this.underlying);
        return this;
    }
    setFromRotationMatrix(m: THREE.Matrix4): THREE.Quaternion {
        throw new Error("Method not implemented.");
    }
    setFromUnitVectors(vFrom: THREE.Vector3, vTo: THREE.Vector3): THREE.Quaternion {
        this.underlying.setFromUnitVectors(vFrom, vTo);
        this.cb(this.underlying);
        return this;
    }
    angleTo(q: THREE.Quaternion): number {
        return this.underlying.angleTo(q);
    }
    rotateTowards(q: THREE.Quaternion, step: number): THREE.Quaternion {
        this.underlying.rotateTowards(q, step);
        this.cb(this.underlying);
        return this;
    }
    identity(): THREE.Quaternion {
        this.underlying.identity();
        this.cb(this.underlying);
        return this;
    }
    invert(): THREE.Quaternion {
        this.underlying.invert();
        this.cb(this.underlying);
        return this;
    }
    conjugate(): THREE.Quaternion {
        this.underlying.conjugate();
        this.cb(this.underlying);
        return this;
    }
    dot(v: THREE.Quaternion): number {
        return this.underlying.dot(v);
    }
    lengthSq(): number {
        return this.underlying.lengthSq();
    }
    length(): number {
        return this.underlying.length();
    }
    normalize(): THREE.Quaternion {
        this.underlying.normalize();
        this.cb(this.underlying);
        return this;
    }
    multiply(q: THREE.Quaternion): THREE.Quaternion {
        this.underlying.multiply(q);
        this.cb(this.underlying);
        return this;
    }
    premultiply(q: THREE.Quaternion): THREE.Quaternion {
        this.underlying.premultiply(q);
        this.cb(this.underlying);
        return this;
    }
    multiplyQuaternions(a: THREE.Quaternion, b: THREE.Quaternion): THREE.Quaternion {
        this.underlying.multiplyQuaternions(a, b);
        this.cb(this.underlying);
        return this;
    }
    slerp(qb: THREE.Quaternion, t: number): THREE.Quaternion {
        this.underlying.slerp(qb, t);
        this.cb(this.underlying);
        return this;
    }
    slerpQuaternions(qa: THREE.Quaternion, qb: THREE.Quaternion, t: number): THREE.Quaternion {
        this.underlying.slerpQuaternions(qa, qb, t);
        this.cb(this.underlying);
        return this;
    }
    equals(v: THREE.Quaternion): boolean {
        return this.underlying.equals(v);
    }
    fromArray(array: number[] | ArrayLike<number>, offset?: number | undefined): this {
        this.underlying.fromArray(array, offset);
        this.cb(this.underlying);
        return this;
    }
    toArray(array?: number[] | undefined, offset?: number | undefined): number[];
    toArray(array: ArrayLike<number>, offset?: number | undefined): ArrayLike<number>;
    toArray(array?: unknown, offset?: unknown): number[] | ArrayLike<number> {
        return this.underlying.toArray(array as number[], offset as number);
    }
    _onChange(callback: () => void): THREE.Quaternion {
        throw new Error("Method not implemented.");
    }
    _onChangeCallback() {

    }

    multiplyVector3(v: any) {
        return this.underlying.multiplyVector3(v);
    }

    random(): THREE.Quaternion {
        this.underlying.random();
        this.cb(this.underlying);
        return this.underlying;
    }
    isQuaternion: true = true;


    [Symbol.iterator](): Generator<number, void, unknown> {
        return this.underlying[Symbol.iterator]();
    }
}