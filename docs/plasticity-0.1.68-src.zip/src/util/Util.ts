import * as THREE from "three";
import { DisposableLike } from "event-kit";
import { X, Y, Z, origin } from "./Constants";

// https://www.typescriptlang.org/docs/handbook/mixins.html
export type Constructor = new (...args: any[]) => {};
export type GConstructor<T = {}> = new (...args: any[]) => T;
export type AGConstructor<T = {}> = abstract new (...args: any[]) => T;

export type CreateMutable<Type> = {
    -readonly [Property in keyof Type]: Type[Property];
};

export function assertUnreachable(_x: never): never {
    console.error(_x);
    throw new Error("Didn't expect to get here", _x);
}

export class RefCounter<T> {
    private readonly counts: Map<T, readonly [number, ReadonlySet<Redisposable>]>;

    constructor(from?: RefCounter<T>) {
        if (from) {
            this.counts = new Map(from.counts);
        } else {
            this.counts = new Map<T, [number, Set<Redisposable>]>();
        }
    }

    keys() { return this.counts.keys() }

    has(item: T): boolean {
        return this.counts.has(item);
    }

    incr(item: T, disposable: Redisposable): void {
        if (this.counts.has(item)) {
            const value = this.counts.get(item);
            if (!value) throw new Error("invalid key");

            const [count, disposables] = value;
            const copy = new Set(disposables);
            copy.add(disposable);
            this.counts.set(item, [count + 1, copy])
        } else {
            this.counts.set(item, [1, new Set([disposable])]);
        }
    }

    decr(item: T): void {
        const value = this.counts.get(item);
        if (!value) throw new Error("invalid key");

        const [count, disposable] = value;
        if (count === 1) {
            this.delete(item);
        } else {
            this.counts.set(item, [count - 1, disposable])
        }
    }

    delete(item: T): void {
        const value = this.counts.get(item);
        if (value === undefined) return;
        this.counts.delete(item);

        const [, disposables] = value;
        for (const disposable of disposables) disposable.dispose();
    }

    clear(): void {
        this.counts.clear();
    }
}

export class Redisposable implements DisposableLike {
    constructor(private readonly d: () => void) { }
    dispose() { this.d() }
}

export function CircleGeometry(radius: number, segmentsPerCircle: number, arc = 1.0): Float32Array {
    const segments = Math.floor(segmentsPerCircle * arc);
    const vertices = new Float32Array((segments + 1) * 3);
    for (let i = 0; i <= segments; i++) {
        const theta = (i / segmentsPerCircle) * Math.PI * 2;
        vertices[i * 3] = Math.cos(theta) * radius;
        vertices[i * 3 + 1] = Math.sin(theta) * radius;
        vertices[i * 3 + 2] = 0;
    }
    return vertices;
}

export const zip = <T, S>(a: Array<T>, b: Array<S>): [T | undefined, S | undefined][] => {
    return Array.from(Array(Math.max(b.length, a.length)), (_, i) => [a[i], b[i]]);
}

export class AtomicRef<T> {
    private clock = 0;
    private value: T;

    constructor(value: T) {
        this.value = value;
    }

    set(value: T) {
        const before = this.value;
        this.value = value;
        return { clock: ++this.clock, before };
    }

    get() {
        return { clock: this.clock, value: this.value };
    }

    compareAndSet(clock: number, value: T): number | undefined {
        if (this.clock === clock) {
            this.set(value);
            return this.clock;
        } else return undefined;
    }

    eq(clock: number) {
        return this.clock === clock;
    }

    gt(clock: number) {
        return this.clock > clock;
    }
}

export function computeCentroid(objects: THREE.Object3D[], into = new THREE.Vector3) {
    const bbox = new THREE.Box3();
    for (const object of objects) bbox.expandByObject(object);
    const centroid = bbox.getCenter(into);
    return centroid;
}

export function computeBoxCentroid(boxes: THREE.Box3[], into = new THREE.Vector3) {
    const bbox = new THREE.Box3();
    for (const box of boxes) bbox.union(box);
    const centroid = bbox.getCenter(into);
    return centroid;
}

export function findOrthogonal(vector: THREE.Vector3, into = new THREE.Vector3()): THREE.Vector3 {
    into.crossVectors(vector, X);
    if (into.manhattanLength() === 0) {
        into.crossVectors(vector, Y);
    }
    return into;
}

const anorm = new THREE.Vector3();
const bnorm = new THREE.Vector3();
export function isParallel(a: THREE.Vector3, b: THREE.Vector3) {
    anorm.copy(a).normalize();
    bnorm.copy(b).normalize();
    return anorm.dot(bnorm) > 1 - 10e-6;
}

export function later(delay: number) {
    return new Promise(function (resolve) {
        setTimeout(resolve, delay);
    });
}



const __lookAtMat = new THREE.Matrix4();
export function lookAt(normal: THREE.Vector3) {
    let orientation;
    if (Math.abs(1 - normal.dot(Z)) < 1e-6) { // Avoid numerical precision issues
        orientation = new THREE.Quaternion();
    } else if (Math.abs(1 + normal.dot(Z)) < 1e-6) {
        orientation = new THREE.Quaternion(-1, 0, 0, 0);
    } else {
        __lookAtMat.lookAt(normal, origin, Z);
        orientation = new THREE.Quaternion().setFromRotationMatrix(__lookAtMat).normalize();
    }
    return orientation;
}

export function indexOfSorted(arr: Int32Array, x: number) {
    let start = 0, end = arr.length - 1;

    while (start <= end) {
        const mid = Math.floor((start + end) / 2);
        if (arr[mid] === x) return mid;
        else if (arr[mid] < x)
            start = mid + 1;
        else
            end = mid - 1;
    }
    return -1;
}

export function indexOfIndexed(arr: Int32Array, index: Int32Array, x: number) {
    let start = 0, end = arr.length - 1;

    while (start <= end) {
        const mid = Math.floor((start + end) / 2);
        if (arr[index[mid]] === x) return index[mid];
        else if (arr[index[mid]] < x)
            start = mid + 1;
        else
            end = mid - 1;
    }
    return -1;
}